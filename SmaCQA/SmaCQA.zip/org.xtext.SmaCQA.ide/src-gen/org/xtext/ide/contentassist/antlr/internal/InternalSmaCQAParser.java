package org.xtext.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.services.SmaCQAGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSmaCQAParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_EOLINE", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'yes'", "'no'", "'Number'", "'Text'", "'TrueOrFalse'", "'minutes'", "'days'", "'weeks'", "'years'", "'ether'", "'wei'", "'pwei'", "'gwei'", "'szabo'", "'================= Value Exchange ======================= \\r\\nThe exchange of value in which'", "'sends/grants'", "'the following object of value'", "'has the following associated questions and answers: '", "'================= Completion of the question process for this value exchange ================='", "'--------- 1.Data Questions: -----------'", "'--------- 2.Legal Questions: -----------'", "'--------- 3.Economy Questions: -----------'", "'answer = '", "'Data Declaration: '", "'End Data Declaration'", "'Data name: '", "'Value: '", "'Data Declaration Token ERC20: '", "'Token ERC20 name: '", "'Token ERC20 Symbol: '", "'Token ERC20 decimals: '", "'Token ERC20 supply: '", "'1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?'", "'1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?'", "'End Data Declaration Token ERC20'", "'Data Declaration Token ERC223: '", "'Token ERC223 name: '", "'Token ERC223 Symbol: '", "'Token ERC223 decimals: '", "'Token ERC223 supply: '", "'End Data Declaration Token ERC223'", "'Data Declaration Non Fungible Token ERC721: '", "'Token ERC721 name: '", "'Token ERC721 Symbol: '", "'1.5.1 If it\\'s possible to mint more than one NFT at a time?'", "'1.5.2 Is it possible to remove/disable the token from circulation (burn token)?'", "'1.5.3 What is the price of this token?'", "'1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?'", "'End Data Declaration Token ERC721'", "'1.5.5 Which data or properties are requiered for the NFT information?'", "'1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?'", "'total supply = '", "'unitTime = '", "'1.5 Is the object of value a right that can be reflected as active or inactive?'", "'1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?'", "'1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?'", "'1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)'", "'1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)'", "'1.3 Can the value exchange be repeated over time?'", "'1.4 Are the same conditions always maintained when exchanging value?'", "'2.1  What would be the minimum legal age if necessary in this exchange?'", "'2.2 What is the name of the tax?'", "'2.2.1 Who collects the tax?'", "'3.1 Which would be the minimum amount if necessary in this exchange?'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int RULE_EOLINE=4;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=7;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSmaCQAParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSmaCQAParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSmaCQAParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSmaCQA.g"; }


    	private SmaCQAGrammarAccess grammarAccess;

    	public void setGrammarAccess(SmaCQAGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalSmaCQA.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalSmaCQA.g:54:1: ( ruleModel EOF )
            // InternalSmaCQA.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalSmaCQA.g:62:1: ruleModel : ( ( ( rule__Model__ValueExchangesAssignment ) ) ( ( rule__Model__ValueExchangesAssignment )* ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:66:2: ( ( ( ( rule__Model__ValueExchangesAssignment ) ) ( ( rule__Model__ValueExchangesAssignment )* ) ) )
            // InternalSmaCQA.g:67:2: ( ( ( rule__Model__ValueExchangesAssignment ) ) ( ( rule__Model__ValueExchangesAssignment )* ) )
            {
            // InternalSmaCQA.g:67:2: ( ( ( rule__Model__ValueExchangesAssignment ) ) ( ( rule__Model__ValueExchangesAssignment )* ) )
            // InternalSmaCQA.g:68:3: ( ( rule__Model__ValueExchangesAssignment ) ) ( ( rule__Model__ValueExchangesAssignment )* )
            {
            // InternalSmaCQA.g:68:3: ( ( rule__Model__ValueExchangesAssignment ) )
            // InternalSmaCQA.g:69:4: ( rule__Model__ValueExchangesAssignment )
            {
             before(grammarAccess.getModelAccess().getValueExchangesAssignment()); 
            // InternalSmaCQA.g:70:4: ( rule__Model__ValueExchangesAssignment )
            // InternalSmaCQA.g:70:5: rule__Model__ValueExchangesAssignment
            {
            pushFollow(FOLLOW_3);
            rule__Model__ValueExchangesAssignment();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getValueExchangesAssignment()); 

            }

            // InternalSmaCQA.g:73:3: ( ( rule__Model__ValueExchangesAssignment )* )
            // InternalSmaCQA.g:74:4: ( rule__Model__ValueExchangesAssignment )*
            {
             before(grammarAccess.getModelAccess().getValueExchangesAssignment()); 
            // InternalSmaCQA.g:75:4: ( rule__Model__ValueExchangesAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==26) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSmaCQA.g:75:5: rule__Model__ValueExchangesAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Model__ValueExchangesAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getValueExchangesAssignment()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleValueExchange"
    // InternalSmaCQA.g:85:1: entryRuleValueExchange : ruleValueExchange EOF ;
    public final void entryRuleValueExchange() throws RecognitionException {
        try {
            // InternalSmaCQA.g:86:1: ( ruleValueExchange EOF )
            // InternalSmaCQA.g:87:1: ruleValueExchange EOF
            {
             before(grammarAccess.getValueExchangeRule()); 
            pushFollow(FOLLOW_1);
            ruleValueExchange();

            state._fsp--;

             after(grammarAccess.getValueExchangeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleValueExchange"


    // $ANTLR start "ruleValueExchange"
    // InternalSmaCQA.g:94:1: ruleValueExchange : ( ( rule__ValueExchange__Group__0 ) ) ;
    public final void ruleValueExchange() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:98:2: ( ( ( rule__ValueExchange__Group__0 ) ) )
            // InternalSmaCQA.g:99:2: ( ( rule__ValueExchange__Group__0 ) )
            {
            // InternalSmaCQA.g:99:2: ( ( rule__ValueExchange__Group__0 ) )
            // InternalSmaCQA.g:100:3: ( rule__ValueExchange__Group__0 )
            {
             before(grammarAccess.getValueExchangeAccess().getGroup()); 
            // InternalSmaCQA.g:101:3: ( rule__ValueExchange__Group__0 )
            // InternalSmaCQA.g:101:4: rule__ValueExchange__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getValueExchangeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleValueExchange"


    // $ANTLR start "entryRuleDataQuestion"
    // InternalSmaCQA.g:110:1: entryRuleDataQuestion : ruleDataQuestion EOF ;
    public final void entryRuleDataQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:111:1: ( ruleDataQuestion EOF )
            // InternalSmaCQA.g:112:1: ruleDataQuestion EOF
            {
             before(grammarAccess.getDataQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleDataQuestion();

            state._fsp--;

             after(grammarAccess.getDataQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataQuestion"


    // $ANTLR start "ruleDataQuestion"
    // InternalSmaCQA.g:119:1: ruleDataQuestion : ( ( rule__DataQuestion__Group__0 ) ) ;
    public final void ruleDataQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:123:2: ( ( ( rule__DataQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:124:2: ( ( rule__DataQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:124:2: ( ( rule__DataQuestion__Group__0 ) )
            // InternalSmaCQA.g:125:3: ( rule__DataQuestion__Group__0 )
            {
             before(grammarAccess.getDataQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:126:3: ( rule__DataQuestion__Group__0 )
            // InternalSmaCQA.g:126:4: rule__DataQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DataQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDataQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataQuestion"


    // $ANTLR start "entryRuleValueObjectQuestion"
    // InternalSmaCQA.g:135:1: entryRuleValueObjectQuestion : ruleValueObjectQuestion EOF ;
    public final void entryRuleValueObjectQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:136:1: ( ruleValueObjectQuestion EOF )
            // InternalSmaCQA.g:137:1: ruleValueObjectQuestion EOF
            {
             before(grammarAccess.getValueObjectQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleValueObjectQuestion();

            state._fsp--;

             after(grammarAccess.getValueObjectQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleValueObjectQuestion"


    // $ANTLR start "ruleValueObjectQuestion"
    // InternalSmaCQA.g:144:1: ruleValueObjectQuestion : ( ( rule__ValueObjectQuestion__Alternatives ) ) ;
    public final void ruleValueObjectQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:148:2: ( ( ( rule__ValueObjectQuestion__Alternatives ) ) )
            // InternalSmaCQA.g:149:2: ( ( rule__ValueObjectQuestion__Alternatives ) )
            {
            // InternalSmaCQA.g:149:2: ( ( rule__ValueObjectQuestion__Alternatives ) )
            // InternalSmaCQA.g:150:3: ( rule__ValueObjectQuestion__Alternatives )
            {
             before(grammarAccess.getValueObjectQuestionAccess().getAlternatives()); 
            // InternalSmaCQA.g:151:3: ( rule__ValueObjectQuestion__Alternatives )
            // InternalSmaCQA.g:151:4: rule__ValueObjectQuestion__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectQuestion__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectQuestionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleValueObjectQuestion"


    // $ANTLR start "entryRuleValueObjectRightQuestion"
    // InternalSmaCQA.g:160:1: entryRuleValueObjectRightQuestion : ruleValueObjectRightQuestion EOF ;
    public final void entryRuleValueObjectRightQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:161:1: ( ruleValueObjectRightQuestion EOF )
            // InternalSmaCQA.g:162:1: ruleValueObjectRightQuestion EOF
            {
             before(grammarAccess.getValueObjectRightQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleValueObjectRightQuestion();

            state._fsp--;

             after(grammarAccess.getValueObjectRightQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleValueObjectRightQuestion"


    // $ANTLR start "ruleValueObjectRightQuestion"
    // InternalSmaCQA.g:169:1: ruleValueObjectRightQuestion : ( ( rule__ValueObjectRightQuestion__Group__0 ) ) ;
    public final void ruleValueObjectRightQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:173:2: ( ( ( rule__ValueObjectRightQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:174:2: ( ( rule__ValueObjectRightQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:174:2: ( ( rule__ValueObjectRightQuestion__Group__0 ) )
            // InternalSmaCQA.g:175:3: ( rule__ValueObjectRightQuestion__Group__0 )
            {
             before(grammarAccess.getValueObjectRightQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:176:3: ( rule__ValueObjectRightQuestion__Group__0 )
            // InternalSmaCQA.g:176:4: rule__ValueObjectRightQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectRightQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectRightQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleValueObjectRightQuestion"


    // $ANTLR start "entryRuleValueObjectTokenQuestion"
    // InternalSmaCQA.g:185:1: entryRuleValueObjectTokenQuestion : ruleValueObjectTokenQuestion EOF ;
    public final void entryRuleValueObjectTokenQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:186:1: ( ruleValueObjectTokenQuestion EOF )
            // InternalSmaCQA.g:187:1: ruleValueObjectTokenQuestion EOF
            {
             before(grammarAccess.getValueObjectTokenQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleValueObjectTokenQuestion();

            state._fsp--;

             after(grammarAccess.getValueObjectTokenQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleValueObjectTokenQuestion"


    // $ANTLR start "ruleValueObjectTokenQuestion"
    // InternalSmaCQA.g:194:1: ruleValueObjectTokenQuestion : ( ( rule__ValueObjectTokenQuestion__Group__0 ) ) ;
    public final void ruleValueObjectTokenQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:198:2: ( ( ( rule__ValueObjectTokenQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:199:2: ( ( rule__ValueObjectTokenQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:199:2: ( ( rule__ValueObjectTokenQuestion__Group__0 ) )
            // InternalSmaCQA.g:200:3: ( rule__ValueObjectTokenQuestion__Group__0 )
            {
             before(grammarAccess.getValueObjectTokenQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:201:3: ( rule__ValueObjectTokenQuestion__Group__0 )
            // InternalSmaCQA.g:201:4: rule__ValueObjectTokenQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectTokenQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectTokenQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleValueObjectTokenQuestion"


    // $ANTLR start "entryRuleValueObjectTangibleQuestion"
    // InternalSmaCQA.g:210:1: entryRuleValueObjectTangibleQuestion : ruleValueObjectTangibleQuestion EOF ;
    public final void entryRuleValueObjectTangibleQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:211:1: ( ruleValueObjectTangibleQuestion EOF )
            // InternalSmaCQA.g:212:1: ruleValueObjectTangibleQuestion EOF
            {
             before(grammarAccess.getValueObjectTangibleQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleValueObjectTangibleQuestion();

            state._fsp--;

             after(grammarAccess.getValueObjectTangibleQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleValueObjectTangibleQuestion"


    // $ANTLR start "ruleValueObjectTangibleQuestion"
    // InternalSmaCQA.g:219:1: ruleValueObjectTangibleQuestion : ( ( rule__ValueObjectTangibleQuestion__Group__0 ) ) ;
    public final void ruleValueObjectTangibleQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:223:2: ( ( ( rule__ValueObjectTangibleQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:224:2: ( ( rule__ValueObjectTangibleQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:224:2: ( ( rule__ValueObjectTangibleQuestion__Group__0 ) )
            // InternalSmaCQA.g:225:3: ( rule__ValueObjectTangibleQuestion__Group__0 )
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:226:3: ( rule__ValueObjectTangibleQuestion__Group__0 )
            // InternalSmaCQA.g:226:4: rule__ValueObjectTangibleQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectTangibleQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectTangibleQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleValueObjectTangibleQuestion"


    // $ANTLR start "entryRuleDataRegister"
    // InternalSmaCQA.g:235:1: entryRuleDataRegister : ruleDataRegister EOF ;
    public final void entryRuleDataRegister() throws RecognitionException {
        try {
            // InternalSmaCQA.g:236:1: ( ruleDataRegister EOF )
            // InternalSmaCQA.g:237:1: ruleDataRegister EOF
            {
             before(grammarAccess.getDataRegisterRule()); 
            pushFollow(FOLLOW_1);
            ruleDataRegister();

            state._fsp--;

             after(grammarAccess.getDataRegisterRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataRegister"


    // $ANTLR start "ruleDataRegister"
    // InternalSmaCQA.g:244:1: ruleDataRegister : ( ( rule__DataRegister__Group__0 ) ) ;
    public final void ruleDataRegister() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:248:2: ( ( ( rule__DataRegister__Group__0 ) ) )
            // InternalSmaCQA.g:249:2: ( ( rule__DataRegister__Group__0 ) )
            {
            // InternalSmaCQA.g:249:2: ( ( rule__DataRegister__Group__0 ) )
            // InternalSmaCQA.g:250:3: ( rule__DataRegister__Group__0 )
            {
             before(grammarAccess.getDataRegisterAccess().getGroup()); 
            // InternalSmaCQA.g:251:3: ( rule__DataRegister__Group__0 )
            // InternalSmaCQA.g:251:4: rule__DataRegister__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__DataRegister__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDataRegisterAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataRegister"


    // $ANTLR start "entryRuleToken"
    // InternalSmaCQA.g:260:1: entryRuleToken : ruleToken EOF ;
    public final void entryRuleToken() throws RecognitionException {
        try {
            // InternalSmaCQA.g:261:1: ( ruleToken EOF )
            // InternalSmaCQA.g:262:1: ruleToken EOF
            {
             before(grammarAccess.getTokenRule()); 
            pushFollow(FOLLOW_1);
            ruleToken();

            state._fsp--;

             after(grammarAccess.getTokenRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleToken"


    // $ANTLR start "ruleToken"
    // InternalSmaCQA.g:269:1: ruleToken : ( ( rule__Token__Alternatives ) ) ;
    public final void ruleToken() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:273:2: ( ( ( rule__Token__Alternatives ) ) )
            // InternalSmaCQA.g:274:2: ( ( rule__Token__Alternatives ) )
            {
            // InternalSmaCQA.g:274:2: ( ( rule__Token__Alternatives ) )
            // InternalSmaCQA.g:275:3: ( rule__Token__Alternatives )
            {
             before(grammarAccess.getTokenAccess().getAlternatives()); 
            // InternalSmaCQA.g:276:3: ( rule__Token__Alternatives )
            // InternalSmaCQA.g:276:4: rule__Token__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Token__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTokenAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleToken"


    // $ANTLR start "entryRuleTokenERC20"
    // InternalSmaCQA.g:285:1: entryRuleTokenERC20 : ruleTokenERC20 EOF ;
    public final void entryRuleTokenERC20() throws RecognitionException {
        try {
            // InternalSmaCQA.g:286:1: ( ruleTokenERC20 EOF )
            // InternalSmaCQA.g:287:1: ruleTokenERC20 EOF
            {
             before(grammarAccess.getTokenERC20Rule()); 
            pushFollow(FOLLOW_1);
            ruleTokenERC20();

            state._fsp--;

             after(grammarAccess.getTokenERC20Rule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTokenERC20"


    // $ANTLR start "ruleTokenERC20"
    // InternalSmaCQA.g:294:1: ruleTokenERC20 : ( ( rule__TokenERC20__Group__0 ) ) ;
    public final void ruleTokenERC20() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:298:2: ( ( ( rule__TokenERC20__Group__0 ) ) )
            // InternalSmaCQA.g:299:2: ( ( rule__TokenERC20__Group__0 ) )
            {
            // InternalSmaCQA.g:299:2: ( ( rule__TokenERC20__Group__0 ) )
            // InternalSmaCQA.g:300:3: ( rule__TokenERC20__Group__0 )
            {
             before(grammarAccess.getTokenERC20Access().getGroup()); 
            // InternalSmaCQA.g:301:3: ( rule__TokenERC20__Group__0 )
            // InternalSmaCQA.g:301:4: rule__TokenERC20__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTokenERC20"


    // $ANTLR start "entryRuleTokenERC223"
    // InternalSmaCQA.g:310:1: entryRuleTokenERC223 : ruleTokenERC223 EOF ;
    public final void entryRuleTokenERC223() throws RecognitionException {
        try {
            // InternalSmaCQA.g:311:1: ( ruleTokenERC223 EOF )
            // InternalSmaCQA.g:312:1: ruleTokenERC223 EOF
            {
             before(grammarAccess.getTokenERC223Rule()); 
            pushFollow(FOLLOW_1);
            ruleTokenERC223();

            state._fsp--;

             after(grammarAccess.getTokenERC223Rule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTokenERC223"


    // $ANTLR start "ruleTokenERC223"
    // InternalSmaCQA.g:319:1: ruleTokenERC223 : ( ( rule__TokenERC223__Group__0 ) ) ;
    public final void ruleTokenERC223() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:323:2: ( ( ( rule__TokenERC223__Group__0 ) ) )
            // InternalSmaCQA.g:324:2: ( ( rule__TokenERC223__Group__0 ) )
            {
            // InternalSmaCQA.g:324:2: ( ( rule__TokenERC223__Group__0 ) )
            // InternalSmaCQA.g:325:3: ( rule__TokenERC223__Group__0 )
            {
             before(grammarAccess.getTokenERC223Access().getGroup()); 
            // InternalSmaCQA.g:326:3: ( rule__TokenERC223__Group__0 )
            // InternalSmaCQA.g:326:4: rule__TokenERC223__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTokenERC223"


    // $ANTLR start "entryRuleTokenERC721"
    // InternalSmaCQA.g:335:1: entryRuleTokenERC721 : ruleTokenERC721 EOF ;
    public final void entryRuleTokenERC721() throws RecognitionException {
        try {
            // InternalSmaCQA.g:336:1: ( ruleTokenERC721 EOF )
            // InternalSmaCQA.g:337:1: ruleTokenERC721 EOF
            {
             before(grammarAccess.getTokenERC721Rule()); 
            pushFollow(FOLLOW_1);
            ruleTokenERC721();

            state._fsp--;

             after(grammarAccess.getTokenERC721Rule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTokenERC721"


    // $ANTLR start "ruleTokenERC721"
    // InternalSmaCQA.g:344:1: ruleTokenERC721 : ( ( rule__TokenERC721__Group__0 ) ) ;
    public final void ruleTokenERC721() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:348:2: ( ( ( rule__TokenERC721__Group__0 ) ) )
            // InternalSmaCQA.g:349:2: ( ( rule__TokenERC721__Group__0 ) )
            {
            // InternalSmaCQA.g:349:2: ( ( rule__TokenERC721__Group__0 ) )
            // InternalSmaCQA.g:350:3: ( rule__TokenERC721__Group__0 )
            {
             before(grammarAccess.getTokenERC721Access().getGroup()); 
            // InternalSmaCQA.g:351:3: ( rule__TokenERC721__Group__0 )
            // InternalSmaCQA.g:351:4: rule__TokenERC721__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTokenERC721"


    // $ANTLR start "entryRuleTimeValueExchangeDurationQuestion"
    // InternalSmaCQA.g:360:1: entryRuleTimeValueExchangeDurationQuestion : ruleTimeValueExchangeDurationQuestion EOF ;
    public final void entryRuleTimeValueExchangeDurationQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:361:1: ( ruleTimeValueExchangeDurationQuestion EOF )
            // InternalSmaCQA.g:362:1: ruleTimeValueExchangeDurationQuestion EOF
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleTimeValueExchangeDurationQuestion();

            state._fsp--;

             after(grammarAccess.getTimeValueExchangeDurationQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTimeValueExchangeDurationQuestion"


    // $ANTLR start "ruleTimeValueExchangeDurationQuestion"
    // InternalSmaCQA.g:369:1: ruleTimeValueExchangeDurationQuestion : ( ( rule__TimeValueExchangeDurationQuestion__Group__0 ) ) ;
    public final void ruleTimeValueExchangeDurationQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:373:2: ( ( ( rule__TimeValueExchangeDurationQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:374:2: ( ( rule__TimeValueExchangeDurationQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:374:2: ( ( rule__TimeValueExchangeDurationQuestion__Group__0 ) )
            // InternalSmaCQA.g:375:3: ( rule__TimeValueExchangeDurationQuestion__Group__0 )
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:376:3: ( rule__TimeValueExchangeDurationQuestion__Group__0 )
            // InternalSmaCQA.g:376:4: rule__TimeValueExchangeDurationQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTimeValueExchangeDurationQuestion"


    // $ANTLR start "entryRuleTimeStartValueExchangeQuestion"
    // InternalSmaCQA.g:385:1: entryRuleTimeStartValueExchangeQuestion : ruleTimeStartValueExchangeQuestion EOF ;
    public final void entryRuleTimeStartValueExchangeQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:386:1: ( ruleTimeStartValueExchangeQuestion EOF )
            // InternalSmaCQA.g:387:1: ruleTimeStartValueExchangeQuestion EOF
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleTimeStartValueExchangeQuestion();

            state._fsp--;

             after(grammarAccess.getTimeStartValueExchangeQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTimeStartValueExchangeQuestion"


    // $ANTLR start "ruleTimeStartValueExchangeQuestion"
    // InternalSmaCQA.g:394:1: ruleTimeStartValueExchangeQuestion : ( ( rule__TimeStartValueExchangeQuestion__Group__0 ) ) ;
    public final void ruleTimeStartValueExchangeQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:398:2: ( ( ( rule__TimeStartValueExchangeQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:399:2: ( ( rule__TimeStartValueExchangeQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:399:2: ( ( rule__TimeStartValueExchangeQuestion__Group__0 ) )
            // InternalSmaCQA.g:400:3: ( rule__TimeStartValueExchangeQuestion__Group__0 )
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:401:3: ( rule__TimeStartValueExchangeQuestion__Group__0 )
            // InternalSmaCQA.g:401:4: rule__TimeStartValueExchangeQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTimeStartValueExchangeQuestion"


    // $ANTLR start "entryRuleRepeatValueExchangeQuestion"
    // InternalSmaCQA.g:410:1: entryRuleRepeatValueExchangeQuestion : ruleRepeatValueExchangeQuestion EOF ;
    public final void entryRuleRepeatValueExchangeQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:411:1: ( ruleRepeatValueExchangeQuestion EOF )
            // InternalSmaCQA.g:412:1: ruleRepeatValueExchangeQuestion EOF
            {
             before(grammarAccess.getRepeatValueExchangeQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleRepeatValueExchangeQuestion();

            state._fsp--;

             after(grammarAccess.getRepeatValueExchangeQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRepeatValueExchangeQuestion"


    // $ANTLR start "ruleRepeatValueExchangeQuestion"
    // InternalSmaCQA.g:419:1: ruleRepeatValueExchangeQuestion : ( ( rule__RepeatValueExchangeQuestion__Group__0 ) ) ;
    public final void ruleRepeatValueExchangeQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:423:2: ( ( ( rule__RepeatValueExchangeQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:424:2: ( ( rule__RepeatValueExchangeQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:424:2: ( ( rule__RepeatValueExchangeQuestion__Group__0 ) )
            // InternalSmaCQA.g:425:3: ( rule__RepeatValueExchangeQuestion__Group__0 )
            {
             before(grammarAccess.getRepeatValueExchangeQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:426:3: ( rule__RepeatValueExchangeQuestion__Group__0 )
            // InternalSmaCQA.g:426:4: rule__RepeatValueExchangeQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RepeatValueExchangeQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRepeatValueExchangeQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRepeatValueExchangeQuestion"


    // $ANTLR start "entryRuleConditionsValueExchangeQuestion"
    // InternalSmaCQA.g:435:1: entryRuleConditionsValueExchangeQuestion : ruleConditionsValueExchangeQuestion EOF ;
    public final void entryRuleConditionsValueExchangeQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:436:1: ( ruleConditionsValueExchangeQuestion EOF )
            // InternalSmaCQA.g:437:1: ruleConditionsValueExchangeQuestion EOF
            {
             before(grammarAccess.getConditionsValueExchangeQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleConditionsValueExchangeQuestion();

            state._fsp--;

             after(grammarAccess.getConditionsValueExchangeQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConditionsValueExchangeQuestion"


    // $ANTLR start "ruleConditionsValueExchangeQuestion"
    // InternalSmaCQA.g:444:1: ruleConditionsValueExchangeQuestion : ( ( rule__ConditionsValueExchangeQuestion__Group__0 ) ) ;
    public final void ruleConditionsValueExchangeQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:448:2: ( ( ( rule__ConditionsValueExchangeQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:449:2: ( ( rule__ConditionsValueExchangeQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:449:2: ( ( rule__ConditionsValueExchangeQuestion__Group__0 ) )
            // InternalSmaCQA.g:450:3: ( rule__ConditionsValueExchangeQuestion__Group__0 )
            {
             before(grammarAccess.getConditionsValueExchangeQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:451:3: ( rule__ConditionsValueExchangeQuestion__Group__0 )
            // InternalSmaCQA.g:451:4: rule__ConditionsValueExchangeQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ConditionsValueExchangeQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getConditionsValueExchangeQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConditionsValueExchangeQuestion"


    // $ANTLR start "entryRuleLegalQuestion"
    // InternalSmaCQA.g:460:1: entryRuleLegalQuestion : ruleLegalQuestion EOF ;
    public final void entryRuleLegalQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:461:1: ( ruleLegalQuestion EOF )
            // InternalSmaCQA.g:462:1: ruleLegalQuestion EOF
            {
             before(grammarAccess.getLegalQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleLegalQuestion();

            state._fsp--;

             after(grammarAccess.getLegalQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLegalQuestion"


    // $ANTLR start "ruleLegalQuestion"
    // InternalSmaCQA.g:469:1: ruleLegalQuestion : ( ( rule__LegalQuestion__Group__0 ) ) ;
    public final void ruleLegalQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:473:2: ( ( ( rule__LegalQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:474:2: ( ( rule__LegalQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:474:2: ( ( rule__LegalQuestion__Group__0 ) )
            // InternalSmaCQA.g:475:3: ( rule__LegalQuestion__Group__0 )
            {
             before(grammarAccess.getLegalQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:476:3: ( rule__LegalQuestion__Group__0 )
            // InternalSmaCQA.g:476:4: rule__LegalQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LegalQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLegalQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLegalQuestion"


    // $ANTLR start "entryRuleAgeQuestion"
    // InternalSmaCQA.g:485:1: entryRuleAgeQuestion : ruleAgeQuestion EOF ;
    public final void entryRuleAgeQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:486:1: ( ruleAgeQuestion EOF )
            // InternalSmaCQA.g:487:1: ruleAgeQuestion EOF
            {
             before(grammarAccess.getAgeQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleAgeQuestion();

            state._fsp--;

             after(grammarAccess.getAgeQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAgeQuestion"


    // $ANTLR start "ruleAgeQuestion"
    // InternalSmaCQA.g:494:1: ruleAgeQuestion : ( ( rule__AgeQuestion__Group__0 ) ) ;
    public final void ruleAgeQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:498:2: ( ( ( rule__AgeQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:499:2: ( ( rule__AgeQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:499:2: ( ( rule__AgeQuestion__Group__0 ) )
            // InternalSmaCQA.g:500:3: ( rule__AgeQuestion__Group__0 )
            {
             before(grammarAccess.getAgeQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:501:3: ( rule__AgeQuestion__Group__0 )
            // InternalSmaCQA.g:501:4: rule__AgeQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__AgeQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAgeQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAgeQuestion"


    // $ANTLR start "entryRuleTaxQuestion"
    // InternalSmaCQA.g:510:1: entryRuleTaxQuestion : ruleTaxQuestion EOF ;
    public final void entryRuleTaxQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:511:1: ( ruleTaxQuestion EOF )
            // InternalSmaCQA.g:512:1: ruleTaxQuestion EOF
            {
             before(grammarAccess.getTaxQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleTaxQuestion();

            state._fsp--;

             after(grammarAccess.getTaxQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTaxQuestion"


    // $ANTLR start "ruleTaxQuestion"
    // InternalSmaCQA.g:519:1: ruleTaxQuestion : ( ( rule__TaxQuestion__Group__0 ) ) ;
    public final void ruleTaxQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:523:2: ( ( ( rule__TaxQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:524:2: ( ( rule__TaxQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:524:2: ( ( rule__TaxQuestion__Group__0 ) )
            // InternalSmaCQA.g:525:3: ( rule__TaxQuestion__Group__0 )
            {
             before(grammarAccess.getTaxQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:526:3: ( rule__TaxQuestion__Group__0 )
            // InternalSmaCQA.g:526:4: rule__TaxQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TaxQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTaxQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTaxQuestion"


    // $ANTLR start "entryRuleEconomyQuestion"
    // InternalSmaCQA.g:535:1: entryRuleEconomyQuestion : ruleEconomyQuestion EOF ;
    public final void entryRuleEconomyQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:536:1: ( ruleEconomyQuestion EOF )
            // InternalSmaCQA.g:537:1: ruleEconomyQuestion EOF
            {
             before(grammarAccess.getEconomyQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleEconomyQuestion();

            state._fsp--;

             after(grammarAccess.getEconomyQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEconomyQuestion"


    // $ANTLR start "ruleEconomyQuestion"
    // InternalSmaCQA.g:544:1: ruleEconomyQuestion : ( ( rule__EconomyQuestion__MinimumAmountQuestionAssignment )? ) ;
    public final void ruleEconomyQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:548:2: ( ( ( rule__EconomyQuestion__MinimumAmountQuestionAssignment )? ) )
            // InternalSmaCQA.g:549:2: ( ( rule__EconomyQuestion__MinimumAmountQuestionAssignment )? )
            {
            // InternalSmaCQA.g:549:2: ( ( rule__EconomyQuestion__MinimumAmountQuestionAssignment )? )
            // InternalSmaCQA.g:550:3: ( rule__EconomyQuestion__MinimumAmountQuestionAssignment )?
            {
             before(grammarAccess.getEconomyQuestionAccess().getMinimumAmountQuestionAssignment()); 
            // InternalSmaCQA.g:551:3: ( rule__EconomyQuestion__MinimumAmountQuestionAssignment )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==75) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalSmaCQA.g:551:4: rule__EconomyQuestion__MinimumAmountQuestionAssignment
                    {
                    pushFollow(FOLLOW_2);
                    rule__EconomyQuestion__MinimumAmountQuestionAssignment();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEconomyQuestionAccess().getMinimumAmountQuestionAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEconomyQuestion"


    // $ANTLR start "entryRuleMinimumAmountQuestion"
    // InternalSmaCQA.g:560:1: entryRuleMinimumAmountQuestion : ruleMinimumAmountQuestion EOF ;
    public final void entryRuleMinimumAmountQuestion() throws RecognitionException {
        try {
            // InternalSmaCQA.g:561:1: ( ruleMinimumAmountQuestion EOF )
            // InternalSmaCQA.g:562:1: ruleMinimumAmountQuestion EOF
            {
             before(grammarAccess.getMinimumAmountQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleMinimumAmountQuestion();

            state._fsp--;

             after(grammarAccess.getMinimumAmountQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMinimumAmountQuestion"


    // $ANTLR start "ruleMinimumAmountQuestion"
    // InternalSmaCQA.g:569:1: ruleMinimumAmountQuestion : ( ( rule__MinimumAmountQuestion__Group__0 ) ) ;
    public final void ruleMinimumAmountQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:573:2: ( ( ( rule__MinimumAmountQuestion__Group__0 ) ) )
            // InternalSmaCQA.g:574:2: ( ( rule__MinimumAmountQuestion__Group__0 ) )
            {
            // InternalSmaCQA.g:574:2: ( ( rule__MinimumAmountQuestion__Group__0 ) )
            // InternalSmaCQA.g:575:3: ( rule__MinimumAmountQuestion__Group__0 )
            {
             before(grammarAccess.getMinimumAmountQuestionAccess().getGroup()); 
            // InternalSmaCQA.g:576:3: ( rule__MinimumAmountQuestion__Group__0 )
            // InternalSmaCQA.g:576:4: rule__MinimumAmountQuestion__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__MinimumAmountQuestion__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMinimumAmountQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMinimumAmountQuestion"


    // $ANTLR start "ruleType"
    // InternalSmaCQA.g:585:1: ruleType : ( ( rule__Type__Alternatives ) ) ;
    public final void ruleType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:589:1: ( ( ( rule__Type__Alternatives ) ) )
            // InternalSmaCQA.g:590:2: ( ( rule__Type__Alternatives ) )
            {
            // InternalSmaCQA.g:590:2: ( ( rule__Type__Alternatives ) )
            // InternalSmaCQA.g:591:3: ( rule__Type__Alternatives )
            {
             before(grammarAccess.getTypeAccess().getAlternatives()); 
            // InternalSmaCQA.g:592:3: ( rule__Type__Alternatives )
            // InternalSmaCQA.g:592:4: rule__Type__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Type__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "ruleUnitTime"
    // InternalSmaCQA.g:601:1: ruleUnitTime : ( ( rule__UnitTime__Alternatives ) ) ;
    public final void ruleUnitTime() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:605:1: ( ( ( rule__UnitTime__Alternatives ) ) )
            // InternalSmaCQA.g:606:2: ( ( rule__UnitTime__Alternatives ) )
            {
            // InternalSmaCQA.g:606:2: ( ( rule__UnitTime__Alternatives ) )
            // InternalSmaCQA.g:607:3: ( rule__UnitTime__Alternatives )
            {
             before(grammarAccess.getUnitTimeAccess().getAlternatives()); 
            // InternalSmaCQA.g:608:3: ( rule__UnitTime__Alternatives )
            // InternalSmaCQA.g:608:4: rule__UnitTime__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__UnitTime__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getUnitTimeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUnitTime"


    // $ANTLR start "ruleUnitCoin"
    // InternalSmaCQA.g:617:1: ruleUnitCoin : ( ( rule__UnitCoin__Alternatives ) ) ;
    public final void ruleUnitCoin() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:621:1: ( ( ( rule__UnitCoin__Alternatives ) ) )
            // InternalSmaCQA.g:622:2: ( ( rule__UnitCoin__Alternatives ) )
            {
            // InternalSmaCQA.g:622:2: ( ( rule__UnitCoin__Alternatives ) )
            // InternalSmaCQA.g:623:3: ( rule__UnitCoin__Alternatives )
            {
             before(grammarAccess.getUnitCoinAccess().getAlternatives()); 
            // InternalSmaCQA.g:624:3: ( rule__UnitCoin__Alternatives )
            // InternalSmaCQA.g:624:4: rule__UnitCoin__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__UnitCoin__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getUnitCoinAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUnitCoin"


    // $ANTLR start "rule__ValueObjectQuestion__Alternatives"
    // InternalSmaCQA.g:632:1: rule__ValueObjectQuestion__Alternatives : ( ( ruleValueObjectTokenQuestion ) | ( ruleValueObjectRightQuestion ) | ( ruleValueObjectTangibleQuestion ) );
    public final void rule__ValueObjectQuestion__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:636:1: ( ( ruleValueObjectTokenQuestion ) | ( ruleValueObjectRightQuestion ) | ( ruleValueObjectTangibleQuestion ) )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 66:
                {
                alt3=1;
                }
                break;
            case 65:
                {
                alt3=2;
                }
                break;
            case 67:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalSmaCQA.g:637:2: ( ruleValueObjectTokenQuestion )
                    {
                    // InternalSmaCQA.g:637:2: ( ruleValueObjectTokenQuestion )
                    // InternalSmaCQA.g:638:3: ruleValueObjectTokenQuestion
                    {
                     before(grammarAccess.getValueObjectQuestionAccess().getValueObjectTokenQuestionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleValueObjectTokenQuestion();

                    state._fsp--;

                     after(grammarAccess.getValueObjectQuestionAccess().getValueObjectTokenQuestionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:643:2: ( ruleValueObjectRightQuestion )
                    {
                    // InternalSmaCQA.g:643:2: ( ruleValueObjectRightQuestion )
                    // InternalSmaCQA.g:644:3: ruleValueObjectRightQuestion
                    {
                     before(grammarAccess.getValueObjectQuestionAccess().getValueObjectRightQuestionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleValueObjectRightQuestion();

                    state._fsp--;

                     after(grammarAccess.getValueObjectQuestionAccess().getValueObjectRightQuestionParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:649:2: ( ruleValueObjectTangibleQuestion )
                    {
                    // InternalSmaCQA.g:649:2: ( ruleValueObjectTangibleQuestion )
                    // InternalSmaCQA.g:650:3: ruleValueObjectTangibleQuestion
                    {
                     before(grammarAccess.getValueObjectQuestionAccess().getValueObjectTangibleQuestionParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleValueObjectTangibleQuestion();

                    state._fsp--;

                     after(grammarAccess.getValueObjectQuestionAccess().getValueObjectTangibleQuestionParserRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectQuestion__Alternatives"


    // $ANTLR start "rule__ValueObjectRightQuestion__AnswerAlternatives_2_0"
    // InternalSmaCQA.g:659:1: rule__ValueObjectRightQuestion__AnswerAlternatives_2_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__ValueObjectRightQuestion__AnswerAlternatives_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:663:1: ( ( 'yes' ) | ( 'no' ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==12) ) {
                alt4=1;
            }
            else if ( (LA4_0==13) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalSmaCQA.g:664:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:664:2: ( 'yes' )
                    // InternalSmaCQA.g:665:3: 'yes'
                    {
                     before(grammarAccess.getValueObjectRightQuestionAccess().getAnswerYesKeyword_2_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getValueObjectRightQuestionAccess().getAnswerYesKeyword_2_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:670:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:670:2: ( 'no' )
                    // InternalSmaCQA.g:671:3: 'no'
                    {
                     before(grammarAccess.getValueObjectRightQuestionAccess().getAnswerNoKeyword_2_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getValueObjectRightQuestionAccess().getAnswerNoKeyword_2_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__AnswerAlternatives_2_0"


    // $ANTLR start "rule__Token__Alternatives"
    // InternalSmaCQA.g:680:1: rule__Token__Alternatives : ( ( ruleTokenERC20 ) | ( ruleTokenERC223 ) | ( ruleTokenERC721 ) );
    public final void rule__Token__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:684:1: ( ( ruleTokenERC20 ) | ( ruleTokenERC223 ) | ( ruleTokenERC721 ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 39:
                {
                alt5=1;
                }
                break;
            case 47:
                {
                alt5=2;
                }
                break;
            case 53:
                {
                alt5=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalSmaCQA.g:685:2: ( ruleTokenERC20 )
                    {
                    // InternalSmaCQA.g:685:2: ( ruleTokenERC20 )
                    // InternalSmaCQA.g:686:3: ruleTokenERC20
                    {
                     before(grammarAccess.getTokenAccess().getTokenERC20ParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleTokenERC20();

                    state._fsp--;

                     after(grammarAccess.getTokenAccess().getTokenERC20ParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:691:2: ( ruleTokenERC223 )
                    {
                    // InternalSmaCQA.g:691:2: ( ruleTokenERC223 )
                    // InternalSmaCQA.g:692:3: ruleTokenERC223
                    {
                     before(grammarAccess.getTokenAccess().getTokenERC223ParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleTokenERC223();

                    state._fsp--;

                     after(grammarAccess.getTokenAccess().getTokenERC223ParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:697:2: ( ruleTokenERC721 )
                    {
                    // InternalSmaCQA.g:697:2: ( ruleTokenERC721 )
                    // InternalSmaCQA.g:698:3: ruleTokenERC721
                    {
                     before(grammarAccess.getTokenAccess().getTokenERC721ParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleTokenERC721();

                    state._fsp--;

                     after(grammarAccess.getTokenAccess().getTokenERC721ParserRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Token__Alternatives"


    // $ANTLR start "rule__TokenERC20__AnswerMintSentenceAlternatives_11_0"
    // InternalSmaCQA.g:707:1: rule__TokenERC20__AnswerMintSentenceAlternatives_11_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__TokenERC20__AnswerMintSentenceAlternatives_11_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:711:1: ( ( 'yes' ) | ( 'no' ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==12) ) {
                alt6=1;
            }
            else if ( (LA6_0==13) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalSmaCQA.g:712:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:712:2: ( 'yes' )
                    // InternalSmaCQA.g:713:3: 'yes'
                    {
                     before(grammarAccess.getTokenERC20Access().getAnswerMintSentenceYesKeyword_11_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getTokenERC20Access().getAnswerMintSentenceYesKeyword_11_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:718:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:718:2: ( 'no' )
                    // InternalSmaCQA.g:719:3: 'no'
                    {
                     before(grammarAccess.getTokenERC20Access().getAnswerMintSentenceNoKeyword_11_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getTokenERC20Access().getAnswerMintSentenceNoKeyword_11_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__AnswerMintSentenceAlternatives_11_0"


    // $ANTLR start "rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0"
    // InternalSmaCQA.g:728:1: rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:732:1: ( ( 'yes' ) | ( 'no' ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==12) ) {
                alt7=1;
            }
            else if ( (LA7_0==13) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalSmaCQA.g:733:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:733:2: ( 'yes' )
                    // InternalSmaCQA.g:734:3: 'yes'
                    {
                     before(grammarAccess.getTokenERC20Access().getAnswerBurnSentenceYesKeyword_14_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getTokenERC20Access().getAnswerBurnSentenceYesKeyword_14_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:739:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:739:2: ( 'no' )
                    // InternalSmaCQA.g:740:3: 'no'
                    {
                     before(grammarAccess.getTokenERC20Access().getAnswerBurnSentenceNoKeyword_14_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getTokenERC20Access().getAnswerBurnSentenceNoKeyword_14_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0"


    // $ANTLR start "rule__TokenERC223__AnswerMintSentenceAlternatives_11_0"
    // InternalSmaCQA.g:749:1: rule__TokenERC223__AnswerMintSentenceAlternatives_11_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__TokenERC223__AnswerMintSentenceAlternatives_11_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:753:1: ( ( 'yes' ) | ( 'no' ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==12) ) {
                alt8=1;
            }
            else if ( (LA8_0==13) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalSmaCQA.g:754:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:754:2: ( 'yes' )
                    // InternalSmaCQA.g:755:3: 'yes'
                    {
                     before(grammarAccess.getTokenERC223Access().getAnswerMintSentenceYesKeyword_11_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getTokenERC223Access().getAnswerMintSentenceYesKeyword_11_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:760:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:760:2: ( 'no' )
                    // InternalSmaCQA.g:761:3: 'no'
                    {
                     before(grammarAccess.getTokenERC223Access().getAnswerMintSentenceNoKeyword_11_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getTokenERC223Access().getAnswerMintSentenceNoKeyword_11_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__AnswerMintSentenceAlternatives_11_0"


    // $ANTLR start "rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0"
    // InternalSmaCQA.g:770:1: rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:774:1: ( ( 'yes' ) | ( 'no' ) )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==12) ) {
                alt9=1;
            }
            else if ( (LA9_0==13) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalSmaCQA.g:775:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:775:2: ( 'yes' )
                    // InternalSmaCQA.g:776:3: 'yes'
                    {
                     before(grammarAccess.getTokenERC223Access().getAnswerBurnSentenceYesKeyword_14_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getTokenERC223Access().getAnswerBurnSentenceYesKeyword_14_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:781:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:781:2: ( 'no' )
                    // InternalSmaCQA.g:782:3: 'no'
                    {
                     before(grammarAccess.getTokenERC223Access().getAnswerBurnSentenceNoKeyword_14_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getTokenERC223Access().getAnswerBurnSentenceNoKeyword_14_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0"


    // $ANTLR start "rule__TokenERC721__AnswerMintSentenceAlternatives_7_0"
    // InternalSmaCQA.g:791:1: rule__TokenERC721__AnswerMintSentenceAlternatives_7_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__TokenERC721__AnswerMintSentenceAlternatives_7_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:795:1: ( ( 'yes' ) | ( 'no' ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==12) ) {
                alt10=1;
            }
            else if ( (LA10_0==13) ) {
                alt10=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalSmaCQA.g:796:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:796:2: ( 'yes' )
                    // InternalSmaCQA.g:797:3: 'yes'
                    {
                     before(grammarAccess.getTokenERC721Access().getAnswerMintSentenceYesKeyword_7_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getTokenERC721Access().getAnswerMintSentenceYesKeyword_7_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:802:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:802:2: ( 'no' )
                    // InternalSmaCQA.g:803:3: 'no'
                    {
                     before(grammarAccess.getTokenERC721Access().getAnswerMintSentenceNoKeyword_7_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getTokenERC721Access().getAnswerMintSentenceNoKeyword_7_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerMintSentenceAlternatives_7_0"


    // $ANTLR start "rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0"
    // InternalSmaCQA.g:812:1: rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:816:1: ( ( 'yes' ) | ( 'no' ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==12) ) {
                alt11=1;
            }
            else if ( (LA11_0==13) ) {
                alt11=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalSmaCQA.g:817:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:817:2: ( 'yes' )
                    // InternalSmaCQA.g:818:3: 'yes'
                    {
                     before(grammarAccess.getTokenERC721Access().getAnswerBurnSentenceYesKeyword_10_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getTokenERC721Access().getAnswerBurnSentenceYesKeyword_10_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:823:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:823:2: ( 'no' )
                    // InternalSmaCQA.g:824:3: 'no'
                    {
                     before(grammarAccess.getTokenERC721Access().getAnswerBurnSentenceNoKeyword_10_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getTokenERC721Access().getAnswerBurnSentenceNoKeyword_10_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0"


    // $ANTLR start "rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0"
    // InternalSmaCQA.g:833:1: rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:837:1: ( ( 'yes' ) | ( 'no' ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==12) ) {
                alt12=1;
            }
            else if ( (LA12_0==13) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalSmaCQA.g:838:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:838:2: ( 'yes' )
                    // InternalSmaCQA.g:839:3: 'yes'
                    {
                     before(grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceYesKeyword_17_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceYesKeyword_17_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:844:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:844:2: ( 'no' )
                    // InternalSmaCQA.g:845:3: 'no'
                    {
                     before(grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceNoKeyword_17_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceNoKeyword_17_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0"
    // InternalSmaCQA.g:854:1: rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:858:1: ( ( 'yes' ) | ( 'no' ) )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==12) ) {
                alt13=1;
            }
            else if ( (LA13_0==13) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalSmaCQA.g:859:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:859:2: ( 'yes' )
                    // InternalSmaCQA.g:860:3: 'yes'
                    {
                     before(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerYesKeyword_2_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerYesKeyword_2_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:865:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:865:2: ( 'no' )
                    // InternalSmaCQA.g:866:3: 'no'
                    {
                     before(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerNoKeyword_2_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerNoKeyword_2_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0"
    // InternalSmaCQA.g:875:1: rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0 : ( ( 'yes' ) | ( 'no' ) );
    public final void rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:879:1: ( ( 'yes' ) | ( 'no' ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==12) ) {
                alt14=1;
            }
            else if ( (LA14_0==13) ) {
                alt14=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // InternalSmaCQA.g:880:2: ( 'yes' )
                    {
                    // InternalSmaCQA.g:880:2: ( 'yes' )
                    // InternalSmaCQA.g:881:3: 'yes'
                    {
                     before(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerYesKeyword_2_0_0()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerYesKeyword_2_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:886:2: ( 'no' )
                    {
                    // InternalSmaCQA.g:886:2: ( 'no' )
                    // InternalSmaCQA.g:887:3: 'no'
                    {
                     before(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerNoKeyword_2_0_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerNoKeyword_2_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0"


    // $ANTLR start "rule__Type__Alternatives"
    // InternalSmaCQA.g:896:1: rule__Type__Alternatives : ( ( ( 'Number' ) ) | ( ( 'Text' ) ) | ( ( 'TrueOrFalse' ) ) );
    public final void rule__Type__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:900:1: ( ( ( 'Number' ) ) | ( ( 'Text' ) ) | ( ( 'TrueOrFalse' ) ) )
            int alt15=3;
            switch ( input.LA(1) ) {
            case 14:
                {
                alt15=1;
                }
                break;
            case 15:
                {
                alt15=2;
                }
                break;
            case 16:
                {
                alt15=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalSmaCQA.g:901:2: ( ( 'Number' ) )
                    {
                    // InternalSmaCQA.g:901:2: ( ( 'Number' ) )
                    // InternalSmaCQA.g:902:3: ( 'Number' )
                    {
                     before(grammarAccess.getTypeAccess().getNumberEnumLiteralDeclaration_0()); 
                    // InternalSmaCQA.g:903:3: ( 'Number' )
                    // InternalSmaCQA.g:903:4: 'Number'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypeAccess().getNumberEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:907:2: ( ( 'Text' ) )
                    {
                    // InternalSmaCQA.g:907:2: ( ( 'Text' ) )
                    // InternalSmaCQA.g:908:3: ( 'Text' )
                    {
                     before(grammarAccess.getTypeAccess().getTextEnumLiteralDeclaration_1()); 
                    // InternalSmaCQA.g:909:3: ( 'Text' )
                    // InternalSmaCQA.g:909:4: 'Text'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypeAccess().getTextEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:913:2: ( ( 'TrueOrFalse' ) )
                    {
                    // InternalSmaCQA.g:913:2: ( ( 'TrueOrFalse' ) )
                    // InternalSmaCQA.g:914:3: ( 'TrueOrFalse' )
                    {
                     before(grammarAccess.getTypeAccess().getTrueOrFalseEnumLiteralDeclaration_2()); 
                    // InternalSmaCQA.g:915:3: ( 'TrueOrFalse' )
                    // InternalSmaCQA.g:915:4: 'TrueOrFalse'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypeAccess().getTrueOrFalseEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Type__Alternatives"


    // $ANTLR start "rule__UnitTime__Alternatives"
    // InternalSmaCQA.g:923:1: rule__UnitTime__Alternatives : ( ( ( 'minutes' ) ) | ( ( 'days' ) ) | ( ( 'weeks' ) ) | ( ( 'years' ) ) );
    public final void rule__UnitTime__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:927:1: ( ( ( 'minutes' ) ) | ( ( 'days' ) ) | ( ( 'weeks' ) ) | ( ( 'years' ) ) )
            int alt16=4;
            switch ( input.LA(1) ) {
            case 17:
                {
                alt16=1;
                }
                break;
            case 18:
                {
                alt16=2;
                }
                break;
            case 19:
                {
                alt16=3;
                }
                break;
            case 20:
                {
                alt16=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalSmaCQA.g:928:2: ( ( 'minutes' ) )
                    {
                    // InternalSmaCQA.g:928:2: ( ( 'minutes' ) )
                    // InternalSmaCQA.g:929:3: ( 'minutes' )
                    {
                     before(grammarAccess.getUnitTimeAccess().getMinutesEnumLiteralDeclaration_0()); 
                    // InternalSmaCQA.g:930:3: ( 'minutes' )
                    // InternalSmaCQA.g:930:4: 'minutes'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitTimeAccess().getMinutesEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:934:2: ( ( 'days' ) )
                    {
                    // InternalSmaCQA.g:934:2: ( ( 'days' ) )
                    // InternalSmaCQA.g:935:3: ( 'days' )
                    {
                     before(grammarAccess.getUnitTimeAccess().getDaysEnumLiteralDeclaration_1()); 
                    // InternalSmaCQA.g:936:3: ( 'days' )
                    // InternalSmaCQA.g:936:4: 'days'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitTimeAccess().getDaysEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:940:2: ( ( 'weeks' ) )
                    {
                    // InternalSmaCQA.g:940:2: ( ( 'weeks' ) )
                    // InternalSmaCQA.g:941:3: ( 'weeks' )
                    {
                     before(grammarAccess.getUnitTimeAccess().getWeeksEnumLiteralDeclaration_2()); 
                    // InternalSmaCQA.g:942:3: ( 'weeks' )
                    // InternalSmaCQA.g:942:4: 'weeks'
                    {
                    match(input,19,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitTimeAccess().getWeeksEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSmaCQA.g:946:2: ( ( 'years' ) )
                    {
                    // InternalSmaCQA.g:946:2: ( ( 'years' ) )
                    // InternalSmaCQA.g:947:3: ( 'years' )
                    {
                     before(grammarAccess.getUnitTimeAccess().getYearsEnumLiteralDeclaration_3()); 
                    // InternalSmaCQA.g:948:3: ( 'years' )
                    // InternalSmaCQA.g:948:4: 'years'
                    {
                    match(input,20,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitTimeAccess().getYearsEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnitTime__Alternatives"


    // $ANTLR start "rule__UnitCoin__Alternatives"
    // InternalSmaCQA.g:956:1: rule__UnitCoin__Alternatives : ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'pwei' ) ) | ( ( 'gwei' ) ) | ( ( 'szabo' ) ) );
    public final void rule__UnitCoin__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:960:1: ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'pwei' ) ) | ( ( 'gwei' ) ) | ( ( 'szabo' ) ) )
            int alt17=5;
            switch ( input.LA(1) ) {
            case 21:
                {
                alt17=1;
                }
                break;
            case 22:
                {
                alt17=2;
                }
                break;
            case 23:
                {
                alt17=3;
                }
                break;
            case 24:
                {
                alt17=4;
                }
                break;
            case 25:
                {
                alt17=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalSmaCQA.g:961:2: ( ( 'ether' ) )
                    {
                    // InternalSmaCQA.g:961:2: ( ( 'ether' ) )
                    // InternalSmaCQA.g:962:3: ( 'ether' )
                    {
                     before(grammarAccess.getUnitCoinAccess().getEtherEnumLiteralDeclaration_0()); 
                    // InternalSmaCQA.g:963:3: ( 'ether' )
                    // InternalSmaCQA.g:963:4: 'ether'
                    {
                    match(input,21,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitCoinAccess().getEtherEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:967:2: ( ( 'wei' ) )
                    {
                    // InternalSmaCQA.g:967:2: ( ( 'wei' ) )
                    // InternalSmaCQA.g:968:3: ( 'wei' )
                    {
                     before(grammarAccess.getUnitCoinAccess().getWeiEnumLiteralDeclaration_1()); 
                    // InternalSmaCQA.g:969:3: ( 'wei' )
                    // InternalSmaCQA.g:969:4: 'wei'
                    {
                    match(input,22,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitCoinAccess().getWeiEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:973:2: ( ( 'pwei' ) )
                    {
                    // InternalSmaCQA.g:973:2: ( ( 'pwei' ) )
                    // InternalSmaCQA.g:974:3: ( 'pwei' )
                    {
                     before(grammarAccess.getUnitCoinAccess().getPweiEnumLiteralDeclaration_2()); 
                    // InternalSmaCQA.g:975:3: ( 'pwei' )
                    // InternalSmaCQA.g:975:4: 'pwei'
                    {
                    match(input,23,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitCoinAccess().getPweiEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSmaCQA.g:979:2: ( ( 'gwei' ) )
                    {
                    // InternalSmaCQA.g:979:2: ( ( 'gwei' ) )
                    // InternalSmaCQA.g:980:3: ( 'gwei' )
                    {
                     before(grammarAccess.getUnitCoinAccess().getGweiEnumLiteralDeclaration_3()); 
                    // InternalSmaCQA.g:981:3: ( 'gwei' )
                    // InternalSmaCQA.g:981:4: 'gwei'
                    {
                    match(input,24,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitCoinAccess().getGweiEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSmaCQA.g:985:2: ( ( 'szabo' ) )
                    {
                    // InternalSmaCQA.g:985:2: ( ( 'szabo' ) )
                    // InternalSmaCQA.g:986:3: ( 'szabo' )
                    {
                     before(grammarAccess.getUnitCoinAccess().getSzaboEnumLiteralDeclaration_4()); 
                    // InternalSmaCQA.g:987:3: ( 'szabo' )
                    // InternalSmaCQA.g:987:4: 'szabo'
                    {
                    match(input,25,FOLLOW_2); 

                    }

                     after(grammarAccess.getUnitCoinAccess().getSzaboEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UnitCoin__Alternatives"


    // $ANTLR start "rule__ValueExchange__Group__0"
    // InternalSmaCQA.g:995:1: rule__ValueExchange__Group__0 : rule__ValueExchange__Group__0__Impl rule__ValueExchange__Group__1 ;
    public final void rule__ValueExchange__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:999:1: ( rule__ValueExchange__Group__0__Impl rule__ValueExchange__Group__1 )
            // InternalSmaCQA.g:1000:2: rule__ValueExchange__Group__0__Impl rule__ValueExchange__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__ValueExchange__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__0"


    // $ANTLR start "rule__ValueExchange__Group__0__Impl"
    // InternalSmaCQA.g:1007:1: rule__ValueExchange__Group__0__Impl : ( '================= Value Exchange ======================= \\r\\nThe exchange of value in which' ) ;
    public final void rule__ValueExchange__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1011:1: ( ( '================= Value Exchange ======================= \\r\\nThe exchange of value in which' ) )
            // InternalSmaCQA.g:1012:1: ( '================= Value Exchange ======================= \\r\\nThe exchange of value in which' )
            {
            // InternalSmaCQA.g:1012:1: ( '================= Value Exchange ======================= \\r\\nThe exchange of value in which' )
            // InternalSmaCQA.g:1013:2: '================= Value Exchange ======================= \\r\\nThe exchange of value in which'
            {
             before(grammarAccess.getValueExchangeAccess().getValueExchangeTheExchangeOfValueInWhichKeyword_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getValueExchangeTheExchangeOfValueInWhichKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__0__Impl"


    // $ANTLR start "rule__ValueExchange__Group__1"
    // InternalSmaCQA.g:1022:1: rule__ValueExchange__Group__1 : rule__ValueExchange__Group__1__Impl rule__ValueExchange__Group__2 ;
    public final void rule__ValueExchange__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1026:1: ( rule__ValueExchange__Group__1__Impl rule__ValueExchange__Group__2 )
            // InternalSmaCQA.g:1027:2: rule__ValueExchange__Group__1__Impl rule__ValueExchange__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__ValueExchange__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__1"


    // $ANTLR start "rule__ValueExchange__Group__1__Impl"
    // InternalSmaCQA.g:1034:1: rule__ValueExchange__Group__1__Impl : ( ( rule__ValueExchange__ActorSendAssignment_1 ) ) ;
    public final void rule__ValueExchange__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1038:1: ( ( ( rule__ValueExchange__ActorSendAssignment_1 ) ) )
            // InternalSmaCQA.g:1039:1: ( ( rule__ValueExchange__ActorSendAssignment_1 ) )
            {
            // InternalSmaCQA.g:1039:1: ( ( rule__ValueExchange__ActorSendAssignment_1 ) )
            // InternalSmaCQA.g:1040:2: ( rule__ValueExchange__ActorSendAssignment_1 )
            {
             before(grammarAccess.getValueExchangeAccess().getActorSendAssignment_1()); 
            // InternalSmaCQA.g:1041:2: ( rule__ValueExchange__ActorSendAssignment_1 )
            // InternalSmaCQA.g:1041:3: rule__ValueExchange__ActorSendAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__ActorSendAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getValueExchangeAccess().getActorSendAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__1__Impl"


    // $ANTLR start "rule__ValueExchange__Group__2"
    // InternalSmaCQA.g:1049:1: rule__ValueExchange__Group__2 : rule__ValueExchange__Group__2__Impl rule__ValueExchange__Group__3 ;
    public final void rule__ValueExchange__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1053:1: ( rule__ValueExchange__Group__2__Impl rule__ValueExchange__Group__3 )
            // InternalSmaCQA.g:1054:2: rule__ValueExchange__Group__2__Impl rule__ValueExchange__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__ValueExchange__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__2"


    // $ANTLR start "rule__ValueExchange__Group__2__Impl"
    // InternalSmaCQA.g:1061:1: rule__ValueExchange__Group__2__Impl : ( 'sends/grants' ) ;
    public final void rule__ValueExchange__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1065:1: ( ( 'sends/grants' ) )
            // InternalSmaCQA.g:1066:1: ( 'sends/grants' )
            {
            // InternalSmaCQA.g:1066:1: ( 'sends/grants' )
            // InternalSmaCQA.g:1067:2: 'sends/grants'
            {
             before(grammarAccess.getValueExchangeAccess().getSendsGrantsKeyword_2()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getSendsGrantsKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__2__Impl"


    // $ANTLR start "rule__ValueExchange__Group__3"
    // InternalSmaCQA.g:1076:1: rule__ValueExchange__Group__3 : rule__ValueExchange__Group__3__Impl rule__ValueExchange__Group__4 ;
    public final void rule__ValueExchange__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1080:1: ( rule__ValueExchange__Group__3__Impl rule__ValueExchange__Group__4 )
            // InternalSmaCQA.g:1081:2: rule__ValueExchange__Group__3__Impl rule__ValueExchange__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__ValueExchange__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__3"


    // $ANTLR start "rule__ValueExchange__Group__3__Impl"
    // InternalSmaCQA.g:1088:1: rule__ValueExchange__Group__3__Impl : ( ( rule__ValueExchange__ActorReceiptAssignment_3 ) ) ;
    public final void rule__ValueExchange__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1092:1: ( ( ( rule__ValueExchange__ActorReceiptAssignment_3 ) ) )
            // InternalSmaCQA.g:1093:1: ( ( rule__ValueExchange__ActorReceiptAssignment_3 ) )
            {
            // InternalSmaCQA.g:1093:1: ( ( rule__ValueExchange__ActorReceiptAssignment_3 ) )
            // InternalSmaCQA.g:1094:2: ( rule__ValueExchange__ActorReceiptAssignment_3 )
            {
             before(grammarAccess.getValueExchangeAccess().getActorReceiptAssignment_3()); 
            // InternalSmaCQA.g:1095:2: ( rule__ValueExchange__ActorReceiptAssignment_3 )
            // InternalSmaCQA.g:1095:3: rule__ValueExchange__ActorReceiptAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__ActorReceiptAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getValueExchangeAccess().getActorReceiptAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__3__Impl"


    // $ANTLR start "rule__ValueExchange__Group__4"
    // InternalSmaCQA.g:1103:1: rule__ValueExchange__Group__4 : rule__ValueExchange__Group__4__Impl rule__ValueExchange__Group__5 ;
    public final void rule__ValueExchange__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1107:1: ( rule__ValueExchange__Group__4__Impl rule__ValueExchange__Group__5 )
            // InternalSmaCQA.g:1108:2: rule__ValueExchange__Group__4__Impl rule__ValueExchange__Group__5
            {
            pushFollow(FOLLOW_4);
            rule__ValueExchange__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__4"


    // $ANTLR start "rule__ValueExchange__Group__4__Impl"
    // InternalSmaCQA.g:1115:1: rule__ValueExchange__Group__4__Impl : ( 'the following object of value' ) ;
    public final void rule__ValueExchange__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1119:1: ( ( 'the following object of value' ) )
            // InternalSmaCQA.g:1120:1: ( 'the following object of value' )
            {
            // InternalSmaCQA.g:1120:1: ( 'the following object of value' )
            // InternalSmaCQA.g:1121:2: 'the following object of value'
            {
             before(grammarAccess.getValueExchangeAccess().getTheFollowingObjectOfValueKeyword_4()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getTheFollowingObjectOfValueKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__4__Impl"


    // $ANTLR start "rule__ValueExchange__Group__5"
    // InternalSmaCQA.g:1130:1: rule__ValueExchange__Group__5 : rule__ValueExchange__Group__5__Impl rule__ValueExchange__Group__6 ;
    public final void rule__ValueExchange__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1134:1: ( rule__ValueExchange__Group__5__Impl rule__ValueExchange__Group__6 )
            // InternalSmaCQA.g:1135:2: rule__ValueExchange__Group__5__Impl rule__ValueExchange__Group__6
            {
            pushFollow(FOLLOW_7);
            rule__ValueExchange__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__5"


    // $ANTLR start "rule__ValueExchange__Group__5__Impl"
    // InternalSmaCQA.g:1142:1: rule__ValueExchange__Group__5__Impl : ( ( rule__ValueExchange__ValueObjectAssignment_5 ) ) ;
    public final void rule__ValueExchange__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1146:1: ( ( ( rule__ValueExchange__ValueObjectAssignment_5 ) ) )
            // InternalSmaCQA.g:1147:1: ( ( rule__ValueExchange__ValueObjectAssignment_5 ) )
            {
            // InternalSmaCQA.g:1147:1: ( ( rule__ValueExchange__ValueObjectAssignment_5 ) )
            // InternalSmaCQA.g:1148:2: ( rule__ValueExchange__ValueObjectAssignment_5 )
            {
             before(grammarAccess.getValueExchangeAccess().getValueObjectAssignment_5()); 
            // InternalSmaCQA.g:1149:2: ( rule__ValueExchange__ValueObjectAssignment_5 )
            // InternalSmaCQA.g:1149:3: rule__ValueExchange__ValueObjectAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__ValueObjectAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getValueExchangeAccess().getValueObjectAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__5__Impl"


    // $ANTLR start "rule__ValueExchange__Group__6"
    // InternalSmaCQA.g:1157:1: rule__ValueExchange__Group__6 : rule__ValueExchange__Group__6__Impl rule__ValueExchange__Group__7 ;
    public final void rule__ValueExchange__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1161:1: ( rule__ValueExchange__Group__6__Impl rule__ValueExchange__Group__7 )
            // InternalSmaCQA.g:1162:2: rule__ValueExchange__Group__6__Impl rule__ValueExchange__Group__7
            {
            pushFollow(FOLLOW_8);
            rule__ValueExchange__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__6"


    // $ANTLR start "rule__ValueExchange__Group__6__Impl"
    // InternalSmaCQA.g:1169:1: rule__ValueExchange__Group__6__Impl : ( 'has the following associated questions and answers: ' ) ;
    public final void rule__ValueExchange__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1173:1: ( ( 'has the following associated questions and answers: ' ) )
            // InternalSmaCQA.g:1174:1: ( 'has the following associated questions and answers: ' )
            {
            // InternalSmaCQA.g:1174:1: ( 'has the following associated questions and answers: ' )
            // InternalSmaCQA.g:1175:2: 'has the following associated questions and answers: '
            {
             before(grammarAccess.getValueExchangeAccess().getHasTheFollowingAssociatedQuestionsAndAnswersKeyword_6()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getHasTheFollowingAssociatedQuestionsAndAnswersKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__6__Impl"


    // $ANTLR start "rule__ValueExchange__Group__7"
    // InternalSmaCQA.g:1184:1: rule__ValueExchange__Group__7 : rule__ValueExchange__Group__7__Impl rule__ValueExchange__Group__8 ;
    public final void rule__ValueExchange__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1188:1: ( rule__ValueExchange__Group__7__Impl rule__ValueExchange__Group__8 )
            // InternalSmaCQA.g:1189:2: rule__ValueExchange__Group__7__Impl rule__ValueExchange__Group__8
            {
            pushFollow(FOLLOW_8);
            rule__ValueExchange__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__7"


    // $ANTLR start "rule__ValueExchange__Group__7__Impl"
    // InternalSmaCQA.g:1196:1: rule__ValueExchange__Group__7__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__ValueExchange__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1200:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSmaCQA.g:1201:1: ( ( RULE_EOLINE )? )
            {
            // InternalSmaCQA.g:1201:1: ( ( RULE_EOLINE )? )
            // InternalSmaCQA.g:1202:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_7()); 
            // InternalSmaCQA.g:1203:2: ( RULE_EOLINE )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==RULE_EOLINE) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalSmaCQA.g:1203:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__7__Impl"


    // $ANTLR start "rule__ValueExchange__Group__8"
    // InternalSmaCQA.g:1211:1: rule__ValueExchange__Group__8 : rule__ValueExchange__Group__8__Impl rule__ValueExchange__Group__9 ;
    public final void rule__ValueExchange__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1215:1: ( rule__ValueExchange__Group__8__Impl rule__ValueExchange__Group__9 )
            // InternalSmaCQA.g:1216:2: rule__ValueExchange__Group__8__Impl rule__ValueExchange__Group__9
            {
            pushFollow(FOLLOW_8);
            rule__ValueExchange__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__8"


    // $ANTLR start "rule__ValueExchange__Group__8__Impl"
    // InternalSmaCQA.g:1223:1: rule__ValueExchange__Group__8__Impl : ( ( rule__ValueExchange__Group_8__0 )? ) ;
    public final void rule__ValueExchange__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1227:1: ( ( ( rule__ValueExchange__Group_8__0 )? ) )
            // InternalSmaCQA.g:1228:1: ( ( rule__ValueExchange__Group_8__0 )? )
            {
            // InternalSmaCQA.g:1228:1: ( ( rule__ValueExchange__Group_8__0 )? )
            // InternalSmaCQA.g:1229:2: ( rule__ValueExchange__Group_8__0 )?
            {
             before(grammarAccess.getValueExchangeAccess().getGroup_8()); 
            // InternalSmaCQA.g:1230:2: ( rule__ValueExchange__Group_8__0 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==31) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalSmaCQA.g:1230:3: rule__ValueExchange__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ValueExchange__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getValueExchangeAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__8__Impl"


    // $ANTLR start "rule__ValueExchange__Group__9"
    // InternalSmaCQA.g:1238:1: rule__ValueExchange__Group__9 : rule__ValueExchange__Group__9__Impl rule__ValueExchange__Group__10 ;
    public final void rule__ValueExchange__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1242:1: ( rule__ValueExchange__Group__9__Impl rule__ValueExchange__Group__10 )
            // InternalSmaCQA.g:1243:2: rule__ValueExchange__Group__9__Impl rule__ValueExchange__Group__10
            {
            pushFollow(FOLLOW_8);
            rule__ValueExchange__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__9"


    // $ANTLR start "rule__ValueExchange__Group__9__Impl"
    // InternalSmaCQA.g:1250:1: rule__ValueExchange__Group__9__Impl : ( ( rule__ValueExchange__Group_9__0 )? ) ;
    public final void rule__ValueExchange__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1254:1: ( ( ( rule__ValueExchange__Group_9__0 )? ) )
            // InternalSmaCQA.g:1255:1: ( ( rule__ValueExchange__Group_9__0 )? )
            {
            // InternalSmaCQA.g:1255:1: ( ( rule__ValueExchange__Group_9__0 )? )
            // InternalSmaCQA.g:1256:2: ( rule__ValueExchange__Group_9__0 )?
            {
             before(grammarAccess.getValueExchangeAccess().getGroup_9()); 
            // InternalSmaCQA.g:1257:2: ( rule__ValueExchange__Group_9__0 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==32) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSmaCQA.g:1257:3: rule__ValueExchange__Group_9__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ValueExchange__Group_9__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getValueExchangeAccess().getGroup_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__9__Impl"


    // $ANTLR start "rule__ValueExchange__Group__10"
    // InternalSmaCQA.g:1265:1: rule__ValueExchange__Group__10 : rule__ValueExchange__Group__10__Impl rule__ValueExchange__Group__11 ;
    public final void rule__ValueExchange__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1269:1: ( rule__ValueExchange__Group__10__Impl rule__ValueExchange__Group__11 )
            // InternalSmaCQA.g:1270:2: rule__ValueExchange__Group__10__Impl rule__ValueExchange__Group__11
            {
            pushFollow(FOLLOW_8);
            rule__ValueExchange__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__10"


    // $ANTLR start "rule__ValueExchange__Group__10__Impl"
    // InternalSmaCQA.g:1277:1: rule__ValueExchange__Group__10__Impl : ( ( rule__ValueExchange__Group_10__0 )? ) ;
    public final void rule__ValueExchange__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1281:1: ( ( ( rule__ValueExchange__Group_10__0 )? ) )
            // InternalSmaCQA.g:1282:1: ( ( rule__ValueExchange__Group_10__0 )? )
            {
            // InternalSmaCQA.g:1282:1: ( ( rule__ValueExchange__Group_10__0 )? )
            // InternalSmaCQA.g:1283:2: ( rule__ValueExchange__Group_10__0 )?
            {
             before(grammarAccess.getValueExchangeAccess().getGroup_10()); 
            // InternalSmaCQA.g:1284:2: ( rule__ValueExchange__Group_10__0 )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==33) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalSmaCQA.g:1284:3: rule__ValueExchange__Group_10__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ValueExchange__Group_10__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getValueExchangeAccess().getGroup_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__10__Impl"


    // $ANTLR start "rule__ValueExchange__Group__11"
    // InternalSmaCQA.g:1292:1: rule__ValueExchange__Group__11 : rule__ValueExchange__Group__11__Impl ;
    public final void rule__ValueExchange__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1296:1: ( rule__ValueExchange__Group__11__Impl )
            // InternalSmaCQA.g:1297:2: rule__ValueExchange__Group__11__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group__11__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__11"


    // $ANTLR start "rule__ValueExchange__Group__11__Impl"
    // InternalSmaCQA.g:1303:1: rule__ValueExchange__Group__11__Impl : ( '================= Completion of the question process for this value exchange =================' ) ;
    public final void rule__ValueExchange__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1307:1: ( ( '================= Completion of the question process for this value exchange =================' ) )
            // InternalSmaCQA.g:1308:1: ( '================= Completion of the question process for this value exchange =================' )
            {
            // InternalSmaCQA.g:1308:1: ( '================= Completion of the question process for this value exchange =================' )
            // InternalSmaCQA.g:1309:2: '================= Completion of the question process for this value exchange ================='
            {
             before(grammarAccess.getValueExchangeAccess().getCompletionOfTheQuestionProcessForThisValueExchangeKeyword_11()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getCompletionOfTheQuestionProcessForThisValueExchangeKeyword_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group__11__Impl"


    // $ANTLR start "rule__ValueExchange__Group_8__0"
    // InternalSmaCQA.g:1319:1: rule__ValueExchange__Group_8__0 : rule__ValueExchange__Group_8__0__Impl rule__ValueExchange__Group_8__1 ;
    public final void rule__ValueExchange__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1323:1: ( rule__ValueExchange__Group_8__0__Impl rule__ValueExchange__Group_8__1 )
            // InternalSmaCQA.g:1324:2: rule__ValueExchange__Group_8__0__Impl rule__ValueExchange__Group_8__1
            {
            pushFollow(FOLLOW_9);
            rule__ValueExchange__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_8__0"


    // $ANTLR start "rule__ValueExchange__Group_8__0__Impl"
    // InternalSmaCQA.g:1331:1: rule__ValueExchange__Group_8__0__Impl : ( '--------- 1.Data Questions: -----------' ) ;
    public final void rule__ValueExchange__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1335:1: ( ( '--------- 1.Data Questions: -----------' ) )
            // InternalSmaCQA.g:1336:1: ( '--------- 1.Data Questions: -----------' )
            {
            // InternalSmaCQA.g:1336:1: ( '--------- 1.Data Questions: -----------' )
            // InternalSmaCQA.g:1337:2: '--------- 1.Data Questions: -----------'
            {
             before(grammarAccess.getValueExchangeAccess().getDataQuestionsKeyword_8_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getDataQuestionsKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_8__0__Impl"


    // $ANTLR start "rule__ValueExchange__Group_8__1"
    // InternalSmaCQA.g:1346:1: rule__ValueExchange__Group_8__1 : rule__ValueExchange__Group_8__1__Impl rule__ValueExchange__Group_8__2 ;
    public final void rule__ValueExchange__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1350:1: ( rule__ValueExchange__Group_8__1__Impl rule__ValueExchange__Group_8__2 )
            // InternalSmaCQA.g:1351:2: rule__ValueExchange__Group_8__1__Impl rule__ValueExchange__Group_8__2
            {
            pushFollow(FOLLOW_9);
            rule__ValueExchange__Group_8__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_8__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_8__1"


    // $ANTLR start "rule__ValueExchange__Group_8__1__Impl"
    // InternalSmaCQA.g:1358:1: rule__ValueExchange__Group_8__1__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__ValueExchange__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1362:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSmaCQA.g:1363:1: ( ( RULE_EOLINE )? )
            {
            // InternalSmaCQA.g:1363:1: ( ( RULE_EOLINE )? )
            // InternalSmaCQA.g:1364:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_8_1()); 
            // InternalSmaCQA.g:1365:2: ( RULE_EOLINE )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==RULE_EOLINE) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalSmaCQA.g:1365:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_8__1__Impl"


    // $ANTLR start "rule__ValueExchange__Group_8__2"
    // InternalSmaCQA.g:1373:1: rule__ValueExchange__Group_8__2 : rule__ValueExchange__Group_8__2__Impl ;
    public final void rule__ValueExchange__Group_8__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1377:1: ( rule__ValueExchange__Group_8__2__Impl )
            // InternalSmaCQA.g:1378:2: rule__ValueExchange__Group_8__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_8__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_8__2"


    // $ANTLR start "rule__ValueExchange__Group_8__2__Impl"
    // InternalSmaCQA.g:1384:1: rule__ValueExchange__Group_8__2__Impl : ( ( rule__ValueExchange__DataQuestionAssignment_8_2 ) ) ;
    public final void rule__ValueExchange__Group_8__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1388:1: ( ( ( rule__ValueExchange__DataQuestionAssignment_8_2 ) ) )
            // InternalSmaCQA.g:1389:1: ( ( rule__ValueExchange__DataQuestionAssignment_8_2 ) )
            {
            // InternalSmaCQA.g:1389:1: ( ( rule__ValueExchange__DataQuestionAssignment_8_2 ) )
            // InternalSmaCQA.g:1390:2: ( rule__ValueExchange__DataQuestionAssignment_8_2 )
            {
             before(grammarAccess.getValueExchangeAccess().getDataQuestionAssignment_8_2()); 
            // InternalSmaCQA.g:1391:2: ( rule__ValueExchange__DataQuestionAssignment_8_2 )
            // InternalSmaCQA.g:1391:3: rule__ValueExchange__DataQuestionAssignment_8_2
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__DataQuestionAssignment_8_2();

            state._fsp--;


            }

             after(grammarAccess.getValueExchangeAccess().getDataQuestionAssignment_8_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_8__2__Impl"


    // $ANTLR start "rule__ValueExchange__Group_9__0"
    // InternalSmaCQA.g:1400:1: rule__ValueExchange__Group_9__0 : rule__ValueExchange__Group_9__0__Impl rule__ValueExchange__Group_9__1 ;
    public final void rule__ValueExchange__Group_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1404:1: ( rule__ValueExchange__Group_9__0__Impl rule__ValueExchange__Group_9__1 )
            // InternalSmaCQA.g:1405:2: rule__ValueExchange__Group_9__0__Impl rule__ValueExchange__Group_9__1
            {
            pushFollow(FOLLOW_10);
            rule__ValueExchange__Group_9__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_9__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_9__0"


    // $ANTLR start "rule__ValueExchange__Group_9__0__Impl"
    // InternalSmaCQA.g:1412:1: rule__ValueExchange__Group_9__0__Impl : ( '--------- 2.Legal Questions: -----------' ) ;
    public final void rule__ValueExchange__Group_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1416:1: ( ( '--------- 2.Legal Questions: -----------' ) )
            // InternalSmaCQA.g:1417:1: ( '--------- 2.Legal Questions: -----------' )
            {
            // InternalSmaCQA.g:1417:1: ( '--------- 2.Legal Questions: -----------' )
            // InternalSmaCQA.g:1418:2: '--------- 2.Legal Questions: -----------'
            {
             before(grammarAccess.getValueExchangeAccess().getLegalQuestionsKeyword_9_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getLegalQuestionsKeyword_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_9__0__Impl"


    // $ANTLR start "rule__ValueExchange__Group_9__1"
    // InternalSmaCQA.g:1427:1: rule__ValueExchange__Group_9__1 : rule__ValueExchange__Group_9__1__Impl rule__ValueExchange__Group_9__2 ;
    public final void rule__ValueExchange__Group_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1431:1: ( rule__ValueExchange__Group_9__1__Impl rule__ValueExchange__Group_9__2 )
            // InternalSmaCQA.g:1432:2: rule__ValueExchange__Group_9__1__Impl rule__ValueExchange__Group_9__2
            {
            pushFollow(FOLLOW_10);
            rule__ValueExchange__Group_9__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_9__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_9__1"


    // $ANTLR start "rule__ValueExchange__Group_9__1__Impl"
    // InternalSmaCQA.g:1439:1: rule__ValueExchange__Group_9__1__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__ValueExchange__Group_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1443:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSmaCQA.g:1444:1: ( ( RULE_EOLINE )? )
            {
            // InternalSmaCQA.g:1444:1: ( ( RULE_EOLINE )? )
            // InternalSmaCQA.g:1445:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_9_1()); 
            // InternalSmaCQA.g:1446:2: ( RULE_EOLINE )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_EOLINE) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalSmaCQA.g:1446:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_9_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_9__1__Impl"


    // $ANTLR start "rule__ValueExchange__Group_9__2"
    // InternalSmaCQA.g:1454:1: rule__ValueExchange__Group_9__2 : rule__ValueExchange__Group_9__2__Impl ;
    public final void rule__ValueExchange__Group_9__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1458:1: ( rule__ValueExchange__Group_9__2__Impl )
            // InternalSmaCQA.g:1459:2: rule__ValueExchange__Group_9__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_9__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_9__2"


    // $ANTLR start "rule__ValueExchange__Group_9__2__Impl"
    // InternalSmaCQA.g:1465:1: rule__ValueExchange__Group_9__2__Impl : ( ( rule__ValueExchange__LegalQuestionAssignment_9_2 ) ) ;
    public final void rule__ValueExchange__Group_9__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1469:1: ( ( ( rule__ValueExchange__LegalQuestionAssignment_9_2 ) ) )
            // InternalSmaCQA.g:1470:1: ( ( rule__ValueExchange__LegalQuestionAssignment_9_2 ) )
            {
            // InternalSmaCQA.g:1470:1: ( ( rule__ValueExchange__LegalQuestionAssignment_9_2 ) )
            // InternalSmaCQA.g:1471:2: ( rule__ValueExchange__LegalQuestionAssignment_9_2 )
            {
             before(grammarAccess.getValueExchangeAccess().getLegalQuestionAssignment_9_2()); 
            // InternalSmaCQA.g:1472:2: ( rule__ValueExchange__LegalQuestionAssignment_9_2 )
            // InternalSmaCQA.g:1472:3: rule__ValueExchange__LegalQuestionAssignment_9_2
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__LegalQuestionAssignment_9_2();

            state._fsp--;


            }

             after(grammarAccess.getValueExchangeAccess().getLegalQuestionAssignment_9_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_9__2__Impl"


    // $ANTLR start "rule__ValueExchange__Group_10__0"
    // InternalSmaCQA.g:1481:1: rule__ValueExchange__Group_10__0 : rule__ValueExchange__Group_10__0__Impl rule__ValueExchange__Group_10__1 ;
    public final void rule__ValueExchange__Group_10__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1485:1: ( rule__ValueExchange__Group_10__0__Impl rule__ValueExchange__Group_10__1 )
            // InternalSmaCQA.g:1486:2: rule__ValueExchange__Group_10__0__Impl rule__ValueExchange__Group_10__1
            {
            pushFollow(FOLLOW_11);
            rule__ValueExchange__Group_10__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_10__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_10__0"


    // $ANTLR start "rule__ValueExchange__Group_10__0__Impl"
    // InternalSmaCQA.g:1493:1: rule__ValueExchange__Group_10__0__Impl : ( '--------- 3.Economy Questions: -----------' ) ;
    public final void rule__ValueExchange__Group_10__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1497:1: ( ( '--------- 3.Economy Questions: -----------' ) )
            // InternalSmaCQA.g:1498:1: ( '--------- 3.Economy Questions: -----------' )
            {
            // InternalSmaCQA.g:1498:1: ( '--------- 3.Economy Questions: -----------' )
            // InternalSmaCQA.g:1499:2: '--------- 3.Economy Questions: -----------'
            {
             before(grammarAccess.getValueExchangeAccess().getEconomyQuestionsKeyword_10_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getEconomyQuestionsKeyword_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_10__0__Impl"


    // $ANTLR start "rule__ValueExchange__Group_10__1"
    // InternalSmaCQA.g:1508:1: rule__ValueExchange__Group_10__1 : rule__ValueExchange__Group_10__1__Impl rule__ValueExchange__Group_10__2 ;
    public final void rule__ValueExchange__Group_10__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1512:1: ( rule__ValueExchange__Group_10__1__Impl rule__ValueExchange__Group_10__2 )
            // InternalSmaCQA.g:1513:2: rule__ValueExchange__Group_10__1__Impl rule__ValueExchange__Group_10__2
            {
            pushFollow(FOLLOW_11);
            rule__ValueExchange__Group_10__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_10__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_10__1"


    // $ANTLR start "rule__ValueExchange__Group_10__1__Impl"
    // InternalSmaCQA.g:1520:1: rule__ValueExchange__Group_10__1__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__ValueExchange__Group_10__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1524:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSmaCQA.g:1525:1: ( ( RULE_EOLINE )? )
            {
            // InternalSmaCQA.g:1525:1: ( ( RULE_EOLINE )? )
            // InternalSmaCQA.g:1526:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_10_1()); 
            // InternalSmaCQA.g:1527:2: ( RULE_EOLINE )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==RULE_EOLINE) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalSmaCQA.g:1527:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_10_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_10__1__Impl"


    // $ANTLR start "rule__ValueExchange__Group_10__2"
    // InternalSmaCQA.g:1535:1: rule__ValueExchange__Group_10__2 : rule__ValueExchange__Group_10__2__Impl ;
    public final void rule__ValueExchange__Group_10__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1539:1: ( rule__ValueExchange__Group_10__2__Impl )
            // InternalSmaCQA.g:1540:2: rule__ValueExchange__Group_10__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__Group_10__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_10__2"


    // $ANTLR start "rule__ValueExchange__Group_10__2__Impl"
    // InternalSmaCQA.g:1546:1: rule__ValueExchange__Group_10__2__Impl : ( ( rule__ValueExchange__EconomyQuestionAssignment_10_2 ) ) ;
    public final void rule__ValueExchange__Group_10__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1550:1: ( ( ( rule__ValueExchange__EconomyQuestionAssignment_10_2 ) ) )
            // InternalSmaCQA.g:1551:1: ( ( rule__ValueExchange__EconomyQuestionAssignment_10_2 ) )
            {
            // InternalSmaCQA.g:1551:1: ( ( rule__ValueExchange__EconomyQuestionAssignment_10_2 ) )
            // InternalSmaCQA.g:1552:2: ( rule__ValueExchange__EconomyQuestionAssignment_10_2 )
            {
             before(grammarAccess.getValueExchangeAccess().getEconomyQuestionAssignment_10_2()); 
            // InternalSmaCQA.g:1553:2: ( rule__ValueExchange__EconomyQuestionAssignment_10_2 )
            // InternalSmaCQA.g:1553:3: rule__ValueExchange__EconomyQuestionAssignment_10_2
            {
            pushFollow(FOLLOW_2);
            rule__ValueExchange__EconomyQuestionAssignment_10_2();

            state._fsp--;


            }

             after(grammarAccess.getValueExchangeAccess().getEconomyQuestionAssignment_10_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__Group_10__2__Impl"


    // $ANTLR start "rule__DataQuestion__Group__0"
    // InternalSmaCQA.g:1562:1: rule__DataQuestion__Group__0 : rule__DataQuestion__Group__0__Impl rule__DataQuestion__Group__1 ;
    public final void rule__DataQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1566:1: ( rule__DataQuestion__Group__0__Impl rule__DataQuestion__Group__1 )
            // InternalSmaCQA.g:1567:2: rule__DataQuestion__Group__0__Impl rule__DataQuestion__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__DataQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__0"


    // $ANTLR start "rule__DataQuestion__Group__0__Impl"
    // InternalSmaCQA.g:1574:1: rule__DataQuestion__Group__0__Impl : ( ( rule__DataQuestion__TimeDurationValueExchangeAssignment_0 )? ) ;
    public final void rule__DataQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1578:1: ( ( ( rule__DataQuestion__TimeDurationValueExchangeAssignment_0 )? ) )
            // InternalSmaCQA.g:1579:1: ( ( rule__DataQuestion__TimeDurationValueExchangeAssignment_0 )? )
            {
            // InternalSmaCQA.g:1579:1: ( ( rule__DataQuestion__TimeDurationValueExchangeAssignment_0 )? )
            // InternalSmaCQA.g:1580:2: ( rule__DataQuestion__TimeDurationValueExchangeAssignment_0 )?
            {
             before(grammarAccess.getDataQuestionAccess().getTimeDurationValueExchangeAssignment_0()); 
            // InternalSmaCQA.g:1581:2: ( rule__DataQuestion__TimeDurationValueExchangeAssignment_0 )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==68) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSmaCQA.g:1581:3: rule__DataQuestion__TimeDurationValueExchangeAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DataQuestion__TimeDurationValueExchangeAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDataQuestionAccess().getTimeDurationValueExchangeAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__0__Impl"


    // $ANTLR start "rule__DataQuestion__Group__1"
    // InternalSmaCQA.g:1589:1: rule__DataQuestion__Group__1 : rule__DataQuestion__Group__1__Impl rule__DataQuestion__Group__2 ;
    public final void rule__DataQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1593:1: ( rule__DataQuestion__Group__1__Impl rule__DataQuestion__Group__2 )
            // InternalSmaCQA.g:1594:2: rule__DataQuestion__Group__1__Impl rule__DataQuestion__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__DataQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__1"


    // $ANTLR start "rule__DataQuestion__Group__1__Impl"
    // InternalSmaCQA.g:1601:1: rule__DataQuestion__Group__1__Impl : ( ( rule__DataQuestion__TimeStartValueExchangeAssignment_1 )? ) ;
    public final void rule__DataQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1605:1: ( ( ( rule__DataQuestion__TimeStartValueExchangeAssignment_1 )? ) )
            // InternalSmaCQA.g:1606:1: ( ( rule__DataQuestion__TimeStartValueExchangeAssignment_1 )? )
            {
            // InternalSmaCQA.g:1606:1: ( ( rule__DataQuestion__TimeStartValueExchangeAssignment_1 )? )
            // InternalSmaCQA.g:1607:2: ( rule__DataQuestion__TimeStartValueExchangeAssignment_1 )?
            {
             before(grammarAccess.getDataQuestionAccess().getTimeStartValueExchangeAssignment_1()); 
            // InternalSmaCQA.g:1608:2: ( rule__DataQuestion__TimeStartValueExchangeAssignment_1 )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==69) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalSmaCQA.g:1608:3: rule__DataQuestion__TimeStartValueExchangeAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__DataQuestion__TimeStartValueExchangeAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDataQuestionAccess().getTimeStartValueExchangeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__1__Impl"


    // $ANTLR start "rule__DataQuestion__Group__2"
    // InternalSmaCQA.g:1616:1: rule__DataQuestion__Group__2 : rule__DataQuestion__Group__2__Impl rule__DataQuestion__Group__3 ;
    public final void rule__DataQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1620:1: ( rule__DataQuestion__Group__2__Impl rule__DataQuestion__Group__3 )
            // InternalSmaCQA.g:1621:2: rule__DataQuestion__Group__2__Impl rule__DataQuestion__Group__3
            {
            pushFollow(FOLLOW_9);
            rule__DataQuestion__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataQuestion__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__2"


    // $ANTLR start "rule__DataQuestion__Group__2__Impl"
    // InternalSmaCQA.g:1628:1: rule__DataQuestion__Group__2__Impl : ( ( rule__DataQuestion__RepeatValueExchangeAssignment_2 )? ) ;
    public final void rule__DataQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1632:1: ( ( ( rule__DataQuestion__RepeatValueExchangeAssignment_2 )? ) )
            // InternalSmaCQA.g:1633:1: ( ( rule__DataQuestion__RepeatValueExchangeAssignment_2 )? )
            {
            // InternalSmaCQA.g:1633:1: ( ( rule__DataQuestion__RepeatValueExchangeAssignment_2 )? )
            // InternalSmaCQA.g:1634:2: ( rule__DataQuestion__RepeatValueExchangeAssignment_2 )?
            {
             before(grammarAccess.getDataQuestionAccess().getRepeatValueExchangeAssignment_2()); 
            // InternalSmaCQA.g:1635:2: ( rule__DataQuestion__RepeatValueExchangeAssignment_2 )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==70) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSmaCQA.g:1635:3: rule__DataQuestion__RepeatValueExchangeAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__DataQuestion__RepeatValueExchangeAssignment_2();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDataQuestionAccess().getRepeatValueExchangeAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__2__Impl"


    // $ANTLR start "rule__DataQuestion__Group__3"
    // InternalSmaCQA.g:1643:1: rule__DataQuestion__Group__3 : rule__DataQuestion__Group__3__Impl rule__DataQuestion__Group__4 ;
    public final void rule__DataQuestion__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1647:1: ( rule__DataQuestion__Group__3__Impl rule__DataQuestion__Group__4 )
            // InternalSmaCQA.g:1648:2: rule__DataQuestion__Group__3__Impl rule__DataQuestion__Group__4
            {
            pushFollow(FOLLOW_9);
            rule__DataQuestion__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataQuestion__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__3"


    // $ANTLR start "rule__DataQuestion__Group__3__Impl"
    // InternalSmaCQA.g:1655:1: rule__DataQuestion__Group__3__Impl : ( ( rule__DataQuestion__ConditionValueExchangeAssignment_3 )? ) ;
    public final void rule__DataQuestion__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1659:1: ( ( ( rule__DataQuestion__ConditionValueExchangeAssignment_3 )? ) )
            // InternalSmaCQA.g:1660:1: ( ( rule__DataQuestion__ConditionValueExchangeAssignment_3 )? )
            {
            // InternalSmaCQA.g:1660:1: ( ( rule__DataQuestion__ConditionValueExchangeAssignment_3 )? )
            // InternalSmaCQA.g:1661:2: ( rule__DataQuestion__ConditionValueExchangeAssignment_3 )?
            {
             before(grammarAccess.getDataQuestionAccess().getConditionValueExchangeAssignment_3()); 
            // InternalSmaCQA.g:1662:2: ( rule__DataQuestion__ConditionValueExchangeAssignment_3 )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==71) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalSmaCQA.g:1662:3: rule__DataQuestion__ConditionValueExchangeAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__DataQuestion__ConditionValueExchangeAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDataQuestionAccess().getConditionValueExchangeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__3__Impl"


    // $ANTLR start "rule__DataQuestion__Group__4"
    // InternalSmaCQA.g:1670:1: rule__DataQuestion__Group__4 : rule__DataQuestion__Group__4__Impl ;
    public final void rule__DataQuestion__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1674:1: ( rule__DataQuestion__Group__4__Impl )
            // InternalSmaCQA.g:1675:2: rule__DataQuestion__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DataQuestion__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__4"


    // $ANTLR start "rule__DataQuestion__Group__4__Impl"
    // InternalSmaCQA.g:1681:1: rule__DataQuestion__Group__4__Impl : ( ( rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4 )? ) ;
    public final void rule__DataQuestion__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1685:1: ( ( ( rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4 )? ) )
            // InternalSmaCQA.g:1686:1: ( ( rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4 )? )
            {
            // InternalSmaCQA.g:1686:1: ( ( rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4 )? )
            // InternalSmaCQA.g:1687:2: ( rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4 )?
            {
             before(grammarAccess.getDataQuestionAccess().getValueObjectTypeValueExchangeAssignment_4()); 
            // InternalSmaCQA.g:1688:2: ( rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4 )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( ((LA29_0>=65 && LA29_0<=67)) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSmaCQA.g:1688:3: rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDataQuestionAccess().getValueObjectTypeValueExchangeAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__Group__4__Impl"


    // $ANTLR start "rule__ValueObjectRightQuestion__Group__0"
    // InternalSmaCQA.g:1697:1: rule__ValueObjectRightQuestion__Group__0 : rule__ValueObjectRightQuestion__Group__0__Impl rule__ValueObjectRightQuestion__Group__1 ;
    public final void rule__ValueObjectRightQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1701:1: ( rule__ValueObjectRightQuestion__Group__0__Impl rule__ValueObjectRightQuestion__Group__1 )
            // InternalSmaCQA.g:1702:2: rule__ValueObjectRightQuestion__Group__0__Impl rule__ValueObjectRightQuestion__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__ValueObjectRightQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueObjectRightQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__Group__0"


    // $ANTLR start "rule__ValueObjectRightQuestion__Group__0__Impl"
    // InternalSmaCQA.g:1709:1: rule__ValueObjectRightQuestion__Group__0__Impl : ( ( rule__ValueObjectRightQuestion__NameAssignment_0 ) ) ;
    public final void rule__ValueObjectRightQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1713:1: ( ( ( rule__ValueObjectRightQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:1714:1: ( ( rule__ValueObjectRightQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:1714:1: ( ( rule__ValueObjectRightQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:1715:2: ( rule__ValueObjectRightQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getValueObjectRightQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:1716:2: ( rule__ValueObjectRightQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:1716:3: rule__ValueObjectRightQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectRightQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectRightQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__Group__0__Impl"


    // $ANTLR start "rule__ValueObjectRightQuestion__Group__1"
    // InternalSmaCQA.g:1724:1: rule__ValueObjectRightQuestion__Group__1 : rule__ValueObjectRightQuestion__Group__1__Impl rule__ValueObjectRightQuestion__Group__2 ;
    public final void rule__ValueObjectRightQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1728:1: ( rule__ValueObjectRightQuestion__Group__1__Impl rule__ValueObjectRightQuestion__Group__2 )
            // InternalSmaCQA.g:1729:2: rule__ValueObjectRightQuestion__Group__1__Impl rule__ValueObjectRightQuestion__Group__2
            {
            pushFollow(FOLLOW_13);
            rule__ValueObjectRightQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueObjectRightQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__Group__1"


    // $ANTLR start "rule__ValueObjectRightQuestion__Group__1__Impl"
    // InternalSmaCQA.g:1736:1: rule__ValueObjectRightQuestion__Group__1__Impl : ( 'answer = ' ) ;
    public final void rule__ValueObjectRightQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1740:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:1741:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:1741:1: ( 'answer = ' )
            // InternalSmaCQA.g:1742:2: 'answer = '
            {
             before(grammarAccess.getValueObjectRightQuestionAccess().getAnswerKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getValueObjectRightQuestionAccess().getAnswerKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__Group__1__Impl"


    // $ANTLR start "rule__ValueObjectRightQuestion__Group__2"
    // InternalSmaCQA.g:1751:1: rule__ValueObjectRightQuestion__Group__2 : rule__ValueObjectRightQuestion__Group__2__Impl ;
    public final void rule__ValueObjectRightQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1755:1: ( rule__ValueObjectRightQuestion__Group__2__Impl )
            // InternalSmaCQA.g:1756:2: rule__ValueObjectRightQuestion__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectRightQuestion__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__Group__2"


    // $ANTLR start "rule__ValueObjectRightQuestion__Group__2__Impl"
    // InternalSmaCQA.g:1762:1: rule__ValueObjectRightQuestion__Group__2__Impl : ( ( rule__ValueObjectRightQuestion__AnswerAssignment_2 ) ) ;
    public final void rule__ValueObjectRightQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1766:1: ( ( ( rule__ValueObjectRightQuestion__AnswerAssignment_2 ) ) )
            // InternalSmaCQA.g:1767:1: ( ( rule__ValueObjectRightQuestion__AnswerAssignment_2 ) )
            {
            // InternalSmaCQA.g:1767:1: ( ( rule__ValueObjectRightQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:1768:2: ( rule__ValueObjectRightQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getValueObjectRightQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:1769:2: ( rule__ValueObjectRightQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:1769:3: rule__ValueObjectRightQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectRightQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectRightQuestionAccess().getAnswerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__Group__2__Impl"


    // $ANTLR start "rule__ValueObjectTokenQuestion__Group__0"
    // InternalSmaCQA.g:1778:1: rule__ValueObjectTokenQuestion__Group__0 : rule__ValueObjectTokenQuestion__Group__0__Impl rule__ValueObjectTokenQuestion__Group__1 ;
    public final void rule__ValueObjectTokenQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1782:1: ( rule__ValueObjectTokenQuestion__Group__0__Impl rule__ValueObjectTokenQuestion__Group__1 )
            // InternalSmaCQA.g:1783:2: rule__ValueObjectTokenQuestion__Group__0__Impl rule__ValueObjectTokenQuestion__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__ValueObjectTokenQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueObjectTokenQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTokenQuestion__Group__0"


    // $ANTLR start "rule__ValueObjectTokenQuestion__Group__0__Impl"
    // InternalSmaCQA.g:1790:1: rule__ValueObjectTokenQuestion__Group__0__Impl : ( ( rule__ValueObjectTokenQuestion__NameAssignment_0 ) ) ;
    public final void rule__ValueObjectTokenQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1794:1: ( ( ( rule__ValueObjectTokenQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:1795:1: ( ( rule__ValueObjectTokenQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:1795:1: ( ( rule__ValueObjectTokenQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:1796:2: ( rule__ValueObjectTokenQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getValueObjectTokenQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:1797:2: ( rule__ValueObjectTokenQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:1797:3: rule__ValueObjectTokenQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectTokenQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectTokenQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTokenQuestion__Group__0__Impl"


    // $ANTLR start "rule__ValueObjectTokenQuestion__Group__1"
    // InternalSmaCQA.g:1805:1: rule__ValueObjectTokenQuestion__Group__1 : rule__ValueObjectTokenQuestion__Group__1__Impl ;
    public final void rule__ValueObjectTokenQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1809:1: ( rule__ValueObjectTokenQuestion__Group__1__Impl )
            // InternalSmaCQA.g:1810:2: rule__ValueObjectTokenQuestion__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectTokenQuestion__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTokenQuestion__Group__1"


    // $ANTLR start "rule__ValueObjectTokenQuestion__Group__1__Impl"
    // InternalSmaCQA.g:1816:1: rule__ValueObjectTokenQuestion__Group__1__Impl : ( ( rule__ValueObjectTokenQuestion__AnswerAssignment_1 ) ) ;
    public final void rule__ValueObjectTokenQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1820:1: ( ( ( rule__ValueObjectTokenQuestion__AnswerAssignment_1 ) ) )
            // InternalSmaCQA.g:1821:1: ( ( rule__ValueObjectTokenQuestion__AnswerAssignment_1 ) )
            {
            // InternalSmaCQA.g:1821:1: ( ( rule__ValueObjectTokenQuestion__AnswerAssignment_1 ) )
            // InternalSmaCQA.g:1822:2: ( rule__ValueObjectTokenQuestion__AnswerAssignment_1 )
            {
             before(grammarAccess.getValueObjectTokenQuestionAccess().getAnswerAssignment_1()); 
            // InternalSmaCQA.g:1823:2: ( rule__ValueObjectTokenQuestion__AnswerAssignment_1 )
            // InternalSmaCQA.g:1823:3: rule__ValueObjectTokenQuestion__AnswerAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectTokenQuestion__AnswerAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectTokenQuestionAccess().getAnswerAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTokenQuestion__Group__1__Impl"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__Group__0"
    // InternalSmaCQA.g:1832:1: rule__ValueObjectTangibleQuestion__Group__0 : rule__ValueObjectTangibleQuestion__Group__0__Impl rule__ValueObjectTangibleQuestion__Group__1 ;
    public final void rule__ValueObjectTangibleQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1836:1: ( rule__ValueObjectTangibleQuestion__Group__0__Impl rule__ValueObjectTangibleQuestion__Group__1 )
            // InternalSmaCQA.g:1837:2: rule__ValueObjectTangibleQuestion__Group__0__Impl rule__ValueObjectTangibleQuestion__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__ValueObjectTangibleQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueObjectTangibleQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__Group__0"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__Group__0__Impl"
    // InternalSmaCQA.g:1844:1: rule__ValueObjectTangibleQuestion__Group__0__Impl : ( ( rule__ValueObjectTangibleQuestion__NameAssignment_0 ) ) ;
    public final void rule__ValueObjectTangibleQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1848:1: ( ( ( rule__ValueObjectTangibleQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:1849:1: ( ( rule__ValueObjectTangibleQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:1849:1: ( ( rule__ValueObjectTangibleQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:1850:2: ( rule__ValueObjectTangibleQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:1851:2: ( rule__ValueObjectTangibleQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:1851:3: rule__ValueObjectTangibleQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectTangibleQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectTangibleQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__Group__0__Impl"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__Group__1"
    // InternalSmaCQA.g:1859:1: rule__ValueObjectTangibleQuestion__Group__1 : rule__ValueObjectTangibleQuestion__Group__1__Impl rule__ValueObjectTangibleQuestion__Group__2 ;
    public final void rule__ValueObjectTangibleQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1863:1: ( rule__ValueObjectTangibleQuestion__Group__1__Impl rule__ValueObjectTangibleQuestion__Group__2 )
            // InternalSmaCQA.g:1864:2: rule__ValueObjectTangibleQuestion__Group__1__Impl rule__ValueObjectTangibleQuestion__Group__2
            {
            pushFollow(FOLLOW_16);
            rule__ValueObjectTangibleQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueObjectTangibleQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__Group__1"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__Group__1__Impl"
    // InternalSmaCQA.g:1871:1: rule__ValueObjectTangibleQuestion__Group__1__Impl : ( 'Data Declaration: ' ) ;
    public final void rule__ValueObjectTangibleQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1875:1: ( ( 'Data Declaration: ' ) )
            // InternalSmaCQA.g:1876:1: ( 'Data Declaration: ' )
            {
            // InternalSmaCQA.g:1876:1: ( 'Data Declaration: ' )
            // InternalSmaCQA.g:1877:2: 'Data Declaration: '
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getDataDeclarationKeyword_1()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getValueObjectTangibleQuestionAccess().getDataDeclarationKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__Group__1__Impl"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__Group__2"
    // InternalSmaCQA.g:1886:1: rule__ValueObjectTangibleQuestion__Group__2 : rule__ValueObjectTangibleQuestion__Group__2__Impl rule__ValueObjectTangibleQuestion__Group__3 ;
    public final void rule__ValueObjectTangibleQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1890:1: ( rule__ValueObjectTangibleQuestion__Group__2__Impl rule__ValueObjectTangibleQuestion__Group__3 )
            // InternalSmaCQA.g:1891:2: rule__ValueObjectTangibleQuestion__Group__2__Impl rule__ValueObjectTangibleQuestion__Group__3
            {
            pushFollow(FOLLOW_17);
            rule__ValueObjectTangibleQuestion__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ValueObjectTangibleQuestion__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__Group__2"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__Group__2__Impl"
    // InternalSmaCQA.g:1898:1: rule__ValueObjectTangibleQuestion__Group__2__Impl : ( ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 ) ) ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )* ) ) ;
    public final void rule__ValueObjectTangibleQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1902:1: ( ( ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 ) ) ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )* ) ) )
            // InternalSmaCQA.g:1903:1: ( ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 ) ) ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )* ) )
            {
            // InternalSmaCQA.g:1903:1: ( ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 ) ) ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )* ) )
            // InternalSmaCQA.g:1904:2: ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 ) ) ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )* )
            {
            // InternalSmaCQA.g:1904:2: ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:1905:3: ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:1906:3: ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:1906:4: rule__ValueObjectTangibleQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_18);
            rule__ValueObjectTangibleQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectTangibleQuestionAccess().getAnswerAssignment_2()); 

            }

            // InternalSmaCQA.g:1909:2: ( ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )* )
            // InternalSmaCQA.g:1910:3: ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )*
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:1911:3: ( rule__ValueObjectTangibleQuestion__AnswerAssignment_2 )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==37) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalSmaCQA.g:1911:4: rule__ValueObjectTangibleQuestion__AnswerAssignment_2
            	    {
            	    pushFollow(FOLLOW_18);
            	    rule__ValueObjectTangibleQuestion__AnswerAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

             after(grammarAccess.getValueObjectTangibleQuestionAccess().getAnswerAssignment_2()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__Group__2__Impl"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__Group__3"
    // InternalSmaCQA.g:1920:1: rule__ValueObjectTangibleQuestion__Group__3 : rule__ValueObjectTangibleQuestion__Group__3__Impl ;
    public final void rule__ValueObjectTangibleQuestion__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1924:1: ( rule__ValueObjectTangibleQuestion__Group__3__Impl )
            // InternalSmaCQA.g:1925:2: rule__ValueObjectTangibleQuestion__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectTangibleQuestion__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__Group__3"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__Group__3__Impl"
    // InternalSmaCQA.g:1931:1: rule__ValueObjectTangibleQuestion__Group__3__Impl : ( 'End Data Declaration' ) ;
    public final void rule__ValueObjectTangibleQuestion__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1935:1: ( ( 'End Data Declaration' ) )
            // InternalSmaCQA.g:1936:1: ( 'End Data Declaration' )
            {
            // InternalSmaCQA.g:1936:1: ( 'End Data Declaration' )
            // InternalSmaCQA.g:1937:2: 'End Data Declaration'
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getEndDataDeclarationKeyword_3()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getValueObjectTangibleQuestionAccess().getEndDataDeclarationKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__Group__3__Impl"


    // $ANTLR start "rule__DataRegister__Group__0"
    // InternalSmaCQA.g:1947:1: rule__DataRegister__Group__0 : rule__DataRegister__Group__0__Impl rule__DataRegister__Group__1 ;
    public final void rule__DataRegister__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1951:1: ( rule__DataRegister__Group__0__Impl rule__DataRegister__Group__1 )
            // InternalSmaCQA.g:1952:2: rule__DataRegister__Group__0__Impl rule__DataRegister__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__DataRegister__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataRegister__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__Group__0"


    // $ANTLR start "rule__DataRegister__Group__0__Impl"
    // InternalSmaCQA.g:1959:1: rule__DataRegister__Group__0__Impl : ( 'Data name: ' ) ;
    public final void rule__DataRegister__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1963:1: ( ( 'Data name: ' ) )
            // InternalSmaCQA.g:1964:1: ( 'Data name: ' )
            {
            // InternalSmaCQA.g:1964:1: ( 'Data name: ' )
            // InternalSmaCQA.g:1965:2: 'Data name: '
            {
             before(grammarAccess.getDataRegisterAccess().getDataNameKeyword_0()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getDataRegisterAccess().getDataNameKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__Group__0__Impl"


    // $ANTLR start "rule__DataRegister__Group__1"
    // InternalSmaCQA.g:1974:1: rule__DataRegister__Group__1 : rule__DataRegister__Group__1__Impl rule__DataRegister__Group__2 ;
    public final void rule__DataRegister__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1978:1: ( rule__DataRegister__Group__1__Impl rule__DataRegister__Group__2 )
            // InternalSmaCQA.g:1979:2: rule__DataRegister__Group__1__Impl rule__DataRegister__Group__2
            {
            pushFollow(FOLLOW_19);
            rule__DataRegister__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataRegister__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__Group__1"


    // $ANTLR start "rule__DataRegister__Group__1__Impl"
    // InternalSmaCQA.g:1986:1: rule__DataRegister__Group__1__Impl : ( ( rule__DataRegister__NameAssignment_1 ) ) ;
    public final void rule__DataRegister__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:1990:1: ( ( ( rule__DataRegister__NameAssignment_1 ) ) )
            // InternalSmaCQA.g:1991:1: ( ( rule__DataRegister__NameAssignment_1 ) )
            {
            // InternalSmaCQA.g:1991:1: ( ( rule__DataRegister__NameAssignment_1 ) )
            // InternalSmaCQA.g:1992:2: ( rule__DataRegister__NameAssignment_1 )
            {
             before(grammarAccess.getDataRegisterAccess().getNameAssignment_1()); 
            // InternalSmaCQA.g:1993:2: ( rule__DataRegister__NameAssignment_1 )
            // InternalSmaCQA.g:1993:3: rule__DataRegister__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__DataRegister__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getDataRegisterAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__Group__1__Impl"


    // $ANTLR start "rule__DataRegister__Group__2"
    // InternalSmaCQA.g:2001:1: rule__DataRegister__Group__2 : rule__DataRegister__Group__2__Impl rule__DataRegister__Group__3 ;
    public final void rule__DataRegister__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2005:1: ( rule__DataRegister__Group__2__Impl rule__DataRegister__Group__3 )
            // InternalSmaCQA.g:2006:2: rule__DataRegister__Group__2__Impl rule__DataRegister__Group__3
            {
            pushFollow(FOLLOW_20);
            rule__DataRegister__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataRegister__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__Group__2"


    // $ANTLR start "rule__DataRegister__Group__2__Impl"
    // InternalSmaCQA.g:2013:1: rule__DataRegister__Group__2__Impl : ( 'Value: ' ) ;
    public final void rule__DataRegister__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2017:1: ( ( 'Value: ' ) )
            // InternalSmaCQA.g:2018:1: ( 'Value: ' )
            {
            // InternalSmaCQA.g:2018:1: ( 'Value: ' )
            // InternalSmaCQA.g:2019:2: 'Value: '
            {
             before(grammarAccess.getDataRegisterAccess().getValueKeyword_2()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getDataRegisterAccess().getValueKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__Group__2__Impl"


    // $ANTLR start "rule__DataRegister__Group__3"
    // InternalSmaCQA.g:2028:1: rule__DataRegister__Group__3 : rule__DataRegister__Group__3__Impl ;
    public final void rule__DataRegister__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2032:1: ( rule__DataRegister__Group__3__Impl )
            // InternalSmaCQA.g:2033:2: rule__DataRegister__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DataRegister__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__Group__3"


    // $ANTLR start "rule__DataRegister__Group__3__Impl"
    // InternalSmaCQA.g:2039:1: rule__DataRegister__Group__3__Impl : ( ( rule__DataRegister__TypeAssignment_3 ) ) ;
    public final void rule__DataRegister__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2043:1: ( ( ( rule__DataRegister__TypeAssignment_3 ) ) )
            // InternalSmaCQA.g:2044:1: ( ( rule__DataRegister__TypeAssignment_3 ) )
            {
            // InternalSmaCQA.g:2044:1: ( ( rule__DataRegister__TypeAssignment_3 ) )
            // InternalSmaCQA.g:2045:2: ( rule__DataRegister__TypeAssignment_3 )
            {
             before(grammarAccess.getDataRegisterAccess().getTypeAssignment_3()); 
            // InternalSmaCQA.g:2046:2: ( rule__DataRegister__TypeAssignment_3 )
            // InternalSmaCQA.g:2046:3: rule__DataRegister__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__DataRegister__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getDataRegisterAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__Group__3__Impl"


    // $ANTLR start "rule__TokenERC20__Group__0"
    // InternalSmaCQA.g:2055:1: rule__TokenERC20__Group__0 : rule__TokenERC20__Group__0__Impl rule__TokenERC20__Group__1 ;
    public final void rule__TokenERC20__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2059:1: ( rule__TokenERC20__Group__0__Impl rule__TokenERC20__Group__1 )
            // InternalSmaCQA.g:2060:2: rule__TokenERC20__Group__0__Impl rule__TokenERC20__Group__1
            {
            pushFollow(FOLLOW_21);
            rule__TokenERC20__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__0"


    // $ANTLR start "rule__TokenERC20__Group__0__Impl"
    // InternalSmaCQA.g:2067:1: rule__TokenERC20__Group__0__Impl : ( 'Data Declaration Token ERC20: ' ) ;
    public final void rule__TokenERC20__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2071:1: ( ( 'Data Declaration Token ERC20: ' ) )
            // InternalSmaCQA.g:2072:1: ( 'Data Declaration Token ERC20: ' )
            {
            // InternalSmaCQA.g:2072:1: ( 'Data Declaration Token ERC20: ' )
            // InternalSmaCQA.g:2073:2: 'Data Declaration Token ERC20: '
            {
             before(grammarAccess.getTokenERC20Access().getDataDeclarationTokenERC20Keyword_0()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getDataDeclarationTokenERC20Keyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__0__Impl"


    // $ANTLR start "rule__TokenERC20__Group__1"
    // InternalSmaCQA.g:2082:1: rule__TokenERC20__Group__1 : rule__TokenERC20__Group__1__Impl rule__TokenERC20__Group__2 ;
    public final void rule__TokenERC20__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2086:1: ( rule__TokenERC20__Group__1__Impl rule__TokenERC20__Group__2 )
            // InternalSmaCQA.g:2087:2: rule__TokenERC20__Group__1__Impl rule__TokenERC20__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__TokenERC20__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__1"


    // $ANTLR start "rule__TokenERC20__Group__1__Impl"
    // InternalSmaCQA.g:2094:1: rule__TokenERC20__Group__1__Impl : ( 'Token ERC20 name: ' ) ;
    public final void rule__TokenERC20__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2098:1: ( ( 'Token ERC20 name: ' ) )
            // InternalSmaCQA.g:2099:1: ( 'Token ERC20 name: ' )
            {
            // InternalSmaCQA.g:2099:1: ( 'Token ERC20 name: ' )
            // InternalSmaCQA.g:2100:2: 'Token ERC20 name: '
            {
             before(grammarAccess.getTokenERC20Access().getTokenERC20NameKeyword_1()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getTokenERC20NameKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__1__Impl"


    // $ANTLR start "rule__TokenERC20__Group__2"
    // InternalSmaCQA.g:2109:1: rule__TokenERC20__Group__2 : rule__TokenERC20__Group__2__Impl rule__TokenERC20__Group__3 ;
    public final void rule__TokenERC20__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2113:1: ( rule__TokenERC20__Group__2__Impl rule__TokenERC20__Group__3 )
            // InternalSmaCQA.g:2114:2: rule__TokenERC20__Group__2__Impl rule__TokenERC20__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__TokenERC20__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__2"


    // $ANTLR start "rule__TokenERC20__Group__2__Impl"
    // InternalSmaCQA.g:2121:1: rule__TokenERC20__Group__2__Impl : ( ( rule__TokenERC20__NameAssignment_2 ) ) ;
    public final void rule__TokenERC20__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2125:1: ( ( ( rule__TokenERC20__NameAssignment_2 ) ) )
            // InternalSmaCQA.g:2126:1: ( ( rule__TokenERC20__NameAssignment_2 ) )
            {
            // InternalSmaCQA.g:2126:1: ( ( rule__TokenERC20__NameAssignment_2 ) )
            // InternalSmaCQA.g:2127:2: ( rule__TokenERC20__NameAssignment_2 )
            {
             before(grammarAccess.getTokenERC20Access().getNameAssignment_2()); 
            // InternalSmaCQA.g:2128:2: ( rule__TokenERC20__NameAssignment_2 )
            // InternalSmaCQA.g:2128:3: rule__TokenERC20__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__2__Impl"


    // $ANTLR start "rule__TokenERC20__Group__3"
    // InternalSmaCQA.g:2136:1: rule__TokenERC20__Group__3 : rule__TokenERC20__Group__3__Impl rule__TokenERC20__Group__4 ;
    public final void rule__TokenERC20__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2140:1: ( rule__TokenERC20__Group__3__Impl rule__TokenERC20__Group__4 )
            // InternalSmaCQA.g:2141:2: rule__TokenERC20__Group__3__Impl rule__TokenERC20__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__TokenERC20__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__3"


    // $ANTLR start "rule__TokenERC20__Group__3__Impl"
    // InternalSmaCQA.g:2148:1: rule__TokenERC20__Group__3__Impl : ( 'Token ERC20 Symbol: ' ) ;
    public final void rule__TokenERC20__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2152:1: ( ( 'Token ERC20 Symbol: ' ) )
            // InternalSmaCQA.g:2153:1: ( 'Token ERC20 Symbol: ' )
            {
            // InternalSmaCQA.g:2153:1: ( 'Token ERC20 Symbol: ' )
            // InternalSmaCQA.g:2154:2: 'Token ERC20 Symbol: '
            {
             before(grammarAccess.getTokenERC20Access().getTokenERC20SymbolKeyword_3()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getTokenERC20SymbolKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__3__Impl"


    // $ANTLR start "rule__TokenERC20__Group__4"
    // InternalSmaCQA.g:2163:1: rule__TokenERC20__Group__4 : rule__TokenERC20__Group__4__Impl rule__TokenERC20__Group__5 ;
    public final void rule__TokenERC20__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2167:1: ( rule__TokenERC20__Group__4__Impl rule__TokenERC20__Group__5 )
            // InternalSmaCQA.g:2168:2: rule__TokenERC20__Group__4__Impl rule__TokenERC20__Group__5
            {
            pushFollow(FOLLOW_23);
            rule__TokenERC20__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__4"


    // $ANTLR start "rule__TokenERC20__Group__4__Impl"
    // InternalSmaCQA.g:2175:1: rule__TokenERC20__Group__4__Impl : ( ( rule__TokenERC20__SymbolAssignment_4 ) ) ;
    public final void rule__TokenERC20__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2179:1: ( ( ( rule__TokenERC20__SymbolAssignment_4 ) ) )
            // InternalSmaCQA.g:2180:1: ( ( rule__TokenERC20__SymbolAssignment_4 ) )
            {
            // InternalSmaCQA.g:2180:1: ( ( rule__TokenERC20__SymbolAssignment_4 ) )
            // InternalSmaCQA.g:2181:2: ( rule__TokenERC20__SymbolAssignment_4 )
            {
             before(grammarAccess.getTokenERC20Access().getSymbolAssignment_4()); 
            // InternalSmaCQA.g:2182:2: ( rule__TokenERC20__SymbolAssignment_4 )
            // InternalSmaCQA.g:2182:3: rule__TokenERC20__SymbolAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__SymbolAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getSymbolAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__4__Impl"


    // $ANTLR start "rule__TokenERC20__Group__5"
    // InternalSmaCQA.g:2190:1: rule__TokenERC20__Group__5 : rule__TokenERC20__Group__5__Impl rule__TokenERC20__Group__6 ;
    public final void rule__TokenERC20__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2194:1: ( rule__TokenERC20__Group__5__Impl rule__TokenERC20__Group__6 )
            // InternalSmaCQA.g:2195:2: rule__TokenERC20__Group__5__Impl rule__TokenERC20__Group__6
            {
            pushFollow(FOLLOW_24);
            rule__TokenERC20__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__5"


    // $ANTLR start "rule__TokenERC20__Group__5__Impl"
    // InternalSmaCQA.g:2202:1: rule__TokenERC20__Group__5__Impl : ( 'Token ERC20 decimals: ' ) ;
    public final void rule__TokenERC20__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2206:1: ( ( 'Token ERC20 decimals: ' ) )
            // InternalSmaCQA.g:2207:1: ( 'Token ERC20 decimals: ' )
            {
            // InternalSmaCQA.g:2207:1: ( 'Token ERC20 decimals: ' )
            // InternalSmaCQA.g:2208:2: 'Token ERC20 decimals: '
            {
             before(grammarAccess.getTokenERC20Access().getTokenERC20DecimalsKeyword_5()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getTokenERC20DecimalsKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__5__Impl"


    // $ANTLR start "rule__TokenERC20__Group__6"
    // InternalSmaCQA.g:2217:1: rule__TokenERC20__Group__6 : rule__TokenERC20__Group__6__Impl rule__TokenERC20__Group__7 ;
    public final void rule__TokenERC20__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2221:1: ( rule__TokenERC20__Group__6__Impl rule__TokenERC20__Group__7 )
            // InternalSmaCQA.g:2222:2: rule__TokenERC20__Group__6__Impl rule__TokenERC20__Group__7
            {
            pushFollow(FOLLOW_25);
            rule__TokenERC20__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__6"


    // $ANTLR start "rule__TokenERC20__Group__6__Impl"
    // InternalSmaCQA.g:2229:1: rule__TokenERC20__Group__6__Impl : ( ( rule__TokenERC20__DecimalsAssignment_6 ) ) ;
    public final void rule__TokenERC20__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2233:1: ( ( ( rule__TokenERC20__DecimalsAssignment_6 ) ) )
            // InternalSmaCQA.g:2234:1: ( ( rule__TokenERC20__DecimalsAssignment_6 ) )
            {
            // InternalSmaCQA.g:2234:1: ( ( rule__TokenERC20__DecimalsAssignment_6 ) )
            // InternalSmaCQA.g:2235:2: ( rule__TokenERC20__DecimalsAssignment_6 )
            {
             before(grammarAccess.getTokenERC20Access().getDecimalsAssignment_6()); 
            // InternalSmaCQA.g:2236:2: ( rule__TokenERC20__DecimalsAssignment_6 )
            // InternalSmaCQA.g:2236:3: rule__TokenERC20__DecimalsAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__DecimalsAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getDecimalsAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__6__Impl"


    // $ANTLR start "rule__TokenERC20__Group__7"
    // InternalSmaCQA.g:2244:1: rule__TokenERC20__Group__7 : rule__TokenERC20__Group__7__Impl rule__TokenERC20__Group__8 ;
    public final void rule__TokenERC20__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2248:1: ( rule__TokenERC20__Group__7__Impl rule__TokenERC20__Group__8 )
            // InternalSmaCQA.g:2249:2: rule__TokenERC20__Group__7__Impl rule__TokenERC20__Group__8
            {
            pushFollow(FOLLOW_24);
            rule__TokenERC20__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__7"


    // $ANTLR start "rule__TokenERC20__Group__7__Impl"
    // InternalSmaCQA.g:2256:1: rule__TokenERC20__Group__7__Impl : ( 'Token ERC20 supply: ' ) ;
    public final void rule__TokenERC20__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2260:1: ( ( 'Token ERC20 supply: ' ) )
            // InternalSmaCQA.g:2261:1: ( 'Token ERC20 supply: ' )
            {
            // InternalSmaCQA.g:2261:1: ( 'Token ERC20 supply: ' )
            // InternalSmaCQA.g:2262:2: 'Token ERC20 supply: '
            {
             before(grammarAccess.getTokenERC20Access().getTokenERC20SupplyKeyword_7()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getTokenERC20SupplyKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__7__Impl"


    // $ANTLR start "rule__TokenERC20__Group__8"
    // InternalSmaCQA.g:2271:1: rule__TokenERC20__Group__8 : rule__TokenERC20__Group__8__Impl rule__TokenERC20__Group__9 ;
    public final void rule__TokenERC20__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2275:1: ( rule__TokenERC20__Group__8__Impl rule__TokenERC20__Group__9 )
            // InternalSmaCQA.g:2276:2: rule__TokenERC20__Group__8__Impl rule__TokenERC20__Group__9
            {
            pushFollow(FOLLOW_26);
            rule__TokenERC20__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__8"


    // $ANTLR start "rule__TokenERC20__Group__8__Impl"
    // InternalSmaCQA.g:2283:1: rule__TokenERC20__Group__8__Impl : ( ( rule__TokenERC20__SupplyAssignment_8 ) ) ;
    public final void rule__TokenERC20__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2287:1: ( ( ( rule__TokenERC20__SupplyAssignment_8 ) ) )
            // InternalSmaCQA.g:2288:1: ( ( rule__TokenERC20__SupplyAssignment_8 ) )
            {
            // InternalSmaCQA.g:2288:1: ( ( rule__TokenERC20__SupplyAssignment_8 ) )
            // InternalSmaCQA.g:2289:2: ( rule__TokenERC20__SupplyAssignment_8 )
            {
             before(grammarAccess.getTokenERC20Access().getSupplyAssignment_8()); 
            // InternalSmaCQA.g:2290:2: ( rule__TokenERC20__SupplyAssignment_8 )
            // InternalSmaCQA.g:2290:3: rule__TokenERC20__SupplyAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__SupplyAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getSupplyAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__8__Impl"


    // $ANTLR start "rule__TokenERC20__Group__9"
    // InternalSmaCQA.g:2298:1: rule__TokenERC20__Group__9 : rule__TokenERC20__Group__9__Impl rule__TokenERC20__Group__10 ;
    public final void rule__TokenERC20__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2302:1: ( rule__TokenERC20__Group__9__Impl rule__TokenERC20__Group__10 )
            // InternalSmaCQA.g:2303:2: rule__TokenERC20__Group__9__Impl rule__TokenERC20__Group__10
            {
            pushFollow(FOLLOW_12);
            rule__TokenERC20__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__9"


    // $ANTLR start "rule__TokenERC20__Group__9__Impl"
    // InternalSmaCQA.g:2310:1: rule__TokenERC20__Group__9__Impl : ( '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' ) ;
    public final void rule__TokenERC20__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2314:1: ( ( '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' ) )
            // InternalSmaCQA.g:2315:1: ( '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' )
            {
            // InternalSmaCQA.g:2315:1: ( '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' )
            // InternalSmaCQA.g:2316:2: '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?'
            {
             before(grammarAccess.getTokenERC20Access().getIsItPossibleToIncreaseTheTotalSupplyOnceItIsAlreadyInCirculationMintMoreKeyword_9()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getIsItPossibleToIncreaseTheTotalSupplyOnceItIsAlreadyInCirculationMintMoreKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__9__Impl"


    // $ANTLR start "rule__TokenERC20__Group__10"
    // InternalSmaCQA.g:2325:1: rule__TokenERC20__Group__10 : rule__TokenERC20__Group__10__Impl rule__TokenERC20__Group__11 ;
    public final void rule__TokenERC20__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2329:1: ( rule__TokenERC20__Group__10__Impl rule__TokenERC20__Group__11 )
            // InternalSmaCQA.g:2330:2: rule__TokenERC20__Group__10__Impl rule__TokenERC20__Group__11
            {
            pushFollow(FOLLOW_13);
            rule__TokenERC20__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__10"


    // $ANTLR start "rule__TokenERC20__Group__10__Impl"
    // InternalSmaCQA.g:2337:1: rule__TokenERC20__Group__10__Impl : ( 'answer = ' ) ;
    public final void rule__TokenERC20__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2341:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:2342:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:2342:1: ( 'answer = ' )
            // InternalSmaCQA.g:2343:2: 'answer = '
            {
             before(grammarAccess.getTokenERC20Access().getAnswerKeyword_10()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getAnswerKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__10__Impl"


    // $ANTLR start "rule__TokenERC20__Group__11"
    // InternalSmaCQA.g:2352:1: rule__TokenERC20__Group__11 : rule__TokenERC20__Group__11__Impl rule__TokenERC20__Group__12 ;
    public final void rule__TokenERC20__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2356:1: ( rule__TokenERC20__Group__11__Impl rule__TokenERC20__Group__12 )
            // InternalSmaCQA.g:2357:2: rule__TokenERC20__Group__11__Impl rule__TokenERC20__Group__12
            {
            pushFollow(FOLLOW_27);
            rule__TokenERC20__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__11"


    // $ANTLR start "rule__TokenERC20__Group__11__Impl"
    // InternalSmaCQA.g:2364:1: rule__TokenERC20__Group__11__Impl : ( ( rule__TokenERC20__AnswerMintSentenceAssignment_11 ) ) ;
    public final void rule__TokenERC20__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2368:1: ( ( ( rule__TokenERC20__AnswerMintSentenceAssignment_11 ) ) )
            // InternalSmaCQA.g:2369:1: ( ( rule__TokenERC20__AnswerMintSentenceAssignment_11 ) )
            {
            // InternalSmaCQA.g:2369:1: ( ( rule__TokenERC20__AnswerMintSentenceAssignment_11 ) )
            // InternalSmaCQA.g:2370:2: ( rule__TokenERC20__AnswerMintSentenceAssignment_11 )
            {
             before(grammarAccess.getTokenERC20Access().getAnswerMintSentenceAssignment_11()); 
            // InternalSmaCQA.g:2371:2: ( rule__TokenERC20__AnswerMintSentenceAssignment_11 )
            // InternalSmaCQA.g:2371:3: rule__TokenERC20__AnswerMintSentenceAssignment_11
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__AnswerMintSentenceAssignment_11();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getAnswerMintSentenceAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__11__Impl"


    // $ANTLR start "rule__TokenERC20__Group__12"
    // InternalSmaCQA.g:2379:1: rule__TokenERC20__Group__12 : rule__TokenERC20__Group__12__Impl rule__TokenERC20__Group__13 ;
    public final void rule__TokenERC20__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2383:1: ( rule__TokenERC20__Group__12__Impl rule__TokenERC20__Group__13 )
            // InternalSmaCQA.g:2384:2: rule__TokenERC20__Group__12__Impl rule__TokenERC20__Group__13
            {
            pushFollow(FOLLOW_12);
            rule__TokenERC20__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__12"


    // $ANTLR start "rule__TokenERC20__Group__12__Impl"
    // InternalSmaCQA.g:2391:1: rule__TokenERC20__Group__12__Impl : ( '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' ) ;
    public final void rule__TokenERC20__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2395:1: ( ( '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' ) )
            // InternalSmaCQA.g:2396:1: ( '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' )
            {
            // InternalSmaCQA.g:2396:1: ( '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' )
            // InternalSmaCQA.g:2397:2: '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?'
            {
             before(grammarAccess.getTokenERC20Access().getIsItPossibleToRemoveACertainAmountOfTokenFromCirculationBurnTokenKeyword_12()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getIsItPossibleToRemoveACertainAmountOfTokenFromCirculationBurnTokenKeyword_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__12__Impl"


    // $ANTLR start "rule__TokenERC20__Group__13"
    // InternalSmaCQA.g:2406:1: rule__TokenERC20__Group__13 : rule__TokenERC20__Group__13__Impl rule__TokenERC20__Group__14 ;
    public final void rule__TokenERC20__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2410:1: ( rule__TokenERC20__Group__13__Impl rule__TokenERC20__Group__14 )
            // InternalSmaCQA.g:2411:2: rule__TokenERC20__Group__13__Impl rule__TokenERC20__Group__14
            {
            pushFollow(FOLLOW_13);
            rule__TokenERC20__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__13"


    // $ANTLR start "rule__TokenERC20__Group__13__Impl"
    // InternalSmaCQA.g:2418:1: rule__TokenERC20__Group__13__Impl : ( 'answer = ' ) ;
    public final void rule__TokenERC20__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2422:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:2423:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:2423:1: ( 'answer = ' )
            // InternalSmaCQA.g:2424:2: 'answer = '
            {
             before(grammarAccess.getTokenERC20Access().getAnswerKeyword_13()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getAnswerKeyword_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__13__Impl"


    // $ANTLR start "rule__TokenERC20__Group__14"
    // InternalSmaCQA.g:2433:1: rule__TokenERC20__Group__14 : rule__TokenERC20__Group__14__Impl rule__TokenERC20__Group__15 ;
    public final void rule__TokenERC20__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2437:1: ( rule__TokenERC20__Group__14__Impl rule__TokenERC20__Group__15 )
            // InternalSmaCQA.g:2438:2: rule__TokenERC20__Group__14__Impl rule__TokenERC20__Group__15
            {
            pushFollow(FOLLOW_28);
            rule__TokenERC20__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__14"


    // $ANTLR start "rule__TokenERC20__Group__14__Impl"
    // InternalSmaCQA.g:2445:1: rule__TokenERC20__Group__14__Impl : ( ( rule__TokenERC20__AnswerBurnSentenceAssignment_14 ) ) ;
    public final void rule__TokenERC20__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2449:1: ( ( ( rule__TokenERC20__AnswerBurnSentenceAssignment_14 ) ) )
            // InternalSmaCQA.g:2450:1: ( ( rule__TokenERC20__AnswerBurnSentenceAssignment_14 ) )
            {
            // InternalSmaCQA.g:2450:1: ( ( rule__TokenERC20__AnswerBurnSentenceAssignment_14 ) )
            // InternalSmaCQA.g:2451:2: ( rule__TokenERC20__AnswerBurnSentenceAssignment_14 )
            {
             before(grammarAccess.getTokenERC20Access().getAnswerBurnSentenceAssignment_14()); 
            // InternalSmaCQA.g:2452:2: ( rule__TokenERC20__AnswerBurnSentenceAssignment_14 )
            // InternalSmaCQA.g:2452:3: rule__TokenERC20__AnswerBurnSentenceAssignment_14
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__AnswerBurnSentenceAssignment_14();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getAnswerBurnSentenceAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__14__Impl"


    // $ANTLR start "rule__TokenERC20__Group__15"
    // InternalSmaCQA.g:2460:1: rule__TokenERC20__Group__15 : rule__TokenERC20__Group__15__Impl ;
    public final void rule__TokenERC20__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2464:1: ( rule__TokenERC20__Group__15__Impl )
            // InternalSmaCQA.g:2465:2: rule__TokenERC20__Group__15__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__Group__15__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__15"


    // $ANTLR start "rule__TokenERC20__Group__15__Impl"
    // InternalSmaCQA.g:2471:1: rule__TokenERC20__Group__15__Impl : ( 'End Data Declaration Token ERC20' ) ;
    public final void rule__TokenERC20__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2475:1: ( ( 'End Data Declaration Token ERC20' ) )
            // InternalSmaCQA.g:2476:1: ( 'End Data Declaration Token ERC20' )
            {
            // InternalSmaCQA.g:2476:1: ( 'End Data Declaration Token ERC20' )
            // InternalSmaCQA.g:2477:2: 'End Data Declaration Token ERC20'
            {
             before(grammarAccess.getTokenERC20Access().getEndDataDeclarationTokenERC20Keyword_15()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getEndDataDeclarationTokenERC20Keyword_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__Group__15__Impl"


    // $ANTLR start "rule__TokenERC223__Group__0"
    // InternalSmaCQA.g:2487:1: rule__TokenERC223__Group__0 : rule__TokenERC223__Group__0__Impl rule__TokenERC223__Group__1 ;
    public final void rule__TokenERC223__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2491:1: ( rule__TokenERC223__Group__0__Impl rule__TokenERC223__Group__1 )
            // InternalSmaCQA.g:2492:2: rule__TokenERC223__Group__0__Impl rule__TokenERC223__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__TokenERC223__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__0"


    // $ANTLR start "rule__TokenERC223__Group__0__Impl"
    // InternalSmaCQA.g:2499:1: rule__TokenERC223__Group__0__Impl : ( 'Data Declaration Token ERC223: ' ) ;
    public final void rule__TokenERC223__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2503:1: ( ( 'Data Declaration Token ERC223: ' ) )
            // InternalSmaCQA.g:2504:1: ( 'Data Declaration Token ERC223: ' )
            {
            // InternalSmaCQA.g:2504:1: ( 'Data Declaration Token ERC223: ' )
            // InternalSmaCQA.g:2505:2: 'Data Declaration Token ERC223: '
            {
             before(grammarAccess.getTokenERC223Access().getDataDeclarationTokenERC223Keyword_0()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getDataDeclarationTokenERC223Keyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__0__Impl"


    // $ANTLR start "rule__TokenERC223__Group__1"
    // InternalSmaCQA.g:2514:1: rule__TokenERC223__Group__1 : rule__TokenERC223__Group__1__Impl rule__TokenERC223__Group__2 ;
    public final void rule__TokenERC223__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2518:1: ( rule__TokenERC223__Group__1__Impl rule__TokenERC223__Group__2 )
            // InternalSmaCQA.g:2519:2: rule__TokenERC223__Group__1__Impl rule__TokenERC223__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__TokenERC223__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__1"


    // $ANTLR start "rule__TokenERC223__Group__1__Impl"
    // InternalSmaCQA.g:2526:1: rule__TokenERC223__Group__1__Impl : ( 'Token ERC223 name: ' ) ;
    public final void rule__TokenERC223__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2530:1: ( ( 'Token ERC223 name: ' ) )
            // InternalSmaCQA.g:2531:1: ( 'Token ERC223 name: ' )
            {
            // InternalSmaCQA.g:2531:1: ( 'Token ERC223 name: ' )
            // InternalSmaCQA.g:2532:2: 'Token ERC223 name: '
            {
             before(grammarAccess.getTokenERC223Access().getTokenERC223NameKeyword_1()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getTokenERC223NameKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__1__Impl"


    // $ANTLR start "rule__TokenERC223__Group__2"
    // InternalSmaCQA.g:2541:1: rule__TokenERC223__Group__2 : rule__TokenERC223__Group__2__Impl rule__TokenERC223__Group__3 ;
    public final void rule__TokenERC223__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2545:1: ( rule__TokenERC223__Group__2__Impl rule__TokenERC223__Group__3 )
            // InternalSmaCQA.g:2546:2: rule__TokenERC223__Group__2__Impl rule__TokenERC223__Group__3
            {
            pushFollow(FOLLOW_30);
            rule__TokenERC223__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__2"


    // $ANTLR start "rule__TokenERC223__Group__2__Impl"
    // InternalSmaCQA.g:2553:1: rule__TokenERC223__Group__2__Impl : ( ( rule__TokenERC223__NameAssignment_2 ) ) ;
    public final void rule__TokenERC223__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2557:1: ( ( ( rule__TokenERC223__NameAssignment_2 ) ) )
            // InternalSmaCQA.g:2558:1: ( ( rule__TokenERC223__NameAssignment_2 ) )
            {
            // InternalSmaCQA.g:2558:1: ( ( rule__TokenERC223__NameAssignment_2 ) )
            // InternalSmaCQA.g:2559:2: ( rule__TokenERC223__NameAssignment_2 )
            {
             before(grammarAccess.getTokenERC223Access().getNameAssignment_2()); 
            // InternalSmaCQA.g:2560:2: ( rule__TokenERC223__NameAssignment_2 )
            // InternalSmaCQA.g:2560:3: rule__TokenERC223__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__2__Impl"


    // $ANTLR start "rule__TokenERC223__Group__3"
    // InternalSmaCQA.g:2568:1: rule__TokenERC223__Group__3 : rule__TokenERC223__Group__3__Impl rule__TokenERC223__Group__4 ;
    public final void rule__TokenERC223__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2572:1: ( rule__TokenERC223__Group__3__Impl rule__TokenERC223__Group__4 )
            // InternalSmaCQA.g:2573:2: rule__TokenERC223__Group__3__Impl rule__TokenERC223__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__TokenERC223__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__3"


    // $ANTLR start "rule__TokenERC223__Group__3__Impl"
    // InternalSmaCQA.g:2580:1: rule__TokenERC223__Group__3__Impl : ( 'Token ERC223 Symbol: ' ) ;
    public final void rule__TokenERC223__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2584:1: ( ( 'Token ERC223 Symbol: ' ) )
            // InternalSmaCQA.g:2585:1: ( 'Token ERC223 Symbol: ' )
            {
            // InternalSmaCQA.g:2585:1: ( 'Token ERC223 Symbol: ' )
            // InternalSmaCQA.g:2586:2: 'Token ERC223 Symbol: '
            {
             before(grammarAccess.getTokenERC223Access().getTokenERC223SymbolKeyword_3()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getTokenERC223SymbolKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__3__Impl"


    // $ANTLR start "rule__TokenERC223__Group__4"
    // InternalSmaCQA.g:2595:1: rule__TokenERC223__Group__4 : rule__TokenERC223__Group__4__Impl rule__TokenERC223__Group__5 ;
    public final void rule__TokenERC223__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2599:1: ( rule__TokenERC223__Group__4__Impl rule__TokenERC223__Group__5 )
            // InternalSmaCQA.g:2600:2: rule__TokenERC223__Group__4__Impl rule__TokenERC223__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__TokenERC223__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__4"


    // $ANTLR start "rule__TokenERC223__Group__4__Impl"
    // InternalSmaCQA.g:2607:1: rule__TokenERC223__Group__4__Impl : ( ( rule__TokenERC223__SymbolAssignment_4 ) ) ;
    public final void rule__TokenERC223__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2611:1: ( ( ( rule__TokenERC223__SymbolAssignment_4 ) ) )
            // InternalSmaCQA.g:2612:1: ( ( rule__TokenERC223__SymbolAssignment_4 ) )
            {
            // InternalSmaCQA.g:2612:1: ( ( rule__TokenERC223__SymbolAssignment_4 ) )
            // InternalSmaCQA.g:2613:2: ( rule__TokenERC223__SymbolAssignment_4 )
            {
             before(grammarAccess.getTokenERC223Access().getSymbolAssignment_4()); 
            // InternalSmaCQA.g:2614:2: ( rule__TokenERC223__SymbolAssignment_4 )
            // InternalSmaCQA.g:2614:3: rule__TokenERC223__SymbolAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__SymbolAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getSymbolAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__4__Impl"


    // $ANTLR start "rule__TokenERC223__Group__5"
    // InternalSmaCQA.g:2622:1: rule__TokenERC223__Group__5 : rule__TokenERC223__Group__5__Impl rule__TokenERC223__Group__6 ;
    public final void rule__TokenERC223__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2626:1: ( rule__TokenERC223__Group__5__Impl rule__TokenERC223__Group__6 )
            // InternalSmaCQA.g:2627:2: rule__TokenERC223__Group__5__Impl rule__TokenERC223__Group__6
            {
            pushFollow(FOLLOW_24);
            rule__TokenERC223__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__5"


    // $ANTLR start "rule__TokenERC223__Group__5__Impl"
    // InternalSmaCQA.g:2634:1: rule__TokenERC223__Group__5__Impl : ( 'Token ERC223 decimals: ' ) ;
    public final void rule__TokenERC223__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2638:1: ( ( 'Token ERC223 decimals: ' ) )
            // InternalSmaCQA.g:2639:1: ( 'Token ERC223 decimals: ' )
            {
            // InternalSmaCQA.g:2639:1: ( 'Token ERC223 decimals: ' )
            // InternalSmaCQA.g:2640:2: 'Token ERC223 decimals: '
            {
             before(grammarAccess.getTokenERC223Access().getTokenERC223DecimalsKeyword_5()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getTokenERC223DecimalsKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__5__Impl"


    // $ANTLR start "rule__TokenERC223__Group__6"
    // InternalSmaCQA.g:2649:1: rule__TokenERC223__Group__6 : rule__TokenERC223__Group__6__Impl rule__TokenERC223__Group__7 ;
    public final void rule__TokenERC223__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2653:1: ( rule__TokenERC223__Group__6__Impl rule__TokenERC223__Group__7 )
            // InternalSmaCQA.g:2654:2: rule__TokenERC223__Group__6__Impl rule__TokenERC223__Group__7
            {
            pushFollow(FOLLOW_32);
            rule__TokenERC223__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__6"


    // $ANTLR start "rule__TokenERC223__Group__6__Impl"
    // InternalSmaCQA.g:2661:1: rule__TokenERC223__Group__6__Impl : ( ( rule__TokenERC223__DecimalsAssignment_6 ) ) ;
    public final void rule__TokenERC223__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2665:1: ( ( ( rule__TokenERC223__DecimalsAssignment_6 ) ) )
            // InternalSmaCQA.g:2666:1: ( ( rule__TokenERC223__DecimalsAssignment_6 ) )
            {
            // InternalSmaCQA.g:2666:1: ( ( rule__TokenERC223__DecimalsAssignment_6 ) )
            // InternalSmaCQA.g:2667:2: ( rule__TokenERC223__DecimalsAssignment_6 )
            {
             before(grammarAccess.getTokenERC223Access().getDecimalsAssignment_6()); 
            // InternalSmaCQA.g:2668:2: ( rule__TokenERC223__DecimalsAssignment_6 )
            // InternalSmaCQA.g:2668:3: rule__TokenERC223__DecimalsAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__DecimalsAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getDecimalsAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__6__Impl"


    // $ANTLR start "rule__TokenERC223__Group__7"
    // InternalSmaCQA.g:2676:1: rule__TokenERC223__Group__7 : rule__TokenERC223__Group__7__Impl rule__TokenERC223__Group__8 ;
    public final void rule__TokenERC223__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2680:1: ( rule__TokenERC223__Group__7__Impl rule__TokenERC223__Group__8 )
            // InternalSmaCQA.g:2681:2: rule__TokenERC223__Group__7__Impl rule__TokenERC223__Group__8
            {
            pushFollow(FOLLOW_24);
            rule__TokenERC223__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__7"


    // $ANTLR start "rule__TokenERC223__Group__7__Impl"
    // InternalSmaCQA.g:2688:1: rule__TokenERC223__Group__7__Impl : ( 'Token ERC223 supply: ' ) ;
    public final void rule__TokenERC223__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2692:1: ( ( 'Token ERC223 supply: ' ) )
            // InternalSmaCQA.g:2693:1: ( 'Token ERC223 supply: ' )
            {
            // InternalSmaCQA.g:2693:1: ( 'Token ERC223 supply: ' )
            // InternalSmaCQA.g:2694:2: 'Token ERC223 supply: '
            {
             before(grammarAccess.getTokenERC223Access().getTokenERC223SupplyKeyword_7()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getTokenERC223SupplyKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__7__Impl"


    // $ANTLR start "rule__TokenERC223__Group__8"
    // InternalSmaCQA.g:2703:1: rule__TokenERC223__Group__8 : rule__TokenERC223__Group__8__Impl rule__TokenERC223__Group__9 ;
    public final void rule__TokenERC223__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2707:1: ( rule__TokenERC223__Group__8__Impl rule__TokenERC223__Group__9 )
            // InternalSmaCQA.g:2708:2: rule__TokenERC223__Group__8__Impl rule__TokenERC223__Group__9
            {
            pushFollow(FOLLOW_26);
            rule__TokenERC223__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__8"


    // $ANTLR start "rule__TokenERC223__Group__8__Impl"
    // InternalSmaCQA.g:2715:1: rule__TokenERC223__Group__8__Impl : ( ( rule__TokenERC223__SupplyAssignment_8 ) ) ;
    public final void rule__TokenERC223__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2719:1: ( ( ( rule__TokenERC223__SupplyAssignment_8 ) ) )
            // InternalSmaCQA.g:2720:1: ( ( rule__TokenERC223__SupplyAssignment_8 ) )
            {
            // InternalSmaCQA.g:2720:1: ( ( rule__TokenERC223__SupplyAssignment_8 ) )
            // InternalSmaCQA.g:2721:2: ( rule__TokenERC223__SupplyAssignment_8 )
            {
             before(grammarAccess.getTokenERC223Access().getSupplyAssignment_8()); 
            // InternalSmaCQA.g:2722:2: ( rule__TokenERC223__SupplyAssignment_8 )
            // InternalSmaCQA.g:2722:3: rule__TokenERC223__SupplyAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__SupplyAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getSupplyAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__8__Impl"


    // $ANTLR start "rule__TokenERC223__Group__9"
    // InternalSmaCQA.g:2730:1: rule__TokenERC223__Group__9 : rule__TokenERC223__Group__9__Impl rule__TokenERC223__Group__10 ;
    public final void rule__TokenERC223__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2734:1: ( rule__TokenERC223__Group__9__Impl rule__TokenERC223__Group__10 )
            // InternalSmaCQA.g:2735:2: rule__TokenERC223__Group__9__Impl rule__TokenERC223__Group__10
            {
            pushFollow(FOLLOW_12);
            rule__TokenERC223__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__9"


    // $ANTLR start "rule__TokenERC223__Group__9__Impl"
    // InternalSmaCQA.g:2742:1: rule__TokenERC223__Group__9__Impl : ( '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' ) ;
    public final void rule__TokenERC223__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2746:1: ( ( '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' ) )
            // InternalSmaCQA.g:2747:1: ( '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' )
            {
            // InternalSmaCQA.g:2747:1: ( '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' )
            // InternalSmaCQA.g:2748:2: '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?'
            {
             before(grammarAccess.getTokenERC223Access().getIsItPossibleToIncreaseTheTotalSupplyOnceItIsAlreadyInCirculationMintMoreKeyword_9()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getIsItPossibleToIncreaseTheTotalSupplyOnceItIsAlreadyInCirculationMintMoreKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__9__Impl"


    // $ANTLR start "rule__TokenERC223__Group__10"
    // InternalSmaCQA.g:2757:1: rule__TokenERC223__Group__10 : rule__TokenERC223__Group__10__Impl rule__TokenERC223__Group__11 ;
    public final void rule__TokenERC223__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2761:1: ( rule__TokenERC223__Group__10__Impl rule__TokenERC223__Group__11 )
            // InternalSmaCQA.g:2762:2: rule__TokenERC223__Group__10__Impl rule__TokenERC223__Group__11
            {
            pushFollow(FOLLOW_13);
            rule__TokenERC223__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__10"


    // $ANTLR start "rule__TokenERC223__Group__10__Impl"
    // InternalSmaCQA.g:2769:1: rule__TokenERC223__Group__10__Impl : ( 'answer = ' ) ;
    public final void rule__TokenERC223__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2773:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:2774:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:2774:1: ( 'answer = ' )
            // InternalSmaCQA.g:2775:2: 'answer = '
            {
             before(grammarAccess.getTokenERC223Access().getAnswerKeyword_10()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getAnswerKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__10__Impl"


    // $ANTLR start "rule__TokenERC223__Group__11"
    // InternalSmaCQA.g:2784:1: rule__TokenERC223__Group__11 : rule__TokenERC223__Group__11__Impl rule__TokenERC223__Group__12 ;
    public final void rule__TokenERC223__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2788:1: ( rule__TokenERC223__Group__11__Impl rule__TokenERC223__Group__12 )
            // InternalSmaCQA.g:2789:2: rule__TokenERC223__Group__11__Impl rule__TokenERC223__Group__12
            {
            pushFollow(FOLLOW_27);
            rule__TokenERC223__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__11"


    // $ANTLR start "rule__TokenERC223__Group__11__Impl"
    // InternalSmaCQA.g:2796:1: rule__TokenERC223__Group__11__Impl : ( ( rule__TokenERC223__AnswerMintSentenceAssignment_11 ) ) ;
    public final void rule__TokenERC223__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2800:1: ( ( ( rule__TokenERC223__AnswerMintSentenceAssignment_11 ) ) )
            // InternalSmaCQA.g:2801:1: ( ( rule__TokenERC223__AnswerMintSentenceAssignment_11 ) )
            {
            // InternalSmaCQA.g:2801:1: ( ( rule__TokenERC223__AnswerMintSentenceAssignment_11 ) )
            // InternalSmaCQA.g:2802:2: ( rule__TokenERC223__AnswerMintSentenceAssignment_11 )
            {
             before(grammarAccess.getTokenERC223Access().getAnswerMintSentenceAssignment_11()); 
            // InternalSmaCQA.g:2803:2: ( rule__TokenERC223__AnswerMintSentenceAssignment_11 )
            // InternalSmaCQA.g:2803:3: rule__TokenERC223__AnswerMintSentenceAssignment_11
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__AnswerMintSentenceAssignment_11();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getAnswerMintSentenceAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__11__Impl"


    // $ANTLR start "rule__TokenERC223__Group__12"
    // InternalSmaCQA.g:2811:1: rule__TokenERC223__Group__12 : rule__TokenERC223__Group__12__Impl rule__TokenERC223__Group__13 ;
    public final void rule__TokenERC223__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2815:1: ( rule__TokenERC223__Group__12__Impl rule__TokenERC223__Group__13 )
            // InternalSmaCQA.g:2816:2: rule__TokenERC223__Group__12__Impl rule__TokenERC223__Group__13
            {
            pushFollow(FOLLOW_12);
            rule__TokenERC223__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__12"


    // $ANTLR start "rule__TokenERC223__Group__12__Impl"
    // InternalSmaCQA.g:2823:1: rule__TokenERC223__Group__12__Impl : ( '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' ) ;
    public final void rule__TokenERC223__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2827:1: ( ( '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' ) )
            // InternalSmaCQA.g:2828:1: ( '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' )
            {
            // InternalSmaCQA.g:2828:1: ( '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' )
            // InternalSmaCQA.g:2829:2: '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?'
            {
             before(grammarAccess.getTokenERC223Access().getIsItPossibleToRemoveACertainAmountOfTokenFromCirculationBurnTokenKeyword_12()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getIsItPossibleToRemoveACertainAmountOfTokenFromCirculationBurnTokenKeyword_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__12__Impl"


    // $ANTLR start "rule__TokenERC223__Group__13"
    // InternalSmaCQA.g:2838:1: rule__TokenERC223__Group__13 : rule__TokenERC223__Group__13__Impl rule__TokenERC223__Group__14 ;
    public final void rule__TokenERC223__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2842:1: ( rule__TokenERC223__Group__13__Impl rule__TokenERC223__Group__14 )
            // InternalSmaCQA.g:2843:2: rule__TokenERC223__Group__13__Impl rule__TokenERC223__Group__14
            {
            pushFollow(FOLLOW_13);
            rule__TokenERC223__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__13"


    // $ANTLR start "rule__TokenERC223__Group__13__Impl"
    // InternalSmaCQA.g:2850:1: rule__TokenERC223__Group__13__Impl : ( 'answer = ' ) ;
    public final void rule__TokenERC223__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2854:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:2855:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:2855:1: ( 'answer = ' )
            // InternalSmaCQA.g:2856:2: 'answer = '
            {
             before(grammarAccess.getTokenERC223Access().getAnswerKeyword_13()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getAnswerKeyword_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__13__Impl"


    // $ANTLR start "rule__TokenERC223__Group__14"
    // InternalSmaCQA.g:2865:1: rule__TokenERC223__Group__14 : rule__TokenERC223__Group__14__Impl rule__TokenERC223__Group__15 ;
    public final void rule__TokenERC223__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2869:1: ( rule__TokenERC223__Group__14__Impl rule__TokenERC223__Group__15 )
            // InternalSmaCQA.g:2870:2: rule__TokenERC223__Group__14__Impl rule__TokenERC223__Group__15
            {
            pushFollow(FOLLOW_33);
            rule__TokenERC223__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__14"


    // $ANTLR start "rule__TokenERC223__Group__14__Impl"
    // InternalSmaCQA.g:2877:1: rule__TokenERC223__Group__14__Impl : ( ( rule__TokenERC223__AnswerBurnSentenceAssignment_14 ) ) ;
    public final void rule__TokenERC223__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2881:1: ( ( ( rule__TokenERC223__AnswerBurnSentenceAssignment_14 ) ) )
            // InternalSmaCQA.g:2882:1: ( ( rule__TokenERC223__AnswerBurnSentenceAssignment_14 ) )
            {
            // InternalSmaCQA.g:2882:1: ( ( rule__TokenERC223__AnswerBurnSentenceAssignment_14 ) )
            // InternalSmaCQA.g:2883:2: ( rule__TokenERC223__AnswerBurnSentenceAssignment_14 )
            {
             before(grammarAccess.getTokenERC223Access().getAnswerBurnSentenceAssignment_14()); 
            // InternalSmaCQA.g:2884:2: ( rule__TokenERC223__AnswerBurnSentenceAssignment_14 )
            // InternalSmaCQA.g:2884:3: rule__TokenERC223__AnswerBurnSentenceAssignment_14
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__AnswerBurnSentenceAssignment_14();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getAnswerBurnSentenceAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__14__Impl"


    // $ANTLR start "rule__TokenERC223__Group__15"
    // InternalSmaCQA.g:2892:1: rule__TokenERC223__Group__15 : rule__TokenERC223__Group__15__Impl ;
    public final void rule__TokenERC223__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2896:1: ( rule__TokenERC223__Group__15__Impl )
            // InternalSmaCQA.g:2897:2: rule__TokenERC223__Group__15__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__Group__15__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__15"


    // $ANTLR start "rule__TokenERC223__Group__15__Impl"
    // InternalSmaCQA.g:2903:1: rule__TokenERC223__Group__15__Impl : ( 'End Data Declaration Token ERC223' ) ;
    public final void rule__TokenERC223__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2907:1: ( ( 'End Data Declaration Token ERC223' ) )
            // InternalSmaCQA.g:2908:1: ( 'End Data Declaration Token ERC223' )
            {
            // InternalSmaCQA.g:2908:1: ( 'End Data Declaration Token ERC223' )
            // InternalSmaCQA.g:2909:2: 'End Data Declaration Token ERC223'
            {
             before(grammarAccess.getTokenERC223Access().getEndDataDeclarationTokenERC223Keyword_15()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getEndDataDeclarationTokenERC223Keyword_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__Group__15__Impl"


    // $ANTLR start "rule__TokenERC721__Group__0"
    // InternalSmaCQA.g:2919:1: rule__TokenERC721__Group__0 : rule__TokenERC721__Group__0__Impl rule__TokenERC721__Group__1 ;
    public final void rule__TokenERC721__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2923:1: ( rule__TokenERC721__Group__0__Impl rule__TokenERC721__Group__1 )
            // InternalSmaCQA.g:2924:2: rule__TokenERC721__Group__0__Impl rule__TokenERC721__Group__1
            {
            pushFollow(FOLLOW_34);
            rule__TokenERC721__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__0"


    // $ANTLR start "rule__TokenERC721__Group__0__Impl"
    // InternalSmaCQA.g:2931:1: rule__TokenERC721__Group__0__Impl : ( 'Data Declaration Non Fungible Token ERC721: ' ) ;
    public final void rule__TokenERC721__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2935:1: ( ( 'Data Declaration Non Fungible Token ERC721: ' ) )
            // InternalSmaCQA.g:2936:1: ( 'Data Declaration Non Fungible Token ERC721: ' )
            {
            // InternalSmaCQA.g:2936:1: ( 'Data Declaration Non Fungible Token ERC721: ' )
            // InternalSmaCQA.g:2937:2: 'Data Declaration Non Fungible Token ERC721: '
            {
             before(grammarAccess.getTokenERC721Access().getDataDeclarationNonFungibleTokenERC721Keyword_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getDataDeclarationNonFungibleTokenERC721Keyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__0__Impl"


    // $ANTLR start "rule__TokenERC721__Group__1"
    // InternalSmaCQA.g:2946:1: rule__TokenERC721__Group__1 : rule__TokenERC721__Group__1__Impl rule__TokenERC721__Group__2 ;
    public final void rule__TokenERC721__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2950:1: ( rule__TokenERC721__Group__1__Impl rule__TokenERC721__Group__2 )
            // InternalSmaCQA.g:2951:2: rule__TokenERC721__Group__1__Impl rule__TokenERC721__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__TokenERC721__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__1"


    // $ANTLR start "rule__TokenERC721__Group__1__Impl"
    // InternalSmaCQA.g:2958:1: rule__TokenERC721__Group__1__Impl : ( 'Token ERC721 name: ' ) ;
    public final void rule__TokenERC721__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2962:1: ( ( 'Token ERC721 name: ' ) )
            // InternalSmaCQA.g:2963:1: ( 'Token ERC721 name: ' )
            {
            // InternalSmaCQA.g:2963:1: ( 'Token ERC721 name: ' )
            // InternalSmaCQA.g:2964:2: 'Token ERC721 name: '
            {
             before(grammarAccess.getTokenERC721Access().getTokenERC721NameKeyword_1()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getTokenERC721NameKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__1__Impl"


    // $ANTLR start "rule__TokenERC721__Group__2"
    // InternalSmaCQA.g:2973:1: rule__TokenERC721__Group__2 : rule__TokenERC721__Group__2__Impl rule__TokenERC721__Group__3 ;
    public final void rule__TokenERC721__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2977:1: ( rule__TokenERC721__Group__2__Impl rule__TokenERC721__Group__3 )
            // InternalSmaCQA.g:2978:2: rule__TokenERC721__Group__2__Impl rule__TokenERC721__Group__3
            {
            pushFollow(FOLLOW_35);
            rule__TokenERC721__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__2"


    // $ANTLR start "rule__TokenERC721__Group__2__Impl"
    // InternalSmaCQA.g:2985:1: rule__TokenERC721__Group__2__Impl : ( ( rule__TokenERC721__NameAssignment_2 ) ) ;
    public final void rule__TokenERC721__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:2989:1: ( ( ( rule__TokenERC721__NameAssignment_2 ) ) )
            // InternalSmaCQA.g:2990:1: ( ( rule__TokenERC721__NameAssignment_2 ) )
            {
            // InternalSmaCQA.g:2990:1: ( ( rule__TokenERC721__NameAssignment_2 ) )
            // InternalSmaCQA.g:2991:2: ( rule__TokenERC721__NameAssignment_2 )
            {
             before(grammarAccess.getTokenERC721Access().getNameAssignment_2()); 
            // InternalSmaCQA.g:2992:2: ( rule__TokenERC721__NameAssignment_2 )
            // InternalSmaCQA.g:2992:3: rule__TokenERC721__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__2__Impl"


    // $ANTLR start "rule__TokenERC721__Group__3"
    // InternalSmaCQA.g:3000:1: rule__TokenERC721__Group__3 : rule__TokenERC721__Group__3__Impl rule__TokenERC721__Group__4 ;
    public final void rule__TokenERC721__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3004:1: ( rule__TokenERC721__Group__3__Impl rule__TokenERC721__Group__4 )
            // InternalSmaCQA.g:3005:2: rule__TokenERC721__Group__3__Impl rule__TokenERC721__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__TokenERC721__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__3"


    // $ANTLR start "rule__TokenERC721__Group__3__Impl"
    // InternalSmaCQA.g:3012:1: rule__TokenERC721__Group__3__Impl : ( 'Token ERC721 Symbol: ' ) ;
    public final void rule__TokenERC721__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3016:1: ( ( 'Token ERC721 Symbol: ' ) )
            // InternalSmaCQA.g:3017:1: ( 'Token ERC721 Symbol: ' )
            {
            // InternalSmaCQA.g:3017:1: ( 'Token ERC721 Symbol: ' )
            // InternalSmaCQA.g:3018:2: 'Token ERC721 Symbol: '
            {
             before(grammarAccess.getTokenERC721Access().getTokenERC721SymbolKeyword_3()); 
            match(input,55,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getTokenERC721SymbolKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__3__Impl"


    // $ANTLR start "rule__TokenERC721__Group__4"
    // InternalSmaCQA.g:3027:1: rule__TokenERC721__Group__4 : rule__TokenERC721__Group__4__Impl rule__TokenERC721__Group__5 ;
    public final void rule__TokenERC721__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3031:1: ( rule__TokenERC721__Group__4__Impl rule__TokenERC721__Group__5 )
            // InternalSmaCQA.g:3032:2: rule__TokenERC721__Group__4__Impl rule__TokenERC721__Group__5
            {
            pushFollow(FOLLOW_36);
            rule__TokenERC721__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__4"


    // $ANTLR start "rule__TokenERC721__Group__4__Impl"
    // InternalSmaCQA.g:3039:1: rule__TokenERC721__Group__4__Impl : ( ( rule__TokenERC721__SymbolAssignment_4 ) ) ;
    public final void rule__TokenERC721__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3043:1: ( ( ( rule__TokenERC721__SymbolAssignment_4 ) ) )
            // InternalSmaCQA.g:3044:1: ( ( rule__TokenERC721__SymbolAssignment_4 ) )
            {
            // InternalSmaCQA.g:3044:1: ( ( rule__TokenERC721__SymbolAssignment_4 ) )
            // InternalSmaCQA.g:3045:2: ( rule__TokenERC721__SymbolAssignment_4 )
            {
             before(grammarAccess.getTokenERC721Access().getSymbolAssignment_4()); 
            // InternalSmaCQA.g:3046:2: ( rule__TokenERC721__SymbolAssignment_4 )
            // InternalSmaCQA.g:3046:3: rule__TokenERC721__SymbolAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__SymbolAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getSymbolAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__4__Impl"


    // $ANTLR start "rule__TokenERC721__Group__5"
    // InternalSmaCQA.g:3054:1: rule__TokenERC721__Group__5 : rule__TokenERC721__Group__5__Impl rule__TokenERC721__Group__6 ;
    public final void rule__TokenERC721__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3058:1: ( rule__TokenERC721__Group__5__Impl rule__TokenERC721__Group__6 )
            // InternalSmaCQA.g:3059:2: rule__TokenERC721__Group__5__Impl rule__TokenERC721__Group__6
            {
            pushFollow(FOLLOW_12);
            rule__TokenERC721__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__5"


    // $ANTLR start "rule__TokenERC721__Group__5__Impl"
    // InternalSmaCQA.g:3066:1: rule__TokenERC721__Group__5__Impl : ( '1.5.1 If it\\'s possible to mint more than one NFT at a time?' ) ;
    public final void rule__TokenERC721__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3070:1: ( ( '1.5.1 If it\\'s possible to mint more than one NFT at a time?' ) )
            // InternalSmaCQA.g:3071:1: ( '1.5.1 If it\\'s possible to mint more than one NFT at a time?' )
            {
            // InternalSmaCQA.g:3071:1: ( '1.5.1 If it\\'s possible to mint more than one NFT at a time?' )
            // InternalSmaCQA.g:3072:2: '1.5.1 If it\\'s possible to mint more than one NFT at a time?'
            {
             before(grammarAccess.getTokenERC721Access().getIfItSPossibleToMintMoreThanOneNFTAtATimeKeyword_5()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getIfItSPossibleToMintMoreThanOneNFTAtATimeKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__5__Impl"


    // $ANTLR start "rule__TokenERC721__Group__6"
    // InternalSmaCQA.g:3081:1: rule__TokenERC721__Group__6 : rule__TokenERC721__Group__6__Impl rule__TokenERC721__Group__7 ;
    public final void rule__TokenERC721__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3085:1: ( rule__TokenERC721__Group__6__Impl rule__TokenERC721__Group__7 )
            // InternalSmaCQA.g:3086:2: rule__TokenERC721__Group__6__Impl rule__TokenERC721__Group__7
            {
            pushFollow(FOLLOW_13);
            rule__TokenERC721__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__6"


    // $ANTLR start "rule__TokenERC721__Group__6__Impl"
    // InternalSmaCQA.g:3093:1: rule__TokenERC721__Group__6__Impl : ( 'answer = ' ) ;
    public final void rule__TokenERC721__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3097:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:3098:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:3098:1: ( 'answer = ' )
            // InternalSmaCQA.g:3099:2: 'answer = '
            {
             before(grammarAccess.getTokenERC721Access().getAnswerKeyword_6()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getAnswerKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__6__Impl"


    // $ANTLR start "rule__TokenERC721__Group__7"
    // InternalSmaCQA.g:3108:1: rule__TokenERC721__Group__7 : rule__TokenERC721__Group__7__Impl rule__TokenERC721__Group__8 ;
    public final void rule__TokenERC721__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3112:1: ( rule__TokenERC721__Group__7__Impl rule__TokenERC721__Group__8 )
            // InternalSmaCQA.g:3113:2: rule__TokenERC721__Group__7__Impl rule__TokenERC721__Group__8
            {
            pushFollow(FOLLOW_37);
            rule__TokenERC721__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__7"


    // $ANTLR start "rule__TokenERC721__Group__7__Impl"
    // InternalSmaCQA.g:3120:1: rule__TokenERC721__Group__7__Impl : ( ( rule__TokenERC721__AnswerMintSentenceAssignment_7 ) ) ;
    public final void rule__TokenERC721__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3124:1: ( ( ( rule__TokenERC721__AnswerMintSentenceAssignment_7 ) ) )
            // InternalSmaCQA.g:3125:1: ( ( rule__TokenERC721__AnswerMintSentenceAssignment_7 ) )
            {
            // InternalSmaCQA.g:3125:1: ( ( rule__TokenERC721__AnswerMintSentenceAssignment_7 ) )
            // InternalSmaCQA.g:3126:2: ( rule__TokenERC721__AnswerMintSentenceAssignment_7 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerMintSentenceAssignment_7()); 
            // InternalSmaCQA.g:3127:2: ( rule__TokenERC721__AnswerMintSentenceAssignment_7 )
            // InternalSmaCQA.g:3127:3: rule__TokenERC721__AnswerMintSentenceAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__AnswerMintSentenceAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerMintSentenceAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__7__Impl"


    // $ANTLR start "rule__TokenERC721__Group__8"
    // InternalSmaCQA.g:3135:1: rule__TokenERC721__Group__8 : rule__TokenERC721__Group__8__Impl rule__TokenERC721__Group__9 ;
    public final void rule__TokenERC721__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3139:1: ( rule__TokenERC721__Group__8__Impl rule__TokenERC721__Group__9 )
            // InternalSmaCQA.g:3140:2: rule__TokenERC721__Group__8__Impl rule__TokenERC721__Group__9
            {
            pushFollow(FOLLOW_12);
            rule__TokenERC721__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__8"


    // $ANTLR start "rule__TokenERC721__Group__8__Impl"
    // InternalSmaCQA.g:3147:1: rule__TokenERC721__Group__8__Impl : ( '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' ) ;
    public final void rule__TokenERC721__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3151:1: ( ( '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' ) )
            // InternalSmaCQA.g:3152:1: ( '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' )
            {
            // InternalSmaCQA.g:3152:1: ( '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' )
            // InternalSmaCQA.g:3153:2: '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?'
            {
             before(grammarAccess.getTokenERC721Access().getIsItPossibleToRemoveDisableTheTokenFromCirculationBurnTokenKeyword_8()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getIsItPossibleToRemoveDisableTheTokenFromCirculationBurnTokenKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__8__Impl"


    // $ANTLR start "rule__TokenERC721__Group__9"
    // InternalSmaCQA.g:3162:1: rule__TokenERC721__Group__9 : rule__TokenERC721__Group__9__Impl rule__TokenERC721__Group__10 ;
    public final void rule__TokenERC721__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3166:1: ( rule__TokenERC721__Group__9__Impl rule__TokenERC721__Group__10 )
            // InternalSmaCQA.g:3167:2: rule__TokenERC721__Group__9__Impl rule__TokenERC721__Group__10
            {
            pushFollow(FOLLOW_13);
            rule__TokenERC721__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__9"


    // $ANTLR start "rule__TokenERC721__Group__9__Impl"
    // InternalSmaCQA.g:3174:1: rule__TokenERC721__Group__9__Impl : ( 'answer = ' ) ;
    public final void rule__TokenERC721__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3178:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:3179:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:3179:1: ( 'answer = ' )
            // InternalSmaCQA.g:3180:2: 'answer = '
            {
             before(grammarAccess.getTokenERC721Access().getAnswerKeyword_9()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getAnswerKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__9__Impl"


    // $ANTLR start "rule__TokenERC721__Group__10"
    // InternalSmaCQA.g:3189:1: rule__TokenERC721__Group__10 : rule__TokenERC721__Group__10__Impl rule__TokenERC721__Group__11 ;
    public final void rule__TokenERC721__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3193:1: ( rule__TokenERC721__Group__10__Impl rule__TokenERC721__Group__11 )
            // InternalSmaCQA.g:3194:2: rule__TokenERC721__Group__10__Impl rule__TokenERC721__Group__11
            {
            pushFollow(FOLLOW_38);
            rule__TokenERC721__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__10"


    // $ANTLR start "rule__TokenERC721__Group__10__Impl"
    // InternalSmaCQA.g:3201:1: rule__TokenERC721__Group__10__Impl : ( ( rule__TokenERC721__AnswerBurnSentenceAssignment_10 ) ) ;
    public final void rule__TokenERC721__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3205:1: ( ( ( rule__TokenERC721__AnswerBurnSentenceAssignment_10 ) ) )
            // InternalSmaCQA.g:3206:1: ( ( rule__TokenERC721__AnswerBurnSentenceAssignment_10 ) )
            {
            // InternalSmaCQA.g:3206:1: ( ( rule__TokenERC721__AnswerBurnSentenceAssignment_10 ) )
            // InternalSmaCQA.g:3207:2: ( rule__TokenERC721__AnswerBurnSentenceAssignment_10 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerBurnSentenceAssignment_10()); 
            // InternalSmaCQA.g:3208:2: ( rule__TokenERC721__AnswerBurnSentenceAssignment_10 )
            // InternalSmaCQA.g:3208:3: rule__TokenERC721__AnswerBurnSentenceAssignment_10
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__AnswerBurnSentenceAssignment_10();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerBurnSentenceAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__10__Impl"


    // $ANTLR start "rule__TokenERC721__Group__11"
    // InternalSmaCQA.g:3216:1: rule__TokenERC721__Group__11 : rule__TokenERC721__Group__11__Impl rule__TokenERC721__Group__12 ;
    public final void rule__TokenERC721__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3220:1: ( rule__TokenERC721__Group__11__Impl rule__TokenERC721__Group__12 )
            // InternalSmaCQA.g:3221:2: rule__TokenERC721__Group__11__Impl rule__TokenERC721__Group__12
            {
            pushFollow(FOLLOW_12);
            rule__TokenERC721__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__11"


    // $ANTLR start "rule__TokenERC721__Group__11__Impl"
    // InternalSmaCQA.g:3228:1: rule__TokenERC721__Group__11__Impl : ( '1.5.3 What is the price of this token?' ) ;
    public final void rule__TokenERC721__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3232:1: ( ( '1.5.3 What is the price of this token?' ) )
            // InternalSmaCQA.g:3233:1: ( '1.5.3 What is the price of this token?' )
            {
            // InternalSmaCQA.g:3233:1: ( '1.5.3 What is the price of this token?' )
            // InternalSmaCQA.g:3234:2: '1.5.3 What is the price of this token?'
            {
             before(grammarAccess.getTokenERC721Access().getWhatIsThePriceOfThisTokenKeyword_11()); 
            match(input,58,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getWhatIsThePriceOfThisTokenKeyword_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__11__Impl"


    // $ANTLR start "rule__TokenERC721__Group__12"
    // InternalSmaCQA.g:3243:1: rule__TokenERC721__Group__12 : rule__TokenERC721__Group__12__Impl rule__TokenERC721__Group__13 ;
    public final void rule__TokenERC721__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3247:1: ( rule__TokenERC721__Group__12__Impl rule__TokenERC721__Group__13 )
            // InternalSmaCQA.g:3248:2: rule__TokenERC721__Group__12__Impl rule__TokenERC721__Group__13
            {
            pushFollow(FOLLOW_24);
            rule__TokenERC721__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__12"


    // $ANTLR start "rule__TokenERC721__Group__12__Impl"
    // InternalSmaCQA.g:3255:1: rule__TokenERC721__Group__12__Impl : ( 'answer = ' ) ;
    public final void rule__TokenERC721__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3259:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:3260:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:3260:1: ( 'answer = ' )
            // InternalSmaCQA.g:3261:2: 'answer = '
            {
             before(grammarAccess.getTokenERC721Access().getAnswerKeyword_12()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getAnswerKeyword_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__12__Impl"


    // $ANTLR start "rule__TokenERC721__Group__13"
    // InternalSmaCQA.g:3270:1: rule__TokenERC721__Group__13 : rule__TokenERC721__Group__13__Impl rule__TokenERC721__Group__14 ;
    public final void rule__TokenERC721__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3274:1: ( rule__TokenERC721__Group__13__Impl rule__TokenERC721__Group__14 )
            // InternalSmaCQA.g:3275:2: rule__TokenERC721__Group__13__Impl rule__TokenERC721__Group__14
            {
            pushFollow(FOLLOW_39);
            rule__TokenERC721__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__13"


    // $ANTLR start "rule__TokenERC721__Group__13__Impl"
    // InternalSmaCQA.g:3282:1: rule__TokenERC721__Group__13__Impl : ( ( rule__TokenERC721__AnswerUnitPriceAssignment_13 ) ) ;
    public final void rule__TokenERC721__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3286:1: ( ( ( rule__TokenERC721__AnswerUnitPriceAssignment_13 ) ) )
            // InternalSmaCQA.g:3287:1: ( ( rule__TokenERC721__AnswerUnitPriceAssignment_13 ) )
            {
            // InternalSmaCQA.g:3287:1: ( ( rule__TokenERC721__AnswerUnitPriceAssignment_13 ) )
            // InternalSmaCQA.g:3288:2: ( rule__TokenERC721__AnswerUnitPriceAssignment_13 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerUnitPriceAssignment_13()); 
            // InternalSmaCQA.g:3289:2: ( rule__TokenERC721__AnswerUnitPriceAssignment_13 )
            // InternalSmaCQA.g:3289:3: rule__TokenERC721__AnswerUnitPriceAssignment_13
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__AnswerUnitPriceAssignment_13();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerUnitPriceAssignment_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__13__Impl"


    // $ANTLR start "rule__TokenERC721__Group__14"
    // InternalSmaCQA.g:3297:1: rule__TokenERC721__Group__14 : rule__TokenERC721__Group__14__Impl rule__TokenERC721__Group__15 ;
    public final void rule__TokenERC721__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3301:1: ( rule__TokenERC721__Group__14__Impl rule__TokenERC721__Group__15 )
            // InternalSmaCQA.g:3302:2: rule__TokenERC721__Group__14__Impl rule__TokenERC721__Group__15
            {
            pushFollow(FOLLOW_40);
            rule__TokenERC721__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__14"


    // $ANTLR start "rule__TokenERC721__Group__14__Impl"
    // InternalSmaCQA.g:3309:1: rule__TokenERC721__Group__14__Impl : ( ( rule__TokenERC721__AnswerUnitCoinAssignment_14 ) ) ;
    public final void rule__TokenERC721__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3313:1: ( ( ( rule__TokenERC721__AnswerUnitCoinAssignment_14 ) ) )
            // InternalSmaCQA.g:3314:1: ( ( rule__TokenERC721__AnswerUnitCoinAssignment_14 ) )
            {
            // InternalSmaCQA.g:3314:1: ( ( rule__TokenERC721__AnswerUnitCoinAssignment_14 ) )
            // InternalSmaCQA.g:3315:2: ( rule__TokenERC721__AnswerUnitCoinAssignment_14 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerUnitCoinAssignment_14()); 
            // InternalSmaCQA.g:3316:2: ( rule__TokenERC721__AnswerUnitCoinAssignment_14 )
            // InternalSmaCQA.g:3316:3: rule__TokenERC721__AnswerUnitCoinAssignment_14
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__AnswerUnitCoinAssignment_14();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerUnitCoinAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__14__Impl"


    // $ANTLR start "rule__TokenERC721__Group__15"
    // InternalSmaCQA.g:3324:1: rule__TokenERC721__Group__15 : rule__TokenERC721__Group__15__Impl rule__TokenERC721__Group__16 ;
    public final void rule__TokenERC721__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3328:1: ( rule__TokenERC721__Group__15__Impl rule__TokenERC721__Group__16 )
            // InternalSmaCQA.g:3329:2: rule__TokenERC721__Group__15__Impl rule__TokenERC721__Group__16
            {
            pushFollow(FOLLOW_12);
            rule__TokenERC721__Group__15__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__16();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__15"


    // $ANTLR start "rule__TokenERC721__Group__15__Impl"
    // InternalSmaCQA.g:3336:1: rule__TokenERC721__Group__15__Impl : ( '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' ) ;
    public final void rule__TokenERC721__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3340:1: ( ( '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' ) )
            // InternalSmaCQA.g:3341:1: ( '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' )
            {
            // InternalSmaCQA.g:3341:1: ( '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' )
            // InternalSmaCQA.g:3342:2: '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?'
            {
             before(grammarAccess.getTokenERC721Access().getIsNecessaryAttachMetadataInformationAboutTheTokenExampleUrlImageToTheTokenKeyword_15()); 
            match(input,59,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getIsNecessaryAttachMetadataInformationAboutTheTokenExampleUrlImageToTheTokenKeyword_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__15__Impl"


    // $ANTLR start "rule__TokenERC721__Group__16"
    // InternalSmaCQA.g:3351:1: rule__TokenERC721__Group__16 : rule__TokenERC721__Group__16__Impl rule__TokenERC721__Group__17 ;
    public final void rule__TokenERC721__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3355:1: ( rule__TokenERC721__Group__16__Impl rule__TokenERC721__Group__17 )
            // InternalSmaCQA.g:3356:2: rule__TokenERC721__Group__16__Impl rule__TokenERC721__Group__17
            {
            pushFollow(FOLLOW_13);
            rule__TokenERC721__Group__16__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__17();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__16"


    // $ANTLR start "rule__TokenERC721__Group__16__Impl"
    // InternalSmaCQA.g:3363:1: rule__TokenERC721__Group__16__Impl : ( 'answer = ' ) ;
    public final void rule__TokenERC721__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3367:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:3368:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:3368:1: ( 'answer = ' )
            // InternalSmaCQA.g:3369:2: 'answer = '
            {
             before(grammarAccess.getTokenERC721Access().getAnswerKeyword_16()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getAnswerKeyword_16()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__16__Impl"


    // $ANTLR start "rule__TokenERC721__Group__17"
    // InternalSmaCQA.g:3378:1: rule__TokenERC721__Group__17 : rule__TokenERC721__Group__17__Impl rule__TokenERC721__Group__18 ;
    public final void rule__TokenERC721__Group__17() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3382:1: ( rule__TokenERC721__Group__17__Impl rule__TokenERC721__Group__18 )
            // InternalSmaCQA.g:3383:2: rule__TokenERC721__Group__17__Impl rule__TokenERC721__Group__18
            {
            pushFollow(FOLLOW_41);
            rule__TokenERC721__Group__17__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__18();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__17"


    // $ANTLR start "rule__TokenERC721__Group__17__Impl"
    // InternalSmaCQA.g:3390:1: rule__TokenERC721__Group__17__Impl : ( ( rule__TokenERC721__AnswerMetadataSentenceAssignment_17 ) ) ;
    public final void rule__TokenERC721__Group__17__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3394:1: ( ( ( rule__TokenERC721__AnswerMetadataSentenceAssignment_17 ) ) )
            // InternalSmaCQA.g:3395:1: ( ( rule__TokenERC721__AnswerMetadataSentenceAssignment_17 ) )
            {
            // InternalSmaCQA.g:3395:1: ( ( rule__TokenERC721__AnswerMetadataSentenceAssignment_17 ) )
            // InternalSmaCQA.g:3396:2: ( rule__TokenERC721__AnswerMetadataSentenceAssignment_17 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceAssignment_17()); 
            // InternalSmaCQA.g:3397:2: ( rule__TokenERC721__AnswerMetadataSentenceAssignment_17 )
            // InternalSmaCQA.g:3397:3: rule__TokenERC721__AnswerMetadataSentenceAssignment_17
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__AnswerMetadataSentenceAssignment_17();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceAssignment_17()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__17__Impl"


    // $ANTLR start "rule__TokenERC721__Group__18"
    // InternalSmaCQA.g:3405:1: rule__TokenERC721__Group__18 : rule__TokenERC721__Group__18__Impl rule__TokenERC721__Group__19 ;
    public final void rule__TokenERC721__Group__18() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3409:1: ( rule__TokenERC721__Group__18__Impl rule__TokenERC721__Group__19 )
            // InternalSmaCQA.g:3410:2: rule__TokenERC721__Group__18__Impl rule__TokenERC721__Group__19
            {
            pushFollow(FOLLOW_41);
            rule__TokenERC721__Group__18__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__19();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__18"


    // $ANTLR start "rule__TokenERC721__Group__18__Impl"
    // InternalSmaCQA.g:3417:1: rule__TokenERC721__Group__18__Impl : ( ( rule__TokenERC721__Group_18__0 )? ) ;
    public final void rule__TokenERC721__Group__18__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3421:1: ( ( ( rule__TokenERC721__Group_18__0 )? ) )
            // InternalSmaCQA.g:3422:1: ( ( rule__TokenERC721__Group_18__0 )? )
            {
            // InternalSmaCQA.g:3422:1: ( ( rule__TokenERC721__Group_18__0 )? )
            // InternalSmaCQA.g:3423:2: ( rule__TokenERC721__Group_18__0 )?
            {
             before(grammarAccess.getTokenERC721Access().getGroup_18()); 
            // InternalSmaCQA.g:3424:2: ( rule__TokenERC721__Group_18__0 )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==61) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSmaCQA.g:3424:3: rule__TokenERC721__Group_18__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TokenERC721__Group_18__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTokenERC721Access().getGroup_18()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__18__Impl"


    // $ANTLR start "rule__TokenERC721__Group__19"
    // InternalSmaCQA.g:3432:1: rule__TokenERC721__Group__19 : rule__TokenERC721__Group__19__Impl rule__TokenERC721__Group__20 ;
    public final void rule__TokenERC721__Group__19() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3436:1: ( rule__TokenERC721__Group__19__Impl rule__TokenERC721__Group__20 )
            // InternalSmaCQA.g:3437:2: rule__TokenERC721__Group__19__Impl rule__TokenERC721__Group__20
            {
            pushFollow(FOLLOW_41);
            rule__TokenERC721__Group__19__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__20();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__19"


    // $ANTLR start "rule__TokenERC721__Group__19__Impl"
    // InternalSmaCQA.g:3444:1: rule__TokenERC721__Group__19__Impl : ( ( rule__TokenERC721__Group_19__0 )? ) ;
    public final void rule__TokenERC721__Group__19__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3448:1: ( ( ( rule__TokenERC721__Group_19__0 )? ) )
            // InternalSmaCQA.g:3449:1: ( ( rule__TokenERC721__Group_19__0 )? )
            {
            // InternalSmaCQA.g:3449:1: ( ( rule__TokenERC721__Group_19__0 )? )
            // InternalSmaCQA.g:3450:2: ( rule__TokenERC721__Group_19__0 )?
            {
             before(grammarAccess.getTokenERC721Access().getGroup_19()); 
            // InternalSmaCQA.g:3451:2: ( rule__TokenERC721__Group_19__0 )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==62) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSmaCQA.g:3451:3: rule__TokenERC721__Group_19__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TokenERC721__Group_19__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTokenERC721Access().getGroup_19()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__19__Impl"


    // $ANTLR start "rule__TokenERC721__Group__20"
    // InternalSmaCQA.g:3459:1: rule__TokenERC721__Group__20 : rule__TokenERC721__Group__20__Impl ;
    public final void rule__TokenERC721__Group__20() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3463:1: ( rule__TokenERC721__Group__20__Impl )
            // InternalSmaCQA.g:3464:2: rule__TokenERC721__Group__20__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group__20__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__20"


    // $ANTLR start "rule__TokenERC721__Group__20__Impl"
    // InternalSmaCQA.g:3470:1: rule__TokenERC721__Group__20__Impl : ( 'End Data Declaration Token ERC721' ) ;
    public final void rule__TokenERC721__Group__20__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3474:1: ( ( 'End Data Declaration Token ERC721' ) )
            // InternalSmaCQA.g:3475:1: ( 'End Data Declaration Token ERC721' )
            {
            // InternalSmaCQA.g:3475:1: ( 'End Data Declaration Token ERC721' )
            // InternalSmaCQA.g:3476:2: 'End Data Declaration Token ERC721'
            {
             before(grammarAccess.getTokenERC721Access().getEndDataDeclarationTokenERC721Keyword_20()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getEndDataDeclarationTokenERC721Keyword_20()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group__20__Impl"


    // $ANTLR start "rule__TokenERC721__Group_18__0"
    // InternalSmaCQA.g:3486:1: rule__TokenERC721__Group_18__0 : rule__TokenERC721__Group_18__0__Impl rule__TokenERC721__Group_18__1 ;
    public final void rule__TokenERC721__Group_18__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3490:1: ( rule__TokenERC721__Group_18__0__Impl rule__TokenERC721__Group_18__1 )
            // InternalSmaCQA.g:3491:2: rule__TokenERC721__Group_18__0__Impl rule__TokenERC721__Group_18__1
            {
            pushFollow(FOLLOW_15);
            rule__TokenERC721__Group_18__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group_18__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_18__0"


    // $ANTLR start "rule__TokenERC721__Group_18__0__Impl"
    // InternalSmaCQA.g:3498:1: rule__TokenERC721__Group_18__0__Impl : ( '1.5.5 Which data or properties are requiered for the NFT information?' ) ;
    public final void rule__TokenERC721__Group_18__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3502:1: ( ( '1.5.5 Which data or properties are requiered for the NFT information?' ) )
            // InternalSmaCQA.g:3503:1: ( '1.5.5 Which data or properties are requiered for the NFT information?' )
            {
            // InternalSmaCQA.g:3503:1: ( '1.5.5 Which data or properties are requiered for the NFT information?' )
            // InternalSmaCQA.g:3504:2: '1.5.5 Which data or properties are requiered for the NFT information?'
            {
             before(grammarAccess.getTokenERC721Access().getWhichDataOrPropertiesAreRequieredForTheNFTInformationKeyword_18_0()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getWhichDataOrPropertiesAreRequieredForTheNFTInformationKeyword_18_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_18__0__Impl"


    // $ANTLR start "rule__TokenERC721__Group_18__1"
    // InternalSmaCQA.g:3513:1: rule__TokenERC721__Group_18__1 : rule__TokenERC721__Group_18__1__Impl rule__TokenERC721__Group_18__2 ;
    public final void rule__TokenERC721__Group_18__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3517:1: ( rule__TokenERC721__Group_18__1__Impl rule__TokenERC721__Group_18__2 )
            // InternalSmaCQA.g:3518:2: rule__TokenERC721__Group_18__1__Impl rule__TokenERC721__Group_18__2
            {
            pushFollow(FOLLOW_16);
            rule__TokenERC721__Group_18__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group_18__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_18__1"


    // $ANTLR start "rule__TokenERC721__Group_18__1__Impl"
    // InternalSmaCQA.g:3525:1: rule__TokenERC721__Group_18__1__Impl : ( 'Data Declaration: ' ) ;
    public final void rule__TokenERC721__Group_18__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3529:1: ( ( 'Data Declaration: ' ) )
            // InternalSmaCQA.g:3530:1: ( 'Data Declaration: ' )
            {
            // InternalSmaCQA.g:3530:1: ( 'Data Declaration: ' )
            // InternalSmaCQA.g:3531:2: 'Data Declaration: '
            {
             before(grammarAccess.getTokenERC721Access().getDataDeclarationKeyword_18_1()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getDataDeclarationKeyword_18_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_18__1__Impl"


    // $ANTLR start "rule__TokenERC721__Group_18__2"
    // InternalSmaCQA.g:3540:1: rule__TokenERC721__Group_18__2 : rule__TokenERC721__Group_18__2__Impl rule__TokenERC721__Group_18__3 ;
    public final void rule__TokenERC721__Group_18__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3544:1: ( rule__TokenERC721__Group_18__2__Impl rule__TokenERC721__Group_18__3 )
            // InternalSmaCQA.g:3545:2: rule__TokenERC721__Group_18__2__Impl rule__TokenERC721__Group_18__3
            {
            pushFollow(FOLLOW_17);
            rule__TokenERC721__Group_18__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group_18__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_18__2"


    // $ANTLR start "rule__TokenERC721__Group_18__2__Impl"
    // InternalSmaCQA.g:3552:1: rule__TokenERC721__Group_18__2__Impl : ( ( ( rule__TokenERC721__AnswerAssignment_18_2 ) ) ( ( rule__TokenERC721__AnswerAssignment_18_2 )* ) ) ;
    public final void rule__TokenERC721__Group_18__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3556:1: ( ( ( ( rule__TokenERC721__AnswerAssignment_18_2 ) ) ( ( rule__TokenERC721__AnswerAssignment_18_2 )* ) ) )
            // InternalSmaCQA.g:3557:1: ( ( ( rule__TokenERC721__AnswerAssignment_18_2 ) ) ( ( rule__TokenERC721__AnswerAssignment_18_2 )* ) )
            {
            // InternalSmaCQA.g:3557:1: ( ( ( rule__TokenERC721__AnswerAssignment_18_2 ) ) ( ( rule__TokenERC721__AnswerAssignment_18_2 )* ) )
            // InternalSmaCQA.g:3558:2: ( ( rule__TokenERC721__AnswerAssignment_18_2 ) ) ( ( rule__TokenERC721__AnswerAssignment_18_2 )* )
            {
            // InternalSmaCQA.g:3558:2: ( ( rule__TokenERC721__AnswerAssignment_18_2 ) )
            // InternalSmaCQA.g:3559:3: ( rule__TokenERC721__AnswerAssignment_18_2 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerAssignment_18_2()); 
            // InternalSmaCQA.g:3560:3: ( rule__TokenERC721__AnswerAssignment_18_2 )
            // InternalSmaCQA.g:3560:4: rule__TokenERC721__AnswerAssignment_18_2
            {
            pushFollow(FOLLOW_18);
            rule__TokenERC721__AnswerAssignment_18_2();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerAssignment_18_2()); 

            }

            // InternalSmaCQA.g:3563:2: ( ( rule__TokenERC721__AnswerAssignment_18_2 )* )
            // InternalSmaCQA.g:3564:3: ( rule__TokenERC721__AnswerAssignment_18_2 )*
            {
             before(grammarAccess.getTokenERC721Access().getAnswerAssignment_18_2()); 
            // InternalSmaCQA.g:3565:3: ( rule__TokenERC721__AnswerAssignment_18_2 )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==37) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // InternalSmaCQA.g:3565:4: rule__TokenERC721__AnswerAssignment_18_2
            	    {
            	    pushFollow(FOLLOW_18);
            	    rule__TokenERC721__AnswerAssignment_18_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

             after(grammarAccess.getTokenERC721Access().getAnswerAssignment_18_2()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_18__2__Impl"


    // $ANTLR start "rule__TokenERC721__Group_18__3"
    // InternalSmaCQA.g:3574:1: rule__TokenERC721__Group_18__3 : rule__TokenERC721__Group_18__3__Impl ;
    public final void rule__TokenERC721__Group_18__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3578:1: ( rule__TokenERC721__Group_18__3__Impl )
            // InternalSmaCQA.g:3579:2: rule__TokenERC721__Group_18__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group_18__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_18__3"


    // $ANTLR start "rule__TokenERC721__Group_18__3__Impl"
    // InternalSmaCQA.g:3585:1: rule__TokenERC721__Group_18__3__Impl : ( 'End Data Declaration' ) ;
    public final void rule__TokenERC721__Group_18__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3589:1: ( ( 'End Data Declaration' ) )
            // InternalSmaCQA.g:3590:1: ( 'End Data Declaration' )
            {
            // InternalSmaCQA.g:3590:1: ( 'End Data Declaration' )
            // InternalSmaCQA.g:3591:2: 'End Data Declaration'
            {
             before(grammarAccess.getTokenERC721Access().getEndDataDeclarationKeyword_18_3()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getEndDataDeclarationKeyword_18_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_18__3__Impl"


    // $ANTLR start "rule__TokenERC721__Group_19__0"
    // InternalSmaCQA.g:3601:1: rule__TokenERC721__Group_19__0 : rule__TokenERC721__Group_19__0__Impl rule__TokenERC721__Group_19__1 ;
    public final void rule__TokenERC721__Group_19__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3605:1: ( rule__TokenERC721__Group_19__0__Impl rule__TokenERC721__Group_19__1 )
            // InternalSmaCQA.g:3606:2: rule__TokenERC721__Group_19__0__Impl rule__TokenERC721__Group_19__1
            {
            pushFollow(FOLLOW_42);
            rule__TokenERC721__Group_19__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group_19__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_19__0"


    // $ANTLR start "rule__TokenERC721__Group_19__0__Impl"
    // InternalSmaCQA.g:3613:1: rule__TokenERC721__Group_19__0__Impl : ( '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' ) ;
    public final void rule__TokenERC721__Group_19__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3617:1: ( ( '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' ) )
            // InternalSmaCQA.g:3618:1: ( '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' )
            {
            // InternalSmaCQA.g:3618:1: ( '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' )
            // InternalSmaCQA.g:3619:2: '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?'
            {
             before(grammarAccess.getTokenERC721Access().getIfItSPossibleToDefineAnAmountToRestrictTheAmountOfNFTsThatAreMintedWhatIsTheMaximumAmountKeyword_19_0()); 
            match(input,62,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getIfItSPossibleToDefineAnAmountToRestrictTheAmountOfNFTsThatAreMintedWhatIsTheMaximumAmountKeyword_19_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_19__0__Impl"


    // $ANTLR start "rule__TokenERC721__Group_19__1"
    // InternalSmaCQA.g:3628:1: rule__TokenERC721__Group_19__1 : rule__TokenERC721__Group_19__1__Impl rule__TokenERC721__Group_19__2 ;
    public final void rule__TokenERC721__Group_19__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3632:1: ( rule__TokenERC721__Group_19__1__Impl rule__TokenERC721__Group_19__2 )
            // InternalSmaCQA.g:3633:2: rule__TokenERC721__Group_19__1__Impl rule__TokenERC721__Group_19__2
            {
            pushFollow(FOLLOW_24);
            rule__TokenERC721__Group_19__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group_19__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_19__1"


    // $ANTLR start "rule__TokenERC721__Group_19__1__Impl"
    // InternalSmaCQA.g:3640:1: rule__TokenERC721__Group_19__1__Impl : ( 'total supply = ' ) ;
    public final void rule__TokenERC721__Group_19__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3644:1: ( ( 'total supply = ' ) )
            // InternalSmaCQA.g:3645:1: ( 'total supply = ' )
            {
            // InternalSmaCQA.g:3645:1: ( 'total supply = ' )
            // InternalSmaCQA.g:3646:2: 'total supply = '
            {
             before(grammarAccess.getTokenERC721Access().getTotalSupplyKeyword_19_1()); 
            match(input,63,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getTotalSupplyKeyword_19_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_19__1__Impl"


    // $ANTLR start "rule__TokenERC721__Group_19__2"
    // InternalSmaCQA.g:3655:1: rule__TokenERC721__Group_19__2 : rule__TokenERC721__Group_19__2__Impl ;
    public final void rule__TokenERC721__Group_19__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3659:1: ( rule__TokenERC721__Group_19__2__Impl )
            // InternalSmaCQA.g:3660:2: rule__TokenERC721__Group_19__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__Group_19__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_19__2"


    // $ANTLR start "rule__TokenERC721__Group_19__2__Impl"
    // InternalSmaCQA.g:3666:1: rule__TokenERC721__Group_19__2__Impl : ( ( rule__TokenERC721__SupplyAssignment_19_2 ) ) ;
    public final void rule__TokenERC721__Group_19__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3670:1: ( ( ( rule__TokenERC721__SupplyAssignment_19_2 ) ) )
            // InternalSmaCQA.g:3671:1: ( ( rule__TokenERC721__SupplyAssignment_19_2 ) )
            {
            // InternalSmaCQA.g:3671:1: ( ( rule__TokenERC721__SupplyAssignment_19_2 ) )
            // InternalSmaCQA.g:3672:2: ( rule__TokenERC721__SupplyAssignment_19_2 )
            {
             before(grammarAccess.getTokenERC721Access().getSupplyAssignment_19_2()); 
            // InternalSmaCQA.g:3673:2: ( rule__TokenERC721__SupplyAssignment_19_2 )
            // InternalSmaCQA.g:3673:3: rule__TokenERC721__SupplyAssignment_19_2
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__SupplyAssignment_19_2();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getSupplyAssignment_19_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__Group_19__2__Impl"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__0"
    // InternalSmaCQA.g:3682:1: rule__TimeValueExchangeDurationQuestion__Group__0 : rule__TimeValueExchangeDurationQuestion__Group__0__Impl rule__TimeValueExchangeDurationQuestion__Group__1 ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3686:1: ( rule__TimeValueExchangeDurationQuestion__Group__0__Impl rule__TimeValueExchangeDurationQuestion__Group__1 )
            // InternalSmaCQA.g:3687:2: rule__TimeValueExchangeDurationQuestion__Group__0__Impl rule__TimeValueExchangeDurationQuestion__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__TimeValueExchangeDurationQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__0"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__0__Impl"
    // InternalSmaCQA.g:3694:1: rule__TimeValueExchangeDurationQuestion__Group__0__Impl : ( ( rule__TimeValueExchangeDurationQuestion__NameAssignment_0 ) ) ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3698:1: ( ( ( rule__TimeValueExchangeDurationQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:3699:1: ( ( rule__TimeValueExchangeDurationQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:3699:1: ( ( rule__TimeValueExchangeDurationQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:3700:2: ( rule__TimeValueExchangeDurationQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:3701:2: ( rule__TimeValueExchangeDurationQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:3701:3: rule__TimeValueExchangeDurationQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__0__Impl"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__1"
    // InternalSmaCQA.g:3709:1: rule__TimeValueExchangeDurationQuestion__Group__1 : rule__TimeValueExchangeDurationQuestion__Group__1__Impl rule__TimeValueExchangeDurationQuestion__Group__2 ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3713:1: ( rule__TimeValueExchangeDurationQuestion__Group__1__Impl rule__TimeValueExchangeDurationQuestion__Group__2 )
            // InternalSmaCQA.g:3714:2: rule__TimeValueExchangeDurationQuestion__Group__1__Impl rule__TimeValueExchangeDurationQuestion__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__TimeValueExchangeDurationQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__1"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__1__Impl"
    // InternalSmaCQA.g:3721:1: rule__TimeValueExchangeDurationQuestion__Group__1__Impl : ( 'answer = ' ) ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3725:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:3726:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:3726:1: ( 'answer = ' )
            // InternalSmaCQA.g:3727:2: 'answer = '
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__1__Impl"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__2"
    // InternalSmaCQA.g:3736:1: rule__TimeValueExchangeDurationQuestion__Group__2 : rule__TimeValueExchangeDurationQuestion__Group__2__Impl rule__TimeValueExchangeDurationQuestion__Group__3 ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3740:1: ( rule__TimeValueExchangeDurationQuestion__Group__2__Impl rule__TimeValueExchangeDurationQuestion__Group__3 )
            // InternalSmaCQA.g:3741:2: rule__TimeValueExchangeDurationQuestion__Group__2__Impl rule__TimeValueExchangeDurationQuestion__Group__3
            {
            pushFollow(FOLLOW_43);
            rule__TimeValueExchangeDurationQuestion__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__2"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__2__Impl"
    // InternalSmaCQA.g:3748:1: rule__TimeValueExchangeDurationQuestion__Group__2__Impl : ( ( rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2 ) ) ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3752:1: ( ( ( rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2 ) ) )
            // InternalSmaCQA.g:3753:1: ( ( rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2 ) )
            {
            // InternalSmaCQA.g:3753:1: ( ( rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:3754:2: ( rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:3755:2: ( rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:3755:3: rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__2__Impl"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__3"
    // InternalSmaCQA.g:3763:1: rule__TimeValueExchangeDurationQuestion__Group__3 : rule__TimeValueExchangeDurationQuestion__Group__3__Impl rule__TimeValueExchangeDurationQuestion__Group__4 ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3767:1: ( rule__TimeValueExchangeDurationQuestion__Group__3__Impl rule__TimeValueExchangeDurationQuestion__Group__4 )
            // InternalSmaCQA.g:3768:2: rule__TimeValueExchangeDurationQuestion__Group__3__Impl rule__TimeValueExchangeDurationQuestion__Group__4
            {
            pushFollow(FOLLOW_44);
            rule__TimeValueExchangeDurationQuestion__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__3"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__3__Impl"
    // InternalSmaCQA.g:3775:1: rule__TimeValueExchangeDurationQuestion__Group__3__Impl : ( 'unitTime = ' ) ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3779:1: ( ( 'unitTime = ' ) )
            // InternalSmaCQA.g:3780:1: ( 'unitTime = ' )
            {
            // InternalSmaCQA.g:3780:1: ( 'unitTime = ' )
            // InternalSmaCQA.g:3781:2: 'unitTime = '
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getUnitTimeKeyword_3()); 
            match(input,64,FOLLOW_2); 
             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getUnitTimeKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__3__Impl"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__4"
    // InternalSmaCQA.g:3790:1: rule__TimeValueExchangeDurationQuestion__Group__4 : rule__TimeValueExchangeDurationQuestion__Group__4__Impl ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3794:1: ( rule__TimeValueExchangeDurationQuestion__Group__4__Impl )
            // InternalSmaCQA.g:3795:2: rule__TimeValueExchangeDurationQuestion__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__4"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__Group__4__Impl"
    // InternalSmaCQA.g:3801:1: rule__TimeValueExchangeDurationQuestion__Group__4__Impl : ( ( rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4 ) ) ;
    public final void rule__TimeValueExchangeDurationQuestion__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3805:1: ( ( ( rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4 ) ) )
            // InternalSmaCQA.g:3806:1: ( ( rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4 ) )
            {
            // InternalSmaCQA.g:3806:1: ( ( rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4 ) )
            // InternalSmaCQA.g:3807:2: ( rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4 )
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerUnitTimeAssignment_4()); 
            // InternalSmaCQA.g:3808:2: ( rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4 )
            // InternalSmaCQA.g:3808:3: rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerUnitTimeAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__Group__4__Impl"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__0"
    // InternalSmaCQA.g:3817:1: rule__TimeStartValueExchangeQuestion__Group__0 : rule__TimeStartValueExchangeQuestion__Group__0__Impl rule__TimeStartValueExchangeQuestion__Group__1 ;
    public final void rule__TimeStartValueExchangeQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3821:1: ( rule__TimeStartValueExchangeQuestion__Group__0__Impl rule__TimeStartValueExchangeQuestion__Group__1 )
            // InternalSmaCQA.g:3822:2: rule__TimeStartValueExchangeQuestion__Group__0__Impl rule__TimeStartValueExchangeQuestion__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__TimeStartValueExchangeQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__0"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__0__Impl"
    // InternalSmaCQA.g:3829:1: rule__TimeStartValueExchangeQuestion__Group__0__Impl : ( ( rule__TimeStartValueExchangeQuestion__NameAssignment_0 ) ) ;
    public final void rule__TimeStartValueExchangeQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3833:1: ( ( ( rule__TimeStartValueExchangeQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:3834:1: ( ( rule__TimeStartValueExchangeQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:3834:1: ( ( rule__TimeStartValueExchangeQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:3835:2: ( rule__TimeStartValueExchangeQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:3836:2: ( rule__TimeStartValueExchangeQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:3836:3: rule__TimeStartValueExchangeQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__0__Impl"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__1"
    // InternalSmaCQA.g:3844:1: rule__TimeStartValueExchangeQuestion__Group__1 : rule__TimeStartValueExchangeQuestion__Group__1__Impl rule__TimeStartValueExchangeQuestion__Group__2 ;
    public final void rule__TimeStartValueExchangeQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3848:1: ( rule__TimeStartValueExchangeQuestion__Group__1__Impl rule__TimeStartValueExchangeQuestion__Group__2 )
            // InternalSmaCQA.g:3849:2: rule__TimeStartValueExchangeQuestion__Group__1__Impl rule__TimeStartValueExchangeQuestion__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__TimeStartValueExchangeQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__1"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__1__Impl"
    // InternalSmaCQA.g:3856:1: rule__TimeStartValueExchangeQuestion__Group__1__Impl : ( 'answer = ' ) ;
    public final void rule__TimeStartValueExchangeQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3860:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:3861:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:3861:1: ( 'answer = ' )
            // InternalSmaCQA.g:3862:2: 'answer = '
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__1__Impl"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__2"
    // InternalSmaCQA.g:3871:1: rule__TimeStartValueExchangeQuestion__Group__2 : rule__TimeStartValueExchangeQuestion__Group__2__Impl rule__TimeStartValueExchangeQuestion__Group__3 ;
    public final void rule__TimeStartValueExchangeQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3875:1: ( rule__TimeStartValueExchangeQuestion__Group__2__Impl rule__TimeStartValueExchangeQuestion__Group__3 )
            // InternalSmaCQA.g:3876:2: rule__TimeStartValueExchangeQuestion__Group__2__Impl rule__TimeStartValueExchangeQuestion__Group__3
            {
            pushFollow(FOLLOW_43);
            rule__TimeStartValueExchangeQuestion__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__2"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__2__Impl"
    // InternalSmaCQA.g:3883:1: rule__TimeStartValueExchangeQuestion__Group__2__Impl : ( ( rule__TimeStartValueExchangeQuestion__AnswerAssignment_2 ) ) ;
    public final void rule__TimeStartValueExchangeQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3887:1: ( ( ( rule__TimeStartValueExchangeQuestion__AnswerAssignment_2 ) ) )
            // InternalSmaCQA.g:3888:1: ( ( rule__TimeStartValueExchangeQuestion__AnswerAssignment_2 ) )
            {
            // InternalSmaCQA.g:3888:1: ( ( rule__TimeStartValueExchangeQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:3889:2: ( rule__TimeStartValueExchangeQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:3890:2: ( rule__TimeStartValueExchangeQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:3890:3: rule__TimeStartValueExchangeQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__2__Impl"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__3"
    // InternalSmaCQA.g:3898:1: rule__TimeStartValueExchangeQuestion__Group__3 : rule__TimeStartValueExchangeQuestion__Group__3__Impl rule__TimeStartValueExchangeQuestion__Group__4 ;
    public final void rule__TimeStartValueExchangeQuestion__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3902:1: ( rule__TimeStartValueExchangeQuestion__Group__3__Impl rule__TimeStartValueExchangeQuestion__Group__4 )
            // InternalSmaCQA.g:3903:2: rule__TimeStartValueExchangeQuestion__Group__3__Impl rule__TimeStartValueExchangeQuestion__Group__4
            {
            pushFollow(FOLLOW_44);
            rule__TimeStartValueExchangeQuestion__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__3"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__3__Impl"
    // InternalSmaCQA.g:3910:1: rule__TimeStartValueExchangeQuestion__Group__3__Impl : ( 'unitTime = ' ) ;
    public final void rule__TimeStartValueExchangeQuestion__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3914:1: ( ( 'unitTime = ' ) )
            // InternalSmaCQA.g:3915:1: ( 'unitTime = ' )
            {
            // InternalSmaCQA.g:3915:1: ( 'unitTime = ' )
            // InternalSmaCQA.g:3916:2: 'unitTime = '
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getUnitTimeKeyword_3()); 
            match(input,64,FOLLOW_2); 
             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getUnitTimeKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__3__Impl"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__4"
    // InternalSmaCQA.g:3925:1: rule__TimeStartValueExchangeQuestion__Group__4 : rule__TimeStartValueExchangeQuestion__Group__4__Impl ;
    public final void rule__TimeStartValueExchangeQuestion__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3929:1: ( rule__TimeStartValueExchangeQuestion__Group__4__Impl )
            // InternalSmaCQA.g:3930:2: rule__TimeStartValueExchangeQuestion__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__4"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__Group__4__Impl"
    // InternalSmaCQA.g:3936:1: rule__TimeStartValueExchangeQuestion__Group__4__Impl : ( ( rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4 ) ) ;
    public final void rule__TimeStartValueExchangeQuestion__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3940:1: ( ( ( rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4 ) ) )
            // InternalSmaCQA.g:3941:1: ( ( rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4 ) )
            {
            // InternalSmaCQA.g:3941:1: ( ( rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4 ) )
            // InternalSmaCQA.g:3942:2: ( rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4 )
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerUnitTimeAssignment_4()); 
            // InternalSmaCQA.g:3943:2: ( rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4 )
            // InternalSmaCQA.g:3943:3: rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerUnitTimeAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__Group__4__Impl"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__Group__0"
    // InternalSmaCQA.g:3952:1: rule__RepeatValueExchangeQuestion__Group__0 : rule__RepeatValueExchangeQuestion__Group__0__Impl rule__RepeatValueExchangeQuestion__Group__1 ;
    public final void rule__RepeatValueExchangeQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3956:1: ( rule__RepeatValueExchangeQuestion__Group__0__Impl rule__RepeatValueExchangeQuestion__Group__1 )
            // InternalSmaCQA.g:3957:2: rule__RepeatValueExchangeQuestion__Group__0__Impl rule__RepeatValueExchangeQuestion__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__RepeatValueExchangeQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RepeatValueExchangeQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__Group__0"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__Group__0__Impl"
    // InternalSmaCQA.g:3964:1: rule__RepeatValueExchangeQuestion__Group__0__Impl : ( ( rule__RepeatValueExchangeQuestion__NameAssignment_0 ) ) ;
    public final void rule__RepeatValueExchangeQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3968:1: ( ( ( rule__RepeatValueExchangeQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:3969:1: ( ( rule__RepeatValueExchangeQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:3969:1: ( ( rule__RepeatValueExchangeQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:3970:2: ( rule__RepeatValueExchangeQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getRepeatValueExchangeQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:3971:2: ( rule__RepeatValueExchangeQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:3971:3: rule__RepeatValueExchangeQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__RepeatValueExchangeQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getRepeatValueExchangeQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__Group__0__Impl"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__Group__1"
    // InternalSmaCQA.g:3979:1: rule__RepeatValueExchangeQuestion__Group__1 : rule__RepeatValueExchangeQuestion__Group__1__Impl rule__RepeatValueExchangeQuestion__Group__2 ;
    public final void rule__RepeatValueExchangeQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3983:1: ( rule__RepeatValueExchangeQuestion__Group__1__Impl rule__RepeatValueExchangeQuestion__Group__2 )
            // InternalSmaCQA.g:3984:2: rule__RepeatValueExchangeQuestion__Group__1__Impl rule__RepeatValueExchangeQuestion__Group__2
            {
            pushFollow(FOLLOW_13);
            rule__RepeatValueExchangeQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RepeatValueExchangeQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__Group__1"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__Group__1__Impl"
    // InternalSmaCQA.g:3991:1: rule__RepeatValueExchangeQuestion__Group__1__Impl : ( 'answer = ' ) ;
    public final void rule__RepeatValueExchangeQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:3995:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:3996:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:3996:1: ( 'answer = ' )
            // InternalSmaCQA.g:3997:2: 'answer = '
            {
             before(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__Group__1__Impl"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__Group__2"
    // InternalSmaCQA.g:4006:1: rule__RepeatValueExchangeQuestion__Group__2 : rule__RepeatValueExchangeQuestion__Group__2__Impl ;
    public final void rule__RepeatValueExchangeQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4010:1: ( rule__RepeatValueExchangeQuestion__Group__2__Impl )
            // InternalSmaCQA.g:4011:2: rule__RepeatValueExchangeQuestion__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RepeatValueExchangeQuestion__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__Group__2"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__Group__2__Impl"
    // InternalSmaCQA.g:4017:1: rule__RepeatValueExchangeQuestion__Group__2__Impl : ( ( rule__RepeatValueExchangeQuestion__AnswerAssignment_2 ) ) ;
    public final void rule__RepeatValueExchangeQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4021:1: ( ( ( rule__RepeatValueExchangeQuestion__AnswerAssignment_2 ) ) )
            // InternalSmaCQA.g:4022:1: ( ( rule__RepeatValueExchangeQuestion__AnswerAssignment_2 ) )
            {
            // InternalSmaCQA.g:4022:1: ( ( rule__RepeatValueExchangeQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:4023:2: ( rule__RepeatValueExchangeQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:4024:2: ( rule__RepeatValueExchangeQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:4024:3: rule__RepeatValueExchangeQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__RepeatValueExchangeQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__Group__2__Impl"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__Group__0"
    // InternalSmaCQA.g:4033:1: rule__ConditionsValueExchangeQuestion__Group__0 : rule__ConditionsValueExchangeQuestion__Group__0__Impl rule__ConditionsValueExchangeQuestion__Group__1 ;
    public final void rule__ConditionsValueExchangeQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4037:1: ( rule__ConditionsValueExchangeQuestion__Group__0__Impl rule__ConditionsValueExchangeQuestion__Group__1 )
            // InternalSmaCQA.g:4038:2: rule__ConditionsValueExchangeQuestion__Group__0__Impl rule__ConditionsValueExchangeQuestion__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__ConditionsValueExchangeQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ConditionsValueExchangeQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__Group__0"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__Group__0__Impl"
    // InternalSmaCQA.g:4045:1: rule__ConditionsValueExchangeQuestion__Group__0__Impl : ( ( rule__ConditionsValueExchangeQuestion__NameAssignment_0 ) ) ;
    public final void rule__ConditionsValueExchangeQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4049:1: ( ( ( rule__ConditionsValueExchangeQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:4050:1: ( ( rule__ConditionsValueExchangeQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:4050:1: ( ( rule__ConditionsValueExchangeQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:4051:2: ( rule__ConditionsValueExchangeQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getConditionsValueExchangeQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:4052:2: ( rule__ConditionsValueExchangeQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:4052:3: rule__ConditionsValueExchangeQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ConditionsValueExchangeQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getConditionsValueExchangeQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__Group__0__Impl"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__Group__1"
    // InternalSmaCQA.g:4060:1: rule__ConditionsValueExchangeQuestion__Group__1 : rule__ConditionsValueExchangeQuestion__Group__1__Impl rule__ConditionsValueExchangeQuestion__Group__2 ;
    public final void rule__ConditionsValueExchangeQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4064:1: ( rule__ConditionsValueExchangeQuestion__Group__1__Impl rule__ConditionsValueExchangeQuestion__Group__2 )
            // InternalSmaCQA.g:4065:2: rule__ConditionsValueExchangeQuestion__Group__1__Impl rule__ConditionsValueExchangeQuestion__Group__2
            {
            pushFollow(FOLLOW_13);
            rule__ConditionsValueExchangeQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ConditionsValueExchangeQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__Group__1"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__Group__1__Impl"
    // InternalSmaCQA.g:4072:1: rule__ConditionsValueExchangeQuestion__Group__1__Impl : ( 'answer = ' ) ;
    public final void rule__ConditionsValueExchangeQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4076:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:4077:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:4077:1: ( 'answer = ' )
            // InternalSmaCQA.g:4078:2: 'answer = '
            {
             before(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__Group__1__Impl"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__Group__2"
    // InternalSmaCQA.g:4087:1: rule__ConditionsValueExchangeQuestion__Group__2 : rule__ConditionsValueExchangeQuestion__Group__2__Impl ;
    public final void rule__ConditionsValueExchangeQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4091:1: ( rule__ConditionsValueExchangeQuestion__Group__2__Impl )
            // InternalSmaCQA.g:4092:2: rule__ConditionsValueExchangeQuestion__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ConditionsValueExchangeQuestion__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__Group__2"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__Group__2__Impl"
    // InternalSmaCQA.g:4098:1: rule__ConditionsValueExchangeQuestion__Group__2__Impl : ( ( rule__ConditionsValueExchangeQuestion__AnswerAssignment_2 ) ) ;
    public final void rule__ConditionsValueExchangeQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4102:1: ( ( ( rule__ConditionsValueExchangeQuestion__AnswerAssignment_2 ) ) )
            // InternalSmaCQA.g:4103:1: ( ( rule__ConditionsValueExchangeQuestion__AnswerAssignment_2 ) )
            {
            // InternalSmaCQA.g:4103:1: ( ( rule__ConditionsValueExchangeQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:4104:2: ( rule__ConditionsValueExchangeQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:4105:2: ( rule__ConditionsValueExchangeQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:4105:3: rule__ConditionsValueExchangeQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ConditionsValueExchangeQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__Group__2__Impl"


    // $ANTLR start "rule__LegalQuestion__Group__0"
    // InternalSmaCQA.g:4114:1: rule__LegalQuestion__Group__0 : rule__LegalQuestion__Group__0__Impl rule__LegalQuestion__Group__1 ;
    public final void rule__LegalQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4118:1: ( rule__LegalQuestion__Group__0__Impl rule__LegalQuestion__Group__1 )
            // InternalSmaCQA.g:4119:2: rule__LegalQuestion__Group__0__Impl rule__LegalQuestion__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__LegalQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LegalQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LegalQuestion__Group__0"


    // $ANTLR start "rule__LegalQuestion__Group__0__Impl"
    // InternalSmaCQA.g:4126:1: rule__LegalQuestion__Group__0__Impl : ( ( rule__LegalQuestion__AgeQuestionAssignment_0 )? ) ;
    public final void rule__LegalQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4130:1: ( ( ( rule__LegalQuestion__AgeQuestionAssignment_0 )? ) )
            // InternalSmaCQA.g:4131:1: ( ( rule__LegalQuestion__AgeQuestionAssignment_0 )? )
            {
            // InternalSmaCQA.g:4131:1: ( ( rule__LegalQuestion__AgeQuestionAssignment_0 )? )
            // InternalSmaCQA.g:4132:2: ( rule__LegalQuestion__AgeQuestionAssignment_0 )?
            {
             before(grammarAccess.getLegalQuestionAccess().getAgeQuestionAssignment_0()); 
            // InternalSmaCQA.g:4133:2: ( rule__LegalQuestion__AgeQuestionAssignment_0 )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==72) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSmaCQA.g:4133:3: rule__LegalQuestion__AgeQuestionAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__LegalQuestion__AgeQuestionAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLegalQuestionAccess().getAgeQuestionAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LegalQuestion__Group__0__Impl"


    // $ANTLR start "rule__LegalQuestion__Group__1"
    // InternalSmaCQA.g:4141:1: rule__LegalQuestion__Group__1 : rule__LegalQuestion__Group__1__Impl ;
    public final void rule__LegalQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4145:1: ( rule__LegalQuestion__Group__1__Impl )
            // InternalSmaCQA.g:4146:2: rule__LegalQuestion__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LegalQuestion__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LegalQuestion__Group__1"


    // $ANTLR start "rule__LegalQuestion__Group__1__Impl"
    // InternalSmaCQA.g:4152:1: rule__LegalQuestion__Group__1__Impl : ( ( rule__LegalQuestion__TaxQuestionAssignment_1 )? ) ;
    public final void rule__LegalQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4156:1: ( ( ( rule__LegalQuestion__TaxQuestionAssignment_1 )? ) )
            // InternalSmaCQA.g:4157:1: ( ( rule__LegalQuestion__TaxQuestionAssignment_1 )? )
            {
            // InternalSmaCQA.g:4157:1: ( ( rule__LegalQuestion__TaxQuestionAssignment_1 )? )
            // InternalSmaCQA.g:4158:2: ( rule__LegalQuestion__TaxQuestionAssignment_1 )?
            {
             before(grammarAccess.getLegalQuestionAccess().getTaxQuestionAssignment_1()); 
            // InternalSmaCQA.g:4159:2: ( rule__LegalQuestion__TaxQuestionAssignment_1 )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==73) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSmaCQA.g:4159:3: rule__LegalQuestion__TaxQuestionAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__LegalQuestion__TaxQuestionAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLegalQuestionAccess().getTaxQuestionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LegalQuestion__Group__1__Impl"


    // $ANTLR start "rule__AgeQuestion__Group__0"
    // InternalSmaCQA.g:4168:1: rule__AgeQuestion__Group__0 : rule__AgeQuestion__Group__0__Impl rule__AgeQuestion__Group__1 ;
    public final void rule__AgeQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4172:1: ( rule__AgeQuestion__Group__0__Impl rule__AgeQuestion__Group__1 )
            // InternalSmaCQA.g:4173:2: rule__AgeQuestion__Group__0__Impl rule__AgeQuestion__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__AgeQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AgeQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AgeQuestion__Group__0"


    // $ANTLR start "rule__AgeQuestion__Group__0__Impl"
    // InternalSmaCQA.g:4180:1: rule__AgeQuestion__Group__0__Impl : ( ( rule__AgeQuestion__NameAssignment_0 ) ) ;
    public final void rule__AgeQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4184:1: ( ( ( rule__AgeQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:4185:1: ( ( rule__AgeQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:4185:1: ( ( rule__AgeQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:4186:2: ( rule__AgeQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getAgeQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:4187:2: ( rule__AgeQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:4187:3: rule__AgeQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__AgeQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getAgeQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AgeQuestion__Group__0__Impl"


    // $ANTLR start "rule__AgeQuestion__Group__1"
    // InternalSmaCQA.g:4195:1: rule__AgeQuestion__Group__1 : rule__AgeQuestion__Group__1__Impl rule__AgeQuestion__Group__2 ;
    public final void rule__AgeQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4199:1: ( rule__AgeQuestion__Group__1__Impl rule__AgeQuestion__Group__2 )
            // InternalSmaCQA.g:4200:2: rule__AgeQuestion__Group__1__Impl rule__AgeQuestion__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__AgeQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AgeQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AgeQuestion__Group__1"


    // $ANTLR start "rule__AgeQuestion__Group__1__Impl"
    // InternalSmaCQA.g:4207:1: rule__AgeQuestion__Group__1__Impl : ( 'answer = ' ) ;
    public final void rule__AgeQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4211:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:4212:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:4212:1: ( 'answer = ' )
            // InternalSmaCQA.g:4213:2: 'answer = '
            {
             before(grammarAccess.getAgeQuestionAccess().getAnswerKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getAgeQuestionAccess().getAnswerKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AgeQuestion__Group__1__Impl"


    // $ANTLR start "rule__AgeQuestion__Group__2"
    // InternalSmaCQA.g:4222:1: rule__AgeQuestion__Group__2 : rule__AgeQuestion__Group__2__Impl ;
    public final void rule__AgeQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4226:1: ( rule__AgeQuestion__Group__2__Impl )
            // InternalSmaCQA.g:4227:2: rule__AgeQuestion__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__AgeQuestion__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AgeQuestion__Group__2"


    // $ANTLR start "rule__AgeQuestion__Group__2__Impl"
    // InternalSmaCQA.g:4233:1: rule__AgeQuestion__Group__2__Impl : ( ( rule__AgeQuestion__AnswerAssignment_2 ) ) ;
    public final void rule__AgeQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4237:1: ( ( ( rule__AgeQuestion__AnswerAssignment_2 ) ) )
            // InternalSmaCQA.g:4238:1: ( ( rule__AgeQuestion__AnswerAssignment_2 ) )
            {
            // InternalSmaCQA.g:4238:1: ( ( rule__AgeQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:4239:2: ( rule__AgeQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getAgeQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:4240:2: ( rule__AgeQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:4240:3: rule__AgeQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__AgeQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getAgeQuestionAccess().getAnswerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AgeQuestion__Group__2__Impl"


    // $ANTLR start "rule__TaxQuestion__Group__0"
    // InternalSmaCQA.g:4249:1: rule__TaxQuestion__Group__0 : rule__TaxQuestion__Group__0__Impl rule__TaxQuestion__Group__1 ;
    public final void rule__TaxQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4253:1: ( rule__TaxQuestion__Group__0__Impl rule__TaxQuestion__Group__1 )
            // InternalSmaCQA.g:4254:2: rule__TaxQuestion__Group__0__Impl rule__TaxQuestion__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__TaxQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TaxQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__0"


    // $ANTLR start "rule__TaxQuestion__Group__0__Impl"
    // InternalSmaCQA.g:4261:1: rule__TaxQuestion__Group__0__Impl : ( ( rule__TaxQuestion__NameAssignment_0 ) ) ;
    public final void rule__TaxQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4265:1: ( ( ( rule__TaxQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:4266:1: ( ( rule__TaxQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:4266:1: ( ( rule__TaxQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:4267:2: ( rule__TaxQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getTaxQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:4268:2: ( rule__TaxQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:4268:3: rule__TaxQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__TaxQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getTaxQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__0__Impl"


    // $ANTLR start "rule__TaxQuestion__Group__1"
    // InternalSmaCQA.g:4276:1: rule__TaxQuestion__Group__1 : rule__TaxQuestion__Group__1__Impl rule__TaxQuestion__Group__2 ;
    public final void rule__TaxQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4280:1: ( rule__TaxQuestion__Group__1__Impl rule__TaxQuestion__Group__2 )
            // InternalSmaCQA.g:4281:2: rule__TaxQuestion__Group__1__Impl rule__TaxQuestion__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__TaxQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TaxQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__1"


    // $ANTLR start "rule__TaxQuestion__Group__1__Impl"
    // InternalSmaCQA.g:4288:1: rule__TaxQuestion__Group__1__Impl : ( 'answer = ' ) ;
    public final void rule__TaxQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4292:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:4293:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:4293:1: ( 'answer = ' )
            // InternalSmaCQA.g:4294:2: 'answer = '
            {
             before(grammarAccess.getTaxQuestionAccess().getAnswerKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTaxQuestionAccess().getAnswerKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__1__Impl"


    // $ANTLR start "rule__TaxQuestion__Group__2"
    // InternalSmaCQA.g:4303:1: rule__TaxQuestion__Group__2 : rule__TaxQuestion__Group__2__Impl rule__TaxQuestion__Group__3 ;
    public final void rule__TaxQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4307:1: ( rule__TaxQuestion__Group__2__Impl rule__TaxQuestion__Group__3 )
            // InternalSmaCQA.g:4308:2: rule__TaxQuestion__Group__2__Impl rule__TaxQuestion__Group__3
            {
            pushFollow(FOLLOW_45);
            rule__TaxQuestion__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TaxQuestion__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__2"


    // $ANTLR start "rule__TaxQuestion__Group__2__Impl"
    // InternalSmaCQA.g:4315:1: rule__TaxQuestion__Group__2__Impl : ( ( rule__TaxQuestion__AnswerAssignment_2 ) ) ;
    public final void rule__TaxQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4319:1: ( ( ( rule__TaxQuestion__AnswerAssignment_2 ) ) )
            // InternalSmaCQA.g:4320:1: ( ( rule__TaxQuestion__AnswerAssignment_2 ) )
            {
            // InternalSmaCQA.g:4320:1: ( ( rule__TaxQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:4321:2: ( rule__TaxQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getTaxQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:4322:2: ( rule__TaxQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:4322:3: rule__TaxQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__TaxQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getTaxQuestionAccess().getAnswerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__2__Impl"


    // $ANTLR start "rule__TaxQuestion__Group__3"
    // InternalSmaCQA.g:4330:1: rule__TaxQuestion__Group__3 : rule__TaxQuestion__Group__3__Impl rule__TaxQuestion__Group__4 ;
    public final void rule__TaxQuestion__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4334:1: ( rule__TaxQuestion__Group__3__Impl rule__TaxQuestion__Group__4 )
            // InternalSmaCQA.g:4335:2: rule__TaxQuestion__Group__3__Impl rule__TaxQuestion__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__TaxQuestion__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TaxQuestion__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__3"


    // $ANTLR start "rule__TaxQuestion__Group__3__Impl"
    // InternalSmaCQA.g:4342:1: rule__TaxQuestion__Group__3__Impl : ( ( rule__TaxQuestion__SubSentenceAssignment_3 ) ) ;
    public final void rule__TaxQuestion__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4346:1: ( ( ( rule__TaxQuestion__SubSentenceAssignment_3 ) ) )
            // InternalSmaCQA.g:4347:1: ( ( rule__TaxQuestion__SubSentenceAssignment_3 ) )
            {
            // InternalSmaCQA.g:4347:1: ( ( rule__TaxQuestion__SubSentenceAssignment_3 ) )
            // InternalSmaCQA.g:4348:2: ( rule__TaxQuestion__SubSentenceAssignment_3 )
            {
             before(grammarAccess.getTaxQuestionAccess().getSubSentenceAssignment_3()); 
            // InternalSmaCQA.g:4349:2: ( rule__TaxQuestion__SubSentenceAssignment_3 )
            // InternalSmaCQA.g:4349:3: rule__TaxQuestion__SubSentenceAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__TaxQuestion__SubSentenceAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getTaxQuestionAccess().getSubSentenceAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__3__Impl"


    // $ANTLR start "rule__TaxQuestion__Group__4"
    // InternalSmaCQA.g:4357:1: rule__TaxQuestion__Group__4 : rule__TaxQuestion__Group__4__Impl rule__TaxQuestion__Group__5 ;
    public final void rule__TaxQuestion__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4361:1: ( rule__TaxQuestion__Group__4__Impl rule__TaxQuestion__Group__5 )
            // InternalSmaCQA.g:4362:2: rule__TaxQuestion__Group__4__Impl rule__TaxQuestion__Group__5
            {
            pushFollow(FOLLOW_4);
            rule__TaxQuestion__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TaxQuestion__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__4"


    // $ANTLR start "rule__TaxQuestion__Group__4__Impl"
    // InternalSmaCQA.g:4369:1: rule__TaxQuestion__Group__4__Impl : ( 'answer = ' ) ;
    public final void rule__TaxQuestion__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4373:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:4374:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:4374:1: ( 'answer = ' )
            // InternalSmaCQA.g:4375:2: 'answer = '
            {
             before(grammarAccess.getTaxQuestionAccess().getAnswerKeyword_4()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getTaxQuestionAccess().getAnswerKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__4__Impl"


    // $ANTLR start "rule__TaxQuestion__Group__5"
    // InternalSmaCQA.g:4384:1: rule__TaxQuestion__Group__5 : rule__TaxQuestion__Group__5__Impl ;
    public final void rule__TaxQuestion__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4388:1: ( rule__TaxQuestion__Group__5__Impl )
            // InternalSmaCQA.g:4389:2: rule__TaxQuestion__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TaxQuestion__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__5"


    // $ANTLR start "rule__TaxQuestion__Group__5__Impl"
    // InternalSmaCQA.g:4395:1: rule__TaxQuestion__Group__5__Impl : ( ( rule__TaxQuestion__AnswerSubSentenceAssignment_5 ) ) ;
    public final void rule__TaxQuestion__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4399:1: ( ( ( rule__TaxQuestion__AnswerSubSentenceAssignment_5 ) ) )
            // InternalSmaCQA.g:4400:1: ( ( rule__TaxQuestion__AnswerSubSentenceAssignment_5 ) )
            {
            // InternalSmaCQA.g:4400:1: ( ( rule__TaxQuestion__AnswerSubSentenceAssignment_5 ) )
            // InternalSmaCQA.g:4401:2: ( rule__TaxQuestion__AnswerSubSentenceAssignment_5 )
            {
             before(grammarAccess.getTaxQuestionAccess().getAnswerSubSentenceAssignment_5()); 
            // InternalSmaCQA.g:4402:2: ( rule__TaxQuestion__AnswerSubSentenceAssignment_5 )
            // InternalSmaCQA.g:4402:3: rule__TaxQuestion__AnswerSubSentenceAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__TaxQuestion__AnswerSubSentenceAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getTaxQuestionAccess().getAnswerSubSentenceAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__Group__5__Impl"


    // $ANTLR start "rule__MinimumAmountQuestion__Group__0"
    // InternalSmaCQA.g:4411:1: rule__MinimumAmountQuestion__Group__0 : rule__MinimumAmountQuestion__Group__0__Impl rule__MinimumAmountQuestion__Group__1 ;
    public final void rule__MinimumAmountQuestion__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4415:1: ( rule__MinimumAmountQuestion__Group__0__Impl rule__MinimumAmountQuestion__Group__1 )
            // InternalSmaCQA.g:4416:2: rule__MinimumAmountQuestion__Group__0__Impl rule__MinimumAmountQuestion__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__MinimumAmountQuestion__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MinimumAmountQuestion__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MinimumAmountQuestion__Group__0"


    // $ANTLR start "rule__MinimumAmountQuestion__Group__0__Impl"
    // InternalSmaCQA.g:4423:1: rule__MinimumAmountQuestion__Group__0__Impl : ( ( rule__MinimumAmountQuestion__NameAssignment_0 ) ) ;
    public final void rule__MinimumAmountQuestion__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4427:1: ( ( ( rule__MinimumAmountQuestion__NameAssignment_0 ) ) )
            // InternalSmaCQA.g:4428:1: ( ( rule__MinimumAmountQuestion__NameAssignment_0 ) )
            {
            // InternalSmaCQA.g:4428:1: ( ( rule__MinimumAmountQuestion__NameAssignment_0 ) )
            // InternalSmaCQA.g:4429:2: ( rule__MinimumAmountQuestion__NameAssignment_0 )
            {
             before(grammarAccess.getMinimumAmountQuestionAccess().getNameAssignment_0()); 
            // InternalSmaCQA.g:4430:2: ( rule__MinimumAmountQuestion__NameAssignment_0 )
            // InternalSmaCQA.g:4430:3: rule__MinimumAmountQuestion__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__MinimumAmountQuestion__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getMinimumAmountQuestionAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MinimumAmountQuestion__Group__0__Impl"


    // $ANTLR start "rule__MinimumAmountQuestion__Group__1"
    // InternalSmaCQA.g:4438:1: rule__MinimumAmountQuestion__Group__1 : rule__MinimumAmountQuestion__Group__1__Impl rule__MinimumAmountQuestion__Group__2 ;
    public final void rule__MinimumAmountQuestion__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4442:1: ( rule__MinimumAmountQuestion__Group__1__Impl rule__MinimumAmountQuestion__Group__2 )
            // InternalSmaCQA.g:4443:2: rule__MinimumAmountQuestion__Group__1__Impl rule__MinimumAmountQuestion__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__MinimumAmountQuestion__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MinimumAmountQuestion__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MinimumAmountQuestion__Group__1"


    // $ANTLR start "rule__MinimumAmountQuestion__Group__1__Impl"
    // InternalSmaCQA.g:4450:1: rule__MinimumAmountQuestion__Group__1__Impl : ( 'answer = ' ) ;
    public final void rule__MinimumAmountQuestion__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4454:1: ( ( 'answer = ' ) )
            // InternalSmaCQA.g:4455:1: ( 'answer = ' )
            {
            // InternalSmaCQA.g:4455:1: ( 'answer = ' )
            // InternalSmaCQA.g:4456:2: 'answer = '
            {
             before(grammarAccess.getMinimumAmountQuestionAccess().getAnswerKeyword_1()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getMinimumAmountQuestionAccess().getAnswerKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MinimumAmountQuestion__Group__1__Impl"


    // $ANTLR start "rule__MinimumAmountQuestion__Group__2"
    // InternalSmaCQA.g:4465:1: rule__MinimumAmountQuestion__Group__2 : rule__MinimumAmountQuestion__Group__2__Impl ;
    public final void rule__MinimumAmountQuestion__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4469:1: ( rule__MinimumAmountQuestion__Group__2__Impl )
            // InternalSmaCQA.g:4470:2: rule__MinimumAmountQuestion__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MinimumAmountQuestion__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MinimumAmountQuestion__Group__2"


    // $ANTLR start "rule__MinimumAmountQuestion__Group__2__Impl"
    // InternalSmaCQA.g:4476:1: rule__MinimumAmountQuestion__Group__2__Impl : ( ( rule__MinimumAmountQuestion__AnswerAssignment_2 ) ) ;
    public final void rule__MinimumAmountQuestion__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4480:1: ( ( ( rule__MinimumAmountQuestion__AnswerAssignment_2 ) ) )
            // InternalSmaCQA.g:4481:1: ( ( rule__MinimumAmountQuestion__AnswerAssignment_2 ) )
            {
            // InternalSmaCQA.g:4481:1: ( ( rule__MinimumAmountQuestion__AnswerAssignment_2 ) )
            // InternalSmaCQA.g:4482:2: ( rule__MinimumAmountQuestion__AnswerAssignment_2 )
            {
             before(grammarAccess.getMinimumAmountQuestionAccess().getAnswerAssignment_2()); 
            // InternalSmaCQA.g:4483:2: ( rule__MinimumAmountQuestion__AnswerAssignment_2 )
            // InternalSmaCQA.g:4483:3: rule__MinimumAmountQuestion__AnswerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__MinimumAmountQuestion__AnswerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getMinimumAmountQuestionAccess().getAnswerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MinimumAmountQuestion__Group__2__Impl"


    // $ANTLR start "rule__Model__ValueExchangesAssignment"
    // InternalSmaCQA.g:4492:1: rule__Model__ValueExchangesAssignment : ( ruleValueExchange ) ;
    public final void rule__Model__ValueExchangesAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4496:1: ( ( ruleValueExchange ) )
            // InternalSmaCQA.g:4497:2: ( ruleValueExchange )
            {
            // InternalSmaCQA.g:4497:2: ( ruleValueExchange )
            // InternalSmaCQA.g:4498:3: ruleValueExchange
            {
             before(grammarAccess.getModelAccess().getValueExchangesValueExchangeParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleValueExchange();

            state._fsp--;

             after(grammarAccess.getModelAccess().getValueExchangesValueExchangeParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__ValueExchangesAssignment"


    // $ANTLR start "rule__ValueExchange__ActorSendAssignment_1"
    // InternalSmaCQA.g:4507:1: rule__ValueExchange__ActorSendAssignment_1 : ( RULE_ID ) ;
    public final void rule__ValueExchange__ActorSendAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4511:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4512:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4512:2: ( RULE_ID )
            // InternalSmaCQA.g:4513:3: RULE_ID
            {
             before(grammarAccess.getValueExchangeAccess().getActorSendIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getActorSendIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__ActorSendAssignment_1"


    // $ANTLR start "rule__ValueExchange__ActorReceiptAssignment_3"
    // InternalSmaCQA.g:4522:1: rule__ValueExchange__ActorReceiptAssignment_3 : ( RULE_ID ) ;
    public final void rule__ValueExchange__ActorReceiptAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4526:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4527:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4527:2: ( RULE_ID )
            // InternalSmaCQA.g:4528:3: RULE_ID
            {
             before(grammarAccess.getValueExchangeAccess().getActorReceiptIDTerminalRuleCall_3_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getActorReceiptIDTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__ActorReceiptAssignment_3"


    // $ANTLR start "rule__ValueExchange__ValueObjectAssignment_5"
    // InternalSmaCQA.g:4537:1: rule__ValueExchange__ValueObjectAssignment_5 : ( RULE_ID ) ;
    public final void rule__ValueExchange__ValueObjectAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4541:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4542:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4542:2: ( RULE_ID )
            // InternalSmaCQA.g:4543:3: RULE_ID
            {
             before(grammarAccess.getValueExchangeAccess().getValueObjectIDTerminalRuleCall_5_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getValueExchangeAccess().getValueObjectIDTerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__ValueObjectAssignment_5"


    // $ANTLR start "rule__ValueExchange__DataQuestionAssignment_8_2"
    // InternalSmaCQA.g:4552:1: rule__ValueExchange__DataQuestionAssignment_8_2 : ( ruleDataQuestion ) ;
    public final void rule__ValueExchange__DataQuestionAssignment_8_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4556:1: ( ( ruleDataQuestion ) )
            // InternalSmaCQA.g:4557:2: ( ruleDataQuestion )
            {
            // InternalSmaCQA.g:4557:2: ( ruleDataQuestion )
            // InternalSmaCQA.g:4558:3: ruleDataQuestion
            {
             before(grammarAccess.getValueExchangeAccess().getDataQuestionDataQuestionParserRuleCall_8_2_0()); 
            pushFollow(FOLLOW_2);
            ruleDataQuestion();

            state._fsp--;

             after(grammarAccess.getValueExchangeAccess().getDataQuestionDataQuestionParserRuleCall_8_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__DataQuestionAssignment_8_2"


    // $ANTLR start "rule__ValueExchange__LegalQuestionAssignment_9_2"
    // InternalSmaCQA.g:4567:1: rule__ValueExchange__LegalQuestionAssignment_9_2 : ( ruleLegalQuestion ) ;
    public final void rule__ValueExchange__LegalQuestionAssignment_9_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4571:1: ( ( ruleLegalQuestion ) )
            // InternalSmaCQA.g:4572:2: ( ruleLegalQuestion )
            {
            // InternalSmaCQA.g:4572:2: ( ruleLegalQuestion )
            // InternalSmaCQA.g:4573:3: ruleLegalQuestion
            {
             before(grammarAccess.getValueExchangeAccess().getLegalQuestionLegalQuestionParserRuleCall_9_2_0()); 
            pushFollow(FOLLOW_2);
            ruleLegalQuestion();

            state._fsp--;

             after(grammarAccess.getValueExchangeAccess().getLegalQuestionLegalQuestionParserRuleCall_9_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__LegalQuestionAssignment_9_2"


    // $ANTLR start "rule__ValueExchange__EconomyQuestionAssignment_10_2"
    // InternalSmaCQA.g:4582:1: rule__ValueExchange__EconomyQuestionAssignment_10_2 : ( ruleEconomyQuestion ) ;
    public final void rule__ValueExchange__EconomyQuestionAssignment_10_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4586:1: ( ( ruleEconomyQuestion ) )
            // InternalSmaCQA.g:4587:2: ( ruleEconomyQuestion )
            {
            // InternalSmaCQA.g:4587:2: ( ruleEconomyQuestion )
            // InternalSmaCQA.g:4588:3: ruleEconomyQuestion
            {
             before(grammarAccess.getValueExchangeAccess().getEconomyQuestionEconomyQuestionParserRuleCall_10_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEconomyQuestion();

            state._fsp--;

             after(grammarAccess.getValueExchangeAccess().getEconomyQuestionEconomyQuestionParserRuleCall_10_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueExchange__EconomyQuestionAssignment_10_2"


    // $ANTLR start "rule__DataQuestion__TimeDurationValueExchangeAssignment_0"
    // InternalSmaCQA.g:4597:1: rule__DataQuestion__TimeDurationValueExchangeAssignment_0 : ( ruleTimeValueExchangeDurationQuestion ) ;
    public final void rule__DataQuestion__TimeDurationValueExchangeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4601:1: ( ( ruleTimeValueExchangeDurationQuestion ) )
            // InternalSmaCQA.g:4602:2: ( ruleTimeValueExchangeDurationQuestion )
            {
            // InternalSmaCQA.g:4602:2: ( ruleTimeValueExchangeDurationQuestion )
            // InternalSmaCQA.g:4603:3: ruleTimeValueExchangeDurationQuestion
            {
             before(grammarAccess.getDataQuestionAccess().getTimeDurationValueExchangeTimeValueExchangeDurationQuestionParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleTimeValueExchangeDurationQuestion();

            state._fsp--;

             after(grammarAccess.getDataQuestionAccess().getTimeDurationValueExchangeTimeValueExchangeDurationQuestionParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__TimeDurationValueExchangeAssignment_0"


    // $ANTLR start "rule__DataQuestion__TimeStartValueExchangeAssignment_1"
    // InternalSmaCQA.g:4612:1: rule__DataQuestion__TimeStartValueExchangeAssignment_1 : ( ruleTimeStartValueExchangeQuestion ) ;
    public final void rule__DataQuestion__TimeStartValueExchangeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4616:1: ( ( ruleTimeStartValueExchangeQuestion ) )
            // InternalSmaCQA.g:4617:2: ( ruleTimeStartValueExchangeQuestion )
            {
            // InternalSmaCQA.g:4617:2: ( ruleTimeStartValueExchangeQuestion )
            // InternalSmaCQA.g:4618:3: ruleTimeStartValueExchangeQuestion
            {
             before(grammarAccess.getDataQuestionAccess().getTimeStartValueExchangeTimeStartValueExchangeQuestionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTimeStartValueExchangeQuestion();

            state._fsp--;

             after(grammarAccess.getDataQuestionAccess().getTimeStartValueExchangeTimeStartValueExchangeQuestionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__TimeStartValueExchangeAssignment_1"


    // $ANTLR start "rule__DataQuestion__RepeatValueExchangeAssignment_2"
    // InternalSmaCQA.g:4627:1: rule__DataQuestion__RepeatValueExchangeAssignment_2 : ( ruleRepeatValueExchangeQuestion ) ;
    public final void rule__DataQuestion__RepeatValueExchangeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4631:1: ( ( ruleRepeatValueExchangeQuestion ) )
            // InternalSmaCQA.g:4632:2: ( ruleRepeatValueExchangeQuestion )
            {
            // InternalSmaCQA.g:4632:2: ( ruleRepeatValueExchangeQuestion )
            // InternalSmaCQA.g:4633:3: ruleRepeatValueExchangeQuestion
            {
             before(grammarAccess.getDataQuestionAccess().getRepeatValueExchangeRepeatValueExchangeQuestionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleRepeatValueExchangeQuestion();

            state._fsp--;

             after(grammarAccess.getDataQuestionAccess().getRepeatValueExchangeRepeatValueExchangeQuestionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__RepeatValueExchangeAssignment_2"


    // $ANTLR start "rule__DataQuestion__ConditionValueExchangeAssignment_3"
    // InternalSmaCQA.g:4642:1: rule__DataQuestion__ConditionValueExchangeAssignment_3 : ( ruleConditionsValueExchangeQuestion ) ;
    public final void rule__DataQuestion__ConditionValueExchangeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4646:1: ( ( ruleConditionsValueExchangeQuestion ) )
            // InternalSmaCQA.g:4647:2: ( ruleConditionsValueExchangeQuestion )
            {
            // InternalSmaCQA.g:4647:2: ( ruleConditionsValueExchangeQuestion )
            // InternalSmaCQA.g:4648:3: ruleConditionsValueExchangeQuestion
            {
             before(grammarAccess.getDataQuestionAccess().getConditionValueExchangeConditionsValueExchangeQuestionParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleConditionsValueExchangeQuestion();

            state._fsp--;

             after(grammarAccess.getDataQuestionAccess().getConditionValueExchangeConditionsValueExchangeQuestionParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__ConditionValueExchangeAssignment_3"


    // $ANTLR start "rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4"
    // InternalSmaCQA.g:4657:1: rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4 : ( ruleValueObjectQuestion ) ;
    public final void rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4661:1: ( ( ruleValueObjectQuestion ) )
            // InternalSmaCQA.g:4662:2: ( ruleValueObjectQuestion )
            {
            // InternalSmaCQA.g:4662:2: ( ruleValueObjectQuestion )
            // InternalSmaCQA.g:4663:3: ruleValueObjectQuestion
            {
             before(grammarAccess.getDataQuestionAccess().getValueObjectTypeValueExchangeValueObjectQuestionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleValueObjectQuestion();

            state._fsp--;

             after(grammarAccess.getDataQuestionAccess().getValueObjectTypeValueExchangeValueObjectQuestionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataQuestion__ValueObjectTypeValueExchangeAssignment_4"


    // $ANTLR start "rule__ValueObjectRightQuestion__NameAssignment_0"
    // InternalSmaCQA.g:4672:1: rule__ValueObjectRightQuestion__NameAssignment_0 : ( ( '1.5 Is the object of value a right that can be reflected as active or inactive?' ) ) ;
    public final void rule__ValueObjectRightQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4676:1: ( ( ( '1.5 Is the object of value a right that can be reflected as active or inactive?' ) ) )
            // InternalSmaCQA.g:4677:2: ( ( '1.5 Is the object of value a right that can be reflected as active or inactive?' ) )
            {
            // InternalSmaCQA.g:4677:2: ( ( '1.5 Is the object of value a right that can be reflected as active or inactive?' ) )
            // InternalSmaCQA.g:4678:3: ( '1.5 Is the object of value a right that can be reflected as active or inactive?' )
            {
             before(grammarAccess.getValueObjectRightQuestionAccess().getName15IsTheObjectOfValueARightThatCanBeReflectedAsActiveOrInactiveKeyword_0_0()); 
            // InternalSmaCQA.g:4679:3: ( '1.5 Is the object of value a right that can be reflected as active or inactive?' )
            // InternalSmaCQA.g:4680:4: '1.5 Is the object of value a right that can be reflected as active or inactive?'
            {
             before(grammarAccess.getValueObjectRightQuestionAccess().getName15IsTheObjectOfValueARightThatCanBeReflectedAsActiveOrInactiveKeyword_0_0()); 
            match(input,65,FOLLOW_2); 
             after(grammarAccess.getValueObjectRightQuestionAccess().getName15IsTheObjectOfValueARightThatCanBeReflectedAsActiveOrInactiveKeyword_0_0()); 

            }

             after(grammarAccess.getValueObjectRightQuestionAccess().getName15IsTheObjectOfValueARightThatCanBeReflectedAsActiveOrInactiveKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__NameAssignment_0"


    // $ANTLR start "rule__ValueObjectRightQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:4691:1: rule__ValueObjectRightQuestion__AnswerAssignment_2 : ( ( rule__ValueObjectRightQuestion__AnswerAlternatives_2_0 ) ) ;
    public final void rule__ValueObjectRightQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4695:1: ( ( ( rule__ValueObjectRightQuestion__AnswerAlternatives_2_0 ) ) )
            // InternalSmaCQA.g:4696:2: ( ( rule__ValueObjectRightQuestion__AnswerAlternatives_2_0 ) )
            {
            // InternalSmaCQA.g:4696:2: ( ( rule__ValueObjectRightQuestion__AnswerAlternatives_2_0 ) )
            // InternalSmaCQA.g:4697:3: ( rule__ValueObjectRightQuestion__AnswerAlternatives_2_0 )
            {
             before(grammarAccess.getValueObjectRightQuestionAccess().getAnswerAlternatives_2_0()); 
            // InternalSmaCQA.g:4698:3: ( rule__ValueObjectRightQuestion__AnswerAlternatives_2_0 )
            // InternalSmaCQA.g:4698:4: rule__ValueObjectRightQuestion__AnswerAlternatives_2_0
            {
            pushFollow(FOLLOW_2);
            rule__ValueObjectRightQuestion__AnswerAlternatives_2_0();

            state._fsp--;


            }

             after(grammarAccess.getValueObjectRightQuestionAccess().getAnswerAlternatives_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectRightQuestion__AnswerAssignment_2"


    // $ANTLR start "rule__ValueObjectTokenQuestion__NameAssignment_0"
    // InternalSmaCQA.g:4706:1: rule__ValueObjectTokenQuestion__NameAssignment_0 : ( ( '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) ) ;
    public final void rule__ValueObjectTokenQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4710:1: ( ( ( '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) ) )
            // InternalSmaCQA.g:4711:2: ( ( '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) )
            {
            // InternalSmaCQA.g:4711:2: ( ( '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) )
            // InternalSmaCQA.g:4712:3: ( '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' )
            {
             before(grammarAccess.getValueObjectTokenQuestionAccess().getName15IfTheObjectOfValueTradedOnTheValueExchangeIsADigitalTokenWhatAreThePropertiesOfSaidTokenKeyword_0_0()); 
            // InternalSmaCQA.g:4713:3: ( '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' )
            // InternalSmaCQA.g:4714:4: '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?'
            {
             before(grammarAccess.getValueObjectTokenQuestionAccess().getName15IfTheObjectOfValueTradedOnTheValueExchangeIsADigitalTokenWhatAreThePropertiesOfSaidTokenKeyword_0_0()); 
            match(input,66,FOLLOW_2); 
             after(grammarAccess.getValueObjectTokenQuestionAccess().getName15IfTheObjectOfValueTradedOnTheValueExchangeIsADigitalTokenWhatAreThePropertiesOfSaidTokenKeyword_0_0()); 

            }

             after(grammarAccess.getValueObjectTokenQuestionAccess().getName15IfTheObjectOfValueTradedOnTheValueExchangeIsADigitalTokenWhatAreThePropertiesOfSaidTokenKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTokenQuestion__NameAssignment_0"


    // $ANTLR start "rule__ValueObjectTokenQuestion__AnswerAssignment_1"
    // InternalSmaCQA.g:4725:1: rule__ValueObjectTokenQuestion__AnswerAssignment_1 : ( ruleToken ) ;
    public final void rule__ValueObjectTokenQuestion__AnswerAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4729:1: ( ( ruleToken ) )
            // InternalSmaCQA.g:4730:2: ( ruleToken )
            {
            // InternalSmaCQA.g:4730:2: ( ruleToken )
            // InternalSmaCQA.g:4731:3: ruleToken
            {
             before(grammarAccess.getValueObjectTokenQuestionAccess().getAnswerTokenParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleToken();

            state._fsp--;

             after(grammarAccess.getValueObjectTokenQuestionAccess().getAnswerTokenParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTokenQuestion__AnswerAssignment_1"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__NameAssignment_0"
    // InternalSmaCQA.g:4740:1: rule__ValueObjectTangibleQuestion__NameAssignment_0 : ( ( '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) ) ;
    public final void rule__ValueObjectTangibleQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4744:1: ( ( ( '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) ) )
            // InternalSmaCQA.g:4745:2: ( ( '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) )
            {
            // InternalSmaCQA.g:4745:2: ( ( '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) )
            // InternalSmaCQA.g:4746:3: ( '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' )
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getName15IfTheObjectOfValueNegotiatedInTheValueExchangeIsATangibleEntityThatCanBeRepresentedAsADigitalEntityNotATokenWhatAreThePropertiesOfThatObjectKeyword_0_0()); 
            // InternalSmaCQA.g:4747:3: ( '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' )
            // InternalSmaCQA.g:4748:4: '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?'
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getName15IfTheObjectOfValueNegotiatedInTheValueExchangeIsATangibleEntityThatCanBeRepresentedAsADigitalEntityNotATokenWhatAreThePropertiesOfThatObjectKeyword_0_0()); 
            match(input,67,FOLLOW_2); 
             after(grammarAccess.getValueObjectTangibleQuestionAccess().getName15IfTheObjectOfValueNegotiatedInTheValueExchangeIsATangibleEntityThatCanBeRepresentedAsADigitalEntityNotATokenWhatAreThePropertiesOfThatObjectKeyword_0_0()); 

            }

             after(grammarAccess.getValueObjectTangibleQuestionAccess().getName15IfTheObjectOfValueNegotiatedInTheValueExchangeIsATangibleEntityThatCanBeRepresentedAsADigitalEntityNotATokenWhatAreThePropertiesOfThatObjectKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__NameAssignment_0"


    // $ANTLR start "rule__ValueObjectTangibleQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:4759:1: rule__ValueObjectTangibleQuestion__AnswerAssignment_2 : ( ruleDataRegister ) ;
    public final void rule__ValueObjectTangibleQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4763:1: ( ( ruleDataRegister ) )
            // InternalSmaCQA.g:4764:2: ( ruleDataRegister )
            {
            // InternalSmaCQA.g:4764:2: ( ruleDataRegister )
            // InternalSmaCQA.g:4765:3: ruleDataRegister
            {
             before(grammarAccess.getValueObjectTangibleQuestionAccess().getAnswerDataRegisterParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleDataRegister();

            state._fsp--;

             after(grammarAccess.getValueObjectTangibleQuestionAccess().getAnswerDataRegisterParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ValueObjectTangibleQuestion__AnswerAssignment_2"


    // $ANTLR start "rule__DataRegister__NameAssignment_1"
    // InternalSmaCQA.g:4774:1: rule__DataRegister__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__DataRegister__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4778:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4779:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4779:2: ( RULE_ID )
            // InternalSmaCQA.g:4780:3: RULE_ID
            {
             before(grammarAccess.getDataRegisterAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getDataRegisterAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__NameAssignment_1"


    // $ANTLR start "rule__DataRegister__TypeAssignment_3"
    // InternalSmaCQA.g:4789:1: rule__DataRegister__TypeAssignment_3 : ( ruleType ) ;
    public final void rule__DataRegister__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4793:1: ( ( ruleType ) )
            // InternalSmaCQA.g:4794:2: ( ruleType )
            {
            // InternalSmaCQA.g:4794:2: ( ruleType )
            // InternalSmaCQA.g:4795:3: ruleType
            {
             before(grammarAccess.getDataRegisterAccess().getTypeTypeEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleType();

            state._fsp--;

             after(grammarAccess.getDataRegisterAccess().getTypeTypeEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataRegister__TypeAssignment_3"


    // $ANTLR start "rule__TokenERC20__NameAssignment_2"
    // InternalSmaCQA.g:4804:1: rule__TokenERC20__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__TokenERC20__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4808:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4809:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4809:2: ( RULE_ID )
            // InternalSmaCQA.g:4810:3: RULE_ID
            {
             before(grammarAccess.getTokenERC20Access().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__NameAssignment_2"


    // $ANTLR start "rule__TokenERC20__SymbolAssignment_4"
    // InternalSmaCQA.g:4819:1: rule__TokenERC20__SymbolAssignment_4 : ( RULE_ID ) ;
    public final void rule__TokenERC20__SymbolAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4823:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4824:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4824:2: ( RULE_ID )
            // InternalSmaCQA.g:4825:3: RULE_ID
            {
             before(grammarAccess.getTokenERC20Access().getSymbolIDTerminalRuleCall_4_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getSymbolIDTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__SymbolAssignment_4"


    // $ANTLR start "rule__TokenERC20__DecimalsAssignment_6"
    // InternalSmaCQA.g:4834:1: rule__TokenERC20__DecimalsAssignment_6 : ( RULE_INT ) ;
    public final void rule__TokenERC20__DecimalsAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4838:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:4839:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:4839:2: ( RULE_INT )
            // InternalSmaCQA.g:4840:3: RULE_INT
            {
             before(grammarAccess.getTokenERC20Access().getDecimalsINTTerminalRuleCall_6_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getDecimalsINTTerminalRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__DecimalsAssignment_6"


    // $ANTLR start "rule__TokenERC20__SupplyAssignment_8"
    // InternalSmaCQA.g:4849:1: rule__TokenERC20__SupplyAssignment_8 : ( RULE_INT ) ;
    public final void rule__TokenERC20__SupplyAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4853:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:4854:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:4854:2: ( RULE_INT )
            // InternalSmaCQA.g:4855:3: RULE_INT
            {
             before(grammarAccess.getTokenERC20Access().getSupplyINTTerminalRuleCall_8_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTokenERC20Access().getSupplyINTTerminalRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__SupplyAssignment_8"


    // $ANTLR start "rule__TokenERC20__AnswerMintSentenceAssignment_11"
    // InternalSmaCQA.g:4864:1: rule__TokenERC20__AnswerMintSentenceAssignment_11 : ( ( rule__TokenERC20__AnswerMintSentenceAlternatives_11_0 ) ) ;
    public final void rule__TokenERC20__AnswerMintSentenceAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4868:1: ( ( ( rule__TokenERC20__AnswerMintSentenceAlternatives_11_0 ) ) )
            // InternalSmaCQA.g:4869:2: ( ( rule__TokenERC20__AnswerMintSentenceAlternatives_11_0 ) )
            {
            // InternalSmaCQA.g:4869:2: ( ( rule__TokenERC20__AnswerMintSentenceAlternatives_11_0 ) )
            // InternalSmaCQA.g:4870:3: ( rule__TokenERC20__AnswerMintSentenceAlternatives_11_0 )
            {
             before(grammarAccess.getTokenERC20Access().getAnswerMintSentenceAlternatives_11_0()); 
            // InternalSmaCQA.g:4871:3: ( rule__TokenERC20__AnswerMintSentenceAlternatives_11_0 )
            // InternalSmaCQA.g:4871:4: rule__TokenERC20__AnswerMintSentenceAlternatives_11_0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__AnswerMintSentenceAlternatives_11_0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getAnswerMintSentenceAlternatives_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__AnswerMintSentenceAssignment_11"


    // $ANTLR start "rule__TokenERC20__AnswerBurnSentenceAssignment_14"
    // InternalSmaCQA.g:4879:1: rule__TokenERC20__AnswerBurnSentenceAssignment_14 : ( ( rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0 ) ) ;
    public final void rule__TokenERC20__AnswerBurnSentenceAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4883:1: ( ( ( rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0 ) ) )
            // InternalSmaCQA.g:4884:2: ( ( rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0 ) )
            {
            // InternalSmaCQA.g:4884:2: ( ( rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0 ) )
            // InternalSmaCQA.g:4885:3: ( rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0 )
            {
             before(grammarAccess.getTokenERC20Access().getAnswerBurnSentenceAlternatives_14_0()); 
            // InternalSmaCQA.g:4886:3: ( rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0 )
            // InternalSmaCQA.g:4886:4: rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC20__AnswerBurnSentenceAlternatives_14_0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC20Access().getAnswerBurnSentenceAlternatives_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC20__AnswerBurnSentenceAssignment_14"


    // $ANTLR start "rule__TokenERC223__NameAssignment_2"
    // InternalSmaCQA.g:4894:1: rule__TokenERC223__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__TokenERC223__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4898:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4899:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4899:2: ( RULE_ID )
            // InternalSmaCQA.g:4900:3: RULE_ID
            {
             before(grammarAccess.getTokenERC223Access().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__NameAssignment_2"


    // $ANTLR start "rule__TokenERC223__SymbolAssignment_4"
    // InternalSmaCQA.g:4909:1: rule__TokenERC223__SymbolAssignment_4 : ( RULE_ID ) ;
    public final void rule__TokenERC223__SymbolAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4913:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4914:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4914:2: ( RULE_ID )
            // InternalSmaCQA.g:4915:3: RULE_ID
            {
             before(grammarAccess.getTokenERC223Access().getSymbolIDTerminalRuleCall_4_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getSymbolIDTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__SymbolAssignment_4"


    // $ANTLR start "rule__TokenERC223__DecimalsAssignment_6"
    // InternalSmaCQA.g:4924:1: rule__TokenERC223__DecimalsAssignment_6 : ( RULE_INT ) ;
    public final void rule__TokenERC223__DecimalsAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4928:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:4929:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:4929:2: ( RULE_INT )
            // InternalSmaCQA.g:4930:3: RULE_INT
            {
             before(grammarAccess.getTokenERC223Access().getDecimalsINTTerminalRuleCall_6_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getDecimalsINTTerminalRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__DecimalsAssignment_6"


    // $ANTLR start "rule__TokenERC223__SupplyAssignment_8"
    // InternalSmaCQA.g:4939:1: rule__TokenERC223__SupplyAssignment_8 : ( RULE_INT ) ;
    public final void rule__TokenERC223__SupplyAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4943:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:4944:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:4944:2: ( RULE_INT )
            // InternalSmaCQA.g:4945:3: RULE_INT
            {
             before(grammarAccess.getTokenERC223Access().getSupplyINTTerminalRuleCall_8_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTokenERC223Access().getSupplyINTTerminalRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__SupplyAssignment_8"


    // $ANTLR start "rule__TokenERC223__AnswerMintSentenceAssignment_11"
    // InternalSmaCQA.g:4954:1: rule__TokenERC223__AnswerMintSentenceAssignment_11 : ( ( rule__TokenERC223__AnswerMintSentenceAlternatives_11_0 ) ) ;
    public final void rule__TokenERC223__AnswerMintSentenceAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4958:1: ( ( ( rule__TokenERC223__AnswerMintSentenceAlternatives_11_0 ) ) )
            // InternalSmaCQA.g:4959:2: ( ( rule__TokenERC223__AnswerMintSentenceAlternatives_11_0 ) )
            {
            // InternalSmaCQA.g:4959:2: ( ( rule__TokenERC223__AnswerMintSentenceAlternatives_11_0 ) )
            // InternalSmaCQA.g:4960:3: ( rule__TokenERC223__AnswerMintSentenceAlternatives_11_0 )
            {
             before(grammarAccess.getTokenERC223Access().getAnswerMintSentenceAlternatives_11_0()); 
            // InternalSmaCQA.g:4961:3: ( rule__TokenERC223__AnswerMintSentenceAlternatives_11_0 )
            // InternalSmaCQA.g:4961:4: rule__TokenERC223__AnswerMintSentenceAlternatives_11_0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__AnswerMintSentenceAlternatives_11_0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getAnswerMintSentenceAlternatives_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__AnswerMintSentenceAssignment_11"


    // $ANTLR start "rule__TokenERC223__AnswerBurnSentenceAssignment_14"
    // InternalSmaCQA.g:4969:1: rule__TokenERC223__AnswerBurnSentenceAssignment_14 : ( ( rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0 ) ) ;
    public final void rule__TokenERC223__AnswerBurnSentenceAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4973:1: ( ( ( rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0 ) ) )
            // InternalSmaCQA.g:4974:2: ( ( rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0 ) )
            {
            // InternalSmaCQA.g:4974:2: ( ( rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0 ) )
            // InternalSmaCQA.g:4975:3: ( rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0 )
            {
             before(grammarAccess.getTokenERC223Access().getAnswerBurnSentenceAlternatives_14_0()); 
            // InternalSmaCQA.g:4976:3: ( rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0 )
            // InternalSmaCQA.g:4976:4: rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC223__AnswerBurnSentenceAlternatives_14_0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC223Access().getAnswerBurnSentenceAlternatives_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC223__AnswerBurnSentenceAssignment_14"


    // $ANTLR start "rule__TokenERC721__NameAssignment_2"
    // InternalSmaCQA.g:4984:1: rule__TokenERC721__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__TokenERC721__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:4988:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:4989:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:4989:2: ( RULE_ID )
            // InternalSmaCQA.g:4990:3: RULE_ID
            {
             before(grammarAccess.getTokenERC721Access().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__NameAssignment_2"


    // $ANTLR start "rule__TokenERC721__SymbolAssignment_4"
    // InternalSmaCQA.g:4999:1: rule__TokenERC721__SymbolAssignment_4 : ( RULE_ID ) ;
    public final void rule__TokenERC721__SymbolAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5003:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:5004:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:5004:2: ( RULE_ID )
            // InternalSmaCQA.g:5005:3: RULE_ID
            {
             before(grammarAccess.getTokenERC721Access().getSymbolIDTerminalRuleCall_4_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getSymbolIDTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__SymbolAssignment_4"


    // $ANTLR start "rule__TokenERC721__AnswerMintSentenceAssignment_7"
    // InternalSmaCQA.g:5014:1: rule__TokenERC721__AnswerMintSentenceAssignment_7 : ( ( rule__TokenERC721__AnswerMintSentenceAlternatives_7_0 ) ) ;
    public final void rule__TokenERC721__AnswerMintSentenceAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5018:1: ( ( ( rule__TokenERC721__AnswerMintSentenceAlternatives_7_0 ) ) )
            // InternalSmaCQA.g:5019:2: ( ( rule__TokenERC721__AnswerMintSentenceAlternatives_7_0 ) )
            {
            // InternalSmaCQA.g:5019:2: ( ( rule__TokenERC721__AnswerMintSentenceAlternatives_7_0 ) )
            // InternalSmaCQA.g:5020:3: ( rule__TokenERC721__AnswerMintSentenceAlternatives_7_0 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerMintSentenceAlternatives_7_0()); 
            // InternalSmaCQA.g:5021:3: ( rule__TokenERC721__AnswerMintSentenceAlternatives_7_0 )
            // InternalSmaCQA.g:5021:4: rule__TokenERC721__AnswerMintSentenceAlternatives_7_0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__AnswerMintSentenceAlternatives_7_0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerMintSentenceAlternatives_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerMintSentenceAssignment_7"


    // $ANTLR start "rule__TokenERC721__AnswerBurnSentenceAssignment_10"
    // InternalSmaCQA.g:5029:1: rule__TokenERC721__AnswerBurnSentenceAssignment_10 : ( ( rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0 ) ) ;
    public final void rule__TokenERC721__AnswerBurnSentenceAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5033:1: ( ( ( rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0 ) ) )
            // InternalSmaCQA.g:5034:2: ( ( rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0 ) )
            {
            // InternalSmaCQA.g:5034:2: ( ( rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0 ) )
            // InternalSmaCQA.g:5035:3: ( rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerBurnSentenceAlternatives_10_0()); 
            // InternalSmaCQA.g:5036:3: ( rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0 )
            // InternalSmaCQA.g:5036:4: rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__AnswerBurnSentenceAlternatives_10_0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerBurnSentenceAlternatives_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerBurnSentenceAssignment_10"


    // $ANTLR start "rule__TokenERC721__AnswerUnitPriceAssignment_13"
    // InternalSmaCQA.g:5044:1: rule__TokenERC721__AnswerUnitPriceAssignment_13 : ( RULE_INT ) ;
    public final void rule__TokenERC721__AnswerUnitPriceAssignment_13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5048:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:5049:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:5049:2: ( RULE_INT )
            // InternalSmaCQA.g:5050:3: RULE_INT
            {
             before(grammarAccess.getTokenERC721Access().getAnswerUnitPriceINTTerminalRuleCall_13_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getAnswerUnitPriceINTTerminalRuleCall_13_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerUnitPriceAssignment_13"


    // $ANTLR start "rule__TokenERC721__AnswerUnitCoinAssignment_14"
    // InternalSmaCQA.g:5059:1: rule__TokenERC721__AnswerUnitCoinAssignment_14 : ( ruleUnitCoin ) ;
    public final void rule__TokenERC721__AnswerUnitCoinAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5063:1: ( ( ruleUnitCoin ) )
            // InternalSmaCQA.g:5064:2: ( ruleUnitCoin )
            {
            // InternalSmaCQA.g:5064:2: ( ruleUnitCoin )
            // InternalSmaCQA.g:5065:3: ruleUnitCoin
            {
             before(grammarAccess.getTokenERC721Access().getAnswerUnitCoinUnitCoinEnumRuleCall_14_0()); 
            pushFollow(FOLLOW_2);
            ruleUnitCoin();

            state._fsp--;

             after(grammarAccess.getTokenERC721Access().getAnswerUnitCoinUnitCoinEnumRuleCall_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerUnitCoinAssignment_14"


    // $ANTLR start "rule__TokenERC721__AnswerMetadataSentenceAssignment_17"
    // InternalSmaCQA.g:5074:1: rule__TokenERC721__AnswerMetadataSentenceAssignment_17 : ( ( rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0 ) ) ;
    public final void rule__TokenERC721__AnswerMetadataSentenceAssignment_17() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5078:1: ( ( ( rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0 ) ) )
            // InternalSmaCQA.g:5079:2: ( ( rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0 ) )
            {
            // InternalSmaCQA.g:5079:2: ( ( rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0 ) )
            // InternalSmaCQA.g:5080:3: ( rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0 )
            {
             before(grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceAlternatives_17_0()); 
            // InternalSmaCQA.g:5081:3: ( rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0 )
            // InternalSmaCQA.g:5081:4: rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0
            {
            pushFollow(FOLLOW_2);
            rule__TokenERC721__AnswerMetadataSentenceAlternatives_17_0();

            state._fsp--;


            }

             after(grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceAlternatives_17_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerMetadataSentenceAssignment_17"


    // $ANTLR start "rule__TokenERC721__AnswerAssignment_18_2"
    // InternalSmaCQA.g:5089:1: rule__TokenERC721__AnswerAssignment_18_2 : ( ruleDataRegister ) ;
    public final void rule__TokenERC721__AnswerAssignment_18_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5093:1: ( ( ruleDataRegister ) )
            // InternalSmaCQA.g:5094:2: ( ruleDataRegister )
            {
            // InternalSmaCQA.g:5094:2: ( ruleDataRegister )
            // InternalSmaCQA.g:5095:3: ruleDataRegister
            {
             before(grammarAccess.getTokenERC721Access().getAnswerDataRegisterParserRuleCall_18_2_0()); 
            pushFollow(FOLLOW_2);
            ruleDataRegister();

            state._fsp--;

             after(grammarAccess.getTokenERC721Access().getAnswerDataRegisterParserRuleCall_18_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__AnswerAssignment_18_2"


    // $ANTLR start "rule__TokenERC721__SupplyAssignment_19_2"
    // InternalSmaCQA.g:5104:1: rule__TokenERC721__SupplyAssignment_19_2 : ( RULE_INT ) ;
    public final void rule__TokenERC721__SupplyAssignment_19_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5108:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:5109:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:5109:2: ( RULE_INT )
            // InternalSmaCQA.g:5110:3: RULE_INT
            {
             before(grammarAccess.getTokenERC721Access().getSupplyINTTerminalRuleCall_19_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTokenERC721Access().getSupplyINTTerminalRuleCall_19_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TokenERC721__SupplyAssignment_19_2"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__NameAssignment_0"
    // InternalSmaCQA.g:5119:1: rule__TimeValueExchangeDurationQuestion__NameAssignment_0 : ( ( '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) ) ;
    public final void rule__TimeValueExchangeDurationQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5123:1: ( ( ( '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) ) )
            // InternalSmaCQA.g:5124:2: ( ( '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) )
            {
            // InternalSmaCQA.g:5124:2: ( ( '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) )
            // InternalSmaCQA.g:5125:3: ( '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' )
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getName11IfTheExchangeOfValueIsSubjectToADurationOfTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0()); 
            // InternalSmaCQA.g:5126:3: ( '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' )
            // InternalSmaCQA.g:5127:4: '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)'
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getName11IfTheExchangeOfValueIsSubjectToADurationOfTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0()); 
            match(input,68,FOLLOW_2); 
             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getName11IfTheExchangeOfValueIsSubjectToADurationOfTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0()); 

            }

             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getName11IfTheExchangeOfValueIsSubjectToADurationOfTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__NameAssignment_0"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:5138:1: rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2 : ( RULE_INT ) ;
    public final void rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5142:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:5143:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:5143:2: ( RULE_INT )
            // InternalSmaCQA.g:5144:3: RULE_INT
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__AnswerAssignment_2"


    // $ANTLR start "rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4"
    // InternalSmaCQA.g:5153:1: rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4 : ( ruleUnitTime ) ;
    public final void rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5157:1: ( ( ruleUnitTime ) )
            // InternalSmaCQA.g:5158:2: ( ruleUnitTime )
            {
            // InternalSmaCQA.g:5158:2: ( ruleUnitTime )
            // InternalSmaCQA.g:5159:3: ruleUnitTime
            {
             before(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerUnitTimeUnitTimeEnumRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleUnitTime();

            state._fsp--;

             after(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerUnitTimeUnitTimeEnumRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeValueExchangeDurationQuestion__AnswerUnitTimeAssignment_4"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__NameAssignment_0"
    // InternalSmaCQA.g:5168:1: rule__TimeStartValueExchangeQuestion__NameAssignment_0 : ( ( '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) ) ;
    public final void rule__TimeStartValueExchangeQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5172:1: ( ( ( '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) ) )
            // InternalSmaCQA.g:5173:2: ( ( '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) )
            {
            // InternalSmaCQA.g:5173:2: ( ( '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) )
            // InternalSmaCQA.g:5174:3: ( '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' )
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getName12IfTheExchangeOfValueCouldOnlyTakePlaceAfterACertainTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0()); 
            // InternalSmaCQA.g:5175:3: ( '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' )
            // InternalSmaCQA.g:5176:4: '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)'
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getName12IfTheExchangeOfValueCouldOnlyTakePlaceAfterACertainTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0()); 
            match(input,69,FOLLOW_2); 
             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getName12IfTheExchangeOfValueCouldOnlyTakePlaceAfterACertainTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0()); 

            }

             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getName12IfTheExchangeOfValueCouldOnlyTakePlaceAfterACertainTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__NameAssignment_0"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:5187:1: rule__TimeStartValueExchangeQuestion__AnswerAssignment_2 : ( RULE_INT ) ;
    public final void rule__TimeStartValueExchangeQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5191:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:5192:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:5192:2: ( RULE_INT )
            // InternalSmaCQA.g:5193:3: RULE_INT
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__AnswerAssignment_2"


    // $ANTLR start "rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4"
    // InternalSmaCQA.g:5202:1: rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4 : ( ruleUnitTime ) ;
    public final void rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5206:1: ( ( ruleUnitTime ) )
            // InternalSmaCQA.g:5207:2: ( ruleUnitTime )
            {
            // InternalSmaCQA.g:5207:2: ( ruleUnitTime )
            // InternalSmaCQA.g:5208:3: ruleUnitTime
            {
             before(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerUnitTimeUnitTimeEnumRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleUnitTime();

            state._fsp--;

             after(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerUnitTimeUnitTimeEnumRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TimeStartValueExchangeQuestion__AnswerUnitTimeAssignment_4"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__NameAssignment_0"
    // InternalSmaCQA.g:5217:1: rule__RepeatValueExchangeQuestion__NameAssignment_0 : ( ( '1.3 Can the value exchange be repeated over time?' ) ) ;
    public final void rule__RepeatValueExchangeQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5221:1: ( ( ( '1.3 Can the value exchange be repeated over time?' ) ) )
            // InternalSmaCQA.g:5222:2: ( ( '1.3 Can the value exchange be repeated over time?' ) )
            {
            // InternalSmaCQA.g:5222:2: ( ( '1.3 Can the value exchange be repeated over time?' ) )
            // InternalSmaCQA.g:5223:3: ( '1.3 Can the value exchange be repeated over time?' )
            {
             before(grammarAccess.getRepeatValueExchangeQuestionAccess().getName13CanTheValueExchangeBeRepeatedOverTimeKeyword_0_0()); 
            // InternalSmaCQA.g:5224:3: ( '1.3 Can the value exchange be repeated over time?' )
            // InternalSmaCQA.g:5225:4: '1.3 Can the value exchange be repeated over time?'
            {
             before(grammarAccess.getRepeatValueExchangeQuestionAccess().getName13CanTheValueExchangeBeRepeatedOverTimeKeyword_0_0()); 
            match(input,70,FOLLOW_2); 
             after(grammarAccess.getRepeatValueExchangeQuestionAccess().getName13CanTheValueExchangeBeRepeatedOverTimeKeyword_0_0()); 

            }

             after(grammarAccess.getRepeatValueExchangeQuestionAccess().getName13CanTheValueExchangeBeRepeatedOverTimeKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__NameAssignment_0"


    // $ANTLR start "rule__RepeatValueExchangeQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:5236:1: rule__RepeatValueExchangeQuestion__AnswerAssignment_2 : ( ( rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0 ) ) ;
    public final void rule__RepeatValueExchangeQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5240:1: ( ( ( rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0 ) ) )
            // InternalSmaCQA.g:5241:2: ( ( rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0 ) )
            {
            // InternalSmaCQA.g:5241:2: ( ( rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0 ) )
            // InternalSmaCQA.g:5242:3: ( rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0 )
            {
             before(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerAlternatives_2_0()); 
            // InternalSmaCQA.g:5243:3: ( rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0 )
            // InternalSmaCQA.g:5243:4: rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0
            {
            pushFollow(FOLLOW_2);
            rule__RepeatValueExchangeQuestion__AnswerAlternatives_2_0();

            state._fsp--;


            }

             after(grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerAlternatives_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RepeatValueExchangeQuestion__AnswerAssignment_2"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__NameAssignment_0"
    // InternalSmaCQA.g:5251:1: rule__ConditionsValueExchangeQuestion__NameAssignment_0 : ( ( '1.4 Are the same conditions always maintained when exchanging value?' ) ) ;
    public final void rule__ConditionsValueExchangeQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5255:1: ( ( ( '1.4 Are the same conditions always maintained when exchanging value?' ) ) )
            // InternalSmaCQA.g:5256:2: ( ( '1.4 Are the same conditions always maintained when exchanging value?' ) )
            {
            // InternalSmaCQA.g:5256:2: ( ( '1.4 Are the same conditions always maintained when exchanging value?' ) )
            // InternalSmaCQA.g:5257:3: ( '1.4 Are the same conditions always maintained when exchanging value?' )
            {
             before(grammarAccess.getConditionsValueExchangeQuestionAccess().getName14AreTheSameConditionsAlwaysMaintainedWhenExchangingValueKeyword_0_0()); 
            // InternalSmaCQA.g:5258:3: ( '1.4 Are the same conditions always maintained when exchanging value?' )
            // InternalSmaCQA.g:5259:4: '1.4 Are the same conditions always maintained when exchanging value?'
            {
             before(grammarAccess.getConditionsValueExchangeQuestionAccess().getName14AreTheSameConditionsAlwaysMaintainedWhenExchangingValueKeyword_0_0()); 
            match(input,71,FOLLOW_2); 
             after(grammarAccess.getConditionsValueExchangeQuestionAccess().getName14AreTheSameConditionsAlwaysMaintainedWhenExchangingValueKeyword_0_0()); 

            }

             after(grammarAccess.getConditionsValueExchangeQuestionAccess().getName14AreTheSameConditionsAlwaysMaintainedWhenExchangingValueKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__NameAssignment_0"


    // $ANTLR start "rule__ConditionsValueExchangeQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:5270:1: rule__ConditionsValueExchangeQuestion__AnswerAssignment_2 : ( ( rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0 ) ) ;
    public final void rule__ConditionsValueExchangeQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5274:1: ( ( ( rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0 ) ) )
            // InternalSmaCQA.g:5275:2: ( ( rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0 ) )
            {
            // InternalSmaCQA.g:5275:2: ( ( rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0 ) )
            // InternalSmaCQA.g:5276:3: ( rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0 )
            {
             before(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerAlternatives_2_0()); 
            // InternalSmaCQA.g:5277:3: ( rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0 )
            // InternalSmaCQA.g:5277:4: rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0
            {
            pushFollow(FOLLOW_2);
            rule__ConditionsValueExchangeQuestion__AnswerAlternatives_2_0();

            state._fsp--;


            }

             after(grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerAlternatives_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConditionsValueExchangeQuestion__AnswerAssignment_2"


    // $ANTLR start "rule__LegalQuestion__AgeQuestionAssignment_0"
    // InternalSmaCQA.g:5285:1: rule__LegalQuestion__AgeQuestionAssignment_0 : ( ruleAgeQuestion ) ;
    public final void rule__LegalQuestion__AgeQuestionAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5289:1: ( ( ruleAgeQuestion ) )
            // InternalSmaCQA.g:5290:2: ( ruleAgeQuestion )
            {
            // InternalSmaCQA.g:5290:2: ( ruleAgeQuestion )
            // InternalSmaCQA.g:5291:3: ruleAgeQuestion
            {
             before(grammarAccess.getLegalQuestionAccess().getAgeQuestionAgeQuestionParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleAgeQuestion();

            state._fsp--;

             after(grammarAccess.getLegalQuestionAccess().getAgeQuestionAgeQuestionParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LegalQuestion__AgeQuestionAssignment_0"


    // $ANTLR start "rule__LegalQuestion__TaxQuestionAssignment_1"
    // InternalSmaCQA.g:5300:1: rule__LegalQuestion__TaxQuestionAssignment_1 : ( ruleTaxQuestion ) ;
    public final void rule__LegalQuestion__TaxQuestionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5304:1: ( ( ruleTaxQuestion ) )
            // InternalSmaCQA.g:5305:2: ( ruleTaxQuestion )
            {
            // InternalSmaCQA.g:5305:2: ( ruleTaxQuestion )
            // InternalSmaCQA.g:5306:3: ruleTaxQuestion
            {
             before(grammarAccess.getLegalQuestionAccess().getTaxQuestionTaxQuestionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTaxQuestion();

            state._fsp--;

             after(grammarAccess.getLegalQuestionAccess().getTaxQuestionTaxQuestionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LegalQuestion__TaxQuestionAssignment_1"


    // $ANTLR start "rule__AgeQuestion__NameAssignment_0"
    // InternalSmaCQA.g:5315:1: rule__AgeQuestion__NameAssignment_0 : ( ( '2.1 What would be the minimum legal age if necessary in this exchange?' ) ) ;
    public final void rule__AgeQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5319:1: ( ( ( '2.1 What would be the minimum legal age if necessary in this exchange?' ) ) )
            // InternalSmaCQA.g:5320:2: ( ( '2.1 What would be the minimum legal age if necessary in this exchange?' ) )
            {
            // InternalSmaCQA.g:5320:2: ( ( '2.1 What would be the minimum legal age if necessary in this exchange?' ) )
            // InternalSmaCQA.g:5321:3: ( '2.1 What would be the minimum legal age if necessary in this exchange?' )
            {
             before(grammarAccess.getAgeQuestionAccess().getName21WhatWouldBeTheMinimumLegalAgeIfNecessaryInThisExchangeKeyword_0_0()); 
            // InternalSmaCQA.g:5322:3: ( '2.1 What would be the minimum legal age if necessary in this exchange?' )
            // InternalSmaCQA.g:5323:4: '2.1 What would be the minimum legal age if necessary in this exchange?'
            {
             before(grammarAccess.getAgeQuestionAccess().getName21WhatWouldBeTheMinimumLegalAgeIfNecessaryInThisExchangeKeyword_0_0()); 
            match(input,72,FOLLOW_2); 
             after(grammarAccess.getAgeQuestionAccess().getName21WhatWouldBeTheMinimumLegalAgeIfNecessaryInThisExchangeKeyword_0_0()); 

            }

             after(grammarAccess.getAgeQuestionAccess().getName21WhatWouldBeTheMinimumLegalAgeIfNecessaryInThisExchangeKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AgeQuestion__NameAssignment_0"


    // $ANTLR start "rule__AgeQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:5334:1: rule__AgeQuestion__AnswerAssignment_2 : ( RULE_INT ) ;
    public final void rule__AgeQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5338:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:5339:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:5339:2: ( RULE_INT )
            // InternalSmaCQA.g:5340:3: RULE_INT
            {
             before(grammarAccess.getAgeQuestionAccess().getAnswerINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getAgeQuestionAccess().getAnswerINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AgeQuestion__AnswerAssignment_2"


    // $ANTLR start "rule__TaxQuestion__NameAssignment_0"
    // InternalSmaCQA.g:5349:1: rule__TaxQuestion__NameAssignment_0 : ( ( '2.2 What is the name of the tax?' ) ) ;
    public final void rule__TaxQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5353:1: ( ( ( '2.2 What is the name of the tax?' ) ) )
            // InternalSmaCQA.g:5354:2: ( ( '2.2 What is the name of the tax?' ) )
            {
            // InternalSmaCQA.g:5354:2: ( ( '2.2 What is the name of the tax?' ) )
            // InternalSmaCQA.g:5355:3: ( '2.2 What is the name of the tax?' )
            {
             before(grammarAccess.getTaxQuestionAccess().getName22WhatIsTheNameOfTheTaxKeyword_0_0()); 
            // InternalSmaCQA.g:5356:3: ( '2.2 What is the name of the tax?' )
            // InternalSmaCQA.g:5357:4: '2.2 What is the name of the tax?'
            {
             before(grammarAccess.getTaxQuestionAccess().getName22WhatIsTheNameOfTheTaxKeyword_0_0()); 
            match(input,73,FOLLOW_2); 
             after(grammarAccess.getTaxQuestionAccess().getName22WhatIsTheNameOfTheTaxKeyword_0_0()); 

            }

             after(grammarAccess.getTaxQuestionAccess().getName22WhatIsTheNameOfTheTaxKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__NameAssignment_0"


    // $ANTLR start "rule__TaxQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:5368:1: rule__TaxQuestion__AnswerAssignment_2 : ( RULE_ID ) ;
    public final void rule__TaxQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5372:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:5373:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:5373:2: ( RULE_ID )
            // InternalSmaCQA.g:5374:3: RULE_ID
            {
             before(grammarAccess.getTaxQuestionAccess().getAnswerIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTaxQuestionAccess().getAnswerIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__AnswerAssignment_2"


    // $ANTLR start "rule__TaxQuestion__SubSentenceAssignment_3"
    // InternalSmaCQA.g:5383:1: rule__TaxQuestion__SubSentenceAssignment_3 : ( ( '2.2.1 Who collects the tax?' ) ) ;
    public final void rule__TaxQuestion__SubSentenceAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5387:1: ( ( ( '2.2.1 Who collects the tax?' ) ) )
            // InternalSmaCQA.g:5388:2: ( ( '2.2.1 Who collects the tax?' ) )
            {
            // InternalSmaCQA.g:5388:2: ( ( '2.2.1 Who collects the tax?' ) )
            // InternalSmaCQA.g:5389:3: ( '2.2.1 Who collects the tax?' )
            {
             before(grammarAccess.getTaxQuestionAccess().getSubSentence221WhoCollectsTheTaxKeyword_3_0()); 
            // InternalSmaCQA.g:5390:3: ( '2.2.1 Who collects the tax?' )
            // InternalSmaCQA.g:5391:4: '2.2.1 Who collects the tax?'
            {
             before(grammarAccess.getTaxQuestionAccess().getSubSentence221WhoCollectsTheTaxKeyword_3_0()); 
            match(input,74,FOLLOW_2); 
             after(grammarAccess.getTaxQuestionAccess().getSubSentence221WhoCollectsTheTaxKeyword_3_0()); 

            }

             after(grammarAccess.getTaxQuestionAccess().getSubSentence221WhoCollectsTheTaxKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__SubSentenceAssignment_3"


    // $ANTLR start "rule__TaxQuestion__AnswerSubSentenceAssignment_5"
    // InternalSmaCQA.g:5402:1: rule__TaxQuestion__AnswerSubSentenceAssignment_5 : ( RULE_ID ) ;
    public final void rule__TaxQuestion__AnswerSubSentenceAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5406:1: ( ( RULE_ID ) )
            // InternalSmaCQA.g:5407:2: ( RULE_ID )
            {
            // InternalSmaCQA.g:5407:2: ( RULE_ID )
            // InternalSmaCQA.g:5408:3: RULE_ID
            {
             before(grammarAccess.getTaxQuestionAccess().getAnswerSubSentenceIDTerminalRuleCall_5_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getTaxQuestionAccess().getAnswerSubSentenceIDTerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TaxQuestion__AnswerSubSentenceAssignment_5"


    // $ANTLR start "rule__EconomyQuestion__MinimumAmountQuestionAssignment"
    // InternalSmaCQA.g:5417:1: rule__EconomyQuestion__MinimumAmountQuestionAssignment : ( ruleMinimumAmountQuestion ) ;
    public final void rule__EconomyQuestion__MinimumAmountQuestionAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5421:1: ( ( ruleMinimumAmountQuestion ) )
            // InternalSmaCQA.g:5422:2: ( ruleMinimumAmountQuestion )
            {
            // InternalSmaCQA.g:5422:2: ( ruleMinimumAmountQuestion )
            // InternalSmaCQA.g:5423:3: ruleMinimumAmountQuestion
            {
             before(grammarAccess.getEconomyQuestionAccess().getMinimumAmountQuestionMinimumAmountQuestionParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleMinimumAmountQuestion();

            state._fsp--;

             after(grammarAccess.getEconomyQuestionAccess().getMinimumAmountQuestionMinimumAmountQuestionParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EconomyQuestion__MinimumAmountQuestionAssignment"


    // $ANTLR start "rule__MinimumAmountQuestion__NameAssignment_0"
    // InternalSmaCQA.g:5432:1: rule__MinimumAmountQuestion__NameAssignment_0 : ( ( '3.1 Which would be the minimum amount if necessary in this exchange?' ) ) ;
    public final void rule__MinimumAmountQuestion__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5436:1: ( ( ( '3.1 Which would be the minimum amount if necessary in this exchange?' ) ) )
            // InternalSmaCQA.g:5437:2: ( ( '3.1 Which would be the minimum amount if necessary in this exchange?' ) )
            {
            // InternalSmaCQA.g:5437:2: ( ( '3.1 Which would be the minimum amount if necessary in this exchange?' ) )
            // InternalSmaCQA.g:5438:3: ( '3.1 Which would be the minimum amount if necessary in this exchange?' )
            {
             before(grammarAccess.getMinimumAmountQuestionAccess().getName31WhichWouldBeTheMinimumAmountIfNecessaryInThisExchangeKeyword_0_0()); 
            // InternalSmaCQA.g:5439:3: ( '3.1 Which would be the minimum amount if necessary in this exchange?' )
            // InternalSmaCQA.g:5440:4: '3.1 Which would be the minimum amount if necessary in this exchange?'
            {
             before(grammarAccess.getMinimumAmountQuestionAccess().getName31WhichWouldBeTheMinimumAmountIfNecessaryInThisExchangeKeyword_0_0()); 
            match(input,75,FOLLOW_2); 
             after(grammarAccess.getMinimumAmountQuestionAccess().getName31WhichWouldBeTheMinimumAmountIfNecessaryInThisExchangeKeyword_0_0()); 

            }

             after(grammarAccess.getMinimumAmountQuestionAccess().getName31WhichWouldBeTheMinimumAmountIfNecessaryInThisExchangeKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MinimumAmountQuestion__NameAssignment_0"


    // $ANTLR start "rule__MinimumAmountQuestion__AnswerAssignment_2"
    // InternalSmaCQA.g:5451:1: rule__MinimumAmountQuestion__AnswerAssignment_2 : ( RULE_INT ) ;
    public final void rule__MinimumAmountQuestion__AnswerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSmaCQA.g:5455:1: ( ( RULE_INT ) )
            // InternalSmaCQA.g:5456:2: ( RULE_INT )
            {
            // InternalSmaCQA.g:5456:2: ( RULE_INT )
            // InternalSmaCQA.g:5457:3: RULE_INT
            {
             before(grammarAccess.getMinimumAmountQuestionAccess().getAnswerINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getMinimumAmountQuestionAccess().getAnswerINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MinimumAmountQuestion__AnswerAssignment_2"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000004000002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000003C0000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000010L,0x00000000000000FEL});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000300L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000800L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000003000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0020808000000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000002000000002L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x000000000001C000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000003E00000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x7000000000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x8000000000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x00000000001E0000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});

}