package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SmaCQAGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSmaCQAParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_EOLINE", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'================= Value Exchange ======================= \\r\\nThe exchange of value in which'", "'sends/grants'", "'the following object of value'", "'has the following associated questions and answers: '", "'--------- 1.Data Questions: -----------'", "'--------- 2.Legal Questions: -----------'", "'--------- 3.Economy Questions: -----------'", "'================= Completion of the question process for this value exchange ================='", "'1.5 Is the object of value a right that can be reflected as active or inactive?'", "'answer = '", "'yes'", "'no'", "'1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?'", "'1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?'", "'Data Declaration: '", "'End Data Declaration'", "'Data name: '", "'Value: '", "'Data Declaration Token ERC20: '", "'Token ERC20 name: '", "'Token ERC20 Symbol: '", "'Token ERC20 decimals: '", "'Token ERC20 supply: '", "'1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?'", "'1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?'", "'End Data Declaration Token ERC20'", "'Data Declaration Token ERC223: '", "'Token ERC223 name: '", "'Token ERC223 Symbol: '", "'Token ERC223 decimals: '", "'Token ERC223 supply: '", "'End Data Declaration Token ERC223'", "'Data Declaration Non Fungible Token ERC721: '", "'Token ERC721 name: '", "'Token ERC721 Symbol: '", "'1.5.1 If it\\'s possible to mint more than one NFT at a time?'", "'1.5.2 Is it possible to remove/disable the token from circulation (burn token)?'", "'1.5.3 What is the price of this token?'", "'1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?'", "'1.5.5 Which data or properties are requiered for the NFT information?'", "'1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?'", "'total supply = '", "'End Data Declaration Token ERC721'", "'1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)'", "'unitTime = '", "'1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)'", "'1.3 Can the value exchange be repeated over time?'", "'1.4 Are the same conditions always maintained when exchanging value?'", "'2.1  What would be the minimum legal age if necessary in this exchange?'", "'2.2 What is the name of the tax?'", "'2.2.1 Who collects the tax?'", "'3.1 Which would be the minimum amount if necessary in this exchange?'", "'Number'", "'Text'", "'TrueOrFalse'", "'minutes'", "'days'", "'weeks'", "'years'", "'ether'", "'wei'", "'pwei'", "'gwei'", "'szabo'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int RULE_EOLINE=5;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=7;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSmaCQAParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSmaCQAParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSmaCQAParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSmaCQA.g"; }



     	private SmaCQAGrammarAccess grammarAccess;

        public InternalSmaCQAParser(TokenStream input, SmaCQAGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected SmaCQAGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalSmaCQA.g:65:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalSmaCQA.g:65:46: (iv_ruleModel= ruleModel EOF )
            // InternalSmaCQA.g:66:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalSmaCQA.g:72:1: ruleModel returns [EObject current=null] : ( (lv_valueExchanges_0_0= ruleValueExchange ) )+ ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_valueExchanges_0_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:78:2: ( ( (lv_valueExchanges_0_0= ruleValueExchange ) )+ )
            // InternalSmaCQA.g:79:2: ( (lv_valueExchanges_0_0= ruleValueExchange ) )+
            {
            // InternalSmaCQA.g:79:2: ( (lv_valueExchanges_0_0= ruleValueExchange ) )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==12) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSmaCQA.g:80:3: (lv_valueExchanges_0_0= ruleValueExchange )
            	    {
            	    // InternalSmaCQA.g:80:3: (lv_valueExchanges_0_0= ruleValueExchange )
            	    // InternalSmaCQA.g:81:4: lv_valueExchanges_0_0= ruleValueExchange
            	    {

            	    				newCompositeNode(grammarAccess.getModelAccess().getValueExchangesValueExchangeParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_valueExchanges_0_0=ruleValueExchange();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"valueExchanges",
            	    					lv_valueExchanges_0_0,
            	    					"org.xtext.SmaCQA.ValueExchange");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleValueExchange"
    // InternalSmaCQA.g:101:1: entryRuleValueExchange returns [EObject current=null] : iv_ruleValueExchange= ruleValueExchange EOF ;
    public final EObject entryRuleValueExchange() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValueExchange = null;


        try {
            // InternalSmaCQA.g:101:54: (iv_ruleValueExchange= ruleValueExchange EOF )
            // InternalSmaCQA.g:102:2: iv_ruleValueExchange= ruleValueExchange EOF
            {
             newCompositeNode(grammarAccess.getValueExchangeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValueExchange=ruleValueExchange();

            state._fsp--;

             current =iv_ruleValueExchange; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValueExchange"


    // $ANTLR start "ruleValueExchange"
    // InternalSmaCQA.g:108:1: ruleValueExchange returns [EObject current=null] : (otherlv_0= '================= Value Exchange ======================= \\r\\nThe exchange of value in which' ( (lv_actorSend_1_0= RULE_ID ) ) otherlv_2= 'sends/grants' ( (lv_actorReceipt_3_0= RULE_ID ) ) otherlv_4= 'the following object of value' ( (lv_valueObject_5_0= RULE_ID ) ) otherlv_6= 'has the following associated questions and answers: ' (this_EOLINE_7= RULE_EOLINE )? (otherlv_8= '--------- 1.Data Questions: -----------' (this_EOLINE_9= RULE_EOLINE )? ( (lv_dataQuestion_10_0= ruleDataQuestion ) ) )? (otherlv_11= '--------- 2.Legal Questions: -----------' (this_EOLINE_12= RULE_EOLINE )? ( (lv_legalQuestion_13_0= ruleLegalQuestion ) ) )? (otherlv_14= '--------- 3.Economy Questions: -----------' (this_EOLINE_15= RULE_EOLINE )? ( (lv_economyQuestion_16_0= ruleEconomyQuestion ) ) )? otherlv_17= '================= Completion of the question process for this value exchange =================' ) ;
    public final EObject ruleValueExchange() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_actorSend_1_0=null;
        Token otherlv_2=null;
        Token lv_actorReceipt_3_0=null;
        Token otherlv_4=null;
        Token lv_valueObject_5_0=null;
        Token otherlv_6=null;
        Token this_EOLINE_7=null;
        Token otherlv_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_11=null;
        Token this_EOLINE_12=null;
        Token otherlv_14=null;
        Token this_EOLINE_15=null;
        Token otherlv_17=null;
        EObject lv_dataQuestion_10_0 = null;

        EObject lv_legalQuestion_13_0 = null;

        EObject lv_economyQuestion_16_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:114:2: ( (otherlv_0= '================= Value Exchange ======================= \\r\\nThe exchange of value in which' ( (lv_actorSend_1_0= RULE_ID ) ) otherlv_2= 'sends/grants' ( (lv_actorReceipt_3_0= RULE_ID ) ) otherlv_4= 'the following object of value' ( (lv_valueObject_5_0= RULE_ID ) ) otherlv_6= 'has the following associated questions and answers: ' (this_EOLINE_7= RULE_EOLINE )? (otherlv_8= '--------- 1.Data Questions: -----------' (this_EOLINE_9= RULE_EOLINE )? ( (lv_dataQuestion_10_0= ruleDataQuestion ) ) )? (otherlv_11= '--------- 2.Legal Questions: -----------' (this_EOLINE_12= RULE_EOLINE )? ( (lv_legalQuestion_13_0= ruleLegalQuestion ) ) )? (otherlv_14= '--------- 3.Economy Questions: -----------' (this_EOLINE_15= RULE_EOLINE )? ( (lv_economyQuestion_16_0= ruleEconomyQuestion ) ) )? otherlv_17= '================= Completion of the question process for this value exchange =================' ) )
            // InternalSmaCQA.g:115:2: (otherlv_0= '================= Value Exchange ======================= \\r\\nThe exchange of value in which' ( (lv_actorSend_1_0= RULE_ID ) ) otherlv_2= 'sends/grants' ( (lv_actorReceipt_3_0= RULE_ID ) ) otherlv_4= 'the following object of value' ( (lv_valueObject_5_0= RULE_ID ) ) otherlv_6= 'has the following associated questions and answers: ' (this_EOLINE_7= RULE_EOLINE )? (otherlv_8= '--------- 1.Data Questions: -----------' (this_EOLINE_9= RULE_EOLINE )? ( (lv_dataQuestion_10_0= ruleDataQuestion ) ) )? (otherlv_11= '--------- 2.Legal Questions: -----------' (this_EOLINE_12= RULE_EOLINE )? ( (lv_legalQuestion_13_0= ruleLegalQuestion ) ) )? (otherlv_14= '--------- 3.Economy Questions: -----------' (this_EOLINE_15= RULE_EOLINE )? ( (lv_economyQuestion_16_0= ruleEconomyQuestion ) ) )? otherlv_17= '================= Completion of the question process for this value exchange =================' )
            {
            // InternalSmaCQA.g:115:2: (otherlv_0= '================= Value Exchange ======================= \\r\\nThe exchange of value in which' ( (lv_actorSend_1_0= RULE_ID ) ) otherlv_2= 'sends/grants' ( (lv_actorReceipt_3_0= RULE_ID ) ) otherlv_4= 'the following object of value' ( (lv_valueObject_5_0= RULE_ID ) ) otherlv_6= 'has the following associated questions and answers: ' (this_EOLINE_7= RULE_EOLINE )? (otherlv_8= '--------- 1.Data Questions: -----------' (this_EOLINE_9= RULE_EOLINE )? ( (lv_dataQuestion_10_0= ruleDataQuestion ) ) )? (otherlv_11= '--------- 2.Legal Questions: -----------' (this_EOLINE_12= RULE_EOLINE )? ( (lv_legalQuestion_13_0= ruleLegalQuestion ) ) )? (otherlv_14= '--------- 3.Economy Questions: -----------' (this_EOLINE_15= RULE_EOLINE )? ( (lv_economyQuestion_16_0= ruleEconomyQuestion ) ) )? otherlv_17= '================= Completion of the question process for this value exchange =================' )
            // InternalSmaCQA.g:116:3: otherlv_0= '================= Value Exchange ======================= \\r\\nThe exchange of value in which' ( (lv_actorSend_1_0= RULE_ID ) ) otherlv_2= 'sends/grants' ( (lv_actorReceipt_3_0= RULE_ID ) ) otherlv_4= 'the following object of value' ( (lv_valueObject_5_0= RULE_ID ) ) otherlv_6= 'has the following associated questions and answers: ' (this_EOLINE_7= RULE_EOLINE )? (otherlv_8= '--------- 1.Data Questions: -----------' (this_EOLINE_9= RULE_EOLINE )? ( (lv_dataQuestion_10_0= ruleDataQuestion ) ) )? (otherlv_11= '--------- 2.Legal Questions: -----------' (this_EOLINE_12= RULE_EOLINE )? ( (lv_legalQuestion_13_0= ruleLegalQuestion ) ) )? (otherlv_14= '--------- 3.Economy Questions: -----------' (this_EOLINE_15= RULE_EOLINE )? ( (lv_economyQuestion_16_0= ruleEconomyQuestion ) ) )? otherlv_17= '================= Completion of the question process for this value exchange ================='
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getValueExchangeAccess().getValueExchangeTheExchangeOfValueInWhichKeyword_0());
            		
            // InternalSmaCQA.g:120:3: ( (lv_actorSend_1_0= RULE_ID ) )
            // InternalSmaCQA.g:121:4: (lv_actorSend_1_0= RULE_ID )
            {
            // InternalSmaCQA.g:121:4: (lv_actorSend_1_0= RULE_ID )
            // InternalSmaCQA.g:122:5: lv_actorSend_1_0= RULE_ID
            {
            lv_actorSend_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_actorSend_1_0, grammarAccess.getValueExchangeAccess().getActorSendIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getValueExchangeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"actorSend",
            						lv_actorSend_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getValueExchangeAccess().getSendsGrantsKeyword_2());
            		
            // InternalSmaCQA.g:142:3: ( (lv_actorReceipt_3_0= RULE_ID ) )
            // InternalSmaCQA.g:143:4: (lv_actorReceipt_3_0= RULE_ID )
            {
            // InternalSmaCQA.g:143:4: (lv_actorReceipt_3_0= RULE_ID )
            // InternalSmaCQA.g:144:5: lv_actorReceipt_3_0= RULE_ID
            {
            lv_actorReceipt_3_0=(Token)match(input,RULE_ID,FOLLOW_6); 

            					newLeafNode(lv_actorReceipt_3_0, grammarAccess.getValueExchangeAccess().getActorReceiptIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getValueExchangeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"actorReceipt",
            						lv_actorReceipt_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_4=(Token)match(input,14,FOLLOW_4); 

            			newLeafNode(otherlv_4, grammarAccess.getValueExchangeAccess().getTheFollowingObjectOfValueKeyword_4());
            		
            // InternalSmaCQA.g:164:3: ( (lv_valueObject_5_0= RULE_ID ) )
            // InternalSmaCQA.g:165:4: (lv_valueObject_5_0= RULE_ID )
            {
            // InternalSmaCQA.g:165:4: (lv_valueObject_5_0= RULE_ID )
            // InternalSmaCQA.g:166:5: lv_valueObject_5_0= RULE_ID
            {
            lv_valueObject_5_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            					newLeafNode(lv_valueObject_5_0, grammarAccess.getValueExchangeAccess().getValueObjectIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getValueExchangeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"valueObject",
            						lv_valueObject_5_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_6=(Token)match(input,15,FOLLOW_8); 

            			newLeafNode(otherlv_6, grammarAccess.getValueExchangeAccess().getHasTheFollowingAssociatedQuestionsAndAnswersKeyword_6());
            		
            // InternalSmaCQA.g:186:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_EOLINE) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalSmaCQA.g:187:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_9); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }

            // InternalSmaCQA.g:192:3: (otherlv_8= '--------- 1.Data Questions: -----------' (this_EOLINE_9= RULE_EOLINE )? ( (lv_dataQuestion_10_0= ruleDataQuestion ) ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==16) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalSmaCQA.g:193:4: otherlv_8= '--------- 1.Data Questions: -----------' (this_EOLINE_9= RULE_EOLINE )? ( (lv_dataQuestion_10_0= ruleDataQuestion ) )
                    {
                    otherlv_8=(Token)match(input,16,FOLLOW_10); 

                    				newLeafNode(otherlv_8, grammarAccess.getValueExchangeAccess().getDataQuestionsKeyword_8_0());
                    			
                    // InternalSmaCQA.g:197:4: (this_EOLINE_9= RULE_EOLINE )?
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0==RULE_EOLINE) ) {
                        alt3=1;
                    }
                    switch (alt3) {
                        case 1 :
                            // InternalSmaCQA.g:198:5: this_EOLINE_9= RULE_EOLINE
                            {
                            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_11); 

                            					newLeafNode(this_EOLINE_9, grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_8_1());
                            				

                            }
                            break;

                    }

                    // InternalSmaCQA.g:203:4: ( (lv_dataQuestion_10_0= ruleDataQuestion ) )
                    // InternalSmaCQA.g:204:5: (lv_dataQuestion_10_0= ruleDataQuestion )
                    {
                    // InternalSmaCQA.g:204:5: (lv_dataQuestion_10_0= ruleDataQuestion )
                    // InternalSmaCQA.g:205:6: lv_dataQuestion_10_0= ruleDataQuestion
                    {

                    						newCompositeNode(grammarAccess.getValueExchangeAccess().getDataQuestionDataQuestionParserRuleCall_8_2_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_dataQuestion_10_0=ruleDataQuestion();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getValueExchangeRule());
                    						}
                    						set(
                    							current,
                    							"dataQuestion",
                    							lv_dataQuestion_10_0,
                    							"org.xtext.SmaCQA.DataQuestion");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSmaCQA.g:223:3: (otherlv_11= '--------- 2.Legal Questions: -----------' (this_EOLINE_12= RULE_EOLINE )? ( (lv_legalQuestion_13_0= ruleLegalQuestion ) ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==17) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalSmaCQA.g:224:4: otherlv_11= '--------- 2.Legal Questions: -----------' (this_EOLINE_12= RULE_EOLINE )? ( (lv_legalQuestion_13_0= ruleLegalQuestion ) )
                    {
                    otherlv_11=(Token)match(input,17,FOLLOW_13); 

                    				newLeafNode(otherlv_11, grammarAccess.getValueExchangeAccess().getLegalQuestionsKeyword_9_0());
                    			
                    // InternalSmaCQA.g:228:4: (this_EOLINE_12= RULE_EOLINE )?
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==RULE_EOLINE) ) {
                        alt5=1;
                    }
                    switch (alt5) {
                        case 1 :
                            // InternalSmaCQA.g:229:5: this_EOLINE_12= RULE_EOLINE
                            {
                            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_14); 

                            					newLeafNode(this_EOLINE_12, grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_9_1());
                            				

                            }
                            break;

                    }

                    // InternalSmaCQA.g:234:4: ( (lv_legalQuestion_13_0= ruleLegalQuestion ) )
                    // InternalSmaCQA.g:235:5: (lv_legalQuestion_13_0= ruleLegalQuestion )
                    {
                    // InternalSmaCQA.g:235:5: (lv_legalQuestion_13_0= ruleLegalQuestion )
                    // InternalSmaCQA.g:236:6: lv_legalQuestion_13_0= ruleLegalQuestion
                    {

                    						newCompositeNode(grammarAccess.getValueExchangeAccess().getLegalQuestionLegalQuestionParserRuleCall_9_2_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_legalQuestion_13_0=ruleLegalQuestion();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getValueExchangeRule());
                    						}
                    						set(
                    							current,
                    							"legalQuestion",
                    							lv_legalQuestion_13_0,
                    							"org.xtext.SmaCQA.LegalQuestion");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSmaCQA.g:254:3: (otherlv_14= '--------- 3.Economy Questions: -----------' (this_EOLINE_15= RULE_EOLINE )? ( (lv_economyQuestion_16_0= ruleEconomyQuestion ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==18) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalSmaCQA.g:255:4: otherlv_14= '--------- 3.Economy Questions: -----------' (this_EOLINE_15= RULE_EOLINE )? ( (lv_economyQuestion_16_0= ruleEconomyQuestion ) )
                    {
                    otherlv_14=(Token)match(input,18,FOLLOW_16); 

                    				newLeafNode(otherlv_14, grammarAccess.getValueExchangeAccess().getEconomyQuestionsKeyword_10_0());
                    			
                    // InternalSmaCQA.g:259:4: (this_EOLINE_15= RULE_EOLINE )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==RULE_EOLINE) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalSmaCQA.g:260:5: this_EOLINE_15= RULE_EOLINE
                            {
                            this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_17); 

                            					newLeafNode(this_EOLINE_15, grammarAccess.getValueExchangeAccess().getEOLINETerminalRuleCall_10_1());
                            				

                            }
                            break;

                    }

                    // InternalSmaCQA.g:265:4: ( (lv_economyQuestion_16_0= ruleEconomyQuestion ) )
                    // InternalSmaCQA.g:266:5: (lv_economyQuestion_16_0= ruleEconomyQuestion )
                    {
                    // InternalSmaCQA.g:266:5: (lv_economyQuestion_16_0= ruleEconomyQuestion )
                    // InternalSmaCQA.g:267:6: lv_economyQuestion_16_0= ruleEconomyQuestion
                    {

                    						newCompositeNode(grammarAccess.getValueExchangeAccess().getEconomyQuestionEconomyQuestionParserRuleCall_10_2_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_economyQuestion_16_0=ruleEconomyQuestion();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getValueExchangeRule());
                    						}
                    						set(
                    							current,
                    							"economyQuestion",
                    							lv_economyQuestion_16_0,
                    							"org.xtext.SmaCQA.EconomyQuestion");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_17=(Token)match(input,19,FOLLOW_2); 

            			newLeafNode(otherlv_17, grammarAccess.getValueExchangeAccess().getCompletionOfTheQuestionProcessForThisValueExchangeKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValueExchange"


    // $ANTLR start "entryRuleDataQuestion"
    // InternalSmaCQA.g:293:1: entryRuleDataQuestion returns [EObject current=null] : iv_ruleDataQuestion= ruleDataQuestion EOF ;
    public final EObject entryRuleDataQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataQuestion = null;


        try {
            // InternalSmaCQA.g:293:53: (iv_ruleDataQuestion= ruleDataQuestion EOF )
            // InternalSmaCQA.g:294:2: iv_ruleDataQuestion= ruleDataQuestion EOF
            {
             newCompositeNode(grammarAccess.getDataQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataQuestion=ruleDataQuestion();

            state._fsp--;

             current =iv_ruleDataQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataQuestion"


    // $ANTLR start "ruleDataQuestion"
    // InternalSmaCQA.g:300:1: ruleDataQuestion returns [EObject current=null] : ( ( (lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion ) )? ( (lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion ) )? ( (lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion ) )? ( (lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion ) )? ( (lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion ) )? ) ;
    public final EObject ruleDataQuestion() throws RecognitionException {
        EObject current = null;

        EObject lv_timeDurationValueExchange_0_0 = null;

        EObject lv_timeStartValueExchange_1_0 = null;

        EObject lv_repeatValueExchange_2_0 = null;

        EObject lv_conditionValueExchange_3_0 = null;

        EObject lv_valueObjectTypeValueExchange_4_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:306:2: ( ( ( (lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion ) )? ( (lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion ) )? ( (lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion ) )? ( (lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion ) )? ( (lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion ) )? ) )
            // InternalSmaCQA.g:307:2: ( ( (lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion ) )? ( (lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion ) )? ( (lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion ) )? ( (lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion ) )? ( (lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion ) )? )
            {
            // InternalSmaCQA.g:307:2: ( ( (lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion ) )? ( (lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion ) )? ( (lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion ) )? ( (lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion ) )? ( (lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion ) )? )
            // InternalSmaCQA.g:308:3: ( (lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion ) )? ( (lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion ) )? ( (lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion ) )? ( (lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion ) )? ( (lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion ) )?
            {
            // InternalSmaCQA.g:308:3: ( (lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==55) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSmaCQA.g:309:4: (lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion )
                    {
                    // InternalSmaCQA.g:309:4: (lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion )
                    // InternalSmaCQA.g:310:5: lv_timeDurationValueExchange_0_0= ruleTimeValueExchangeDurationQuestion
                    {

                    					newCompositeNode(grammarAccess.getDataQuestionAccess().getTimeDurationValueExchangeTimeValueExchangeDurationQuestionParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_19);
                    lv_timeDurationValueExchange_0_0=ruleTimeValueExchangeDurationQuestion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getDataQuestionRule());
                    					}
                    					set(
                    						current,
                    						"timeDurationValueExchange",
                    						lv_timeDurationValueExchange_0_0,
                    						"org.xtext.SmaCQA.TimeValueExchangeDurationQuestion");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSmaCQA.g:327:3: ( (lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==57) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSmaCQA.g:328:4: (lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion )
                    {
                    // InternalSmaCQA.g:328:4: (lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion )
                    // InternalSmaCQA.g:329:5: lv_timeStartValueExchange_1_0= ruleTimeStartValueExchangeQuestion
                    {

                    					newCompositeNode(grammarAccess.getDataQuestionAccess().getTimeStartValueExchangeTimeStartValueExchangeQuestionParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_20);
                    lv_timeStartValueExchange_1_0=ruleTimeStartValueExchangeQuestion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getDataQuestionRule());
                    					}
                    					set(
                    						current,
                    						"timeStartValueExchange",
                    						lv_timeStartValueExchange_1_0,
                    						"org.xtext.SmaCQA.TimeStartValueExchangeQuestion");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSmaCQA.g:346:3: ( (lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==58) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalSmaCQA.g:347:4: (lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion )
                    {
                    // InternalSmaCQA.g:347:4: (lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion )
                    // InternalSmaCQA.g:348:5: lv_repeatValueExchange_2_0= ruleRepeatValueExchangeQuestion
                    {

                    					newCompositeNode(grammarAccess.getDataQuestionAccess().getRepeatValueExchangeRepeatValueExchangeQuestionParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_21);
                    lv_repeatValueExchange_2_0=ruleRepeatValueExchangeQuestion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getDataQuestionRule());
                    					}
                    					set(
                    						current,
                    						"repeatValueExchange",
                    						lv_repeatValueExchange_2_0,
                    						"org.xtext.SmaCQA.RepeatValueExchangeQuestion");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSmaCQA.g:365:3: ( (lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==59) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalSmaCQA.g:366:4: (lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion )
                    {
                    // InternalSmaCQA.g:366:4: (lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion )
                    // InternalSmaCQA.g:367:5: lv_conditionValueExchange_3_0= ruleConditionsValueExchangeQuestion
                    {

                    					newCompositeNode(grammarAccess.getDataQuestionAccess().getConditionValueExchangeConditionsValueExchangeQuestionParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_22);
                    lv_conditionValueExchange_3_0=ruleConditionsValueExchangeQuestion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getDataQuestionRule());
                    					}
                    					set(
                    						current,
                    						"conditionValueExchange",
                    						lv_conditionValueExchange_3_0,
                    						"org.xtext.SmaCQA.ConditionsValueExchangeQuestion");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSmaCQA.g:384:3: ( (lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==20||(LA13_0>=24 && LA13_0<=25)) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalSmaCQA.g:385:4: (lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion )
                    {
                    // InternalSmaCQA.g:385:4: (lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion )
                    // InternalSmaCQA.g:386:5: lv_valueObjectTypeValueExchange_4_0= ruleValueObjectQuestion
                    {

                    					newCompositeNode(grammarAccess.getDataQuestionAccess().getValueObjectTypeValueExchangeValueObjectQuestionParserRuleCall_4_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_valueObjectTypeValueExchange_4_0=ruleValueObjectQuestion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getDataQuestionRule());
                    					}
                    					set(
                    						current,
                    						"valueObjectTypeValueExchange",
                    						lv_valueObjectTypeValueExchange_4_0,
                    						"org.xtext.SmaCQA.ValueObjectQuestion");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataQuestion"


    // $ANTLR start "entryRuleValueObjectQuestion"
    // InternalSmaCQA.g:407:1: entryRuleValueObjectQuestion returns [EObject current=null] : iv_ruleValueObjectQuestion= ruleValueObjectQuestion EOF ;
    public final EObject entryRuleValueObjectQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValueObjectQuestion = null;


        try {
            // InternalSmaCQA.g:407:60: (iv_ruleValueObjectQuestion= ruleValueObjectQuestion EOF )
            // InternalSmaCQA.g:408:2: iv_ruleValueObjectQuestion= ruleValueObjectQuestion EOF
            {
             newCompositeNode(grammarAccess.getValueObjectQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValueObjectQuestion=ruleValueObjectQuestion();

            state._fsp--;

             current =iv_ruleValueObjectQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValueObjectQuestion"


    // $ANTLR start "ruleValueObjectQuestion"
    // InternalSmaCQA.g:414:1: ruleValueObjectQuestion returns [EObject current=null] : (this_ValueObjectTokenQuestion_0= ruleValueObjectTokenQuestion | this_ValueObjectRightQuestion_1= ruleValueObjectRightQuestion | this_ValueObjectTangibleQuestion_2= ruleValueObjectTangibleQuestion ) ;
    public final EObject ruleValueObjectQuestion() throws RecognitionException {
        EObject current = null;

        EObject this_ValueObjectTokenQuestion_0 = null;

        EObject this_ValueObjectRightQuestion_1 = null;

        EObject this_ValueObjectTangibleQuestion_2 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:420:2: ( (this_ValueObjectTokenQuestion_0= ruleValueObjectTokenQuestion | this_ValueObjectRightQuestion_1= ruleValueObjectRightQuestion | this_ValueObjectTangibleQuestion_2= ruleValueObjectTangibleQuestion ) )
            // InternalSmaCQA.g:421:2: (this_ValueObjectTokenQuestion_0= ruleValueObjectTokenQuestion | this_ValueObjectRightQuestion_1= ruleValueObjectRightQuestion | this_ValueObjectTangibleQuestion_2= ruleValueObjectTangibleQuestion )
            {
            // InternalSmaCQA.g:421:2: (this_ValueObjectTokenQuestion_0= ruleValueObjectTokenQuestion | this_ValueObjectRightQuestion_1= ruleValueObjectRightQuestion | this_ValueObjectTangibleQuestion_2= ruleValueObjectTangibleQuestion )
            int alt14=3;
            switch ( input.LA(1) ) {
            case 24:
                {
                alt14=1;
                }
                break;
            case 20:
                {
                alt14=2;
                }
                break;
            case 25:
                {
                alt14=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }

            switch (alt14) {
                case 1 :
                    // InternalSmaCQA.g:422:3: this_ValueObjectTokenQuestion_0= ruleValueObjectTokenQuestion
                    {

                    			newCompositeNode(grammarAccess.getValueObjectQuestionAccess().getValueObjectTokenQuestionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ValueObjectTokenQuestion_0=ruleValueObjectTokenQuestion();

                    state._fsp--;


                    			current = this_ValueObjectTokenQuestion_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:431:3: this_ValueObjectRightQuestion_1= ruleValueObjectRightQuestion
                    {

                    			newCompositeNode(grammarAccess.getValueObjectQuestionAccess().getValueObjectRightQuestionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ValueObjectRightQuestion_1=ruleValueObjectRightQuestion();

                    state._fsp--;


                    			current = this_ValueObjectRightQuestion_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:440:3: this_ValueObjectTangibleQuestion_2= ruleValueObjectTangibleQuestion
                    {

                    			newCompositeNode(grammarAccess.getValueObjectQuestionAccess().getValueObjectTangibleQuestionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ValueObjectTangibleQuestion_2=ruleValueObjectTangibleQuestion();

                    state._fsp--;


                    			current = this_ValueObjectTangibleQuestion_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValueObjectQuestion"


    // $ANTLR start "entryRuleValueObjectRightQuestion"
    // InternalSmaCQA.g:452:1: entryRuleValueObjectRightQuestion returns [EObject current=null] : iv_ruleValueObjectRightQuestion= ruleValueObjectRightQuestion EOF ;
    public final EObject entryRuleValueObjectRightQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValueObjectRightQuestion = null;


        try {
            // InternalSmaCQA.g:452:65: (iv_ruleValueObjectRightQuestion= ruleValueObjectRightQuestion EOF )
            // InternalSmaCQA.g:453:2: iv_ruleValueObjectRightQuestion= ruleValueObjectRightQuestion EOF
            {
             newCompositeNode(grammarAccess.getValueObjectRightQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValueObjectRightQuestion=ruleValueObjectRightQuestion();

            state._fsp--;

             current =iv_ruleValueObjectRightQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValueObjectRightQuestion"


    // $ANTLR start "ruleValueObjectRightQuestion"
    // InternalSmaCQA.g:459:1: ruleValueObjectRightQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) ) ;
    public final EObject ruleValueObjectRightQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_answer_2_1=null;
        Token lv_answer_2_2=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:465:2: ( ( ( (lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) ) )
            // InternalSmaCQA.g:466:2: ( ( (lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) )
            {
            // InternalSmaCQA.g:466:2: ( ( (lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) )
            // InternalSmaCQA.g:467:3: ( (lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) )
            {
            // InternalSmaCQA.g:467:3: ( (lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?' ) )
            // InternalSmaCQA.g:468:4: (lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?' )
            {
            // InternalSmaCQA.g:468:4: (lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?' )
            // InternalSmaCQA.g:469:5: lv_name_0_0= '1.5 Is the object of value a right that can be reflected as active or inactive?'
            {
            lv_name_0_0=(Token)match(input,20,FOLLOW_23); 

            					newLeafNode(lv_name_0_0, grammarAccess.getValueObjectRightQuestionAccess().getName15IsTheObjectOfValueARightThatCanBeReflectedAsActiveOrInactiveKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getValueObjectRightQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "1.5 Is the object of value a right that can be reflected as active or inactive?");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_1, grammarAccess.getValueObjectRightQuestionAccess().getAnswerKeyword_1());
            		
            // InternalSmaCQA.g:485:3: ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) )
            // InternalSmaCQA.g:486:4: ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) )
            {
            // InternalSmaCQA.g:486:4: ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) )
            // InternalSmaCQA.g:487:5: (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' )
            {
            // InternalSmaCQA.g:487:5: (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==22) ) {
                alt15=1;
            }
            else if ( (LA15_0==23) ) {
                alt15=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // InternalSmaCQA.g:488:6: lv_answer_2_1= 'yes'
                    {
                    lv_answer_2_1=(Token)match(input,22,FOLLOW_2); 

                    						newLeafNode(lv_answer_2_1, grammarAccess.getValueObjectRightQuestionAccess().getAnswerYesKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getValueObjectRightQuestionRule());
                    						}
                    						setWithLastConsumed(current, "answer", lv_answer_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:499:6: lv_answer_2_2= 'no'
                    {
                    lv_answer_2_2=(Token)match(input,23,FOLLOW_2); 

                    						newLeafNode(lv_answer_2_2, grammarAccess.getValueObjectRightQuestionAccess().getAnswerNoKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getValueObjectRightQuestionRule());
                    						}
                    						setWithLastConsumed(current, "answer", lv_answer_2_2, null);
                    					

                    }
                    break;

            }


            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValueObjectRightQuestion"


    // $ANTLR start "entryRuleValueObjectTokenQuestion"
    // InternalSmaCQA.g:516:1: entryRuleValueObjectTokenQuestion returns [EObject current=null] : iv_ruleValueObjectTokenQuestion= ruleValueObjectTokenQuestion EOF ;
    public final EObject entryRuleValueObjectTokenQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValueObjectTokenQuestion = null;


        try {
            // InternalSmaCQA.g:516:65: (iv_ruleValueObjectTokenQuestion= ruleValueObjectTokenQuestion EOF )
            // InternalSmaCQA.g:517:2: iv_ruleValueObjectTokenQuestion= ruleValueObjectTokenQuestion EOF
            {
             newCompositeNode(grammarAccess.getValueObjectTokenQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValueObjectTokenQuestion=ruleValueObjectTokenQuestion();

            state._fsp--;

             current =iv_ruleValueObjectTokenQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValueObjectTokenQuestion"


    // $ANTLR start "ruleValueObjectTokenQuestion"
    // InternalSmaCQA.g:523:1: ruleValueObjectTokenQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) ) ( (lv_answer_1_0= ruleToken ) ) ) ;
    public final EObject ruleValueObjectTokenQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        EObject lv_answer_1_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:529:2: ( ( ( (lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) ) ( (lv_answer_1_0= ruleToken ) ) ) )
            // InternalSmaCQA.g:530:2: ( ( (lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) ) ( (lv_answer_1_0= ruleToken ) ) )
            {
            // InternalSmaCQA.g:530:2: ( ( (lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) ) ( (lv_answer_1_0= ruleToken ) ) )
            // InternalSmaCQA.g:531:3: ( (lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) ) ( (lv_answer_1_0= ruleToken ) )
            {
            // InternalSmaCQA.g:531:3: ( (lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' ) )
            // InternalSmaCQA.g:532:4: (lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' )
            {
            // InternalSmaCQA.g:532:4: (lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?' )
            // InternalSmaCQA.g:533:5: lv_name_0_0= '1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?'
            {
            lv_name_0_0=(Token)match(input,24,FOLLOW_25); 

            					newLeafNode(lv_name_0_0, grammarAccess.getValueObjectTokenQuestionAccess().getName15IfTheObjectOfValueTradedOnTheValueExchangeIsADigitalTokenWhatAreThePropertiesOfSaidTokenKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getValueObjectTokenQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "1.5 If the object of value traded on the value exchange is a digital token. What are the properties of said token?");
            				

            }


            }

            // InternalSmaCQA.g:545:3: ( (lv_answer_1_0= ruleToken ) )
            // InternalSmaCQA.g:546:4: (lv_answer_1_0= ruleToken )
            {
            // InternalSmaCQA.g:546:4: (lv_answer_1_0= ruleToken )
            // InternalSmaCQA.g:547:5: lv_answer_1_0= ruleToken
            {

            					newCompositeNode(grammarAccess.getValueObjectTokenQuestionAccess().getAnswerTokenParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_answer_1_0=ruleToken();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getValueObjectTokenQuestionRule());
            					}
            					set(
            						current,
            						"answer",
            						lv_answer_1_0,
            						"org.xtext.SmaCQA.Token");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValueObjectTokenQuestion"


    // $ANTLR start "entryRuleValueObjectTangibleQuestion"
    // InternalSmaCQA.g:568:1: entryRuleValueObjectTangibleQuestion returns [EObject current=null] : iv_ruleValueObjectTangibleQuestion= ruleValueObjectTangibleQuestion EOF ;
    public final EObject entryRuleValueObjectTangibleQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValueObjectTangibleQuestion = null;


        try {
            // InternalSmaCQA.g:568:68: (iv_ruleValueObjectTangibleQuestion= ruleValueObjectTangibleQuestion EOF )
            // InternalSmaCQA.g:569:2: iv_ruleValueObjectTangibleQuestion= ruleValueObjectTangibleQuestion EOF
            {
             newCompositeNode(grammarAccess.getValueObjectTangibleQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValueObjectTangibleQuestion=ruleValueObjectTangibleQuestion();

            state._fsp--;

             current =iv_ruleValueObjectTangibleQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValueObjectTangibleQuestion"


    // $ANTLR start "ruleValueObjectTangibleQuestion"
    // InternalSmaCQA.g:575:1: ruleValueObjectTangibleQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) ) otherlv_1= 'Data Declaration: ' ( (lv_answer_2_0= ruleDataRegister ) )+ otherlv_3= 'End Data Declaration' ) ;
    public final EObject ruleValueObjectTangibleQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_answer_2_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:581:2: ( ( ( (lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) ) otherlv_1= 'Data Declaration: ' ( (lv_answer_2_0= ruleDataRegister ) )+ otherlv_3= 'End Data Declaration' ) )
            // InternalSmaCQA.g:582:2: ( ( (lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) ) otherlv_1= 'Data Declaration: ' ( (lv_answer_2_0= ruleDataRegister ) )+ otherlv_3= 'End Data Declaration' )
            {
            // InternalSmaCQA.g:582:2: ( ( (lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) ) otherlv_1= 'Data Declaration: ' ( (lv_answer_2_0= ruleDataRegister ) )+ otherlv_3= 'End Data Declaration' )
            // InternalSmaCQA.g:583:3: ( (lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) ) otherlv_1= 'Data Declaration: ' ( (lv_answer_2_0= ruleDataRegister ) )+ otherlv_3= 'End Data Declaration'
            {
            // InternalSmaCQA.g:583:3: ( (lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' ) )
            // InternalSmaCQA.g:584:4: (lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' )
            {
            // InternalSmaCQA.g:584:4: (lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?' )
            // InternalSmaCQA.g:585:5: lv_name_0_0= '1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?'
            {
            lv_name_0_0=(Token)match(input,25,FOLLOW_26); 

            					newLeafNode(lv_name_0_0, grammarAccess.getValueObjectTangibleQuestionAccess().getName15IfTheObjectOfValueNegotiatedInTheValueExchangeIsATangibleEntityThatCanBeRepresentedAsADigitalEntityNotATokenWhatAreThePropertiesOfThatObjectKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getValueObjectTangibleQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "1.5 If the object of value negotiated in the value exchange is a tangible entity that can be represented as a digital entity (not a token). What are the properties of that object?");
            				

            }


            }

            otherlv_1=(Token)match(input,26,FOLLOW_27); 

            			newLeafNode(otherlv_1, grammarAccess.getValueObjectTangibleQuestionAccess().getDataDeclarationKeyword_1());
            		
            // InternalSmaCQA.g:601:3: ( (lv_answer_2_0= ruleDataRegister ) )+
            int cnt16=0;
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==28) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalSmaCQA.g:602:4: (lv_answer_2_0= ruleDataRegister )
            	    {
            	    // InternalSmaCQA.g:602:4: (lv_answer_2_0= ruleDataRegister )
            	    // InternalSmaCQA.g:603:5: lv_answer_2_0= ruleDataRegister
            	    {

            	    					newCompositeNode(grammarAccess.getValueObjectTangibleQuestionAccess().getAnswerDataRegisterParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_28);
            	    lv_answer_2_0=ruleDataRegister();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getValueObjectTangibleQuestionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"answer",
            	    						lv_answer_2_0,
            	    						"org.xtext.SmaCQA.DataRegister");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt16 >= 1 ) break loop16;
                        EarlyExitException eee =
                            new EarlyExitException(16, input);
                        throw eee;
                }
                cnt16++;
            } while (true);

            otherlv_3=(Token)match(input,27,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getValueObjectTangibleQuestionAccess().getEndDataDeclarationKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValueObjectTangibleQuestion"


    // $ANTLR start "entryRuleDataRegister"
    // InternalSmaCQA.g:628:1: entryRuleDataRegister returns [EObject current=null] : iv_ruleDataRegister= ruleDataRegister EOF ;
    public final EObject entryRuleDataRegister() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataRegister = null;


        try {
            // InternalSmaCQA.g:628:53: (iv_ruleDataRegister= ruleDataRegister EOF )
            // InternalSmaCQA.g:629:2: iv_ruleDataRegister= ruleDataRegister EOF
            {
             newCompositeNode(grammarAccess.getDataRegisterRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataRegister=ruleDataRegister();

            state._fsp--;

             current =iv_ruleDataRegister; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataRegister"


    // $ANTLR start "ruleDataRegister"
    // InternalSmaCQA.g:635:1: ruleDataRegister returns [EObject current=null] : (otherlv_0= 'Data name: ' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'Value: ' ( (lv_type_3_0= ruleType ) ) ) ;
    public final EObject ruleDataRegister() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Enumerator lv_type_3_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:641:2: ( (otherlv_0= 'Data name: ' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'Value: ' ( (lv_type_3_0= ruleType ) ) ) )
            // InternalSmaCQA.g:642:2: (otherlv_0= 'Data name: ' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'Value: ' ( (lv_type_3_0= ruleType ) ) )
            {
            // InternalSmaCQA.g:642:2: (otherlv_0= 'Data name: ' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'Value: ' ( (lv_type_3_0= ruleType ) ) )
            // InternalSmaCQA.g:643:3: otherlv_0= 'Data name: ' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'Value: ' ( (lv_type_3_0= ruleType ) )
            {
            otherlv_0=(Token)match(input,28,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getDataRegisterAccess().getDataNameKeyword_0());
            		
            // InternalSmaCQA.g:647:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSmaCQA.g:648:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSmaCQA.g:648:4: (lv_name_1_0= RULE_ID )
            // InternalSmaCQA.g:649:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_29); 

            					newLeafNode(lv_name_1_0, grammarAccess.getDataRegisterAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDataRegisterRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,29,FOLLOW_30); 

            			newLeafNode(otherlv_2, grammarAccess.getDataRegisterAccess().getValueKeyword_2());
            		
            // InternalSmaCQA.g:669:3: ( (lv_type_3_0= ruleType ) )
            // InternalSmaCQA.g:670:4: (lv_type_3_0= ruleType )
            {
            // InternalSmaCQA.g:670:4: (lv_type_3_0= ruleType )
            // InternalSmaCQA.g:671:5: lv_type_3_0= ruleType
            {

            					newCompositeNode(grammarAccess.getDataRegisterAccess().getTypeTypeEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_type_3_0=ruleType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDataRegisterRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_3_0,
            						"org.xtext.SmaCQA.Type");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataRegister"


    // $ANTLR start "entryRuleToken"
    // InternalSmaCQA.g:692:1: entryRuleToken returns [EObject current=null] : iv_ruleToken= ruleToken EOF ;
    public final EObject entryRuleToken() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleToken = null;


        try {
            // InternalSmaCQA.g:692:46: (iv_ruleToken= ruleToken EOF )
            // InternalSmaCQA.g:693:2: iv_ruleToken= ruleToken EOF
            {
             newCompositeNode(grammarAccess.getTokenRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleToken=ruleToken();

            state._fsp--;

             current =iv_ruleToken; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleToken"


    // $ANTLR start "ruleToken"
    // InternalSmaCQA.g:699:1: ruleToken returns [EObject current=null] : (this_TokenERC20_0= ruleTokenERC20 | this_TokenERC223_1= ruleTokenERC223 | this_TokenERC721_2= ruleTokenERC721 ) ;
    public final EObject ruleToken() throws RecognitionException {
        EObject current = null;

        EObject this_TokenERC20_0 = null;

        EObject this_TokenERC223_1 = null;

        EObject this_TokenERC721_2 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:705:2: ( (this_TokenERC20_0= ruleTokenERC20 | this_TokenERC223_1= ruleTokenERC223 | this_TokenERC721_2= ruleTokenERC721 ) )
            // InternalSmaCQA.g:706:2: (this_TokenERC20_0= ruleTokenERC20 | this_TokenERC223_1= ruleTokenERC223 | this_TokenERC721_2= ruleTokenERC721 )
            {
            // InternalSmaCQA.g:706:2: (this_TokenERC20_0= ruleTokenERC20 | this_TokenERC223_1= ruleTokenERC223 | this_TokenERC721_2= ruleTokenERC721 )
            int alt17=3;
            switch ( input.LA(1) ) {
            case 30:
                {
                alt17=1;
                }
                break;
            case 38:
                {
                alt17=2;
                }
                break;
            case 44:
                {
                alt17=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalSmaCQA.g:707:3: this_TokenERC20_0= ruleTokenERC20
                    {

                    			newCompositeNode(grammarAccess.getTokenAccess().getTokenERC20ParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_TokenERC20_0=ruleTokenERC20();

                    state._fsp--;


                    			current = this_TokenERC20_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:716:3: this_TokenERC223_1= ruleTokenERC223
                    {

                    			newCompositeNode(grammarAccess.getTokenAccess().getTokenERC223ParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_TokenERC223_1=ruleTokenERC223();

                    state._fsp--;


                    			current = this_TokenERC223_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:725:3: this_TokenERC721_2= ruleTokenERC721
                    {

                    			newCompositeNode(grammarAccess.getTokenAccess().getTokenERC721ParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_TokenERC721_2=ruleTokenERC721();

                    state._fsp--;


                    			current = this_TokenERC721_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleToken"


    // $ANTLR start "entryRuleTokenERC20"
    // InternalSmaCQA.g:737:1: entryRuleTokenERC20 returns [EObject current=null] : iv_ruleTokenERC20= ruleTokenERC20 EOF ;
    public final EObject entryRuleTokenERC20() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTokenERC20 = null;


        try {
            // InternalSmaCQA.g:737:51: (iv_ruleTokenERC20= ruleTokenERC20 EOF )
            // InternalSmaCQA.g:738:2: iv_ruleTokenERC20= ruleTokenERC20 EOF
            {
             newCompositeNode(grammarAccess.getTokenERC20Rule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTokenERC20=ruleTokenERC20();

            state._fsp--;

             current =iv_ruleTokenERC20; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTokenERC20"


    // $ANTLR start "ruleTokenERC20"
    // InternalSmaCQA.g:744:1: ruleTokenERC20 returns [EObject current=null] : (otherlv_0= 'Data Declaration Token ERC20: ' otherlv_1= 'Token ERC20 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC20 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC20 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC20 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC20' ) ;
    public final EObject ruleTokenERC20() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token lv_symbol_4_0=null;
        Token otherlv_5=null;
        Token lv_decimals_6_0=null;
        Token otherlv_7=null;
        Token lv_supply_8_0=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token lv_answerMintSentence_11_1=null;
        Token lv_answerMintSentence_11_2=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token lv_answerBurnSentence_14_1=null;
        Token lv_answerBurnSentence_14_2=null;
        Token otherlv_15=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:750:2: ( (otherlv_0= 'Data Declaration Token ERC20: ' otherlv_1= 'Token ERC20 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC20 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC20 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC20 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC20' ) )
            // InternalSmaCQA.g:751:2: (otherlv_0= 'Data Declaration Token ERC20: ' otherlv_1= 'Token ERC20 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC20 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC20 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC20 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC20' )
            {
            // InternalSmaCQA.g:751:2: (otherlv_0= 'Data Declaration Token ERC20: ' otherlv_1= 'Token ERC20 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC20 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC20 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC20 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC20' )
            // InternalSmaCQA.g:752:3: otherlv_0= 'Data Declaration Token ERC20: ' otherlv_1= 'Token ERC20 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC20 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC20 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC20 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC20'
            {
            otherlv_0=(Token)match(input,30,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getTokenERC20Access().getDataDeclarationTokenERC20Keyword_0());
            		
            otherlv_1=(Token)match(input,31,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getTokenERC20Access().getTokenERC20NameKeyword_1());
            		
            // InternalSmaCQA.g:760:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalSmaCQA.g:761:4: (lv_name_2_0= RULE_ID )
            {
            // InternalSmaCQA.g:761:4: (lv_name_2_0= RULE_ID )
            // InternalSmaCQA.g:762:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_32); 

            					newLeafNode(lv_name_2_0, grammarAccess.getTokenERC20Access().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC20Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,32,FOLLOW_4); 

            			newLeafNode(otherlv_3, grammarAccess.getTokenERC20Access().getTokenERC20SymbolKeyword_3());
            		
            // InternalSmaCQA.g:782:3: ( (lv_symbol_4_0= RULE_ID ) )
            // InternalSmaCQA.g:783:4: (lv_symbol_4_0= RULE_ID )
            {
            // InternalSmaCQA.g:783:4: (lv_symbol_4_0= RULE_ID )
            // InternalSmaCQA.g:784:5: lv_symbol_4_0= RULE_ID
            {
            lv_symbol_4_0=(Token)match(input,RULE_ID,FOLLOW_33); 

            					newLeafNode(lv_symbol_4_0, grammarAccess.getTokenERC20Access().getSymbolIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC20Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"symbol",
            						lv_symbol_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_5=(Token)match(input,33,FOLLOW_34); 

            			newLeafNode(otherlv_5, grammarAccess.getTokenERC20Access().getTokenERC20DecimalsKeyword_5());
            		
            // InternalSmaCQA.g:804:3: ( (lv_decimals_6_0= RULE_INT ) )
            // InternalSmaCQA.g:805:4: (lv_decimals_6_0= RULE_INT )
            {
            // InternalSmaCQA.g:805:4: (lv_decimals_6_0= RULE_INT )
            // InternalSmaCQA.g:806:5: lv_decimals_6_0= RULE_INT
            {
            lv_decimals_6_0=(Token)match(input,RULE_INT,FOLLOW_35); 

            					newLeafNode(lv_decimals_6_0, grammarAccess.getTokenERC20Access().getDecimalsINTTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC20Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"decimals",
            						lv_decimals_6_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_7=(Token)match(input,34,FOLLOW_34); 

            			newLeafNode(otherlv_7, grammarAccess.getTokenERC20Access().getTokenERC20SupplyKeyword_7());
            		
            // InternalSmaCQA.g:826:3: ( (lv_supply_8_0= RULE_INT ) )
            // InternalSmaCQA.g:827:4: (lv_supply_8_0= RULE_INT )
            {
            // InternalSmaCQA.g:827:4: (lv_supply_8_0= RULE_INT )
            // InternalSmaCQA.g:828:5: lv_supply_8_0= RULE_INT
            {
            lv_supply_8_0=(Token)match(input,RULE_INT,FOLLOW_36); 

            					newLeafNode(lv_supply_8_0, grammarAccess.getTokenERC20Access().getSupplyINTTerminalRuleCall_8_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC20Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"supply",
            						lv_supply_8_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_9=(Token)match(input,35,FOLLOW_23); 

            			newLeafNode(otherlv_9, grammarAccess.getTokenERC20Access().getIsItPossibleToIncreaseTheTotalSupplyOnceItIsAlreadyInCirculationMintMoreKeyword_9());
            		
            otherlv_10=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_10, grammarAccess.getTokenERC20Access().getAnswerKeyword_10());
            		
            // InternalSmaCQA.g:852:3: ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) )
            // InternalSmaCQA.g:853:4: ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) )
            {
            // InternalSmaCQA.g:853:4: ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) )
            // InternalSmaCQA.g:854:5: (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' )
            {
            // InternalSmaCQA.g:854:5: (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==22) ) {
                alt18=1;
            }
            else if ( (LA18_0==23) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // InternalSmaCQA.g:855:6: lv_answerMintSentence_11_1= 'yes'
                    {
                    lv_answerMintSentence_11_1=(Token)match(input,22,FOLLOW_37); 

                    						newLeafNode(lv_answerMintSentence_11_1, grammarAccess.getTokenERC20Access().getAnswerMintSentenceYesKeyword_11_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC20Rule());
                    						}
                    						setWithLastConsumed(current, "answerMintSentence", lv_answerMintSentence_11_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:866:6: lv_answerMintSentence_11_2= 'no'
                    {
                    lv_answerMintSentence_11_2=(Token)match(input,23,FOLLOW_37); 

                    						newLeafNode(lv_answerMintSentence_11_2, grammarAccess.getTokenERC20Access().getAnswerMintSentenceNoKeyword_11_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC20Rule());
                    						}
                    						setWithLastConsumed(current, "answerMintSentence", lv_answerMintSentence_11_2, null);
                    					

                    }
                    break;

            }


            }


            }

            otherlv_12=(Token)match(input,36,FOLLOW_23); 

            			newLeafNode(otherlv_12, grammarAccess.getTokenERC20Access().getIsItPossibleToRemoveACertainAmountOfTokenFromCirculationBurnTokenKeyword_12());
            		
            otherlv_13=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_13, grammarAccess.getTokenERC20Access().getAnswerKeyword_13());
            		
            // InternalSmaCQA.g:887:3: ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) )
            // InternalSmaCQA.g:888:4: ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) )
            {
            // InternalSmaCQA.g:888:4: ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) )
            // InternalSmaCQA.g:889:5: (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' )
            {
            // InternalSmaCQA.g:889:5: (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' )
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==22) ) {
                alt19=1;
            }
            else if ( (LA19_0==23) ) {
                alt19=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // InternalSmaCQA.g:890:6: lv_answerBurnSentence_14_1= 'yes'
                    {
                    lv_answerBurnSentence_14_1=(Token)match(input,22,FOLLOW_38); 

                    						newLeafNode(lv_answerBurnSentence_14_1, grammarAccess.getTokenERC20Access().getAnswerBurnSentenceYesKeyword_14_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC20Rule());
                    						}
                    						setWithLastConsumed(current, "answerBurnSentence", lv_answerBurnSentence_14_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:901:6: lv_answerBurnSentence_14_2= 'no'
                    {
                    lv_answerBurnSentence_14_2=(Token)match(input,23,FOLLOW_38); 

                    						newLeafNode(lv_answerBurnSentence_14_2, grammarAccess.getTokenERC20Access().getAnswerBurnSentenceNoKeyword_14_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC20Rule());
                    						}
                    						setWithLastConsumed(current, "answerBurnSentence", lv_answerBurnSentence_14_2, null);
                    					

                    }
                    break;

            }


            }


            }

            otherlv_15=(Token)match(input,37,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getTokenERC20Access().getEndDataDeclarationTokenERC20Keyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTokenERC20"


    // $ANTLR start "entryRuleTokenERC223"
    // InternalSmaCQA.g:922:1: entryRuleTokenERC223 returns [EObject current=null] : iv_ruleTokenERC223= ruleTokenERC223 EOF ;
    public final EObject entryRuleTokenERC223() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTokenERC223 = null;


        try {
            // InternalSmaCQA.g:922:52: (iv_ruleTokenERC223= ruleTokenERC223 EOF )
            // InternalSmaCQA.g:923:2: iv_ruleTokenERC223= ruleTokenERC223 EOF
            {
             newCompositeNode(grammarAccess.getTokenERC223Rule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTokenERC223=ruleTokenERC223();

            state._fsp--;

             current =iv_ruleTokenERC223; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTokenERC223"


    // $ANTLR start "ruleTokenERC223"
    // InternalSmaCQA.g:929:1: ruleTokenERC223 returns [EObject current=null] : (otherlv_0= 'Data Declaration Token ERC223: ' otherlv_1= 'Token ERC223 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC223 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC223 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC223 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC223' ) ;
    public final EObject ruleTokenERC223() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token lv_symbol_4_0=null;
        Token otherlv_5=null;
        Token lv_decimals_6_0=null;
        Token otherlv_7=null;
        Token lv_supply_8_0=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token lv_answerMintSentence_11_1=null;
        Token lv_answerMintSentence_11_2=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token lv_answerBurnSentence_14_1=null;
        Token lv_answerBurnSentence_14_2=null;
        Token otherlv_15=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:935:2: ( (otherlv_0= 'Data Declaration Token ERC223: ' otherlv_1= 'Token ERC223 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC223 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC223 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC223 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC223' ) )
            // InternalSmaCQA.g:936:2: (otherlv_0= 'Data Declaration Token ERC223: ' otherlv_1= 'Token ERC223 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC223 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC223 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC223 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC223' )
            {
            // InternalSmaCQA.g:936:2: (otherlv_0= 'Data Declaration Token ERC223: ' otherlv_1= 'Token ERC223 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC223 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC223 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC223 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC223' )
            // InternalSmaCQA.g:937:3: otherlv_0= 'Data Declaration Token ERC223: ' otherlv_1= 'Token ERC223 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC223 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= 'Token ERC223 decimals: ' ( (lv_decimals_6_0= RULE_INT ) ) otherlv_7= 'Token ERC223 supply: ' ( (lv_supply_8_0= RULE_INT ) ) otherlv_9= '1.5.1 Is it possible to increase the total supply once it is already in circulation (mint more)?' otherlv_10= 'answer = ' ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) ) otherlv_12= '1.5.2 Is it possible to remove a certain amount of token from circulation (burn token)?' otherlv_13= 'answer = ' ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) ) otherlv_15= 'End Data Declaration Token ERC223'
            {
            otherlv_0=(Token)match(input,38,FOLLOW_39); 

            			newLeafNode(otherlv_0, grammarAccess.getTokenERC223Access().getDataDeclarationTokenERC223Keyword_0());
            		
            otherlv_1=(Token)match(input,39,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getTokenERC223Access().getTokenERC223NameKeyword_1());
            		
            // InternalSmaCQA.g:945:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalSmaCQA.g:946:4: (lv_name_2_0= RULE_ID )
            {
            // InternalSmaCQA.g:946:4: (lv_name_2_0= RULE_ID )
            // InternalSmaCQA.g:947:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_40); 

            					newLeafNode(lv_name_2_0, grammarAccess.getTokenERC223Access().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC223Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,40,FOLLOW_4); 

            			newLeafNode(otherlv_3, grammarAccess.getTokenERC223Access().getTokenERC223SymbolKeyword_3());
            		
            // InternalSmaCQA.g:967:3: ( (lv_symbol_4_0= RULE_ID ) )
            // InternalSmaCQA.g:968:4: (lv_symbol_4_0= RULE_ID )
            {
            // InternalSmaCQA.g:968:4: (lv_symbol_4_0= RULE_ID )
            // InternalSmaCQA.g:969:5: lv_symbol_4_0= RULE_ID
            {
            lv_symbol_4_0=(Token)match(input,RULE_ID,FOLLOW_41); 

            					newLeafNode(lv_symbol_4_0, grammarAccess.getTokenERC223Access().getSymbolIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC223Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"symbol",
            						lv_symbol_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_5=(Token)match(input,41,FOLLOW_34); 

            			newLeafNode(otherlv_5, grammarAccess.getTokenERC223Access().getTokenERC223DecimalsKeyword_5());
            		
            // InternalSmaCQA.g:989:3: ( (lv_decimals_6_0= RULE_INT ) )
            // InternalSmaCQA.g:990:4: (lv_decimals_6_0= RULE_INT )
            {
            // InternalSmaCQA.g:990:4: (lv_decimals_6_0= RULE_INT )
            // InternalSmaCQA.g:991:5: lv_decimals_6_0= RULE_INT
            {
            lv_decimals_6_0=(Token)match(input,RULE_INT,FOLLOW_42); 

            					newLeafNode(lv_decimals_6_0, grammarAccess.getTokenERC223Access().getDecimalsINTTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC223Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"decimals",
            						lv_decimals_6_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_7=(Token)match(input,42,FOLLOW_34); 

            			newLeafNode(otherlv_7, grammarAccess.getTokenERC223Access().getTokenERC223SupplyKeyword_7());
            		
            // InternalSmaCQA.g:1011:3: ( (lv_supply_8_0= RULE_INT ) )
            // InternalSmaCQA.g:1012:4: (lv_supply_8_0= RULE_INT )
            {
            // InternalSmaCQA.g:1012:4: (lv_supply_8_0= RULE_INT )
            // InternalSmaCQA.g:1013:5: lv_supply_8_0= RULE_INT
            {
            lv_supply_8_0=(Token)match(input,RULE_INT,FOLLOW_36); 

            					newLeafNode(lv_supply_8_0, grammarAccess.getTokenERC223Access().getSupplyINTTerminalRuleCall_8_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC223Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"supply",
            						lv_supply_8_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_9=(Token)match(input,35,FOLLOW_23); 

            			newLeafNode(otherlv_9, grammarAccess.getTokenERC223Access().getIsItPossibleToIncreaseTheTotalSupplyOnceItIsAlreadyInCirculationMintMoreKeyword_9());
            		
            otherlv_10=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_10, grammarAccess.getTokenERC223Access().getAnswerKeyword_10());
            		
            // InternalSmaCQA.g:1037:3: ( ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) ) )
            // InternalSmaCQA.g:1038:4: ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) )
            {
            // InternalSmaCQA.g:1038:4: ( (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' ) )
            // InternalSmaCQA.g:1039:5: (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' )
            {
            // InternalSmaCQA.g:1039:5: (lv_answerMintSentence_11_1= 'yes' | lv_answerMintSentence_11_2= 'no' )
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==22) ) {
                alt20=1;
            }
            else if ( (LA20_0==23) ) {
                alt20=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // InternalSmaCQA.g:1040:6: lv_answerMintSentence_11_1= 'yes'
                    {
                    lv_answerMintSentence_11_1=(Token)match(input,22,FOLLOW_37); 

                    						newLeafNode(lv_answerMintSentence_11_1, grammarAccess.getTokenERC223Access().getAnswerMintSentenceYesKeyword_11_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC223Rule());
                    						}
                    						setWithLastConsumed(current, "answerMintSentence", lv_answerMintSentence_11_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:1051:6: lv_answerMintSentence_11_2= 'no'
                    {
                    lv_answerMintSentence_11_2=(Token)match(input,23,FOLLOW_37); 

                    						newLeafNode(lv_answerMintSentence_11_2, grammarAccess.getTokenERC223Access().getAnswerMintSentenceNoKeyword_11_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC223Rule());
                    						}
                    						setWithLastConsumed(current, "answerMintSentence", lv_answerMintSentence_11_2, null);
                    					

                    }
                    break;

            }


            }


            }

            otherlv_12=(Token)match(input,36,FOLLOW_23); 

            			newLeafNode(otherlv_12, grammarAccess.getTokenERC223Access().getIsItPossibleToRemoveACertainAmountOfTokenFromCirculationBurnTokenKeyword_12());
            		
            otherlv_13=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_13, grammarAccess.getTokenERC223Access().getAnswerKeyword_13());
            		
            // InternalSmaCQA.g:1072:3: ( ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) ) )
            // InternalSmaCQA.g:1073:4: ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) )
            {
            // InternalSmaCQA.g:1073:4: ( (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' ) )
            // InternalSmaCQA.g:1074:5: (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' )
            {
            // InternalSmaCQA.g:1074:5: (lv_answerBurnSentence_14_1= 'yes' | lv_answerBurnSentence_14_2= 'no' )
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==22) ) {
                alt21=1;
            }
            else if ( (LA21_0==23) ) {
                alt21=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // InternalSmaCQA.g:1075:6: lv_answerBurnSentence_14_1= 'yes'
                    {
                    lv_answerBurnSentence_14_1=(Token)match(input,22,FOLLOW_43); 

                    						newLeafNode(lv_answerBurnSentence_14_1, grammarAccess.getTokenERC223Access().getAnswerBurnSentenceYesKeyword_14_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC223Rule());
                    						}
                    						setWithLastConsumed(current, "answerBurnSentence", lv_answerBurnSentence_14_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:1086:6: lv_answerBurnSentence_14_2= 'no'
                    {
                    lv_answerBurnSentence_14_2=(Token)match(input,23,FOLLOW_43); 

                    						newLeafNode(lv_answerBurnSentence_14_2, grammarAccess.getTokenERC223Access().getAnswerBurnSentenceNoKeyword_14_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC223Rule());
                    						}
                    						setWithLastConsumed(current, "answerBurnSentence", lv_answerBurnSentence_14_2, null);
                    					

                    }
                    break;

            }


            }


            }

            otherlv_15=(Token)match(input,43,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getTokenERC223Access().getEndDataDeclarationTokenERC223Keyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTokenERC223"


    // $ANTLR start "entryRuleTokenERC721"
    // InternalSmaCQA.g:1107:1: entryRuleTokenERC721 returns [EObject current=null] : iv_ruleTokenERC721= ruleTokenERC721 EOF ;
    public final EObject entryRuleTokenERC721() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTokenERC721 = null;


        try {
            // InternalSmaCQA.g:1107:52: (iv_ruleTokenERC721= ruleTokenERC721 EOF )
            // InternalSmaCQA.g:1108:2: iv_ruleTokenERC721= ruleTokenERC721 EOF
            {
             newCompositeNode(grammarAccess.getTokenERC721Rule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTokenERC721=ruleTokenERC721();

            state._fsp--;

             current =iv_ruleTokenERC721; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTokenERC721"


    // $ANTLR start "ruleTokenERC721"
    // InternalSmaCQA.g:1114:1: ruleTokenERC721 returns [EObject current=null] : (otherlv_0= 'Data Declaration Non Fungible Token ERC721: ' otherlv_1= 'Token ERC721 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC721 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= '1.5.1 If it\\'s possible to mint more than one NFT at a time?' otherlv_6= 'answer = ' ( ( (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' ) ) ) otherlv_8= '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' otherlv_9= 'answer = ' ( ( (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' ) ) ) otherlv_11= '1.5.3 What is the price of this token?' otherlv_12= 'answer = ' ( (lv_answerUnitPrice_13_0= RULE_INT ) ) ( (lv_answerUnitCoin_14_0= ruleUnitCoin ) ) otherlv_15= '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' otherlv_16= 'answer = ' ( ( (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' ) ) ) (otherlv_18= '1.5.5 Which data or properties are requiered for the NFT information?' otherlv_19= 'Data Declaration: ' ( (lv_answer_20_0= ruleDataRegister ) )+ otherlv_21= 'End Data Declaration' )? (otherlv_22= '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' otherlv_23= 'total supply = ' ( (lv_supply_24_0= RULE_INT ) ) )? otherlv_25= 'End Data Declaration Token ERC721' ) ;
    public final EObject ruleTokenERC721() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token lv_symbol_4_0=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token lv_answerMintSentence_7_1=null;
        Token lv_answerMintSentence_7_2=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token lv_answerBurnSentence_10_1=null;
        Token lv_answerBurnSentence_10_2=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token lv_answerUnitPrice_13_0=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token lv_answerMetadataSentence_17_1=null;
        Token lv_answerMetadataSentence_17_2=null;
        Token otherlv_18=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        Token otherlv_23=null;
        Token lv_supply_24_0=null;
        Token otherlv_25=null;
        Enumerator lv_answerUnitCoin_14_0 = null;

        EObject lv_answer_20_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:1120:2: ( (otherlv_0= 'Data Declaration Non Fungible Token ERC721: ' otherlv_1= 'Token ERC721 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC721 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= '1.5.1 If it\\'s possible to mint more than one NFT at a time?' otherlv_6= 'answer = ' ( ( (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' ) ) ) otherlv_8= '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' otherlv_9= 'answer = ' ( ( (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' ) ) ) otherlv_11= '1.5.3 What is the price of this token?' otherlv_12= 'answer = ' ( (lv_answerUnitPrice_13_0= RULE_INT ) ) ( (lv_answerUnitCoin_14_0= ruleUnitCoin ) ) otherlv_15= '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' otherlv_16= 'answer = ' ( ( (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' ) ) ) (otherlv_18= '1.5.5 Which data or properties are requiered for the NFT information?' otherlv_19= 'Data Declaration: ' ( (lv_answer_20_0= ruleDataRegister ) )+ otherlv_21= 'End Data Declaration' )? (otherlv_22= '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' otherlv_23= 'total supply = ' ( (lv_supply_24_0= RULE_INT ) ) )? otherlv_25= 'End Data Declaration Token ERC721' ) )
            // InternalSmaCQA.g:1121:2: (otherlv_0= 'Data Declaration Non Fungible Token ERC721: ' otherlv_1= 'Token ERC721 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC721 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= '1.5.1 If it\\'s possible to mint more than one NFT at a time?' otherlv_6= 'answer = ' ( ( (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' ) ) ) otherlv_8= '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' otherlv_9= 'answer = ' ( ( (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' ) ) ) otherlv_11= '1.5.3 What is the price of this token?' otherlv_12= 'answer = ' ( (lv_answerUnitPrice_13_0= RULE_INT ) ) ( (lv_answerUnitCoin_14_0= ruleUnitCoin ) ) otherlv_15= '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' otherlv_16= 'answer = ' ( ( (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' ) ) ) (otherlv_18= '1.5.5 Which data or properties are requiered for the NFT information?' otherlv_19= 'Data Declaration: ' ( (lv_answer_20_0= ruleDataRegister ) )+ otherlv_21= 'End Data Declaration' )? (otherlv_22= '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' otherlv_23= 'total supply = ' ( (lv_supply_24_0= RULE_INT ) ) )? otherlv_25= 'End Data Declaration Token ERC721' )
            {
            // InternalSmaCQA.g:1121:2: (otherlv_0= 'Data Declaration Non Fungible Token ERC721: ' otherlv_1= 'Token ERC721 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC721 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= '1.5.1 If it\\'s possible to mint more than one NFT at a time?' otherlv_6= 'answer = ' ( ( (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' ) ) ) otherlv_8= '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' otherlv_9= 'answer = ' ( ( (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' ) ) ) otherlv_11= '1.5.3 What is the price of this token?' otherlv_12= 'answer = ' ( (lv_answerUnitPrice_13_0= RULE_INT ) ) ( (lv_answerUnitCoin_14_0= ruleUnitCoin ) ) otherlv_15= '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' otherlv_16= 'answer = ' ( ( (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' ) ) ) (otherlv_18= '1.5.5 Which data or properties are requiered for the NFT information?' otherlv_19= 'Data Declaration: ' ( (lv_answer_20_0= ruleDataRegister ) )+ otherlv_21= 'End Data Declaration' )? (otherlv_22= '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' otherlv_23= 'total supply = ' ( (lv_supply_24_0= RULE_INT ) ) )? otherlv_25= 'End Data Declaration Token ERC721' )
            // InternalSmaCQA.g:1122:3: otherlv_0= 'Data Declaration Non Fungible Token ERC721: ' otherlv_1= 'Token ERC721 name: ' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'Token ERC721 Symbol: ' ( (lv_symbol_4_0= RULE_ID ) ) otherlv_5= '1.5.1 If it\\'s possible to mint more than one NFT at a time?' otherlv_6= 'answer = ' ( ( (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' ) ) ) otherlv_8= '1.5.2 Is it possible to remove/disable the token from circulation (burn token)?' otherlv_9= 'answer = ' ( ( (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' ) ) ) otherlv_11= '1.5.3 What is the price of this token?' otherlv_12= 'answer = ' ( (lv_answerUnitPrice_13_0= RULE_INT ) ) ( (lv_answerUnitCoin_14_0= ruleUnitCoin ) ) otherlv_15= '1.5.4 Is necessary attach metadata (Information about the token, example: url image) to the token?' otherlv_16= 'answer = ' ( ( (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' ) ) ) (otherlv_18= '1.5.5 Which data or properties are requiered for the NFT information?' otherlv_19= 'Data Declaration: ' ( (lv_answer_20_0= ruleDataRegister ) )+ otherlv_21= 'End Data Declaration' )? (otherlv_22= '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' otherlv_23= 'total supply = ' ( (lv_supply_24_0= RULE_INT ) ) )? otherlv_25= 'End Data Declaration Token ERC721'
            {
            otherlv_0=(Token)match(input,44,FOLLOW_44); 

            			newLeafNode(otherlv_0, grammarAccess.getTokenERC721Access().getDataDeclarationNonFungibleTokenERC721Keyword_0());
            		
            otherlv_1=(Token)match(input,45,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getTokenERC721Access().getTokenERC721NameKeyword_1());
            		
            // InternalSmaCQA.g:1130:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalSmaCQA.g:1131:4: (lv_name_2_0= RULE_ID )
            {
            // InternalSmaCQA.g:1131:4: (lv_name_2_0= RULE_ID )
            // InternalSmaCQA.g:1132:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_45); 

            					newLeafNode(lv_name_2_0, grammarAccess.getTokenERC721Access().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC721Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,46,FOLLOW_4); 

            			newLeafNode(otherlv_3, grammarAccess.getTokenERC721Access().getTokenERC721SymbolKeyword_3());
            		
            // InternalSmaCQA.g:1152:3: ( (lv_symbol_4_0= RULE_ID ) )
            // InternalSmaCQA.g:1153:4: (lv_symbol_4_0= RULE_ID )
            {
            // InternalSmaCQA.g:1153:4: (lv_symbol_4_0= RULE_ID )
            // InternalSmaCQA.g:1154:5: lv_symbol_4_0= RULE_ID
            {
            lv_symbol_4_0=(Token)match(input,RULE_ID,FOLLOW_46); 

            					newLeafNode(lv_symbol_4_0, grammarAccess.getTokenERC721Access().getSymbolIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC721Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"symbol",
            						lv_symbol_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_5=(Token)match(input,47,FOLLOW_23); 

            			newLeafNode(otherlv_5, grammarAccess.getTokenERC721Access().getIfItSPossibleToMintMoreThanOneNFTAtATimeKeyword_5());
            		
            otherlv_6=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_6, grammarAccess.getTokenERC721Access().getAnswerKeyword_6());
            		
            // InternalSmaCQA.g:1178:3: ( ( (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' ) ) )
            // InternalSmaCQA.g:1179:4: ( (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' ) )
            {
            // InternalSmaCQA.g:1179:4: ( (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' ) )
            // InternalSmaCQA.g:1180:5: (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' )
            {
            // InternalSmaCQA.g:1180:5: (lv_answerMintSentence_7_1= 'yes' | lv_answerMintSentence_7_2= 'no' )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==22) ) {
                alt22=1;
            }
            else if ( (LA22_0==23) ) {
                alt22=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // InternalSmaCQA.g:1181:6: lv_answerMintSentence_7_1= 'yes'
                    {
                    lv_answerMintSentence_7_1=(Token)match(input,22,FOLLOW_47); 

                    						newLeafNode(lv_answerMintSentence_7_1, grammarAccess.getTokenERC721Access().getAnswerMintSentenceYesKeyword_7_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC721Rule());
                    						}
                    						setWithLastConsumed(current, "answerMintSentence", lv_answerMintSentence_7_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:1192:6: lv_answerMintSentence_7_2= 'no'
                    {
                    lv_answerMintSentence_7_2=(Token)match(input,23,FOLLOW_47); 

                    						newLeafNode(lv_answerMintSentence_7_2, grammarAccess.getTokenERC721Access().getAnswerMintSentenceNoKeyword_7_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC721Rule());
                    						}
                    						setWithLastConsumed(current, "answerMintSentence", lv_answerMintSentence_7_2, null);
                    					

                    }
                    break;

            }


            }


            }

            otherlv_8=(Token)match(input,48,FOLLOW_23); 

            			newLeafNode(otherlv_8, grammarAccess.getTokenERC721Access().getIsItPossibleToRemoveDisableTheTokenFromCirculationBurnTokenKeyword_8());
            		
            otherlv_9=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_9, grammarAccess.getTokenERC721Access().getAnswerKeyword_9());
            		
            // InternalSmaCQA.g:1213:3: ( ( (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' ) ) )
            // InternalSmaCQA.g:1214:4: ( (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' ) )
            {
            // InternalSmaCQA.g:1214:4: ( (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' ) )
            // InternalSmaCQA.g:1215:5: (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' )
            {
            // InternalSmaCQA.g:1215:5: (lv_answerBurnSentence_10_1= 'yes' | lv_answerBurnSentence_10_2= 'no' )
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==22) ) {
                alt23=1;
            }
            else if ( (LA23_0==23) ) {
                alt23=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // InternalSmaCQA.g:1216:6: lv_answerBurnSentence_10_1= 'yes'
                    {
                    lv_answerBurnSentence_10_1=(Token)match(input,22,FOLLOW_48); 

                    						newLeafNode(lv_answerBurnSentence_10_1, grammarAccess.getTokenERC721Access().getAnswerBurnSentenceYesKeyword_10_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC721Rule());
                    						}
                    						setWithLastConsumed(current, "answerBurnSentence", lv_answerBurnSentence_10_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:1227:6: lv_answerBurnSentence_10_2= 'no'
                    {
                    lv_answerBurnSentence_10_2=(Token)match(input,23,FOLLOW_48); 

                    						newLeafNode(lv_answerBurnSentence_10_2, grammarAccess.getTokenERC721Access().getAnswerBurnSentenceNoKeyword_10_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC721Rule());
                    						}
                    						setWithLastConsumed(current, "answerBurnSentence", lv_answerBurnSentence_10_2, null);
                    					

                    }
                    break;

            }


            }


            }

            otherlv_11=(Token)match(input,49,FOLLOW_23); 

            			newLeafNode(otherlv_11, grammarAccess.getTokenERC721Access().getWhatIsThePriceOfThisTokenKeyword_11());
            		
            otherlv_12=(Token)match(input,21,FOLLOW_34); 

            			newLeafNode(otherlv_12, grammarAccess.getTokenERC721Access().getAnswerKeyword_12());
            		
            // InternalSmaCQA.g:1248:3: ( (lv_answerUnitPrice_13_0= RULE_INT ) )
            // InternalSmaCQA.g:1249:4: (lv_answerUnitPrice_13_0= RULE_INT )
            {
            // InternalSmaCQA.g:1249:4: (lv_answerUnitPrice_13_0= RULE_INT )
            // InternalSmaCQA.g:1250:5: lv_answerUnitPrice_13_0= RULE_INT
            {
            lv_answerUnitPrice_13_0=(Token)match(input,RULE_INT,FOLLOW_49); 

            					newLeafNode(lv_answerUnitPrice_13_0, grammarAccess.getTokenERC721Access().getAnswerUnitPriceINTTerminalRuleCall_13_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTokenERC721Rule());
            					}
            					setWithLastConsumed(
            						current,
            						"answerUnitPrice",
            						lv_answerUnitPrice_13_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSmaCQA.g:1266:3: ( (lv_answerUnitCoin_14_0= ruleUnitCoin ) )
            // InternalSmaCQA.g:1267:4: (lv_answerUnitCoin_14_0= ruleUnitCoin )
            {
            // InternalSmaCQA.g:1267:4: (lv_answerUnitCoin_14_0= ruleUnitCoin )
            // InternalSmaCQA.g:1268:5: lv_answerUnitCoin_14_0= ruleUnitCoin
            {

            					newCompositeNode(grammarAccess.getTokenERC721Access().getAnswerUnitCoinUnitCoinEnumRuleCall_14_0());
            				
            pushFollow(FOLLOW_50);
            lv_answerUnitCoin_14_0=ruleUnitCoin();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTokenERC721Rule());
            					}
            					set(
            						current,
            						"answerUnitCoin",
            						lv_answerUnitCoin_14_0,
            						"org.xtext.SmaCQA.UnitCoin");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_15=(Token)match(input,50,FOLLOW_23); 

            			newLeafNode(otherlv_15, grammarAccess.getTokenERC721Access().getIsNecessaryAttachMetadataInformationAboutTheTokenExampleUrlImageToTheTokenKeyword_15());
            		
            otherlv_16=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_16, grammarAccess.getTokenERC721Access().getAnswerKeyword_16());
            		
            // InternalSmaCQA.g:1293:3: ( ( (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' ) ) )
            // InternalSmaCQA.g:1294:4: ( (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' ) )
            {
            // InternalSmaCQA.g:1294:4: ( (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' ) )
            // InternalSmaCQA.g:1295:5: (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' )
            {
            // InternalSmaCQA.g:1295:5: (lv_answerMetadataSentence_17_1= 'yes' | lv_answerMetadataSentence_17_2= 'no' )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==22) ) {
                alt24=1;
            }
            else if ( (LA24_0==23) ) {
                alt24=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // InternalSmaCQA.g:1296:6: lv_answerMetadataSentence_17_1= 'yes'
                    {
                    lv_answerMetadataSentence_17_1=(Token)match(input,22,FOLLOW_51); 

                    						newLeafNode(lv_answerMetadataSentence_17_1, grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceYesKeyword_17_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC721Rule());
                    						}
                    						setWithLastConsumed(current, "answerMetadataSentence", lv_answerMetadataSentence_17_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:1307:6: lv_answerMetadataSentence_17_2= 'no'
                    {
                    lv_answerMetadataSentence_17_2=(Token)match(input,23,FOLLOW_51); 

                    						newLeafNode(lv_answerMetadataSentence_17_2, grammarAccess.getTokenERC721Access().getAnswerMetadataSentenceNoKeyword_17_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC721Rule());
                    						}
                    						setWithLastConsumed(current, "answerMetadataSentence", lv_answerMetadataSentence_17_2, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSmaCQA.g:1320:3: (otherlv_18= '1.5.5 Which data or properties are requiered for the NFT information?' otherlv_19= 'Data Declaration: ' ( (lv_answer_20_0= ruleDataRegister ) )+ otherlv_21= 'End Data Declaration' )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==51) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalSmaCQA.g:1321:4: otherlv_18= '1.5.5 Which data or properties are requiered for the NFT information?' otherlv_19= 'Data Declaration: ' ( (lv_answer_20_0= ruleDataRegister ) )+ otherlv_21= 'End Data Declaration'
                    {
                    otherlv_18=(Token)match(input,51,FOLLOW_26); 

                    				newLeafNode(otherlv_18, grammarAccess.getTokenERC721Access().getWhichDataOrPropertiesAreRequieredForTheNFTInformationKeyword_18_0());
                    			
                    otherlv_19=(Token)match(input,26,FOLLOW_27); 

                    				newLeafNode(otherlv_19, grammarAccess.getTokenERC721Access().getDataDeclarationKeyword_18_1());
                    			
                    // InternalSmaCQA.g:1329:4: ( (lv_answer_20_0= ruleDataRegister ) )+
                    int cnt25=0;
                    loop25:
                    do {
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==28) ) {
                            alt25=1;
                        }


                        switch (alt25) {
                    	case 1 :
                    	    // InternalSmaCQA.g:1330:5: (lv_answer_20_0= ruleDataRegister )
                    	    {
                    	    // InternalSmaCQA.g:1330:5: (lv_answer_20_0= ruleDataRegister )
                    	    // InternalSmaCQA.g:1331:6: lv_answer_20_0= ruleDataRegister
                    	    {

                    	    						newCompositeNode(grammarAccess.getTokenERC721Access().getAnswerDataRegisterParserRuleCall_18_2_0());
                    	    					
                    	    pushFollow(FOLLOW_28);
                    	    lv_answer_20_0=ruleDataRegister();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getTokenERC721Rule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"answer",
                    	    							lv_answer_20_0,
                    	    							"org.xtext.SmaCQA.DataRegister");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    if ( cnt25 >= 1 ) break loop25;
                                EarlyExitException eee =
                                    new EarlyExitException(25, input);
                                throw eee;
                        }
                        cnt25++;
                    } while (true);

                    otherlv_21=(Token)match(input,27,FOLLOW_52); 

                    				newLeafNode(otherlv_21, grammarAccess.getTokenERC721Access().getEndDataDeclarationKeyword_18_3());
                    			

                    }
                    break;

            }

            // InternalSmaCQA.g:1353:3: (otherlv_22= '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' otherlv_23= 'total supply = ' ( (lv_supply_24_0= RULE_INT ) ) )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==52) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSmaCQA.g:1354:4: otherlv_22= '1.5.6 If it\\'s possible to define an amount to restrict the amount of NFTs that are minted. What is the maximum amount?' otherlv_23= 'total supply = ' ( (lv_supply_24_0= RULE_INT ) )
                    {
                    otherlv_22=(Token)match(input,52,FOLLOW_53); 

                    				newLeafNode(otherlv_22, grammarAccess.getTokenERC721Access().getIfItSPossibleToDefineAnAmountToRestrictTheAmountOfNFTsThatAreMintedWhatIsTheMaximumAmountKeyword_19_0());
                    			
                    otherlv_23=(Token)match(input,53,FOLLOW_34); 

                    				newLeafNode(otherlv_23, grammarAccess.getTokenERC721Access().getTotalSupplyKeyword_19_1());
                    			
                    // InternalSmaCQA.g:1362:4: ( (lv_supply_24_0= RULE_INT ) )
                    // InternalSmaCQA.g:1363:5: (lv_supply_24_0= RULE_INT )
                    {
                    // InternalSmaCQA.g:1363:5: (lv_supply_24_0= RULE_INT )
                    // InternalSmaCQA.g:1364:6: lv_supply_24_0= RULE_INT
                    {
                    lv_supply_24_0=(Token)match(input,RULE_INT,FOLLOW_54); 

                    						newLeafNode(lv_supply_24_0, grammarAccess.getTokenERC721Access().getSupplyINTTerminalRuleCall_19_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTokenERC721Rule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"supply",
                    							lv_supply_24_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_25=(Token)match(input,54,FOLLOW_2); 

            			newLeafNode(otherlv_25, grammarAccess.getTokenERC721Access().getEndDataDeclarationTokenERC721Keyword_20());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTokenERC721"


    // $ANTLR start "entryRuleTimeValueExchangeDurationQuestion"
    // InternalSmaCQA.g:1389:1: entryRuleTimeValueExchangeDurationQuestion returns [EObject current=null] : iv_ruleTimeValueExchangeDurationQuestion= ruleTimeValueExchangeDurationQuestion EOF ;
    public final EObject entryRuleTimeValueExchangeDurationQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimeValueExchangeDurationQuestion = null;


        try {
            // InternalSmaCQA.g:1389:74: (iv_ruleTimeValueExchangeDurationQuestion= ruleTimeValueExchangeDurationQuestion EOF )
            // InternalSmaCQA.g:1390:2: iv_ruleTimeValueExchangeDurationQuestion= ruleTimeValueExchangeDurationQuestion EOF
            {
             newCompositeNode(grammarAccess.getTimeValueExchangeDurationQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTimeValueExchangeDurationQuestion=ruleTimeValueExchangeDurationQuestion();

            state._fsp--;

             current =iv_ruleTimeValueExchangeDurationQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeValueExchangeDurationQuestion"


    // $ANTLR start "ruleTimeValueExchangeDurationQuestion"
    // InternalSmaCQA.g:1396:1: ruleTimeValueExchangeDurationQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) ) ) ;
    public final EObject ruleTimeValueExchangeDurationQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_answer_2_0=null;
        Token otherlv_3=null;
        Enumerator lv_answerUnitTime_4_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:1402:2: ( ( ( (lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) ) ) )
            // InternalSmaCQA.g:1403:2: ( ( (lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) ) )
            {
            // InternalSmaCQA.g:1403:2: ( ( (lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) ) )
            // InternalSmaCQA.g:1404:3: ( (lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) )
            {
            // InternalSmaCQA.g:1404:3: ( (lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' ) )
            // InternalSmaCQA.g:1405:4: (lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' )
            {
            // InternalSmaCQA.g:1405:4: (lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)' )
            // InternalSmaCQA.g:1406:5: lv_name_0_0= '1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)'
            {
            lv_name_0_0=(Token)match(input,55,FOLLOW_23); 

            					newLeafNode(lv_name_0_0, grammarAccess.getTimeValueExchangeDurationQuestionAccess().getName11IfTheExchangeOfValueIsSubjectToADurationOfTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimeValueExchangeDurationQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "1.1 If the exchange of value is subject to a duration of time. What would this be?(indicated in minutes,days,weeks or years)");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_34); 

            			newLeafNode(otherlv_1, grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerKeyword_1());
            		
            // InternalSmaCQA.g:1422:3: ( (lv_answer_2_0= RULE_INT ) )
            // InternalSmaCQA.g:1423:4: (lv_answer_2_0= RULE_INT )
            {
            // InternalSmaCQA.g:1423:4: (lv_answer_2_0= RULE_INT )
            // InternalSmaCQA.g:1424:5: lv_answer_2_0= RULE_INT
            {
            lv_answer_2_0=(Token)match(input,RULE_INT,FOLLOW_55); 

            					newLeafNode(lv_answer_2_0, grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerINTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimeValueExchangeDurationQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"answer",
            						lv_answer_2_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_3=(Token)match(input,56,FOLLOW_56); 

            			newLeafNode(otherlv_3, grammarAccess.getTimeValueExchangeDurationQuestionAccess().getUnitTimeKeyword_3());
            		
            // InternalSmaCQA.g:1444:3: ( (lv_answerUnitTime_4_0= ruleUnitTime ) )
            // InternalSmaCQA.g:1445:4: (lv_answerUnitTime_4_0= ruleUnitTime )
            {
            // InternalSmaCQA.g:1445:4: (lv_answerUnitTime_4_0= ruleUnitTime )
            // InternalSmaCQA.g:1446:5: lv_answerUnitTime_4_0= ruleUnitTime
            {

            					newCompositeNode(grammarAccess.getTimeValueExchangeDurationQuestionAccess().getAnswerUnitTimeUnitTimeEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_answerUnitTime_4_0=ruleUnitTime();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTimeValueExchangeDurationQuestionRule());
            					}
            					set(
            						current,
            						"answerUnitTime",
            						lv_answerUnitTime_4_0,
            						"org.xtext.SmaCQA.UnitTime");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeValueExchangeDurationQuestion"


    // $ANTLR start "entryRuleTimeStartValueExchangeQuestion"
    // InternalSmaCQA.g:1467:1: entryRuleTimeStartValueExchangeQuestion returns [EObject current=null] : iv_ruleTimeStartValueExchangeQuestion= ruleTimeStartValueExchangeQuestion EOF ;
    public final EObject entryRuleTimeStartValueExchangeQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimeStartValueExchangeQuestion = null;


        try {
            // InternalSmaCQA.g:1467:71: (iv_ruleTimeStartValueExchangeQuestion= ruleTimeStartValueExchangeQuestion EOF )
            // InternalSmaCQA.g:1468:2: iv_ruleTimeStartValueExchangeQuestion= ruleTimeStartValueExchangeQuestion EOF
            {
             newCompositeNode(grammarAccess.getTimeStartValueExchangeQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTimeStartValueExchangeQuestion=ruleTimeStartValueExchangeQuestion();

            state._fsp--;

             current =iv_ruleTimeStartValueExchangeQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeStartValueExchangeQuestion"


    // $ANTLR start "ruleTimeStartValueExchangeQuestion"
    // InternalSmaCQA.g:1474:1: ruleTimeStartValueExchangeQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) ) ) ;
    public final EObject ruleTimeStartValueExchangeQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_answer_2_0=null;
        Token otherlv_3=null;
        Enumerator lv_answerUnitTime_4_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:1480:2: ( ( ( (lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) ) ) )
            // InternalSmaCQA.g:1481:2: ( ( (lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) ) )
            {
            // InternalSmaCQA.g:1481:2: ( ( (lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) ) )
            // InternalSmaCQA.g:1482:3: ( (lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) otherlv_3= 'unitTime = ' ( (lv_answerUnitTime_4_0= ruleUnitTime ) )
            {
            // InternalSmaCQA.g:1482:3: ( (lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' ) )
            // InternalSmaCQA.g:1483:4: (lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' )
            {
            // InternalSmaCQA.g:1483:4: (lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)' )
            // InternalSmaCQA.g:1484:5: lv_name_0_0= '1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)'
            {
            lv_name_0_0=(Token)match(input,57,FOLLOW_23); 

            					newLeafNode(lv_name_0_0, grammarAccess.getTimeStartValueExchangeQuestionAccess().getName12IfTheExchangeOfValueCouldOnlyTakePlaceAfterACertainTimeWhatWouldThisBeIndicatedInMinutesDaysWeeksOrYearsKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimeStartValueExchangeQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "1.2 If the exchange of value could only take place after a certain time. What would this be?(indicated in minutes,days,weeks or years)");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_34); 

            			newLeafNode(otherlv_1, grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerKeyword_1());
            		
            // InternalSmaCQA.g:1500:3: ( (lv_answer_2_0= RULE_INT ) )
            // InternalSmaCQA.g:1501:4: (lv_answer_2_0= RULE_INT )
            {
            // InternalSmaCQA.g:1501:4: (lv_answer_2_0= RULE_INT )
            // InternalSmaCQA.g:1502:5: lv_answer_2_0= RULE_INT
            {
            lv_answer_2_0=(Token)match(input,RULE_INT,FOLLOW_55); 

            					newLeafNode(lv_answer_2_0, grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerINTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTimeStartValueExchangeQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"answer",
            						lv_answer_2_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_3=(Token)match(input,56,FOLLOW_56); 

            			newLeafNode(otherlv_3, grammarAccess.getTimeStartValueExchangeQuestionAccess().getUnitTimeKeyword_3());
            		
            // InternalSmaCQA.g:1522:3: ( (lv_answerUnitTime_4_0= ruleUnitTime ) )
            // InternalSmaCQA.g:1523:4: (lv_answerUnitTime_4_0= ruleUnitTime )
            {
            // InternalSmaCQA.g:1523:4: (lv_answerUnitTime_4_0= ruleUnitTime )
            // InternalSmaCQA.g:1524:5: lv_answerUnitTime_4_0= ruleUnitTime
            {

            					newCompositeNode(grammarAccess.getTimeStartValueExchangeQuestionAccess().getAnswerUnitTimeUnitTimeEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_answerUnitTime_4_0=ruleUnitTime();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTimeStartValueExchangeQuestionRule());
            					}
            					set(
            						current,
            						"answerUnitTime",
            						lv_answerUnitTime_4_0,
            						"org.xtext.SmaCQA.UnitTime");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeStartValueExchangeQuestion"


    // $ANTLR start "entryRuleRepeatValueExchangeQuestion"
    // InternalSmaCQA.g:1545:1: entryRuleRepeatValueExchangeQuestion returns [EObject current=null] : iv_ruleRepeatValueExchangeQuestion= ruleRepeatValueExchangeQuestion EOF ;
    public final EObject entryRuleRepeatValueExchangeQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRepeatValueExchangeQuestion = null;


        try {
            // InternalSmaCQA.g:1545:68: (iv_ruleRepeatValueExchangeQuestion= ruleRepeatValueExchangeQuestion EOF )
            // InternalSmaCQA.g:1546:2: iv_ruleRepeatValueExchangeQuestion= ruleRepeatValueExchangeQuestion EOF
            {
             newCompositeNode(grammarAccess.getRepeatValueExchangeQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRepeatValueExchangeQuestion=ruleRepeatValueExchangeQuestion();

            state._fsp--;

             current =iv_ruleRepeatValueExchangeQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRepeatValueExchangeQuestion"


    // $ANTLR start "ruleRepeatValueExchangeQuestion"
    // InternalSmaCQA.g:1552:1: ruleRepeatValueExchangeQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '1.3 Can the value exchange be repeated over time?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) ) ;
    public final EObject ruleRepeatValueExchangeQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_answer_2_1=null;
        Token lv_answer_2_2=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:1558:2: ( ( ( (lv_name_0_0= '1.3 Can the value exchange be repeated over time?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) ) )
            // InternalSmaCQA.g:1559:2: ( ( (lv_name_0_0= '1.3 Can the value exchange be repeated over time?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) )
            {
            // InternalSmaCQA.g:1559:2: ( ( (lv_name_0_0= '1.3 Can the value exchange be repeated over time?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) )
            // InternalSmaCQA.g:1560:3: ( (lv_name_0_0= '1.3 Can the value exchange be repeated over time?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) )
            {
            // InternalSmaCQA.g:1560:3: ( (lv_name_0_0= '1.3 Can the value exchange be repeated over time?' ) )
            // InternalSmaCQA.g:1561:4: (lv_name_0_0= '1.3 Can the value exchange be repeated over time?' )
            {
            // InternalSmaCQA.g:1561:4: (lv_name_0_0= '1.3 Can the value exchange be repeated over time?' )
            // InternalSmaCQA.g:1562:5: lv_name_0_0= '1.3 Can the value exchange be repeated over time?'
            {
            lv_name_0_0=(Token)match(input,58,FOLLOW_23); 

            					newLeafNode(lv_name_0_0, grammarAccess.getRepeatValueExchangeQuestionAccess().getName13CanTheValueExchangeBeRepeatedOverTimeKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRepeatValueExchangeQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "1.3 Can the value exchange be repeated over time?");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_1, grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerKeyword_1());
            		
            // InternalSmaCQA.g:1578:3: ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) )
            // InternalSmaCQA.g:1579:4: ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) )
            {
            // InternalSmaCQA.g:1579:4: ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) )
            // InternalSmaCQA.g:1580:5: (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' )
            {
            // InternalSmaCQA.g:1580:5: (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' )
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==22) ) {
                alt28=1;
            }
            else if ( (LA28_0==23) ) {
                alt28=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }
            switch (alt28) {
                case 1 :
                    // InternalSmaCQA.g:1581:6: lv_answer_2_1= 'yes'
                    {
                    lv_answer_2_1=(Token)match(input,22,FOLLOW_2); 

                    						newLeafNode(lv_answer_2_1, grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerYesKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getRepeatValueExchangeQuestionRule());
                    						}
                    						setWithLastConsumed(current, "answer", lv_answer_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:1592:6: lv_answer_2_2= 'no'
                    {
                    lv_answer_2_2=(Token)match(input,23,FOLLOW_2); 

                    						newLeafNode(lv_answer_2_2, grammarAccess.getRepeatValueExchangeQuestionAccess().getAnswerNoKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getRepeatValueExchangeQuestionRule());
                    						}
                    						setWithLastConsumed(current, "answer", lv_answer_2_2, null);
                    					

                    }
                    break;

            }


            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRepeatValueExchangeQuestion"


    // $ANTLR start "entryRuleConditionsValueExchangeQuestion"
    // InternalSmaCQA.g:1609:1: entryRuleConditionsValueExchangeQuestion returns [EObject current=null] : iv_ruleConditionsValueExchangeQuestion= ruleConditionsValueExchangeQuestion EOF ;
    public final EObject entryRuleConditionsValueExchangeQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditionsValueExchangeQuestion = null;


        try {
            // InternalSmaCQA.g:1609:72: (iv_ruleConditionsValueExchangeQuestion= ruleConditionsValueExchangeQuestion EOF )
            // InternalSmaCQA.g:1610:2: iv_ruleConditionsValueExchangeQuestion= ruleConditionsValueExchangeQuestion EOF
            {
             newCompositeNode(grammarAccess.getConditionsValueExchangeQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConditionsValueExchangeQuestion=ruleConditionsValueExchangeQuestion();

            state._fsp--;

             current =iv_ruleConditionsValueExchangeQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditionsValueExchangeQuestion"


    // $ANTLR start "ruleConditionsValueExchangeQuestion"
    // InternalSmaCQA.g:1616:1: ruleConditionsValueExchangeQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) ) ;
    public final EObject ruleConditionsValueExchangeQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_answer_2_1=null;
        Token lv_answer_2_2=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:1622:2: ( ( ( (lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) ) )
            // InternalSmaCQA.g:1623:2: ( ( (lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) )
            {
            // InternalSmaCQA.g:1623:2: ( ( (lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) ) )
            // InternalSmaCQA.g:1624:3: ( (lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?' ) ) otherlv_1= 'answer = ' ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) )
            {
            // InternalSmaCQA.g:1624:3: ( (lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?' ) )
            // InternalSmaCQA.g:1625:4: (lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?' )
            {
            // InternalSmaCQA.g:1625:4: (lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?' )
            // InternalSmaCQA.g:1626:5: lv_name_0_0= '1.4 Are the same conditions always maintained when exchanging value?'
            {
            lv_name_0_0=(Token)match(input,59,FOLLOW_23); 

            					newLeafNode(lv_name_0_0, grammarAccess.getConditionsValueExchangeQuestionAccess().getName14AreTheSameConditionsAlwaysMaintainedWhenExchangingValueKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getConditionsValueExchangeQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "1.4 Are the same conditions always maintained when exchanging value?");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_24); 

            			newLeafNode(otherlv_1, grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerKeyword_1());
            		
            // InternalSmaCQA.g:1642:3: ( ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) ) )
            // InternalSmaCQA.g:1643:4: ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) )
            {
            // InternalSmaCQA.g:1643:4: ( (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' ) )
            // InternalSmaCQA.g:1644:5: (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' )
            {
            // InternalSmaCQA.g:1644:5: (lv_answer_2_1= 'yes' | lv_answer_2_2= 'no' )
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==22) ) {
                alt29=1;
            }
            else if ( (LA29_0==23) ) {
                alt29=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }
            switch (alt29) {
                case 1 :
                    // InternalSmaCQA.g:1645:6: lv_answer_2_1= 'yes'
                    {
                    lv_answer_2_1=(Token)match(input,22,FOLLOW_2); 

                    						newLeafNode(lv_answer_2_1, grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerYesKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConditionsValueExchangeQuestionRule());
                    						}
                    						setWithLastConsumed(current, "answer", lv_answer_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:1656:6: lv_answer_2_2= 'no'
                    {
                    lv_answer_2_2=(Token)match(input,23,FOLLOW_2); 

                    						newLeafNode(lv_answer_2_2, grammarAccess.getConditionsValueExchangeQuestionAccess().getAnswerNoKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConditionsValueExchangeQuestionRule());
                    						}
                    						setWithLastConsumed(current, "answer", lv_answer_2_2, null);
                    					

                    }
                    break;

            }


            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditionsValueExchangeQuestion"


    // $ANTLR start "entryRuleLegalQuestion"
    // InternalSmaCQA.g:1673:1: entryRuleLegalQuestion returns [EObject current=null] : iv_ruleLegalQuestion= ruleLegalQuestion EOF ;
    public final EObject entryRuleLegalQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLegalQuestion = null;


        try {
            // InternalSmaCQA.g:1673:54: (iv_ruleLegalQuestion= ruleLegalQuestion EOF )
            // InternalSmaCQA.g:1674:2: iv_ruleLegalQuestion= ruleLegalQuestion EOF
            {
             newCompositeNode(grammarAccess.getLegalQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLegalQuestion=ruleLegalQuestion();

            state._fsp--;

             current =iv_ruleLegalQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLegalQuestion"


    // $ANTLR start "ruleLegalQuestion"
    // InternalSmaCQA.g:1680:1: ruleLegalQuestion returns [EObject current=null] : ( ( (lv_ageQuestion_0_0= ruleAgeQuestion ) )? ( (lv_taxQuestion_1_0= ruleTaxQuestion ) )? ) ;
    public final EObject ruleLegalQuestion() throws RecognitionException {
        EObject current = null;

        EObject lv_ageQuestion_0_0 = null;

        EObject lv_taxQuestion_1_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:1686:2: ( ( ( (lv_ageQuestion_0_0= ruleAgeQuestion ) )? ( (lv_taxQuestion_1_0= ruleTaxQuestion ) )? ) )
            // InternalSmaCQA.g:1687:2: ( ( (lv_ageQuestion_0_0= ruleAgeQuestion ) )? ( (lv_taxQuestion_1_0= ruleTaxQuestion ) )? )
            {
            // InternalSmaCQA.g:1687:2: ( ( (lv_ageQuestion_0_0= ruleAgeQuestion ) )? ( (lv_taxQuestion_1_0= ruleTaxQuestion ) )? )
            // InternalSmaCQA.g:1688:3: ( (lv_ageQuestion_0_0= ruleAgeQuestion ) )? ( (lv_taxQuestion_1_0= ruleTaxQuestion ) )?
            {
            // InternalSmaCQA.g:1688:3: ( (lv_ageQuestion_0_0= ruleAgeQuestion ) )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==60) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSmaCQA.g:1689:4: (lv_ageQuestion_0_0= ruleAgeQuestion )
                    {
                    // InternalSmaCQA.g:1689:4: (lv_ageQuestion_0_0= ruleAgeQuestion )
                    // InternalSmaCQA.g:1690:5: lv_ageQuestion_0_0= ruleAgeQuestion
                    {

                    					newCompositeNode(grammarAccess.getLegalQuestionAccess().getAgeQuestionAgeQuestionParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_57);
                    lv_ageQuestion_0_0=ruleAgeQuestion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getLegalQuestionRule());
                    					}
                    					set(
                    						current,
                    						"ageQuestion",
                    						lv_ageQuestion_0_0,
                    						"org.xtext.SmaCQA.AgeQuestion");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSmaCQA.g:1707:3: ( (lv_taxQuestion_1_0= ruleTaxQuestion ) )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==61) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSmaCQA.g:1708:4: (lv_taxQuestion_1_0= ruleTaxQuestion )
                    {
                    // InternalSmaCQA.g:1708:4: (lv_taxQuestion_1_0= ruleTaxQuestion )
                    // InternalSmaCQA.g:1709:5: lv_taxQuestion_1_0= ruleTaxQuestion
                    {

                    					newCompositeNode(grammarAccess.getLegalQuestionAccess().getTaxQuestionTaxQuestionParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_taxQuestion_1_0=ruleTaxQuestion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getLegalQuestionRule());
                    					}
                    					set(
                    						current,
                    						"taxQuestion",
                    						lv_taxQuestion_1_0,
                    						"org.xtext.SmaCQA.TaxQuestion");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLegalQuestion"


    // $ANTLR start "entryRuleAgeQuestion"
    // InternalSmaCQA.g:1730:1: entryRuleAgeQuestion returns [EObject current=null] : iv_ruleAgeQuestion= ruleAgeQuestion EOF ;
    public final EObject entryRuleAgeQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAgeQuestion = null;


        try {
            // InternalSmaCQA.g:1730:52: (iv_ruleAgeQuestion= ruleAgeQuestion EOF )
            // InternalSmaCQA.g:1731:2: iv_ruleAgeQuestion= ruleAgeQuestion EOF
            {
             newCompositeNode(grammarAccess.getAgeQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAgeQuestion=ruleAgeQuestion();

            state._fsp--;

             current =iv_ruleAgeQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAgeQuestion"


    // $ANTLR start "ruleAgeQuestion"
    // InternalSmaCQA.g:1737:1: ruleAgeQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) ) ;
    public final EObject ruleAgeQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_answer_2_0=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:1743:2: ( ( ( (lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) ) )
            // InternalSmaCQA.g:1744:2: ( ( (lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) )
            {
            // InternalSmaCQA.g:1744:2: ( ( (lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) )
            // InternalSmaCQA.g:1745:3: ( (lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) )
            {
            // InternalSmaCQA.g:1745:3: ( (lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?' ) )
            // InternalSmaCQA.g:1746:4: (lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?' )
            {
            // InternalSmaCQA.g:1746:4: (lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?' )
            // InternalSmaCQA.g:1747:5: lv_name_0_0= '2.1 What would be the minimum legal age if necessary in this exchange?'
            {
            lv_name_0_0=(Token)match(input,60,FOLLOW_23); 

            					newLeafNode(lv_name_0_0, grammarAccess.getAgeQuestionAccess().getName21WhatWouldBeTheMinimumLegalAgeIfNecessaryInThisExchangeKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAgeQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "2.1  What would be the minimum legal age if necessary in this exchange?");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_34); 

            			newLeafNode(otherlv_1, grammarAccess.getAgeQuestionAccess().getAnswerKeyword_1());
            		
            // InternalSmaCQA.g:1763:3: ( (lv_answer_2_0= RULE_INT ) )
            // InternalSmaCQA.g:1764:4: (lv_answer_2_0= RULE_INT )
            {
            // InternalSmaCQA.g:1764:4: (lv_answer_2_0= RULE_INT )
            // InternalSmaCQA.g:1765:5: lv_answer_2_0= RULE_INT
            {
            lv_answer_2_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_answer_2_0, grammarAccess.getAgeQuestionAccess().getAnswerINTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getAgeQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"answer",
            						lv_answer_2_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAgeQuestion"


    // $ANTLR start "entryRuleTaxQuestion"
    // InternalSmaCQA.g:1785:1: entryRuleTaxQuestion returns [EObject current=null] : iv_ruleTaxQuestion= ruleTaxQuestion EOF ;
    public final EObject entryRuleTaxQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTaxQuestion = null;


        try {
            // InternalSmaCQA.g:1785:52: (iv_ruleTaxQuestion= ruleTaxQuestion EOF )
            // InternalSmaCQA.g:1786:2: iv_ruleTaxQuestion= ruleTaxQuestion EOF
            {
             newCompositeNode(grammarAccess.getTaxQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTaxQuestion=ruleTaxQuestion();

            state._fsp--;

             current =iv_ruleTaxQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTaxQuestion"


    // $ANTLR start "ruleTaxQuestion"
    // InternalSmaCQA.g:1792:1: ruleTaxQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '2.2 What is the name of the tax?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_ID ) ) ( (lv_subSentence_3_0= '2.2.1 Who collects the tax?' ) ) otherlv_4= 'answer = ' ( (lv_answerSubSentence_5_0= RULE_ID ) ) ) ;
    public final EObject ruleTaxQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_answer_2_0=null;
        Token lv_subSentence_3_0=null;
        Token otherlv_4=null;
        Token lv_answerSubSentence_5_0=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:1798:2: ( ( ( (lv_name_0_0= '2.2 What is the name of the tax?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_ID ) ) ( (lv_subSentence_3_0= '2.2.1 Who collects the tax?' ) ) otherlv_4= 'answer = ' ( (lv_answerSubSentence_5_0= RULE_ID ) ) ) )
            // InternalSmaCQA.g:1799:2: ( ( (lv_name_0_0= '2.2 What is the name of the tax?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_ID ) ) ( (lv_subSentence_3_0= '2.2.1 Who collects the tax?' ) ) otherlv_4= 'answer = ' ( (lv_answerSubSentence_5_0= RULE_ID ) ) )
            {
            // InternalSmaCQA.g:1799:2: ( ( (lv_name_0_0= '2.2 What is the name of the tax?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_ID ) ) ( (lv_subSentence_3_0= '2.2.1 Who collects the tax?' ) ) otherlv_4= 'answer = ' ( (lv_answerSubSentence_5_0= RULE_ID ) ) )
            // InternalSmaCQA.g:1800:3: ( (lv_name_0_0= '2.2 What is the name of the tax?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_ID ) ) ( (lv_subSentence_3_0= '2.2.1 Who collects the tax?' ) ) otherlv_4= 'answer = ' ( (lv_answerSubSentence_5_0= RULE_ID ) )
            {
            // InternalSmaCQA.g:1800:3: ( (lv_name_0_0= '2.2 What is the name of the tax?' ) )
            // InternalSmaCQA.g:1801:4: (lv_name_0_0= '2.2 What is the name of the tax?' )
            {
            // InternalSmaCQA.g:1801:4: (lv_name_0_0= '2.2 What is the name of the tax?' )
            // InternalSmaCQA.g:1802:5: lv_name_0_0= '2.2 What is the name of the tax?'
            {
            lv_name_0_0=(Token)match(input,61,FOLLOW_23); 

            					newLeafNode(lv_name_0_0, grammarAccess.getTaxQuestionAccess().getName22WhatIsTheNameOfTheTaxKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTaxQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "2.2 What is the name of the tax?");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getTaxQuestionAccess().getAnswerKeyword_1());
            		
            // InternalSmaCQA.g:1818:3: ( (lv_answer_2_0= RULE_ID ) )
            // InternalSmaCQA.g:1819:4: (lv_answer_2_0= RULE_ID )
            {
            // InternalSmaCQA.g:1819:4: (lv_answer_2_0= RULE_ID )
            // InternalSmaCQA.g:1820:5: lv_answer_2_0= RULE_ID
            {
            lv_answer_2_0=(Token)match(input,RULE_ID,FOLLOW_58); 

            					newLeafNode(lv_answer_2_0, grammarAccess.getTaxQuestionAccess().getAnswerIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTaxQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"answer",
            						lv_answer_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSmaCQA.g:1836:3: ( (lv_subSentence_3_0= '2.2.1 Who collects the tax?' ) )
            // InternalSmaCQA.g:1837:4: (lv_subSentence_3_0= '2.2.1 Who collects the tax?' )
            {
            // InternalSmaCQA.g:1837:4: (lv_subSentence_3_0= '2.2.1 Who collects the tax?' )
            // InternalSmaCQA.g:1838:5: lv_subSentence_3_0= '2.2.1 Who collects the tax?'
            {
            lv_subSentence_3_0=(Token)match(input,62,FOLLOW_23); 

            					newLeafNode(lv_subSentence_3_0, grammarAccess.getTaxQuestionAccess().getSubSentence221WhoCollectsTheTaxKeyword_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTaxQuestionRule());
            					}
            					setWithLastConsumed(current, "subSentence", lv_subSentence_3_0, "2.2.1 Who collects the tax?");
            				

            }


            }

            otherlv_4=(Token)match(input,21,FOLLOW_4); 

            			newLeafNode(otherlv_4, grammarAccess.getTaxQuestionAccess().getAnswerKeyword_4());
            		
            // InternalSmaCQA.g:1854:3: ( (lv_answerSubSentence_5_0= RULE_ID ) )
            // InternalSmaCQA.g:1855:4: (lv_answerSubSentence_5_0= RULE_ID )
            {
            // InternalSmaCQA.g:1855:4: (lv_answerSubSentence_5_0= RULE_ID )
            // InternalSmaCQA.g:1856:5: lv_answerSubSentence_5_0= RULE_ID
            {
            lv_answerSubSentence_5_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_answerSubSentence_5_0, grammarAccess.getTaxQuestionAccess().getAnswerSubSentenceIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTaxQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"answerSubSentence",
            						lv_answerSubSentence_5_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTaxQuestion"


    // $ANTLR start "entryRuleEconomyQuestion"
    // InternalSmaCQA.g:1876:1: entryRuleEconomyQuestion returns [EObject current=null] : iv_ruleEconomyQuestion= ruleEconomyQuestion EOF ;
    public final EObject entryRuleEconomyQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEconomyQuestion = null;


        try {
            // InternalSmaCQA.g:1876:56: (iv_ruleEconomyQuestion= ruleEconomyQuestion EOF )
            // InternalSmaCQA.g:1877:2: iv_ruleEconomyQuestion= ruleEconomyQuestion EOF
            {
             newCompositeNode(grammarAccess.getEconomyQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEconomyQuestion=ruleEconomyQuestion();

            state._fsp--;

             current =iv_ruleEconomyQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEconomyQuestion"


    // $ANTLR start "ruleEconomyQuestion"
    // InternalSmaCQA.g:1883:1: ruleEconomyQuestion returns [EObject current=null] : ( (lv_minimumAmountQuestion_0_0= ruleMinimumAmountQuestion ) )? ;
    public final EObject ruleEconomyQuestion() throws RecognitionException {
        EObject current = null;

        EObject lv_minimumAmountQuestion_0_0 = null;



        	enterRule();

        try {
            // InternalSmaCQA.g:1889:2: ( ( (lv_minimumAmountQuestion_0_0= ruleMinimumAmountQuestion ) )? )
            // InternalSmaCQA.g:1890:2: ( (lv_minimumAmountQuestion_0_0= ruleMinimumAmountQuestion ) )?
            {
            // InternalSmaCQA.g:1890:2: ( (lv_minimumAmountQuestion_0_0= ruleMinimumAmountQuestion ) )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==63) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSmaCQA.g:1891:3: (lv_minimumAmountQuestion_0_0= ruleMinimumAmountQuestion )
                    {
                    // InternalSmaCQA.g:1891:3: (lv_minimumAmountQuestion_0_0= ruleMinimumAmountQuestion )
                    // InternalSmaCQA.g:1892:4: lv_minimumAmountQuestion_0_0= ruleMinimumAmountQuestion
                    {

                    				newCompositeNode(grammarAccess.getEconomyQuestionAccess().getMinimumAmountQuestionMinimumAmountQuestionParserRuleCall_0());
                    			
                    pushFollow(FOLLOW_2);
                    lv_minimumAmountQuestion_0_0=ruleMinimumAmountQuestion();

                    state._fsp--;


                    				if (current==null) {
                    					current = createModelElementForParent(grammarAccess.getEconomyQuestionRule());
                    				}
                    				set(
                    					current,
                    					"minimumAmountQuestion",
                    					lv_minimumAmountQuestion_0_0,
                    					"org.xtext.SmaCQA.MinimumAmountQuestion");
                    				afterParserOrEnumRuleCall();
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEconomyQuestion"


    // $ANTLR start "entryRuleMinimumAmountQuestion"
    // InternalSmaCQA.g:1912:1: entryRuleMinimumAmountQuestion returns [EObject current=null] : iv_ruleMinimumAmountQuestion= ruleMinimumAmountQuestion EOF ;
    public final EObject entryRuleMinimumAmountQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMinimumAmountQuestion = null;


        try {
            // InternalSmaCQA.g:1912:62: (iv_ruleMinimumAmountQuestion= ruleMinimumAmountQuestion EOF )
            // InternalSmaCQA.g:1913:2: iv_ruleMinimumAmountQuestion= ruleMinimumAmountQuestion EOF
            {
             newCompositeNode(grammarAccess.getMinimumAmountQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMinimumAmountQuestion=ruleMinimumAmountQuestion();

            state._fsp--;

             current =iv_ruleMinimumAmountQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMinimumAmountQuestion"


    // $ANTLR start "ruleMinimumAmountQuestion"
    // InternalSmaCQA.g:1919:1: ruleMinimumAmountQuestion returns [EObject current=null] : ( ( (lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) ) ;
    public final EObject ruleMinimumAmountQuestion() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        Token lv_answer_2_0=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:1925:2: ( ( ( (lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) ) )
            // InternalSmaCQA.g:1926:2: ( ( (lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) )
            {
            // InternalSmaCQA.g:1926:2: ( ( (lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) ) )
            // InternalSmaCQA.g:1927:3: ( (lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?' ) ) otherlv_1= 'answer = ' ( (lv_answer_2_0= RULE_INT ) )
            {
            // InternalSmaCQA.g:1927:3: ( (lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?' ) )
            // InternalSmaCQA.g:1928:4: (lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?' )
            {
            // InternalSmaCQA.g:1928:4: (lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?' )
            // InternalSmaCQA.g:1929:5: lv_name_0_0= '3.1 Which would be the minimum amount if necessary in this exchange?'
            {
            lv_name_0_0=(Token)match(input,63,FOLLOW_23); 

            					newLeafNode(lv_name_0_0, grammarAccess.getMinimumAmountQuestionAccess().getName31WhichWouldBeTheMinimumAmountIfNecessaryInThisExchangeKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMinimumAmountQuestionRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_0_0, "3.1 Which would be the minimum amount if necessary in this exchange?");
            				

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_34); 

            			newLeafNode(otherlv_1, grammarAccess.getMinimumAmountQuestionAccess().getAnswerKeyword_1());
            		
            // InternalSmaCQA.g:1945:3: ( (lv_answer_2_0= RULE_INT ) )
            // InternalSmaCQA.g:1946:4: (lv_answer_2_0= RULE_INT )
            {
            // InternalSmaCQA.g:1946:4: (lv_answer_2_0= RULE_INT )
            // InternalSmaCQA.g:1947:5: lv_answer_2_0= RULE_INT
            {
            lv_answer_2_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_answer_2_0, grammarAccess.getMinimumAmountQuestionAccess().getAnswerINTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMinimumAmountQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"answer",
            						lv_answer_2_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMinimumAmountQuestion"


    // $ANTLR start "ruleType"
    // InternalSmaCQA.g:1967:1: ruleType returns [Enumerator current=null] : ( (enumLiteral_0= 'Number' ) | (enumLiteral_1= 'Text' ) | (enumLiteral_2= 'TrueOrFalse' ) ) ;
    public final Enumerator ruleType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:1973:2: ( ( (enumLiteral_0= 'Number' ) | (enumLiteral_1= 'Text' ) | (enumLiteral_2= 'TrueOrFalse' ) ) )
            // InternalSmaCQA.g:1974:2: ( (enumLiteral_0= 'Number' ) | (enumLiteral_1= 'Text' ) | (enumLiteral_2= 'TrueOrFalse' ) )
            {
            // InternalSmaCQA.g:1974:2: ( (enumLiteral_0= 'Number' ) | (enumLiteral_1= 'Text' ) | (enumLiteral_2= 'TrueOrFalse' ) )
            int alt33=3;
            switch ( input.LA(1) ) {
            case 64:
                {
                alt33=1;
                }
                break;
            case 65:
                {
                alt33=2;
                }
                break;
            case 66:
                {
                alt33=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }

            switch (alt33) {
                case 1 :
                    // InternalSmaCQA.g:1975:3: (enumLiteral_0= 'Number' )
                    {
                    // InternalSmaCQA.g:1975:3: (enumLiteral_0= 'Number' )
                    // InternalSmaCQA.g:1976:4: enumLiteral_0= 'Number'
                    {
                    enumLiteral_0=(Token)match(input,64,FOLLOW_2); 

                    				current = grammarAccess.getTypeAccess().getNumberEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTypeAccess().getNumberEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:1983:3: (enumLiteral_1= 'Text' )
                    {
                    // InternalSmaCQA.g:1983:3: (enumLiteral_1= 'Text' )
                    // InternalSmaCQA.g:1984:4: enumLiteral_1= 'Text'
                    {
                    enumLiteral_1=(Token)match(input,65,FOLLOW_2); 

                    				current = grammarAccess.getTypeAccess().getTextEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTypeAccess().getTextEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:1991:3: (enumLiteral_2= 'TrueOrFalse' )
                    {
                    // InternalSmaCQA.g:1991:3: (enumLiteral_2= 'TrueOrFalse' )
                    // InternalSmaCQA.g:1992:4: enumLiteral_2= 'TrueOrFalse'
                    {
                    enumLiteral_2=(Token)match(input,66,FOLLOW_2); 

                    				current = grammarAccess.getTypeAccess().getTrueOrFalseEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getTypeAccess().getTrueOrFalseEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleType"


    // $ANTLR start "ruleUnitTime"
    // InternalSmaCQA.g:2002:1: ruleUnitTime returns [Enumerator current=null] : ( (enumLiteral_0= 'minutes' ) | (enumLiteral_1= 'days' ) | (enumLiteral_2= 'weeks' ) | (enumLiteral_3= 'years' ) ) ;
    public final Enumerator ruleUnitTime() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:2008:2: ( ( (enumLiteral_0= 'minutes' ) | (enumLiteral_1= 'days' ) | (enumLiteral_2= 'weeks' ) | (enumLiteral_3= 'years' ) ) )
            // InternalSmaCQA.g:2009:2: ( (enumLiteral_0= 'minutes' ) | (enumLiteral_1= 'days' ) | (enumLiteral_2= 'weeks' ) | (enumLiteral_3= 'years' ) )
            {
            // InternalSmaCQA.g:2009:2: ( (enumLiteral_0= 'minutes' ) | (enumLiteral_1= 'days' ) | (enumLiteral_2= 'weeks' ) | (enumLiteral_3= 'years' ) )
            int alt34=4;
            switch ( input.LA(1) ) {
            case 67:
                {
                alt34=1;
                }
                break;
            case 68:
                {
                alt34=2;
                }
                break;
            case 69:
                {
                alt34=3;
                }
                break;
            case 70:
                {
                alt34=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 34, 0, input);

                throw nvae;
            }

            switch (alt34) {
                case 1 :
                    // InternalSmaCQA.g:2010:3: (enumLiteral_0= 'minutes' )
                    {
                    // InternalSmaCQA.g:2010:3: (enumLiteral_0= 'minutes' )
                    // InternalSmaCQA.g:2011:4: enumLiteral_0= 'minutes'
                    {
                    enumLiteral_0=(Token)match(input,67,FOLLOW_2); 

                    				current = grammarAccess.getUnitTimeAccess().getMinutesEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getUnitTimeAccess().getMinutesEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:2018:3: (enumLiteral_1= 'days' )
                    {
                    // InternalSmaCQA.g:2018:3: (enumLiteral_1= 'days' )
                    // InternalSmaCQA.g:2019:4: enumLiteral_1= 'days'
                    {
                    enumLiteral_1=(Token)match(input,68,FOLLOW_2); 

                    				current = grammarAccess.getUnitTimeAccess().getDaysEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getUnitTimeAccess().getDaysEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:2026:3: (enumLiteral_2= 'weeks' )
                    {
                    // InternalSmaCQA.g:2026:3: (enumLiteral_2= 'weeks' )
                    // InternalSmaCQA.g:2027:4: enumLiteral_2= 'weeks'
                    {
                    enumLiteral_2=(Token)match(input,69,FOLLOW_2); 

                    				current = grammarAccess.getUnitTimeAccess().getWeeksEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getUnitTimeAccess().getWeeksEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSmaCQA.g:2034:3: (enumLiteral_3= 'years' )
                    {
                    // InternalSmaCQA.g:2034:3: (enumLiteral_3= 'years' )
                    // InternalSmaCQA.g:2035:4: enumLiteral_3= 'years'
                    {
                    enumLiteral_3=(Token)match(input,70,FOLLOW_2); 

                    				current = grammarAccess.getUnitTimeAccess().getYearsEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getUnitTimeAccess().getYearsEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUnitTime"


    // $ANTLR start "ruleUnitCoin"
    // InternalSmaCQA.g:2045:1: ruleUnitCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'pwei' ) | (enumLiteral_3= 'gwei' ) | (enumLiteral_4= 'szabo' ) ) ;
    public final Enumerator ruleUnitCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSmaCQA.g:2051:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'pwei' ) | (enumLiteral_3= 'gwei' ) | (enumLiteral_4= 'szabo' ) ) )
            // InternalSmaCQA.g:2052:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'pwei' ) | (enumLiteral_3= 'gwei' ) | (enumLiteral_4= 'szabo' ) )
            {
            // InternalSmaCQA.g:2052:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'pwei' ) | (enumLiteral_3= 'gwei' ) | (enumLiteral_4= 'szabo' ) )
            int alt35=5;
            switch ( input.LA(1) ) {
            case 71:
                {
                alt35=1;
                }
                break;
            case 72:
                {
                alt35=2;
                }
                break;
            case 73:
                {
                alt35=3;
                }
                break;
            case 74:
                {
                alt35=4;
                }
                break;
            case 75:
                {
                alt35=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }

            switch (alt35) {
                case 1 :
                    // InternalSmaCQA.g:2053:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSmaCQA.g:2053:3: (enumLiteral_0= 'ether' )
                    // InternalSmaCQA.g:2054:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,71,FOLLOW_2); 

                    				current = grammarAccess.getUnitCoinAccess().getEtherEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getUnitCoinAccess().getEtherEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSmaCQA.g:2061:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSmaCQA.g:2061:3: (enumLiteral_1= 'wei' )
                    // InternalSmaCQA.g:2062:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,72,FOLLOW_2); 

                    				current = grammarAccess.getUnitCoinAccess().getWeiEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getUnitCoinAccess().getWeiEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSmaCQA.g:2069:3: (enumLiteral_2= 'pwei' )
                    {
                    // InternalSmaCQA.g:2069:3: (enumLiteral_2= 'pwei' )
                    // InternalSmaCQA.g:2070:4: enumLiteral_2= 'pwei'
                    {
                    enumLiteral_2=(Token)match(input,73,FOLLOW_2); 

                    				current = grammarAccess.getUnitCoinAccess().getPweiEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getUnitCoinAccess().getPweiEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSmaCQA.g:2077:3: (enumLiteral_3= 'gwei' )
                    {
                    // InternalSmaCQA.g:2077:3: (enumLiteral_3= 'gwei' )
                    // InternalSmaCQA.g:2078:4: enumLiteral_3= 'gwei'
                    {
                    enumLiteral_3=(Token)match(input,74,FOLLOW_2); 

                    				current = grammarAccess.getUnitCoinAccess().getGweiEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getUnitCoinAccess().getGweiEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSmaCQA.g:2085:3: (enumLiteral_4= 'szabo' )
                    {
                    // InternalSmaCQA.g:2085:3: (enumLiteral_4= 'szabo' )
                    // InternalSmaCQA.g:2086:4: enumLiteral_4= 'szabo'
                    {
                    enumLiteral_4=(Token)match(input,75,FOLLOW_2); 

                    				current = grammarAccess.getUnitCoinAccess().getSzaboEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getUnitCoinAccess().getSzaboEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUnitCoin"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000000000F0020L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x00000000000F0000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0E800000031E0020L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0E800000031E0000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x00000000000E0000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x30000000000C0020L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x30000000000C0000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x8000000000080020L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x8000000000080000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0E00000003100002L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0C00000003100002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0800000003100002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000003100002L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000C00000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000104040000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000018000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000007L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000F80L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0058000000000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0050000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000078L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x2000000000000002L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x4000000000000000L});

}