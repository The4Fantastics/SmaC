package org.xtext.ui;

import java.sql.Time;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.documentation.IEObjectDocumentationProvider;
import org.eclipse.xtext.ui.editor.hover.html.DefaultEObjectHoverProvider;
import org.xtext.SmaCQA.*;
import org.xtext.smaCQA.TimeValueExchangeDurationQuestion;
import org.xtext.smaCQA.ValueExchange;
import org.xtext.smaCQA.impl.AgeQuestionImpl;
import org.xtext.smaCQA.impl.MinimumAmountQuestionImpl;
import org.xtext.smaCQA.impl.RepeatValueExchangeQuestionImpl;
import org.xtext.smaCQA.impl.TaxQuestionImpl;
import org.xtext.smaCQA.impl.TimeStartValueExchangeQuestionImpl;
import org.xtext.smaCQA.impl.TimeValueExchangeDurationQuestionImpl;
import org.xtext.smaCQA.impl.TokenERC20Impl;
import org.xtext.smaCQA.impl.TokenERC223Impl;
import org.xtext.smaCQA.impl.TokenERC721Impl;
import org.xtext.smaCQA.impl.ValueExchangeImpl;
import org.xtext.smaCQA.impl.ValueObjectTangibleQuestionImpl;
import org.xtext.smaCQA.impl.ValueObjectTokenQuestionImpl;

public class SmaCQADocumentationProvider implements IEObjectDocumentationProvider  {

	 @Override
	    public String getDocumentation(EObject o) {
	        if (o instanceof ValueExchangeImpl) {
	            return "This element represents a value exchange between actors. Value exchanges require some questions and answers to complete the information.<br> \r\n"
	            		+ " The questions to complete the information about the exchange of value will be presented to you in the following order:<br> \r\n" +
            			"<b>1 Data Questions.</b><br> \r\n" +
            			"<b>2 Legal Questions.</b><br> \r\n" +
            			"<b>3 Economy Questions�.</b><br> \r\n" +
            			"You are free to select one (or several) categories to complete the information. If you do not answer any questions from a certain category for the value exchange, the tool will not show you that category for the current value exchange as a suggestion";
	        }	        	             
	        if (o instanceof RepeatValueExchangeQuestionImpl) {
	        	 return "This question is asked to find out if the exchange of value can be repeated over time.\r\n" + 
	        	 		" The <b>answer must be <i>yes</i> or <i>no</i></b>";
	        }
	        if (o instanceof TimeValueExchangeDurationQuestionImpl) {
	        	 return "This question is formulated to find out if the exchange of value has a certain validity of time to be carried out.\r\n" + 
	        	 		" The <b>answer must be a <b><i>number</i></b> to represent the number of minutes, days, weeks or years</b>";
	        }	
	        if (o instanceof TimeStartValueExchangeQuestionImpl) {
	        	 return "This question is formulated to find out if the exchange of value can only be carried out after a certain time. To determine the time, it can be specified numerically along with the unit of time (minutes, days, weeks or years).\r\n"
	        	 		+ "<b>Important</b>: This time measurement is specified from the date the contract is displayed.";
	        }
	        if (o instanceof ValueObjectTangibleQuestionImpl) {
	        	 return "This question is formulated to find out if the value object (tangible) negotiated can be represented as a digital object/element <b>(NOT TOKEN)</b> that has a series of properties that describe it.\r\n" + 
	        	 		"You can specify the properties of a physical object to represent it digitally.\r\n" +
	        	 		"These <b>properties require a <i>name</i> and a <i>value</i> </b>. Example a physical object that measures X meters, you can define the meters property whose value can be a number.";
	        }
	        if (o instanceof ValueObjectTokenQuestionImpl) {
	        	 return "This question asks whether the traded value object can be represented as a security, utility, intellectual or unique property token. Tokens can be fungible (following ERC20 and ERC223 standard) or non-fungible, <i>alias <b>NFT</b></i> (following ERC721 standard). \r\n "
	        	 		+ "A <b><i>token fungible</i></b> is a <b>digital asset</b> or <b>financial value</b> that allows users who own this <b><i>decision making, remuneration, exchanges for others, etc.</i></b>\r\n" 
	        	 		+ "A <b><i>non fungible token</i></b> is a <b>digital asset</b> represents a intellectual or unique property.\r\n";
	        }
	        if (o instanceof TokenERC20Impl) {
	        	 return "This question asks whether the traded value object can be represented as a security or utility fungible token. A <b><i>token</i></b> is a <b>digital asset</b> or <b>financial value</b> that allows users who own this <b><i>decision making, remuneration, exchanges for others, etc.</i></b>\r\n" + 
	        	 		"To complete the Token information, the following fields must be filled in in order as indicated by the tool:<br> \r\n" + 
	        			"<b>Name</b>: Represents the Token's name.<br>\r\n" +
	        	 		"<b>Symbol</b>: Represents the Token's symbol. It is similar to an identifier versus other tokens. It usually consists of 3 or 5 characters (in uppercase).<br>\r\n" +
	        	 		"<b>Decimals</b>: Returns the number of decimals used to get its user representation. For example, if `decimals` equals `2`, a balance of `505` tokens should be displayed to a user as `5.05` (`505 / 10 ** 2`) Tokens usually opt for a value of 18, imitating the relationship between Ether and Wei.<br>\r\n" + 
	        			"<b>Supply</b>: Number of tokens that will be issued and that will circulate as value negotiated by the network.<br>" +
	        	 		"Subsequently, two questions will be asked:<br>\r\n" + 
	        	 		"The first question is to know if there is the possibility of <b>minting more tokens</b> after having defined the total number of tokens in circulation.<br>\r\n" +
	        	 		"The second question is to know if there is the possibility of <b>burn tokens</b>  to remove them from circulation.\r\n";
	        }
	        if (o instanceof TokenERC223Impl) {
	        	 return "This question asks whether the traded value object can be represented as a security or utility fungible token. A <b><i>token</i></b> is a <b>digital asset</b> or <b>financial value</b> that allows users who own this <b><i>decision making, remuneration, exchanges for others, etc.</i></b>\r\n" + 
	        	 		"To complete the Token information, the following fields must be filled in in order as indicated by the tool:<br> \r\n" + 
	        			"<b>Name</b>: Represents the Token's name.<br>\r\n" +
	        	 		"<b>Symbol</b>: Represents the Token's symbol. It is similar to an identifier versus other tokens. It usually consists of 3 or 5 characters (in uppercase).<br>\r\n" +
	        	 		"<b>Decimals</b>: Returns the number of decimals used to get its user representation. For example, if `decimals` equals `2`, a balance of `505` tokens should be displayed to a user as `5.05` (`505 / 10 ** 2`) Tokens usually opt for a value of 18, imitating the relationship between Ether and Wei.<br>\r\n" + 
	        			"<b>Supply</b>: Number of tokens that will be issued and that will circulate as value negotiated by the network.<br>" +
	        	 		"Subsequently, two questions will be asked:<br>\r\n" + 
	        	 		"The first question is to know if there is the possibility of <b>minting more tokens</b> after having defined the total number of tokens in circulation.<br>\r\n" +
	        	 		"The second question is to know if there is the possibility of <b>burn tokens</b>  to remove them from circulation.\r\n";
	        }
	        if (o instanceof TokenERC721Impl) {
	        	 return "This question asks whether the traded value object can be represented as an unique property represented by a non fungible token (NFT). A <b><i>non fungible token</i></b> is a <b>digital asset</b> represents a intellectual or unique property.\r\n" + 
	        	 		"To complete the NFT information, the following fields must be filled in in order as indicated by the tool:<br> \r\n" + 
	        			"<b>Name</b>: Represents the Token's name.<br>\r\n" +
	        	 		"<b>Symbol</b>: Represents the Token's symbol. It is similar to an identifier versus other tokens. It usually consists of 3 or 5 characters (in uppercase).<br>\r\n" +
	        			"<b>Supply</b>: Number of tokens that will be issued and that will circulate as value negotiated by the network.<br>" +
	        	 		"Subsequently, two questions will be asked:<br>\r\n" + 
	        	 		"The first question is to know if there is the possibility of minting a certain amount of nft (define a specific number of items in a collection) for a certain address.<br>\r\n" +
	        	 		"The second question is to know if there is the possibility of <b>burn tokens</b>  to remove them from circulation.\r\n" +
	        	 		"The third question is to <b>associate a url<b> pointing to a JSON metadata file with publicly exposed ERC-721 information.\r\n" +
	        	 		"The fourth question refers to the price to acquire the NFT.\r\n";
	        }
	        if (o instanceof AgeQuestionImpl) {
	            return "This question mentions the need to demand a minimum legal age for the actors to carry out the exchange of value between them.\r\n" + 
	            		" The answer to be entered by the user <b> must be a number between 16 and 110 years </b> to reflect the <b><i>legal minimum age</i></b>.";
	        }
	        if (o instanceof TaxQuestionImpl) {
	            return "This question mentions the need to specify fee or supplement name in relation to the exchange of value that will take place between the actors.\r\n" +
	            	   " Next, you will be asked to specify <b> which actor is the beneficiary of this fee </b>.";
	        }
	        if (o instanceof MinimumAmountQuestionImpl) {
	        	return "This question is formulated to find out if a minimum amount is necessary from one of the actors to carry out the exchange of value.\r\n"+
	        	" The answer must be a <b><i>number</i></b> to represent the <b><i>minimum amount needed</i></b>.";
	        }
	        return null;
	        
    }
		
}
