package org.xtext.ui;

import java.sql.Time;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.documentation.IEObjectDocumentationProvider;
import org.eclipse.xtext.ui.editor.hover.html.DefaultEObjectHoverProvider;
import org.xtext.smaC.*;
import org.xtext.smaC.impl.ClauseImpl;
import org.xtext.smaC.impl.ConstructorImpl;
import org.xtext.smaC.impl.ContractImpl;
import org.xtext.smaC.impl.DoWhileLoopImpl;
import org.xtext.smaC.impl.EventImpl;
import org.xtext.smaC.impl.FileImpl;
import org.xtext.smaC.impl.ForLoopImpl;
import org.xtext.smaC.impl.ModifierImpl;
import org.xtext.smaC.impl.VersionImpl;
import org.xtext.smaC.impl.WhileLoopImpl;

public class SmaCDocumentationProvider implements IEObjectDocumentationProvider  {

	 @Override
	    public String getDocumentation(EObject o) {
		 if (o instanceof FileImpl) {
	            return "This element represents the file where the smart contract(s) are specified. The order of specifying the elements must be as follows:\r\n <br>" + 
	            		"<b>Compiler version: <b>" + "<br>"+
	            		"<b>Imports:</b> Libraries that the smart contract will use to incorporate its functionality.\r\n" + "<br>"+
	            		"<b>Library: </b> Own libraries defined in the smart contract.";
		 }  
		 if (o instanceof VersionImpl) {
	            return "This statement specifies the <b>version of the compiler<b> in which the contract is to be compiled. It is necessary to check if some of the logic defined in the smart contract is not supported for the specified compiler version.";
         }   
		 if (o instanceof ContractImpl) {
	            return "This element represents a smart contract class. \r\n" +
	            	 "The smart contract can contains (You need to specify them in order): <br>"+
	            	 "<b>Properties</b>: " + "Specification of the data that the smart contract will use." + "<br>"+
	            	 "<b>Constructors</b>: " + "This element represents the smart contract constructor. The constructor initializes the contract parameters contained in it when it is deployed on a blockchain network." + "<br>"+
	            	 "It is necessary to use the reserved word <b><i>constructor</i></b> followed by the access modifier of the constructor and the type and name of the parameter(s)" + "<br>"+
	            	 "<b>Modifiers</b>: " + "The modifiers are specified before the events and their functionality is to check the conditions defined in them before the logic of the function that calls them is executed." + "<br>"+
	            	 "It is necessary to use the reserved word <b><i>modifier</i></b> followed by the name of the modifier and the type and name of the parameter(s)" + "<br>"+
	            	 "<b>Events</b>: " + "This elements represents the smart contract's events. Events are executed inside functions to emit a log of the action that has been carried out"+ "<br>"+
	            	 "It is necessary to use the reserved word <b><i>event</i></b> followed by the name of the event and the type and name of the parameter(s) to be emitted.<br> To emit the event inside a function, it is necessary to call it from the <b><i>emit<i><b> reserved word followed by the name of the defined event and the parameters that we have defined in its declaration." + "<br>"+
	            	 "<b>Clauses</b>: " + "This elements represents the smart contract's functions. Functions contains the smart contract logic execution"+ "<br>"+
	            	 "It is necessary to use the reserved word <b><i>function</i></b> followed by the name of the function and the type and name of the parameter(s)" + "<br>"
	            	 ;
         }
		 if (o instanceof ConstructorImpl) {
	            return "This element should be specified before the modifiers and their functionality is to check the <b>initialized the smart contract's attributes/properties</b>." + "<br>"
	            	 ;
		 }
		 if (o instanceof ModifierImpl) {
	            return "This element should be specified before the events and their functionality is to <b>check the conditions defined in them before the logic of the function that calls them is executed</b>." + "<br>"+
	            		"The modifier can contains (You need to specify them in order): <br>"+
	            	 "<b>Require expression</b>: " + "This expression requires that the condition be met in order to proceed with the execution of the function. If not met, it will abort the execution process of the function that calls this modifier."+ "<br>"+
	            	 "<b> _; </b>: " + "It is required to insert it at the end of the logic defined in the modifier"
	            	 ;
		 }
		 if (o instanceof EventImpl) {
	            return "This element should be specified before the functions and their functionality is to <b>emit a notification when the function's logic is executed</b>." + "<br>"
	            	 ;
		 }
		 
		 if (o instanceof ClauseImpl) {
	            return "The functions contain the <b>logic of the actions</b> that the smart contract will execute according to their interaction with the user. These elements must be declared after the events." + "<br>"
            	;
		 }
		 
		 if (o instanceof DoWhileLoopImpl) {
	            return "It is <b>necessary to specify a gas restriction (Using <i>require expression</i>)</b> to execute the contained logic of the gas in order to avoid infinite loops."
	            	;
		 }
		 if (o instanceof WhileLoopImpl) {
	            return "It is <b>necessary to specify a gas restriction (Using <i>require expression</i>)</b> to execute the contained logic of the gas in order to avoid infinite loops."
	            	 ;
		 }
		 if (o instanceof ForLoopImpl) {
	            return "It is <b>necessary to specify a gas restriction (Using <i>require expression</i>)</b> to execute the contained logic of the gas in order to avoid infinite loops."
	            	 ;
		 }
        return null;
    }
		
}
