package org.xtext.ui;

import java.util.regex.Pattern;

import org.eclipse.xtext.ide.editor.syntaxcoloring.DefaultAntlrTokenToAttributeIdMapper;

public class ColorSyntaxConfigurationAntlrTokenToAttributeIdMapper extends DefaultAntlrTokenToAttributeIdMapper  {

	
	private static final Pattern THIS = Pattern.compile("this", Pattern.MULTILINE);
	
	@Override
	protected String calculateId(String tokenName, int tokenType) {
		if(tokenName.equals("RULE_MSGSENDER") || tokenName.equals("RULE_MSGVALUE") || tokenName.equals("RULE_MSGBALANCE") || tokenName.equals("RULE_MSGGAS") || 
			tokenName.equals("RULE_MSGDATA") || tokenName.equals("RULE_MSGSIG")) {
			return CLHighlightingConfiguration.MSGVARIABLES;
		}
		else if(tokenName.equals("RULE_BCKDIFFICULTY") || tokenName.equals("RULE_BCKNUMBER") || tokenName.equals("RULE_BCKTIMESTAMP") || tokenName.equals("RULE_BCKCOINBASE") || 
				tokenName.equals("RULE_ BCKGASLIMIT") || tokenName.equals("RULE_BCKBLOCKHASH")) {
				return CLHighlightingConfiguration.BCKVARIABLES;
		}
		else if(tokenName.equals("RULE_KECCAK256") || tokenName.equals("RULE_SHA3") || tokenName.equals("RULE_SHA256")  || tokenName.equals("RULE_ABIENCODE")  || tokenName.equals("RULE_ABIDECODE") || tokenName.equals("RULE_ABIENCODEPACKAGE")) {
				return CLHighlightingConfiguration.CRYPTOGRAPHY_FUNCTIONS;
		}
		else if(tokenName.equals("RULE_KECCAK256") || tokenName.equals("RULE_SHA3") || tokenName.equals("RULE_SHA256")) {
			return CLHighlightingConfiguration.BCKVARIABLES;
	}
		else if(tokenName.equals("RULE_TXORIGIN") || tokenName.equals("RULE_TXGASPRICE")) {
				return CLHighlightingConfiguration.TXVARIABLES;
		}
		else if(THIS.matcher(tokenName).matches()) {
			return CLHighlightingConfiguration.THIS;
		}
		else if(tokenName.equals("RULE_EMIT") || tokenName.equals("RULE_NEW") || tokenName.equals("RULE_IF") ||
				tokenName.equals("RULE_ELSE") || tokenName.equals("RULE_RETURN") || tokenName.equals("RULE_RETURN")) {
			return CLHighlightingConfiguration.EMIT;
		}
		else if(tokenName.equals("RULE_COIN")) {
			return CLHighlightingConfiguration.COINS;
		}
		else if(tokenName.equals("RULE_UINT")) {
			return CLHighlightingConfiguration.UINT;
		}
		else if(tokenName.equals("RULE_INT")) {
			return CLHighlightingConfiguration.INT;
		}
		else if(tokenName.equals("RULE_FLOAT")) {
			return CLHighlightingConfiguration.FLOAT;
		}
		else if(tokenName.equals("RULE_STRING")) {
			return CLHighlightingConfiguration.STRINGTEXT;
		}
		else if(tokenName.equals("RULE_BOOLVALUE")) {
			return CLHighlightingConfiguration.BOOLEANVALUE;
		}
		return  super.calculateId(tokenName, tokenType);
	}

}
