package org.xtext.ui;

import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EObject;
import java.lang.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.xtext.nodemodel.INode;
import org.eclipse.xtext.resource.XtextResourceSet;
import org.eclipse.xtext.ui.editor.syntaxcoloring.DefaultHighlightingConfiguration;
import org.eclipse.xtext.ui.editor.syntaxcoloring.IHighlightedPositionAcceptor;
import org.eclipse.xtext.ui.editor.syntaxcoloring.IHighlightingConfigurationAcceptor;
import org.eclipse.xtext.ui.editor.utils.TextStyle;
import org.w3c.dom.css.CSSPrimitiveValue;
import org.w3c.dom.css.RGBColor;

@SuppressWarnings({ "deprecation", "unused" })
public class CLHighlightingConfiguration extends DefaultHighlightingConfiguration{
	
	public static final String MSGVARIABLES = "msgvariables";
	public static final String BCKVARIABLES = "blockvariables";
	public static final String TXVARIABLES = "txvariables";
	public static final String THIS = "this";
	public static final String NEW = "WordNewContractElement";
	public static final String EMIT = "WordEmitContractElement";
	public static final String NOW = "WordNowContractElement";
	public static final String IF = "WordIfContractElement";
	public static final String ELSE = "WordElseContractElement";
	public static final String RETURN = "WordReturnContractElement";
	public static final String RETURNS = "WordReturnsContractElement";
	public static final String COINS = "coins";
	public static final String UINT = "uint";
	public static final String INT = "int";
	public static final String FLOAT = "float";
	public static final String STRINGTEXT = "stringtext";
	public static final String BOOLEANVALUE = "booleanvalue";
	public static final String CRYPTOGRAPHY_FUNCTIONS = "crypthographic_functions";
	
	@Override 
	public void configure(IHighlightingConfigurationAcceptor acceptor) {
		super.configure(acceptor);
		acceptor.acceptDefaultHighlighting(MSGVARIABLES, "msgvariables", varTextMSGVariablesStyle());
		acceptor.acceptDefaultHighlighting(BCKVARIABLES, "blockvariables", varTextBCKVariablesStyle());
		acceptor.acceptDefaultHighlighting(CRYPTOGRAPHY_FUNCTIONS, "crypthographic_functions", varTextCrypthographicFunctions());
		acceptor.acceptDefaultHighlighting(TXVARIABLES, "txvariables", varTextTXVariablesStyle());
		acceptor.acceptDefaultHighlighting(THIS, "this", varTextThisStyle());
		acceptor.acceptDefaultHighlighting(EMIT, "WordEmitContractElement", varTextWordsContractStyle());
		acceptor.acceptDefaultHighlighting(NOW, "WordNowContractElement", varTextWordsContractStyle());
		acceptor.acceptDefaultHighlighting(NEW, "WordNewContractElement", varTextWordsContractStyle());
		acceptor.acceptDefaultHighlighting(IF, "WordIfContractElement", varTextWordsContractStyle());
		acceptor.acceptDefaultHighlighting(ELSE, "WordElseContractElement", varTextWordsContractStyle());
		acceptor.acceptDefaultHighlighting(RETURN, "WordReturnContractElement", varTextWordsContractStyle());
		acceptor.acceptDefaultHighlighting(RETURNS, "WordReturnsContractElement", varTextWordsContractStyle());
		acceptor.acceptDefaultHighlighting(COINS, "coins", varTextCoinWordsContracStyle());
		acceptor.acceptDefaultHighlighting(UINT, "unsigned integer", varTextNumberTypeStyle());
		acceptor.acceptDefaultHighlighting(INT, "integer", varTextNumberTypeStyle());
		acceptor.acceptDefaultHighlighting(FLOAT, "float", varTextNumberTypeStyle());
		acceptor.acceptDefaultHighlighting(STRINGTEXT, "stringtext", varTextStringTypeStyle());
		acceptor.acceptDefaultHighlighting(BOOLEANVALUE, "booleanvalue", varTextBooleanTypeStyle());
	}
	
	private TextStyle varTextMSGVariablesStyle() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(100,100,200));
		t.setStyle(SWT.ITALIC|SWT.BOLD);
		return t; 
	}
	
	private TextStyle varTextBCKVariablesStyle() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(88,85,83));
		t.setStyle(SWT.ITALIC|SWT.BOLD);
		return t;
	}
	
	private TextStyle varTextCrypthographicFunctions() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(228, 119, 0));
		t.setStyle(SWT.ITALIC|SWT.BOLD);
		return t;
	}
	
	private TextStyle varTextTXVariablesStyle() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(216,98,0));
		t.setStyle(SWT.ITALIC|SWT.BOLD);
		return t;
	}
	
	private TextStyle varTextThisStyle() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(110,3,144));
		t.setStyle(SWT.ITALIC|SWT.BOLD);
		return t;
	}
	
	private TextStyle varTextWordsContractStyle() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(127,0,85));
		t.setStyle(SWT.BOLD);
		return t;
	}
	
	private TextStyle varTextCoinWordsContracStyle(){
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(215,99,2));
		t.setStyle(SWT.BOLD);
		return t;
	}
	
	private TextStyle varTextNumberTypeStyle() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(5,42,247));
		t.setStyle(SWT.BOLD);
		return t;
	}
	
	private TextStyle varTextStringTypeStyle() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(59,144,3));
		t.setStyle(SWT.BOLD);
		return t;
	}
	
	private TextStyle varTextBooleanTypeStyle() {
		TextStyle t = defaultTextStyle().copy();
		t.setColor(new RGB(110,3,144));
		t.setStyle(SWT.BOLD);
		return t;
	}
		
}
