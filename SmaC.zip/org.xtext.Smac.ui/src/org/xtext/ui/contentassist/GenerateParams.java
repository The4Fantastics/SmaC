package org.xtext.ui.contentassist;

import org.eclipse.emf.common.util.EList;
import org.xtext.smaC.InputParam;
import org.xtext.smaC.OutputParam;
import org.xtext.smaC.StorageData;

public class GenerateParams {
	
	int counterInputParams = 0;
	 
	/**
     * Procesa cada par�metro de entrada que recibe un elemento para generar una cadena de texto con todos ellos
     * 
     * Este m�todo recibe toda la lista de par�metros de entrada que recibe un elemento
     * 
     * @return Un String con los par�metros de entrada que puede recibir un elemento
     */
    public String generateInputParams(EList<InputParam> inputparams) {
		String textInputParams = "";
		for(int i = 0; i < inputparams.size(); i++) {
			if(inputparams.size() == 1) {
				textInputParams += defineInputParam(inputparams.get(i));
			}
			else {
				if(inputparams.get(i) != inputparams.get(inputparams.size()-1)) {
					textInputParams += defineInputParam(inputparams.get(i)) + ",";
				}
				else {
					textInputParams += defineInputParam(inputparams.get(i));
				}
			}
		}
    	return textInputParams;        
    }
    
    /**
     * Genera la cadena de datos del par�metro de entrada que recibe un elemento
     * 
     * Este m�todo todo la lista de par�metros de entrada que recibe un elemento
     * 
     * @return Un String con la informaci�n del par�metro de entrada
     */
    public String defineInputParam(InputParam inputparam) {
		String textInputParams = "";
		if(inputparam.getIndexed() == "" || inputparam.getIndexed() == null) {
			if((inputparam.getStorageData().getLiteral() != "" && inputparam.getStorageData().getLiteral() != null) &&  (inputparam.getArray() != "" && inputparam.getArray() != null)) {
				textInputParams = inputparam.getType().toString() + " " + inputparam.getArray() + " " + inputparam.getStorageData().getLiteral() + " " + inputparam.getValueInput();
			}
			else if((inputparam.getStorageData().getLiteral() != "" && inputparam.getStorageData().getLiteral() != null) && (inputparam.getArray() == "" || inputparam.getArray() == null)){
				textInputParams = inputparam.getType().toString() + " " + inputparam.getStorageData().getLiteral() + " " + inputparam.getValueInput();					
			}
			else if((inputparam.getStorageData().getLiteral() == "" || inputparam.getStorageData().getLiteral() == null) && (inputparam.getArray() != "" && inputparam.getArray() != null)){
				textInputParams = inputparam.getType().toString() + " " + inputparam.getArray() + " " + inputparam.getValueInput();					
			}
			else{
				textInputParams = inputparam.getType().toString() + " " + inputparam.getValueInput();					
			}
		}
		else {
			if((inputparam.getStorageData().getLiteral() != "" && inputparam.getStorageData().getLiteral() != null) &&  (inputparam.getArray() != "" && inputparam.getArray() != null)) {
				textInputParams = inputparam.getType().toString() + " " + inputparam.getArray() + " " + inputparam.getIndexed() + " " + inputparam.getStorageData().getLiteral() + " " + inputparam.getValueInput();
			}
			else if((inputparam.getStorageData().getLiteral() != "" && inputparam.getStorageData().getLiteral() != null) && (inputparam.getArray() == "" || inputparam.getArray() == null)){
				textInputParams = inputparam.getType().toString() + " " + inputparam.getIndexed() + " " + inputparam.getStorageData().getLiteral() + " " + inputparam.getValueInput();					
			}
			else if((inputparam.getStorageData().getLiteral() == "" || inputparam.getStorageData().getLiteral() == null) && (inputparam.getArray() != "" && inputparam.getArray() != null)){
				textInputParams = inputparam.getType().toString() + " " + inputparam.getArray() + " " + inputparam.getIndexed() + " " + inputparam.getValueInput();					
			}
			else{
				textInputParams = inputparam.getType().toString() + " " + inputparam.getIndexed() + " " + inputparam.getValueInput();					
			}
		}
    	return textInputParams;        
    }
    
    /**
     * Procesa cada par�metro de entrada que recibe un elemento para generar una cadena de texto con todos ellos
     * 
     * Este m�todo recibe toda la lista de par�metros de entrada que recibe un elemento
     * 
     * @return Un String con los par�metros de entrada que puede recibir un elemento
     */
    public String generateOutputParams(EList<OutputParam> outputparams) {
		String textOutputParams = "";
		for(int i = 0; i < outputparams.size(); i++) {
			if(outputparams.size() == 1) {
				textOutputParams += defineOutputParam(outputparams.get(i));
			}
			else {
				if(outputparams.get(i) != outputparams.get(outputparams.size()-1)) {
					textOutputParams += defineOutputParam(outputparams.get(i)) + ",";
				}
				else {
					textOutputParams += defineOutputParam(outputparams.get(i));
				}
			}
		}
    	return textOutputParams;        
    }
    
    /**
     * Genera la cadena de datos del par�metro de salida que recibe un elemento
     * 
     * Este m�todo todo la lista de par�metros de salida que recibe un elemento
     * 
     * @return Un String con la informaci�n del par�metro de salida
     */
    public String defineOutputParam(OutputParam outputparam) {
		String textOutputParams = "";
		if((outputparam.getValue() != "" && outputparam.getValue() != null && outputparam.getValue() != "null") && (outputparam.getStorageData().getLiteral() != "" && outputparam.getStorageData().getLiteral() != null) &&  (outputparam.getArray() != "" && outputparam.getArray() != null)) {
			textOutputParams = outputparam.getType().toString() + " " + outputparam.getArray() + " " + outputparam.getStorageData().getLiteral() + " " + outputparam.getValue();
		}
		else if((outputparam.getValue() != "" && outputparam.getValue() != null && outputparam.getValue() != "null") && (outputparam.getStorageData().getLiteral() != "" && outputparam.getStorageData().getLiteral() != null) && (outputparam.getArray() == "" || outputparam.getArray() == null)){
			textOutputParams = outputparam.getType().toString() + " " + outputparam.getStorageData().getLiteral() + " " + outputparam.getValue();					
		}
		else if((outputparam.getValue() != "" && outputparam.getValue() != null) && (outputparam.getStorageData().getLiteral() == "" || outputparam.getStorageData().getLiteral() == null) && (outputparam.getArray() != "" && outputparam.getArray() != null)){
			textOutputParams = outputparam.getType().toString() + " " + outputparam.getArray() + " " + outputparam.getValue();					
		}
		else if((outputparam.getValue() == "" || outputparam.getValue() == "null" || outputparam.getValue() == null) && (outputparam.getStorageData().getLiteral() == "" || outputparam.getStorageData().getLiteral() == null) && (outputparam.getArray() == "" && outputparam.getArray() == null)){
			textOutputParams = outputparam.getType().toString();					
		}
		else if((outputparam.getValue() == "" || outputparam.getValue() == "null" || outputparam.getValue() == null) && (outputparam.getStorageData().getLiteral() == "" || outputparam.getStorageData().getLiteral() == null) && (outputparam.getArray() != "" && outputparam.getArray() != null)){
			textOutputParams = outputparam.getType().toString() + " " + outputparam.getArray();					
		}
		else if((outputparam.getValue() == "" || outputparam.getValue() == "null" || outputparam.getValue() == null) && (outputparam.getStorageData().getLiteral() == "" || outputparam.getStorageData().getLiteral() == null || outputparam.getStorageData().getLiteral() == "null") && (outputparam.getArray() == "" || outputparam.getArray() == null)){
			textOutputParams = outputparam.getType().toString() + " " + outputparam.getValue();					
		}
		else if((outputparam.getValue() == "" || outputparam.getValue() == "null" || outputparam.getValue() == null) && (outputparam.getStorageData().getLiteral() != "" || outputparam.getStorageData().getLiteral() != null || outputparam.getStorageData().getLiteral() != "null") && (outputparam.getArray() == "" || outputparam.getArray() == null)){
			textOutputParams = outputparam.getType().toString() + " " +outputparam.getStorageData().getLiteral();					
		}
		else{
			textOutputParams = outputparam.getType().toString() + " " + outputparam.getValue();					
		}
    	return textOutputParams;        
    }
    
    public void incrementInputParams(){
    	counterInputParams = counterInputParams++;
    }
    
    public int getCounterInputParams(){
    	return counterInputParams;
    }
    
}
