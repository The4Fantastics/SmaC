package org.xtext.ui.contentassist;

import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

public class HexGenerator {

    private static final Set<String> generatedValues = new HashSet<>();
    private static final SecureRandom random = new SecureRandom();

    /**
     * Genera una cadena hexadecimal aleatoria de 20 bytes que no se ha generado previamente.
     * 
     * Este m�todo no toma par�metros de entrada.
     * 
     * @return Una cadena hexadecimal de 40 caracteres (20 bytes representados en hexadecimal),
     *         o null si no se puede generar un valor �nico despu�s de varios intentos.
     */
    public String generateUniqueRandomHex(int longitud) {
        int attempts = 0;
        while (attempts < 1000000) { // Limita el n�mero de intentos para evitar un bucle infinito
            byte[] bytes = new byte[longitud];//longitud de la cadena hexadecimal
            random.nextBytes(bytes);
            String hex = bytesToHex(bytes);

            if (!generatedValues.contains(hex)) {
                generatedValues.add(hex);
                return hex;
            }

            attempts++;
        }
        return null; // Retorna null si no encuentra un valor �nico despu�s de 1000000 intentos
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(0xff & bytes[i]);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

}
