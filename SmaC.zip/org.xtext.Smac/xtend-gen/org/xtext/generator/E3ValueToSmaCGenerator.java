package org.xtext.generator;

import e3Value.BusinessActor;
import e3Value.E3ValueDiagram;
import e3Value.StimulusElement;
import e3Value.ValueInterface;
import e3Value.ValuePortIn;
import e3Value.ValuePortOut;
import java.util.ArrayList;
import javax.swing.JProgressBar;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.util.CancelIndicator;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;
import org.xtext.generator.e3valuetoSmaC.Constants;
import org.xtext.generator.e3valuetoSmaC.ContractPersonalized;
import org.xtext.generator.e3valuetoSmaC.Function;
import org.xtext.generator.e3valuetoSmaC.Modifier;
import org.xtext.generator.e3valuetoSmaC.PreProcessor;
import org.xtext.generator.e3valuetoSmaC.Property;
import org.xtext.generator.e3valuetoSmaC.StructValueObjectIdentified;
import org.xtext.generator.e3valuetoSmaC.TokenValueObject;
import org.xtext.generator.e3valuetoSmaC.ValueExchangePersonalized;
import org.xtext.generator.e3valuetoSmaC.wizardIU;
import org.xtext.smaCQA.AgeQuestion;
import org.xtext.smaCQA.DataQuestion;
import org.xtext.smaCQA.EconomyQuestion;
import org.xtext.smaCQA.LegalQuestion;
import org.xtext.smaCQA.MinimumAmountQuestion;
import org.xtext.smaCQA.Model;
import org.xtext.smaCQA.RepeatValueExchangeQuestion;
import org.xtext.smaCQA.TaxQuestion;
import org.xtext.smaCQA.TimeStartValueExchangeQuestion;
import org.xtext.smaCQA.TimeValueExchangeDurationQuestion;
import org.xtext.smaCQA.ValueExchange;
import org.xtext.smaCQA.ValueObjectQuestion;
import org.xtext.smaCQA.impl.ValueObjectTangibleQuestionImpl;
import org.xtext.smaCQA.impl.ValueObjectTokenQuestionImpl;

@SuppressWarnings("all")
public class E3ValueToSmaCGenerator extends AbstractGenerator {
  private static final String SMAC_SOURCE_GENERATED_DIRECTORY = "Transformation-src-generated";
  
  private final wizardIU wizardIU = new org.xtext.generator.e3valuetoSmaC.wizardIU();
  
  private final int YES = 0;
  
  private final Constants constants = new Constants();
  
  private String pathSmaCQA;
  
  private ArrayList<ValueExchangePersonalized> valueExchangesIdentified = new ArrayList<ValueExchangePersonalized>();
  
  private ArrayList<ContractPersonalized> contractsIdentified = new ArrayList<ContractPersonalized>();
  
  private ArrayList<Function> functionsIdentified = new ArrayList<Function>();
  
  private ArrayList<Modifier> modifiersIdentified = new ArrayList<Modifier>();
  
  private PreProcessor preProcessor = new PreProcessor();
  
  private boolean generateFunctions = false;
  
  private Model smacqaModel;
  
  private String initialMessage;
  
  private ArrayList<StructValueObjectIdentified> structsValueObjectIdentified = new ArrayList<StructValueObjectIdentified>();
  
  private ArrayList<Property> propertiesIdentified = new ArrayList<Property>();
  
  private ArrayList<String> expressionsConstructorIdentified = new ArrayList<String>();
  
  private boolean insertPropertyAge = false;
  
  private boolean insertEnableRightValueObject = false;
  
  private IFileSystemAccess2 fsaToken;
  
  private Resource inputResourceToken;
  
  private IGeneratorContext contextToken;
  
  private TokenValueObject token = new TokenValueObject();
  
  private ArrayList<TokenValueObject> registerTokens = new ArrayList<TokenValueObject>();
  
  /**
   * Argumentos de entrada:El objeto de la clase e3value diagram (raiz del e3value), el propio modelo e3value, y el nombre del fichero.
   * Descripci�n: Analiza previamente los port out para crear los intercambios de valor, luego se completa la informaci�n de estos con los port in y posteriormente se a�aden a un contrato
   * A continuaci�n, se presenta el asistente de creaci�n para personalizar un poco la transformaci�n y generar el fichero a partir del e3value
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaC_File(final E3ValueDiagram diagram, final Resource input, final String nameFile) {
    CharSequence _xblockexpression = null;
    {
      this.preProcessor.cleanFunctions(this.functionsIdentified);
      this.preProcessor.cleanModifiers(this.modifiersIdentified);
      this.preProcessor.cleanProperties(this.propertiesIdentified);
      this.preProcessor.cleanStructsValueObject(this.structsValueObjectIdentified);
      this.preProcessor.cleanValueExchangesIdentified(this.valueExchangesIdentified);
      this.preProcessor.cleanContractsIdentified(this.contractsIdentified);
      this.preProcessor.cleanExpressionsConstructor(this.expressionsConstructorIdentified);
      StringConcatenation _builder = new StringConcatenation();
      final EList<BusinessActor> actors = diagram.getHasE3ValueModels().get(0).getHasBusinessActors();
      _builder.newLineIfNotEmpty();
      {
        for(final BusinessActor actor : actors) {
          CharSequence _createValueExchangePersonalized = this.createValueExchangePersonalized(actor);
          _builder.append(_createValueExchangePersonalized);
          _builder.append("\t");
        }
      }
      _builder.newLineIfNotEmpty();
      {
        for(final BusinessActor actor_1 : actors) {
          CharSequence _completeValueExchangePersonalized = this.completeValueExchangePersonalized(actor_1);
          _builder.append(_completeValueExchangePersonalized);
          _builder.append("    ");
        }
      }
      _builder.newLineIfNotEmpty();
      {
        for(final ValueExchangePersonalized valueExchangeIdentified : this.valueExchangesIdentified) {
          _builder.append("    ");
          this.preProcessor.addValueExchangeToContract(this.contractsIdentified, valueExchangeIdentified);
          _builder.append("    ");
        }
      }
      _builder.newLineIfNotEmpty();
      _builder.append("    ");
      this.wizardIU.createFrame(this.contractsIdentified);
      _builder.append("    ");
      {
        int _showInitialMessage = this.wizardIU.showInitialMessage(this.initialMessage, false);
        boolean _equals = (_showInitialMessage == 0);
        if (_equals) {
          _builder.newLineIfNotEmpty();
          _builder.append("    ");
          final String version = this.wizardIU.generateJPanelVersion();
          _builder.append("pragma solidity ");
          _builder.append(version, "    ");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          {
            for(final ContractPersonalized contractIdentified : this.contractsIdentified) {
              CharSequence _generateSmaCContract = this.generateSmaCContract(contractIdentified);
              _builder.append(_generateSmaCContract);
              _builder.append("\t\t");
              JProgressBar _progress = this.wizardIU.getProgress();
              int _value = this.wizardIU.getProgress().getValue();
              int _progressContract = this.wizardIU.getProgressContract();
              int _plus = (_value + _progressContract);
              _progress.setValue(_plus);
              _builder.newLineIfNotEmpty();
            }
          }
          this.wizardIU.showMessageInfo("Transformation process finished");
          _builder.newLineIfNotEmpty();
          this.wizardIU.dispose();
          _builder.newLineIfNotEmpty();
        } else {
          this.wizardIU.showMessageInfo("Transformation process not started");
          _builder.newLineIfNotEmpty();
          this.wizardIU.dispose();
          _builder.newLineIfNotEmpty();
          CancelIndicator _cancelIndicator = this.contextToken.getCancelIndicator();
          _builder.append(_cancelIndicator);
          _builder.newLineIfNotEmpty();
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Argumentos de entrada:El objeto de la clase e3value diagram (raiz del e3value), el propio modelo e3value,el nombre del fichero y el modelo qa que contiene preguntas y respuestas sobre el modelo e3value.
   * Descripci�n: Analiza previamente los port out para crear los intercambios de valor, luego se completa la informaci�n de estos con los port in y posteriormente se a�aden a un contrato
   * A continuaci�n, se presenta el asistente de creaci�n para personalizar un poco la transformaci�n y generar el fichero a partir del e3value
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaC_File(final E3ValueDiagram diagram, final Resource input, final String nameFile, final Model smaqaModelInput) {
    CharSequence _xblockexpression = null;
    {
      this.insertEnableRightValueObject = false;
      this.preProcessor.cleanFunctions(this.functionsIdentified);
      this.preProcessor.cleanModifiers(this.modifiersIdentified);
      this.preProcessor.cleanProperties(this.propertiesIdentified);
      this.preProcessor.cleanStructsValueObject(this.structsValueObjectIdentified);
      this.preProcessor.cleanValueExchangesIdentified(this.valueExchangesIdentified);
      this.preProcessor.cleanContractsIdentified(this.contractsIdentified);
      this.preProcessor.cleanExpressionsConstructor(this.expressionsConstructorIdentified);
      this.smacqaModel = smaqaModelInput;
      StringConcatenation _builder = new StringConcatenation();
      final EList<BusinessActor> actors = diagram.getHasE3ValueModels().get(0).getHasBusinessActors();
      _builder.newLineIfNotEmpty();
      {
        for(final BusinessActor actor : actors) {
          CharSequence _createValueExchangePersonalized = this.createValueExchangePersonalized(actor);
          _builder.append(_createValueExchangePersonalized);
          _builder.newLineIfNotEmpty();
        }
      }
      {
        for(final BusinessActor actor_1 : actors) {
          CharSequence _completeValueExchangePersonalized = this.completeValueExchangePersonalized(actor_1);
          _builder.append(_completeValueExchangePersonalized);
          _builder.newLineIfNotEmpty();
        }
      }
      {
        for(final ValueExchangePersonalized valueExchangeIdentified : this.valueExchangesIdentified) {
          _builder.append("    ");
          this.preProcessor.addValueExchangeToContract(this.contractsIdentified, valueExchangeIdentified);
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("    ");
      this.preProcessor.associateValueExchangesBetweenModel(this.valueExchangesIdentified, smaqaModelInput);
      _builder.append("    ");
      this.wizardIU.createFrame(this.contractsIdentified);
      _builder.newLineIfNotEmpty();
      {
        int _showInitialMessage = this.wizardIU.showInitialMessage(this.initialMessage, true);
        boolean _equals = (_showInitialMessage == 0);
        if (_equals) {
          _builder.append("    ");
          final String version = this.wizardIU.generateJPanelVersion();
          _builder.newLineIfNotEmpty();
          _builder.append("pragma solidity ");
          _builder.append(version);
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.newLine();
          {
            for(final ContractPersonalized contractIdentified : this.contractsIdentified) {
              CharSequence _generateSmaCContract = this.generateSmaCContract(contractIdentified);
              _builder.append(_generateSmaCContract);
              _builder.newLineIfNotEmpty();
            }
          }
          this.wizardIU.showMessageInfo("Transformation process finished");
          _builder.newLineIfNotEmpty();
          this.wizardIU.dispose();
          _builder.newLineIfNotEmpty();
        } else {
          this.wizardIU.showMessageInfo("Transformation process not started");
          _builder.newLineIfNotEmpty();
          this.wizardIU.dispose();
          _builder.newLineIfNotEmpty();
          CancelIndicator _cancelIndicator = this.contextToken.getCancelIndicator();
          _builder.append(_cancelIndicator);
          _builder.newLineIfNotEmpty();
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Argumentos de entrada:El objeto de la clase BusinessActor
   * Descripci�n: Obtiene todos los puertos de salida y crea un value exchange personalized con todos los datos que puede obtener a partir de un port out
   * Argumento de salida: Ninguno
   */
  public CharSequence createValueExchangePersonalized(final BusinessActor actor) {
    StringConcatenation _builder = new StringConcatenation();
    {
      EList<ValueInterface> _hasValuesInterface = actor.getHasValuesInterface();
      for(final ValueInterface valueInterface : _hasValuesInterface) {
        _builder.newLineIfNotEmpty();
        final EList<ValuePortOut> portsOut = valueInterface.getHasValuePortOut();
        _builder.append(" ");
        _builder.newLineIfNotEmpty();
        {
          for(final ValuePortOut portOut : portsOut) {
            this.preProcessor.createValueExchangesIdentified(actor, portOut, this.valueExchangesIdentified, valueInterface);
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t\t");
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos de entrada:El objeto de la clase BusinessActor
   * Descripci�n: Obtiene todos los port in de las interfaces que dispone un usuario,
   * Argumento de salida: Ninguno
   */
  public CharSequence completeValueExchangePersonalized(final BusinessActor actor) {
    StringConcatenation _builder = new StringConcatenation();
    {
      EList<ValueInterface> _hasValuesInterface = actor.getHasValuesInterface();
      for(final ValueInterface valueInterface : _hasValuesInterface) {
        _builder.newLineIfNotEmpty();
        final EList<ValuePortIn> portsIn = valueInterface.getHasValuePortIn();
        _builder.newLineIfNotEmpty();
        {
          for(final ValuePortIn portIn : portsIn) {
            this.preProcessor.completeValueExchangesIdentified(actor, portIn, this.valueExchangesIdentified, valueInterface);
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t\t");
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos de entrada: El contrato identificado con los datos de los value exchanges identificados
   * Descripci�n: Se procede a limpiar las funciones y los mmodificadores identificados previamente en otros contratos y luego se van plasmando los modificadores y funciones identificados para este contrato
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaCContract(final ContractPersonalized contractPersonalized) {
    CharSequence _xblockexpression = null;
    {
      this.preProcessor.cleanFunctions(this.functionsIdentified);
      this.preProcessor.cleanModifiers(this.modifiersIdentified);
      this.preProcessor.cleanExpressionsConstructor(this.expressionsConstructorIdentified);
      this.preProcessor.cleanProperties(this.propertiesIdentified);
      this.insertPropertyAge = false;
      this.insertEnableRightValueObject = false;
      StringConcatenation _builder = new StringConcatenation();
      _builder.newLine();
      {
        if ((this.smacqaModel != null)) {
          _builder.append("\t");
          this.processInfoModelQA(contractPersonalized.getValueExchanges(), contractPersonalized);
          _builder.append("\t\t");
        }
      }
      _builder.newLineIfNotEmpty();
      {
        int _size = contractPersonalized.getTokensContract().size();
        boolean _greaterThan = (_size > 0);
        if (_greaterThan) {
          {
            ArrayList<TokenValueObject> _tokensContract = contractPersonalized.getTokensContract();
            for(final TokenValueObject token : _tokensContract) {
              _builder.append("//import route");
              String _name = token.getName();
              _builder.append(_name);
              _builder.append("File; <--- You must replace \"routeNameTokenFile\" with the path where the TokenFile file is located");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t\t");
          _builder.newLine();
          _builder.append("contract ");
          String _firstUpper = StringExtensions.toFirstUpper(this.wizardIU.generateJPanelContract(contractPersonalized));
          _builder.append(_firstUpper);
          _builder.append(" is ");
          String _createInheranceContract = this.preProcessor.createInheranceContract(contractPersonalized);
          _builder.append(_createInheranceContract);
          _builder.append("{");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
        } else {
          _builder.append("contract ");
          String _firstUpper_1 = StringExtensions.toFirstUpper(this.wizardIU.generateJPanelContract(contractPersonalized));
          _builder.append(_firstUpper_1);
          _builder.append("{\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t\t");
          _builder.newLine();
        }
      }
      {
        for(final StructValueObjectIdentified structValueObject : this.structsValueObjectIdentified) {
          _builder.append("\t");
          _builder.append("struct ");
          String _name_1 = structValueObject.getName();
          _builder.append(_name_1, "\t");
          _builder.append("{");
          _builder.newLineIfNotEmpty();
          {
            ArrayList<Property> _properties = structValueObject.getProperties();
            for(final Property property : _properties) {
              _builder.append("\t");
              _builder.append("\t");
              String _string = property.getType().toString();
              _builder.append(_string, "\t\t");
              _builder.append(" ");
              String _string_1 = property.getName().toString();
              _builder.append(_string_1, "\t\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.append("}");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t\t");
          _builder.newLine();
        }
      }
      {
        if (((((Object[])Conversions.unwrapArray(this.structsValueObjectIdentified, Object.class)).length == 0) && (this.insertEnableRightValueObject == false))) {
          _builder.append("\t");
          CharSequence _generateSmaC_User = this.generateSmaC_User(contractPersonalized.getActor_x(), contractPersonalized.getValueExchanges());
          _builder.append(_generateSmaC_User, "\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          CharSequence _generateSmaC_User_1 = this.generateSmaC_User(contractPersonalized.getActor_y(), contractPersonalized.getValueExchanges());
          _builder.append(_generateSmaC_User_1, "\t");
          _builder.newLineIfNotEmpty();
        } else {
          if (((((Object[])Conversions.unwrapArray(this.structsValueObjectIdentified, Object.class)).length != 0) && (this.insertEnableRightValueObject == false))) {
            _builder.append("\t");
            CharSequence _generateSmaC_User_2 = this.generateSmaC_User(contractPersonalized.getActor_x(), contractPersonalized.getValueExchanges(), this.structsValueObjectIdentified);
            _builder.append(_generateSmaC_User_2, "\t");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            CharSequence _generateSmaC_User_3 = this.generateSmaC_User(contractPersonalized.getActor_y(), contractPersonalized.getValueExchanges(), this.structsValueObjectIdentified);
            _builder.append(_generateSmaC_User_3, "\t");
            _builder.newLineIfNotEmpty();
          } else {
            if (((((Object[])Conversions.unwrapArray(this.structsValueObjectIdentified, Object.class)).length == 0) && (this.insertEnableRightValueObject != false))) {
              _builder.append("\t");
              CharSequence _generateSmaC_User_4 = this.generateSmaC_User(contractPersonalized.getActor_x(), contractPersonalized.getValueExchanges(), contractPersonalized.getValueExchanges().get(0).getValueObject().getName());
              _builder.append(_generateSmaC_User_4, "\t");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              CharSequence _generateSmaC_User_5 = this.generateSmaC_User(contractPersonalized.getActor_y(), contractPersonalized.getValueExchanges(), contractPersonalized.getValueExchanges().get(0).getValueObject().getName());
              _builder.append(_generateSmaC_User_5, "\t");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("\t");
      CharSequence _generatePropertyUser = this.generatePropertyUser(contractPersonalized);
      _builder.append(_generatePropertyUser, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      this.preProcessor.createPropertyAddressOwner(this.propertiesIdentified);
      _builder.newLineIfNotEmpty();
      {
        for(final Property property_1 : this.propertiesIdentified) {
          _builder.append("\t");
          CharSequence _generateSmaCProperty = this.generateSmaCProperty(property_1);
          _builder.append(_generateSmaCProperty, "\t");
          _builder.newLineIfNotEmpty();
        }
      }
      {
        if ((this.smacqaModel != null)) {
          _builder.append("\t");
          CharSequence _defineSmaCConstructor = this.defineSmaCConstructor(contractPersonalized);
          _builder.append(_defineSmaCConstructor, "\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          this.defineSmaCModifierOnlyOwner();
          _builder.newLineIfNotEmpty();
        }
      }
      {
        ArrayList<ValueExchangePersonalized> _valueExchanges = contractPersonalized.getValueExchanges();
        for(final ValueExchangePersonalized valueExchangeIdentified : _valueExchanges) {
          _builder.append("\t");
          this.defineSmaCFunction(valueExchangeIdentified);
          _builder.newLineIfNotEmpty();
        }
      }
      {
        for(final Modifier modifierIdentified : this.modifiersIdentified) {
          _builder.append("\t");
          CharSequence _generateSmaCModifier = this.generateSmaCModifier(modifierIdentified);
          _builder.append(_generateSmaCModifier, "\t");
          _builder.newLineIfNotEmpty();
        }
      }
      {
        int _size_1 = contractPersonalized.getTokensContract().size();
        boolean _greaterThan_1 = (_size_1 > 0);
        if (_greaterThan_1) {
          {
            ArrayList<TokenValueObject> _tokensContract_1 = contractPersonalized.getTokensContract();
            for(final TokenValueObject token_1 : _tokensContract_1) {
              {
                boolean _isMintable = token_1.isMintable();
                boolean _tripleEquals = (Boolean.valueOf(_isMintable) == Boolean.valueOf(true));
                if (_tripleEquals) {
                  _builder.append("\t");
                  CharSequence _generateMintFunction = this.generateMintFunction(token_1.getName());
                  _builder.append(_generateMintFunction, "\t");
                  _builder.newLineIfNotEmpty();
                }
              }
              {
                boolean _isBurnable = token_1.isBurnable();
                boolean _tripleEquals_1 = (Boolean.valueOf(_isBurnable) == Boolean.valueOf(true));
                if (_tripleEquals_1) {
                  _builder.append("\t");
                  CharSequence _generateBurnFunction = this.generateBurnFunction(token_1.getName());
                  _builder.append(_generateBurnFunction, "\t");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
        }
      }
      {
        for(final Function functionIdentified : this.functionsIdentified) {
          _builder.append("\t");
          CharSequence _generateSmaCFunction = this.generateSmaCFunction(functionIdentified);
          _builder.append(_generateSmaCFunction, "\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          JProgressBar _progress = this.wizardIU.getProgress();
          int _value = this.wizardIU.getProgress().getValue();
          int _progressFunction = this.wizardIU.getProgressFunction();
          int _plus = (_value + _progressFunction);
          _progress.setValue(_plus);
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("}");
      _builder.newLine();
      String _name_2 = contractPersonalized.getActor_x().getName();
      String _plus_1 = ("Smart contract generated from value exchanges between " + _name_2);
      String _plus_2 = (_plus_1 + " and ");
      String _name_3 = contractPersonalized.getActor_y().getName();
      String _plus_3 = (_plus_2 + _name_3);
      this.wizardIU.showMessageInfo(_plus_3);
      _builder.append("\t");
      _builder.newLineIfNotEmpty();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence generatePropertyUser(final ContractPersonalized contractPersonalized) {
    StringConcatenation _builder = new StringConcatenation();
    {
      boolean _equals = contractPersonalized.getActor_x().eClass().getName().equals("ElementaryActor");
      if (_equals) {
        String _replace = StringExtensions.toFirstUpper(contractPersonalized.getActor_x().getName()).trim().replace(" ", "");
        _builder.append(_replace);
        _builder.append(" actor_");
        String _replace_1 = StringExtensions.toFirstUpper(contractPersonalized.getActor_x().getName()).trim().replace(" ", "");
        _builder.append(_replace_1);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      } else {
        boolean _equals_1 = contractPersonalized.getActor_x().eClass().getName().equals("MarketSegment");
        if (_equals_1) {
          _builder.append("mapping(address => ");
          String _replace_2 = StringExtensions.toFirstUpper(contractPersonalized.getActor_x().getName()).trim().replace(" ", "");
          _builder.append(_replace_2);
          _builder.append(") actorSet_");
          String _replace_3 = StringExtensions.toFirstUpper(contractPersonalized.getActor_x().getName()).trim().replace(" ", "");
          _builder.append(_replace_3);
          _builder.append(";");
          _builder.newLineIfNotEmpty();
        }
      }
    }
    {
      boolean _equals_2 = contractPersonalized.getActor_y().eClass().getName().equals("ElementaryActor");
      if (_equals_2) {
        String _replace_4 = StringExtensions.toFirstUpper(contractPersonalized.getActor_y().getName()).trim().replace(" ", "");
        _builder.append(_replace_4);
        _builder.append(" actor_");
        String _replace_5 = StringExtensions.toFirstUpper(contractPersonalized.getActor_y().getName()).trim().replace(" ", "");
        _builder.append(_replace_5);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      } else {
        boolean _equals_3 = contractPersonalized.getActor_y().eClass().getName().equals("MarketSegment");
        if (_equals_3) {
          _builder.append("mapping(address => ");
          String _replace_6 = StringExtensions.toFirstUpper(contractPersonalized.getActor_y().getName()).trim().replace(" ", "");
          _builder.append(_replace_6);
          _builder.append(") actorSet_");
          String _replace_7 = StringExtensions.toFirstUpper(contractPersonalized.getActor_y().getName()).trim().replace(" ", "");
          _builder.append(_replace_7);
          _builder.append(";");
          _builder.newLineIfNotEmpty();
        }
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos de entrada:El objeto de la clase BussinessActor
   * Descripci�n: Genera el modificador para controlar que solo un usuario registrado en el mapping(address => BusinessActor) pueda ejecutar la acci�n
   * Argumento de salida: Ninguno
   */
  public void defineSmaCModifierRestrictedAccess(final BusinessActor actor) {
    String condition = "";
    boolean _equals = actor.eClass().getName().equals("ElementaryActor");
    if (_equals) {
      String _replace = StringExtensions.toFirstUpper(actor.getName()).replace(" ", "");
      String _plus = ("actor_" + _replace);
      String _plus_1 = (_plus + ".idAddress == msg.sender");
      condition = _plus_1;
    } else {
      boolean _equals_1 = actor.eClass().getName().equals("MarketSegment");
      if (_equals_1) {
        String _replace_1 = StringExtensions.toFirstUpper(actor.getName()).replace(" ", "");
        String _plus_2 = ("actorSet_" + _replace_1);
        String _plus_3 = (_plus_2 + "[msg.sender].idAddress == msg.sender");
        condition = _plus_3;
      }
    }
    String _replace_2 = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
    String _plus_4 = ("only" + _replace_2);
    String _replace_3 = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
    String _plus_5 = ("Only " + _replace_3);
    String _plus_6 = (_plus_5 + " can execute this action");
    this.preProcessor.defineSmaCModifier(this.modifiersIdentified, _plus_4, condition, _plus_6);
  }
  
  /**
   * Argumentos de entrada:Ninguno
   * Descripci�n: Genera el modificador para controlar que solo el due�o del contrato puede ejecutar dicha acci�n
   * Argumento de salida: Ninguno
   */
  public void defineSmaCModifierOnlyOwner() {
    this.preProcessor.createPropertyAddressOwner(this.propertiesIdentified);
    this.preProcessor.defineSmaCModifier(this.modifiersIdentified, "onlyOwner", "owner == msg.sender", "Only owner can execute this action");
  }
  
  /**
   * Argumentos de entrada:El modificador identificado con sus par�metros para ser plasmado en el smart contract
   * Descripci�n: Genera el modificador que recibe como entrada de los datos del modificadorIdentificado
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaCModifier(final Modifier modifierIdentified) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("modifier ");
    String _replace = StringExtensions.toFirstUpper(modifierIdentified.getName().toString().trim()).replace(" ", "");
    _builder.append(_replace);
    _builder.append("(){");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("require(");
    String _condition = modifierIdentified.getCondition();
    _builder.append(_condition, "\t");
    _builder.append(",\"");
    String _message = modifierIdentified.getMessage();
    _builder.append(_message, "\t");
    _builder.append("\");");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("_;");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence generateSmaC_User(final BusinessActor actor, final ArrayList<ValueExchangePersonalized> valueExchangePersonalized) {
    CharSequence _xblockexpression = null;
    {
      String opcion = this.wizardIU.generateJPanelActor(actor.getName());
      StringConcatenation _builder = new StringConcatenation();
      {
        if ((opcion == "User")) {
          {
            String _name = actor.getName();
            boolean _tripleNotEquals = (_name != null);
            if (_tripleNotEquals) {
              _builder.append("struct ");
              String _replace = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
              _builder.append(_replace);
              _builder.append(" {");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string surname;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                String _firstUpper = StringExtensions.toFirstUpper(actor.getName());
                String _plus = ("Do you want to add more data for the " + _firstUpper);
                String _plus_1 = (_plus + " struct?");
                int _showDialogConfirm = this.wizardIU.showDialogConfirm(_plus_1);
                boolean _equals = (_showDialogConfirm == this.YES);
                if (_equals) {
                  _builder.append("\t");
                  final ArrayList<Property> properties = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.newLineIfNotEmpty();
                  {
                    for(final Property property : properties) {
                      {
                        int _dimension = property.getDimension();
                        boolean _equals_1 = (_dimension == 1);
                        if (_equals_1) {
                          _builder.append("\t");
                          String _string = property.getType().toString();
                          _builder.append(_string, "\t");
                          _builder.append("[] ");
                          String _string_1 = property.getName().toString();
                          _builder.append(_string_1, "\t");
                          _builder.append(";");
                          _builder.newLineIfNotEmpty();
                        } else {
                          int _dimension_1 = property.getDimension();
                          boolean _equals_2 = (_dimension_1 == 2);
                          if (_equals_2) {
                            _builder.append("\t");
                            String _string_2 = property.getType().toString();
                            _builder.append(_string_2, "\t");
                            _builder.append("[][]");
                            String _string_3 = property.getName().toString();
                            _builder.append(_string_3, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            _builder.append("\t");
                            String _string_4 = property.getType().toString();
                            _builder.append(_string_4, "\t");
                            _builder.append(" ");
                            String _string_5 = property.getName().toString();
                            _builder.append(_string_5, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              }
              {
                boolean _controlInsertPropertyAge = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("}\t");
              _builder.newLine();
              _builder.newLine();
            } else {
              _builder.append("struct BusinessActors {");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string surname;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                int _showDialogConfirm_1 = this.wizardIU.showDialogConfirm("Do you want to add more data for the Business Actors struct?");
                boolean _equals_3 = (_showDialogConfirm_1 == this.YES);
                if (_equals_3) {
                  _builder.append("\t");
                  ArrayList<Property> _generateJPanelProperty = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.append(_generateJPanelProperty, "\t");
                  _builder.newLineIfNotEmpty();
                }
              }
              {
                boolean _controlInsertPropertyAge_1 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge_1) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("}\t");
              _builder.newLine();
            }
          }
        }
      }
      {
        if ((opcion == "Company")) {
          {
            String _name_1 = actor.getName();
            boolean _tripleNotEquals_1 = (_name_1 != null);
            if (_tripleNotEquals_1) {
              _builder.append("struct ");
              String _replace_1 = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
              _builder.append(_replace_1);
              _builder.append(" {");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string city;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string VAT;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                String _firstUpper_1 = StringExtensions.toFirstUpper(actor.getName());
                String _plus_2 = ("Do you want to add more data for the " + _firstUpper_1);
                String _plus_3 = (_plus_2 + " struct?");
                int _showDialogConfirm_2 = this.wizardIU.showDialogConfirm(_plus_3);
                boolean _equals_4 = (_showDialogConfirm_2 == this.YES);
                if (_equals_4) {
                  _builder.append("\t");
                  final ArrayList<Property> properties_1 = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.newLineIfNotEmpty();
                  {
                    for(final Property property_1 : properties_1) {
                      {
                        int _dimension_2 = property_1.getDimension();
                        boolean _equals_5 = (_dimension_2 == 1);
                        if (_equals_5) {
                          _builder.append("\t");
                          String _string_6 = property_1.getType().toString();
                          _builder.append(_string_6, "\t");
                          _builder.append("[] ");
                          String _string_7 = property_1.getName().toString();
                          _builder.append(_string_7, "\t");
                          _builder.append(";");
                          _builder.newLineIfNotEmpty();
                        } else {
                          int _dimension_3 = property_1.getDimension();
                          boolean _equals_6 = (_dimension_3 == 2);
                          if (_equals_6) {
                            _builder.append("\t");
                            String _string_8 = property_1.getType().toString();
                            _builder.append(_string_8, "\t");
                            _builder.append("[][]");
                            String _string_9 = property_1.getName().toString();
                            _builder.append(_string_9, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            _builder.append("\t");
                            String _string_10 = property_1.getType().toString();
                            _builder.append(_string_10, "\t");
                            _builder.append(" ");
                            String _string_11 = property_1.getName().toString();
                            _builder.append(_string_11, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              }
              {
                boolean _controlInsertPropertyAge_2 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge_2) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("}\t");
              _builder.newLine();
            }
          }
          {
            if ((opcion == "Personalized")) {
              {
                String _name_2 = actor.getName();
                boolean _tripleNotEquals_2 = (_name_2 != null);
                if (_tripleNotEquals_2) {
                  _builder.append("struct ");
                  String _replace_2 = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
                  _builder.append(_replace_2);
                  _builder.append(" {");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("address idAdress;");
                  _builder.newLine();
                  {
                    String _firstUpper_2 = StringExtensions.toFirstUpper(actor.getName());
                    String _plus_4 = ("Do you want to add more data for the " + _firstUpper_2);
                    String _plus_5 = (_plus_4 + " struct?");
                    int _showDialogConfirm_3 = this.wizardIU.showDialogConfirm(_plus_5);
                    boolean _equals_7 = (_showDialogConfirm_3 == this.YES);
                    if (_equals_7) {
                      _builder.append("\t");
                      final ArrayList<Property> properties_2 = this.wizardIU.generateJPanelProperty("Struct");
                      _builder.newLineIfNotEmpty();
                      {
                        for(final Property property_2 : properties_2) {
                          {
                            int _dimension_4 = property_2.getDimension();
                            boolean _equals_8 = (_dimension_4 == 1);
                            if (_equals_8) {
                              _builder.append("\t");
                              String _string_12 = property_2.getType().toString();
                              _builder.append(_string_12, "\t");
                              _builder.append("[] ");
                              String _string_13 = property_2.getName().toString();
                              _builder.append(_string_13, "\t");
                              _builder.append(";");
                              _builder.newLineIfNotEmpty();
                            } else {
                              int _dimension_5 = property_2.getDimension();
                              boolean _equals_9 = (_dimension_5 == 2);
                              if (_equals_9) {
                                _builder.append("\t");
                                String _string_14 = property_2.getType().toString();
                                _builder.append(_string_14, "\t");
                                _builder.append("[][]");
                                String _string_15 = property_2.getName().toString();
                                _builder.append(_string_15, "\t");
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              } else {
                                _builder.append("\t");
                                String _string_16 = property_2.getType().toString();
                                _builder.append(_string_16, "\t");
                                _builder.append(" ");
                                String _string_17 = property_2.getName().toString();
                                _builder.append(_string_17, "\t");
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  {
                    boolean _controlInsertPropertyAge_3 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                    if (_controlInsertPropertyAge_3) {
                      _builder.append("\t");
                      _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                      _builder.newLine();
                    }
                  }
                  _builder.append("}\t");
                  _builder.newLine();
                }
              }
            }
          }
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence generateSmaC_User(final BusinessActor actor, final ArrayList<ValueExchangePersonalized> valueExchangePersonalized, final ArrayList<StructValueObjectIdentified> structsValueObject) {
    CharSequence _xblockexpression = null;
    {
      String opcion = this.wizardIU.generateJPanelActor(actor.getName());
      StringConcatenation _builder = new StringConcatenation();
      {
        if ((opcion == "User")) {
          {
            String _name = actor.getName();
            boolean _tripleNotEquals = (_name != null);
            if (_tripleNotEquals) {
              _builder.append("struct ");
              String _replace = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
              _builder.append(_replace);
              _builder.append(" {");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string surname;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                String _firstUpper = StringExtensions.toFirstUpper(actor.getName());
                String _plus = ("Do you want to add more data for the " + _firstUpper);
                String _plus_1 = (_plus + " struct?");
                int _showDialogConfirm = this.wizardIU.showDialogConfirm(_plus_1);
                boolean _equals = (_showDialogConfirm == this.YES);
                if (_equals) {
                  _builder.append("\t");
                  final ArrayList<Property> properties = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.newLineIfNotEmpty();
                  {
                    for(final Property property : properties) {
                      {
                        int _dimension = property.getDimension();
                        boolean _equals_1 = (_dimension == 1);
                        if (_equals_1) {
                          _builder.append("\t");
                          String _string = property.getType().toString();
                          _builder.append(_string, "\t");
                          _builder.append("[] ");
                          String _string_1 = property.getName().toString();
                          _builder.append(_string_1, "\t");
                          _builder.append(";");
                          _builder.newLineIfNotEmpty();
                        } else {
                          int _dimension_1 = property.getDimension();
                          boolean _equals_2 = (_dimension_1 == 2);
                          if (_equals_2) {
                            _builder.append("\t");
                            String _string_2 = property.getType().toString();
                            _builder.append(_string_2, "\t");
                            _builder.append("[][]");
                            String _string_3 = property.getName().toString();
                            _builder.append(_string_3, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            _builder.append("\t");
                            String _string_4 = property.getType().toString();
                            _builder.append(_string_4, "\t");
                            _builder.append(" ");
                            String _string_5 = property.getName().toString();
                            _builder.append(_string_5, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              }
              {
                for(final StructValueObjectIdentified struct : structsValueObject) {
                  _builder.append("\t");
                  String _firstUpper_1 = StringExtensions.toFirstUpper(struct.getName());
                  _builder.append(_firstUpper_1, "\t");
                  _builder.append(" valueObject_");
                  String _firstUpper_2 = StringExtensions.toFirstUpper(struct.getName());
                  _builder.append(_firstUpper_2, "\t");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                }
              }
              {
                boolean _controlInsertPropertyAge = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("\t");
              _builder.newLine();
              _builder.append("}\t");
              _builder.newLine();
              _builder.newLine();
            } else {
              _builder.append("struct BusinessActors {");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string surname;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                int _showDialogConfirm_1 = this.wizardIU.showDialogConfirm("Do you want to add more data for the Business Actors struct?");
                boolean _equals_3 = (_showDialogConfirm_1 == this.YES);
                if (_equals_3) {
                  _builder.append("\t");
                  ArrayList<Property> _generateJPanelProperty = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.append(_generateJPanelProperty, "\t");
                  _builder.newLineIfNotEmpty();
                }
              }
              {
                for(final StructValueObjectIdentified struct_1 : structsValueObject) {
                  _builder.append("\t");
                  String _firstUpper_3 = StringExtensions.toFirstUpper(struct_1.getName());
                  _builder.append(_firstUpper_3, "\t");
                  _builder.append(" valueObject_");
                  String _firstUpper_4 = StringExtensions.toFirstUpper(struct_1.getName());
                  _builder.append(_firstUpper_4, "\t");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                }
              }
              {
                boolean _controlInsertPropertyAge_1 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge_1) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("}\t");
              _builder.newLine();
            }
          }
        }
      }
      {
        if ((opcion == "Company")) {
          {
            String _name_1 = actor.getName();
            boolean _tripleNotEquals_1 = (_name_1 != null);
            if (_tripleNotEquals_1) {
              _builder.append("struct ");
              String _replace_1 = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
              _builder.append(_replace_1);
              _builder.append(" {");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string city;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string VAT;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                String _firstUpper_5 = StringExtensions.toFirstUpper(actor.getName());
                String _plus_2 = ("Do you want to add more data for the " + _firstUpper_5);
                String _plus_3 = (_plus_2 + " struct?");
                int _showDialogConfirm_2 = this.wizardIU.showDialogConfirm(_plus_3);
                boolean _equals_4 = (_showDialogConfirm_2 == this.YES);
                if (_equals_4) {
                  _builder.append("\t");
                  final ArrayList<Property> properties_1 = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.newLineIfNotEmpty();
                  {
                    for(final Property property_1 : properties_1) {
                      {
                        int _dimension_2 = property_1.getDimension();
                        boolean _equals_5 = (_dimension_2 == 1);
                        if (_equals_5) {
                          _builder.append("\t");
                          String _string_6 = property_1.getType().toString();
                          _builder.append(_string_6, "\t");
                          _builder.append("[] ");
                          String _string_7 = property_1.getName().toString();
                          _builder.append(_string_7, "\t");
                          _builder.append(";");
                          _builder.newLineIfNotEmpty();
                        } else {
                          int _dimension_3 = property_1.getDimension();
                          boolean _equals_6 = (_dimension_3 == 2);
                          if (_equals_6) {
                            _builder.append("\t");
                            String _string_8 = property_1.getType().toString();
                            _builder.append(_string_8, "\t");
                            _builder.append("[][]");
                            String _string_9 = property_1.getName().toString();
                            _builder.append(_string_9, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            _builder.append("\t");
                            String _string_10 = property_1.getType().toString();
                            _builder.append(_string_10, "\t");
                            _builder.append(" ");
                            String _string_11 = property_1.getName().toString();
                            _builder.append(_string_11, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              }
              {
                for(final StructValueObjectIdentified struct_2 : structsValueObject) {
                  _builder.append("\t");
                  String _firstUpper_6 = StringExtensions.toFirstUpper(struct_2.getName());
                  _builder.append(_firstUpper_6, "\t");
                  _builder.append(" valueObject_");
                  String _firstUpper_7 = StringExtensions.toFirstUpper(struct_2.getName());
                  _builder.append(_firstUpper_7, "\t");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                }
              }
              {
                boolean _controlInsertPropertyAge_2 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge_2) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("}\t");
              _builder.newLine();
            }
          }
          {
            if ((opcion == "Personalized")) {
              {
                String _name_2 = actor.getName();
                boolean _tripleNotEquals_2 = (_name_2 != null);
                if (_tripleNotEquals_2) {
                  _builder.append("struct ");
                  String _replace_2 = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
                  _builder.append(_replace_2);
                  _builder.append(" {");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("address idAdress;");
                  _builder.newLine();
                  {
                    String _firstUpper_8 = StringExtensions.toFirstUpper(actor.getName());
                    String _plus_4 = ("Do you want to add more data for the " + _firstUpper_8);
                    String _plus_5 = (_plus_4 + " struct?");
                    int _showDialogConfirm_3 = this.wizardIU.showDialogConfirm(_plus_5);
                    boolean _equals_7 = (_showDialogConfirm_3 == this.YES);
                    if (_equals_7) {
                      _builder.append("\t");
                      final ArrayList<Property> properties_2 = this.wizardIU.generateJPanelProperty("Struct");
                      _builder.newLineIfNotEmpty();
                      {
                        for(final Property property_2 : properties_2) {
                          {
                            int _dimension_4 = property_2.getDimension();
                            boolean _equals_8 = (_dimension_4 == 1);
                            if (_equals_8) {
                              _builder.append("\t");
                              String _string_12 = property_2.getType().toString();
                              _builder.append(_string_12, "\t");
                              _builder.append("[] ");
                              String _string_13 = property_2.getName().toString();
                              _builder.append(_string_13, "\t");
                              _builder.append(";");
                              _builder.newLineIfNotEmpty();
                            } else {
                              int _dimension_5 = property_2.getDimension();
                              boolean _equals_9 = (_dimension_5 == 2);
                              if (_equals_9) {
                                _builder.append("\t");
                                String _string_14 = property_2.getType().toString();
                                _builder.append(_string_14, "\t");
                                _builder.append("[][]");
                                String _string_15 = property_2.getName().toString();
                                _builder.append(_string_15, "\t");
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              } else {
                                _builder.append("\t");
                                String _string_16 = property_2.getType().toString();
                                _builder.append(_string_16, "\t");
                                _builder.append(" ");
                                String _string_17 = property_2.getName().toString();
                                _builder.append(_string_17, "\t");
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  {
                    for(final StructValueObjectIdentified struct_3 : structsValueObject) {
                      _builder.append("\t");
                      String _firstUpper_9 = StringExtensions.toFirstUpper(struct_3.getName());
                      _builder.append(_firstUpper_9, "\t");
                      _builder.append(" valueObject_");
                      String _firstUpper_10 = StringExtensions.toFirstUpper(struct_3.getName());
                      _builder.append(_firstUpper_10, "\t");
                      _builder.append(";");
                      _builder.newLineIfNotEmpty();
                    }
                  }
                  {
                    boolean _controlInsertPropertyAge_3 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                    if (_controlInsertPropertyAge_3) {
                      _builder.append("\t");
                      _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                      _builder.newLine();
                    }
                  }
                  _builder.append("}\t");
                  _builder.newLine();
                }
              }
            }
          }
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence generateSmaC_User(final BusinessActor actor, final ArrayList<ValueExchangePersonalized> valueExchangePersonalized, final String nameValueObjectRight) {
    CharSequence _xblockexpression = null;
    {
      String opcion = this.wizardIU.generateJPanelActor(actor.getName());
      StringConcatenation _builder = new StringConcatenation();
      {
        if ((opcion == "User")) {
          {
            String _name = actor.getName();
            boolean _tripleNotEquals = (_name != null);
            if (_tripleNotEquals) {
              _builder.append("struct ");
              String _replace = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
              _builder.append(_replace);
              _builder.append(" {");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string surname;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                String _firstUpper = StringExtensions.toFirstUpper(actor.getName());
                String _plus = ("Do you want to add more data for the " + _firstUpper);
                String _plus_1 = (_plus + " struct?");
                int _showDialogConfirm = this.wizardIU.showDialogConfirm(_plus_1);
                boolean _equals = (_showDialogConfirm == this.YES);
                if (_equals) {
                  _builder.append("\t");
                  final ArrayList<Property> properties = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.newLineIfNotEmpty();
                  {
                    for(final Property property : properties) {
                      {
                        int _dimension = property.getDimension();
                        boolean _equals_1 = (_dimension == 1);
                        if (_equals_1) {
                          _builder.append("\t");
                          String _string = property.getType().toString();
                          _builder.append(_string, "\t");
                          _builder.append("[] ");
                          String _string_1 = property.getName().toString();
                          _builder.append(_string_1, "\t");
                          _builder.append(";");
                          _builder.newLineIfNotEmpty();
                        } else {
                          int _dimension_1 = property.getDimension();
                          boolean _equals_2 = (_dimension_1 == 2);
                          if (_equals_2) {
                            _builder.append("\t");
                            String _string_2 = property.getType().toString();
                            _builder.append(_string_2, "\t");
                            _builder.append("[][]");
                            String _string_3 = property.getName().toString();
                            _builder.append(_string_3, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            _builder.append("\t");
                            String _string_4 = property.getType().toString();
                            _builder.append(_string_4, "\t");
                            _builder.append(" ");
                            String _string_5 = property.getName().toString();
                            _builder.append(_string_5, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              }
              _builder.append("\t ");
              _builder.append("bool enable");
              String _replace_1 = StringExtensions.toFirstUpper(nameValueObjectRight).trim().replace(" ", "");
              _builder.append(_replace_1, "\t ");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
              {
                boolean _controlInsertPropertyAge = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("\t");
              _builder.newLine();
              _builder.append("}\t");
              _builder.newLine();
              _builder.newLine();
            } else {
              _builder.append("struct BusinessActors {");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string surname;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                int _showDialogConfirm_1 = this.wizardIU.showDialogConfirm("Do you want to add more data for the Business Actors struct?");
                boolean _equals_3 = (_showDialogConfirm_1 == this.YES);
                if (_equals_3) {
                  _builder.append("\t");
                  ArrayList<Property> _generateJPanelProperty = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.append(_generateJPanelProperty, "\t");
                  _builder.newLineIfNotEmpty();
                }
              }
              _builder.append("\t");
              _builder.append("bool enable");
              String _replace_2 = StringExtensions.toFirstUpper(nameValueObjectRight).trim().replace(" ", "");
              _builder.append(_replace_2, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
              {
                boolean _controlInsertPropertyAge_1 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge_1) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("}\t");
              _builder.newLine();
            }
          }
        }
      }
      {
        if ((opcion == "Company")) {
          {
            String _name_1 = actor.getName();
            boolean _tripleNotEquals_1 = (_name_1 != null);
            if (_tripleNotEquals_1) {
              _builder.append("struct ");
              String _replace_3 = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
              _builder.append(_replace_3);
              _builder.append(" {");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("address idAdress;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string name;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string city;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string VAT;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("string email;");
              _builder.newLine();
              {
                String _firstUpper_1 = StringExtensions.toFirstUpper(actor.getName());
                String _plus_2 = ("Do you want to add more data for the " + _firstUpper_1);
                String _plus_3 = (_plus_2 + " struct?");
                int _showDialogConfirm_2 = this.wizardIU.showDialogConfirm(_plus_3);
                boolean _equals_4 = (_showDialogConfirm_2 == this.YES);
                if (_equals_4) {
                  _builder.append("\t");
                  final ArrayList<Property> properties_1 = this.wizardIU.generateJPanelProperty("Struct");
                  _builder.newLineIfNotEmpty();
                  {
                    for(final Property property_1 : properties_1) {
                      {
                        int _dimension_2 = property_1.getDimension();
                        boolean _equals_5 = (_dimension_2 == 1);
                        if (_equals_5) {
                          _builder.append("\t");
                          String _string_6 = property_1.getType().toString();
                          _builder.append(_string_6, "\t");
                          _builder.append("[] ");
                          String _string_7 = property_1.getName().toString();
                          _builder.append(_string_7, "\t");
                          _builder.append(";");
                          _builder.newLineIfNotEmpty();
                        } else {
                          int _dimension_3 = property_1.getDimension();
                          boolean _equals_6 = (_dimension_3 == 2);
                          if (_equals_6) {
                            _builder.append("\t");
                            String _string_8 = property_1.getType().toString();
                            _builder.append(_string_8, "\t");
                            _builder.append("[][]");
                            String _string_9 = property_1.getName().toString();
                            _builder.append(_string_9, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            _builder.append("\t");
                            String _string_10 = property_1.getType().toString();
                            _builder.append(_string_10, "\t");
                            _builder.append(" ");
                            String _string_11 = property_1.getName().toString();
                            _builder.append(_string_11, "\t");
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              }
              _builder.append("\t");
              _builder.append("bool enable");
              String _replace_4 = StringExtensions.toFirstUpper(nameValueObjectRight).trim().replace(" ", "");
              _builder.append(_replace_4, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
              {
                boolean _controlInsertPropertyAge_2 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                if (_controlInsertPropertyAge_2) {
                  _builder.append("\t");
                  _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                  _builder.newLine();
                }
              }
              _builder.append("}\t");
              _builder.newLine();
            }
          }
          {
            if ((opcion == "Personalized")) {
              {
                String _name_2 = actor.getName();
                boolean _tripleNotEquals_2 = (_name_2 != null);
                if (_tripleNotEquals_2) {
                  _builder.append("struct ");
                  String _replace_5 = StringExtensions.toFirstUpper(actor.getName().toString().trim()).replace(" ", "");
                  _builder.append(_replace_5);
                  _builder.append(" {");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("address idAdress;");
                  _builder.newLine();
                  {
                    String _firstUpper_2 = StringExtensions.toFirstUpper(actor.getName());
                    String _plus_4 = ("Do you want to add more data for the " + _firstUpper_2);
                    String _plus_5 = (_plus_4 + " struct?");
                    int _showDialogConfirm_3 = this.wizardIU.showDialogConfirm(_plus_5);
                    boolean _equals_7 = (_showDialogConfirm_3 == this.YES);
                    if (_equals_7) {
                      _builder.append("\t");
                      final ArrayList<Property> properties_2 = this.wizardIU.generateJPanelProperty("Struct");
                      _builder.newLineIfNotEmpty();
                      {
                        for(final Property property_2 : properties_2) {
                          {
                            int _dimension_4 = property_2.getDimension();
                            boolean _equals_8 = (_dimension_4 == 1);
                            if (_equals_8) {
                              _builder.append("\t");
                              String _string_12 = property_2.getType().toString();
                              _builder.append(_string_12, "\t");
                              _builder.append("[] ");
                              String _string_13 = property_2.getName().toString();
                              _builder.append(_string_13, "\t");
                              _builder.append(";");
                              _builder.newLineIfNotEmpty();
                            } else {
                              int _dimension_5 = property_2.getDimension();
                              boolean _equals_9 = (_dimension_5 == 2);
                              if (_equals_9) {
                                _builder.append("\t");
                                String _string_14 = property_2.getType().toString();
                                _builder.append(_string_14, "\t");
                                _builder.append("[][]");
                                String _string_15 = property_2.getName().toString();
                                _builder.append(_string_15, "\t");
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              } else {
                                _builder.append("\t");
                                String _string_16 = property_2.getType().toString();
                                _builder.append(_string_16, "\t");
                                _builder.append(" ");
                                String _string_17 = property_2.getName().toString();
                                _builder.append(_string_17, "\t");
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  _builder.append("\t");
                  _builder.append("bool enable");
                  String _replace_6 = StringExtensions.toFirstUpper(nameValueObjectRight).trim().replace(" ", "");
                  _builder.append(_replace_6, "\t");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                  {
                    boolean _controlInsertPropertyAge_3 = this.preProcessor.controlInsertPropertyAge(valueExchangePersonalized, actor.getName());
                    if (_controlInsertPropertyAge_3) {
                      _builder.append("\t");
                      _builder.append("uint age; //This property has been generated because an age restriction has been detected in the qa model to carry out the exchange of value between the actors involved.");
                      _builder.newLine();
                    }
                  }
                  _builder.append("}\t");
                  _builder.newLine();
                }
              }
            }
          }
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence generateEvent(final StimulusElement stimulus) {
    StringConcatenation _builder = new StringConcatenation();
    final String name = this.wizardIU.generateJPanelEvent();
    _builder.newLineIfNotEmpty();
    _builder.append("event ");
    String _trim = name.trim();
    _builder.append(_trim);
    _builder.append(" (string message);");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos de entrada:Ninguno
   * Descripci�n: Llama al asistente visual para crear un constructor
   * Argumento de salida: Ninguno
   */
  public CharSequence defineSmaCConstructor(final ContractPersonalized contract) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    {
      int _size = contract.getTokensContract().size();
      boolean _lessEqualsThan = (_size <= 0);
      if (_lessEqualsThan) {
        _builder.append("constructor() public{");
        _builder.newLine();
      } else {
        _builder.append("constructor() public ");
        String _createInheranceConstructors = this.preProcessor.createInheranceConstructors(contract);
        _builder.append(_createInheranceConstructors);
        _builder.append("{");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("owner = msg.sender; //The owner of the contract is the user who deployed it");
    _builder.newLine();
    {
      if ((this.expressionsConstructorIdentified != null)) {
        {
          for(final String expression : this.expressionsConstructorIdentified) {
            _builder.append("\t");
            _builder.append(expression, "\t");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Argumentos de entrada:Ninguno
   * Descripci�n: Llama al asistente visual para crear una funci�n a partir de los datos que introduzca el usuario (NO A PARTIR DE UN VALUE EXCHANGE)
   * Argumento de salida: Ninguno
   */
  public CharSequence defineSmaCFunction() {
    StringConcatenation _builder = new StringConcatenation();
    final Function function = this.wizardIU.generateJPanelFunction();
    _builder.newLineIfNotEmpty();
    boolean _add = this.functionsIdentified.add(function);
    _builder.append(_add);
    _builder.append(" ");
    _builder.append("\t");
    return _builder;
  }
  
  /**
   * Argumentos de entrada:El value exchange personalized que se va a asociar a una funci�n (Por cada value exchange del contrato --> 1 funci�n)
   * Descripci�n: Llama al asistente visual para crear una funci�n a partir de los datos de un value exchange personalized
   * Por �ltimo, la a�ade a la lista de las funciones que tiene el contrato
   * Argumento de salida: Ninguno
   */
  public void defineSmaCFunction(final ValueExchangePersonalized valueExchangePersonalized) {
    final Function function = this.wizardIU.generateJPanelFunction(valueExchangePersonalized);
    function.setValueExchangePersonalizedAssociated(valueExchangePersonalized);
    function.setModifiersIdentified(valueExchangePersonalized.getModifiersIdentified());
    this.preProcessor.addFunctionToListContractFunctions(this.functionsIdentified, function);
  }
  
  /**
   * Argumentos de entrada:Una funci�n que ha sido generada a partir de un value exchange personalized
   * Descripci�n:  Comprueba si la funci�n es payable a partir de si el atributo isPayable de esta es true o no para plasmar la funci�n el contrato con el modificador payable
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaCFunction(final Function function) {
    CharSequence _xifexpression = null;
    boolean _isPayable = function.isPayable();
    if (_isPayable) {
      _xifexpression = this.generateSmaCFunctionPayable(function);
    } else {
      _xifexpression = this.generateSmaCFunctionNoPayable(function);
    }
    return _xifexpression;
  }
  
  /**
   * Argumentos de entrada: Una funci�n que ha sido generada a partir de un value exchange personalized
   * Descripci�n:  Plasmar la funci�n el contrato SIN el modificador payable
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaCFunctionNoPayable(final Function function) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if (((function.getModifiersIdentified() != null) && (function.getActorReceipt() != ""))) {
        _builder.append("function ");
        String _name = function.getName();
        _builder.append(_name);
        _builder.append("(address ");
        String _replace = function.getActorReceipt().trim().replace(" ", "");
        _builder.append(_replace);
        _builder.append(") ");
        String _visibility = function.getVisibility();
        _builder.append(_visibility);
        _builder.append(" ");
        String _showModifiersIdentified = function.showModifiersIdentified();
        _builder.append(_showModifiersIdentified);
        _builder.append(" {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified = function.getExpressionIdentified();
          boolean _tripleNotEquals = (_expressionIdentified != null);
          if (_tripleNotEquals) {
            {
              ArrayList<String> _expressionIdentified_1 = function.getExpressionIdentified();
              for(final String expression : _expressionIdentified_1) {
                _builder.append("\t");
                _builder.append(expression, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
      }
    }
    {
      if ((((function.getModifiersIdentified() == null) && (function.getActorReceipt() != "")) && (function.getInputParamsIdentified() == null))) {
        _builder.append("function ");
        String _name_1 = function.getName();
        _builder.append(_name_1);
        _builder.append("(address ");
        String _replace_1 = function.getActorReceipt().trim().replace(" ", "");
        _builder.append(_replace_1);
        _builder.append(") ");
        String _visibility_1 = function.getVisibility();
        _builder.append(_visibility_1);
        _builder.append(" {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified_2 = function.getExpressionIdentified();
          boolean _tripleNotEquals_1 = (_expressionIdentified_2 != null);
          if (_tripleNotEquals_1) {
            {
              ArrayList<String> _expressionIdentified_3 = function.getExpressionIdentified();
              for(final String expression_1 : _expressionIdentified_3) {
                _builder.append("\t");
                _builder.append(expression_1, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
      }
    }
    {
      if ((((function.getModifiersIdentified() != null) && (function.getActorReceipt() == "")) && (function.getInputParamsIdentified() == null))) {
        _builder.append("function ");
        String _name_2 = function.getName();
        _builder.append(_name_2);
        _builder.append("() ");
        String _visibility_2 = function.getVisibility();
        _builder.append(_visibility_2);
        _builder.append(" ");
        String _showModifiersIdentified_1 = function.showModifiersIdentified();
        _builder.append(_showModifiersIdentified_1);
        _builder.append(" {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified_4 = function.getExpressionIdentified();
          boolean _tripleNotEquals_2 = (_expressionIdentified_4 != null);
          if (_tripleNotEquals_2) {
            {
              ArrayList<String> _expressionIdentified_5 = function.getExpressionIdentified();
              for(final String expression_2 : _expressionIdentified_5) {
                _builder.append("\t");
                _builder.append(expression_2, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
      }
    }
    {
      if ((((function.getModifiersIdentified() != null) && (function.getActorReceipt() == "")) && (function.getInputParamsIdentified() != null))) {
        _builder.append("function ");
        String _name_3 = function.getName();
        _builder.append(_name_3);
        _builder.append("(");
        String _type = function.getInputParamsIdentified().get(0).getType();
        _builder.append(_type);
        _builder.append(" ");
        String _name_4 = function.getInputParamsIdentified().get(0).getName();
        _builder.append(_name_4);
        _builder.append(") ");
        String _visibility_3 = function.getVisibility();
        _builder.append(_visibility_3);
        _builder.append(" ");
        String _showModifiersIdentified_2 = function.showModifiersIdentified();
        _builder.append(_showModifiersIdentified_2);
        _builder.append(" {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified_6 = function.getExpressionIdentified();
          boolean _tripleNotEquals_3 = (_expressionIdentified_6 != null);
          if (_tripleNotEquals_3) {
            {
              ArrayList<String> _expressionIdentified_7 = function.getExpressionIdentified();
              for(final String expression_3 : _expressionIdentified_7) {
                _builder.append("\t");
                _builder.append(expression_3, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
      }
    }
    {
      if ((((function.getModifiersIdentified() == null) && (function.getActorReceipt() == "")) && (function.getInputParamsIdentified() == null))) {
        _builder.append("function ");
        String _name_5 = function.getName();
        _builder.append(_name_5);
        _builder.append("() ");
        String _visibility_4 = function.getVisibility();
        _builder.append(_visibility_4);
        _builder.append(" {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified_8 = function.getExpressionIdentified();
          boolean _tripleNotEquals_4 = (_expressionIdentified_8 != null);
          if (_tripleNotEquals_4) {
            {
              ArrayList<String> _expressionIdentified_9 = function.getExpressionIdentified();
              for(final String expression_4 : _expressionIdentified_9) {
                _builder.append("\t");
                _builder.append(expression_4, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}\t");
        _builder.newLine();
        _builder.append("\t");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos de entrada: La propiedad/atributo a generar del smart contract
   * Descripci�n:  Plasmar el atributo del contrato seg�n los par�metros que contenga
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaCProperty(final Property property) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if (((property.getInitialization() == null) && (property.getComment() == ""))) {
        String _string = property.getType().toString();
        _builder.append(_string);
        _builder.append(" ");
        String _string_1 = property.getName().toString();
        _builder.append(_string_1);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      if (((property.getInitialization() != null) && (property.getComment() == ""))) {
        String _string_2 = property.getType().toString();
        _builder.append(_string_2);
        _builder.append(" ");
        String _string_3 = property.getName().toString();
        _builder.append(_string_3);
        _builder.append(" = ");
        String _string_4 = property.getInitialization().toString();
        _builder.append(_string_4);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      if (((property.getInitialization() == null) && (property.getComment() != ""))) {
        String _string_5 = property.getType().toString();
        _builder.append(_string_5);
        _builder.append(" ");
        String _string_6 = property.getName().toString();
        _builder.append(_string_6);
        _builder.append(";//");
        String _comment = property.getComment();
        _builder.append(_comment);
        _builder.newLineIfNotEmpty();
      }
    }
    {
      if (((property.getInitialization() != null) && (property.getComment() != ""))) {
        String _string_7 = property.getType().toString();
        _builder.append(_string_7);
        _builder.append(" ");
        String _string_8 = property.getName().toString();
        _builder.append(_string_8);
        _builder.append(" = ");
        String _string_9 = property.getInitialization().toString();
        _builder.append(_string_9);
        _builder.append(";//");
        String _comment_1 = property.getComment();
        _builder.append(_comment_1);
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos de entrada: Una funci�n que ha sido generada a partir de un value exchange personalized
   * Descripci�n:  Plasmar la funci�n el contrato seg�n los par�metros que contenga
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaCFunctionPayable(final Function function) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if ((((function.getModifiersIdentified() != null) && (function.getActorReceipt() != "")) && (function.getInputParamsIdentified() == null))) {
        _builder.append("function ");
        String _name = function.getName();
        _builder.append(_name);
        _builder.append("(address ");
        String _replace = function.getActorReceipt().trim().replace(" ", "");
        _builder.append(_replace);
        _builder.append(") ");
        String _visibility = function.getVisibility();
        _builder.append(_visibility);
        _builder.append(" ");
        String _showModifiersIdentified = function.showModifiersIdentified();
        _builder.append(_showModifiersIdentified);
        _builder.append(" payable {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified = function.getExpressionIdentified();
          boolean _tripleNotEquals = (_expressionIdentified != null);
          if (_tripleNotEquals) {
            {
              ArrayList<String> _expressionIdentified_1 = function.getExpressionIdentified();
              for(final String expression : _expressionIdentified_1) {
                _builder.append("\t");
                _builder.append(expression, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
      }
    }
    {
      if ((((function.getModifiersIdentified() == null) && (function.getActorReceipt() != "")) && (function.getInputParamsIdentified() == null))) {
        _builder.append("function ");
        String _name_1 = function.getName();
        _builder.append(_name_1);
        _builder.append("(address ");
        String _replace_1 = function.getActorReceipt().trim().replace(" ", "");
        _builder.append(_replace_1);
        _builder.append(") ");
        String _visibility_1 = function.getVisibility();
        _builder.append(_visibility_1);
        _builder.append(" payable {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified_2 = function.getExpressionIdentified();
          boolean _tripleNotEquals_1 = (_expressionIdentified_2 != null);
          if (_tripleNotEquals_1) {
            {
              ArrayList<String> _expressionIdentified_3 = function.getExpressionIdentified();
              for(final String expression_1 : _expressionIdentified_3) {
                _builder.append("\t");
                _builder.append(expression_1, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
      }
    }
    {
      if ((((function.getModifiersIdentified() != null) && (function.getActorReceipt() == "")) && (function.getInputParamsIdentified() == null))) {
        _builder.append("function ");
        String _name_2 = function.getName();
        _builder.append(_name_2);
        _builder.append("() ");
        String _visibility_2 = function.getVisibility();
        _builder.append(_visibility_2);
        _builder.append(" ");
        String _showModifiersIdentified_1 = function.showModifiersIdentified();
        _builder.append(_showModifiersIdentified_1);
        _builder.append(" payable{");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified_4 = function.getExpressionIdentified();
          boolean _tripleNotEquals_2 = (_expressionIdentified_4 != null);
          if (_tripleNotEquals_2) {
            {
              ArrayList<String> _expressionIdentified_5 = function.getExpressionIdentified();
              for(final String expression_2 : _expressionIdentified_5) {
                _builder.append("\t");
                _builder.append(expression_2, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}\t");
        _builder.newLine();
        _builder.newLine();
      }
    }
    {
      if ((((function.getModifiersIdentified() != null) && (function.getActorReceipt() == "")) && (function.getInputParamsIdentified() != null))) {
        _builder.append("function ");
        String _name_3 = function.getName();
        _builder.append(_name_3);
        _builder.append("(");
        String _type = function.getInputParamsIdentified().get(0).getType();
        _builder.append(_type);
        _builder.append(" ");
        String _name_4 = function.getInputParamsIdentified().get(0).getName();
        _builder.append(_name_4);
        _builder.append(") ");
        String _visibility_3 = function.getVisibility();
        _builder.append(_visibility_3);
        _builder.append(" ");
        String _showModifiersIdentified_2 = function.showModifiersIdentified();
        _builder.append(_showModifiersIdentified_2);
        _builder.append(" payable {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified_6 = function.getExpressionIdentified();
          boolean _tripleNotEquals_3 = (_expressionIdentified_6 != null);
          if (_tripleNotEquals_3) {
            {
              ArrayList<String> _expressionIdentified_7 = function.getExpressionIdentified();
              for(final String expression_3 : _expressionIdentified_7) {
                _builder.append("\t");
                _builder.append(expression_3, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}\t");
        _builder.newLine();
        _builder.newLine();
      }
    }
    {
      if ((((function.getModifiersIdentified() == null) && (function.getActorReceipt() == "")) && (function.getInputParamsIdentified() == null))) {
        _builder.append("function ");
        String _name_5 = function.getName();
        _builder.append(_name_5);
        _builder.append("() ");
        String _visibility_4 = function.getVisibility();
        _builder.append(_visibility_4);
        _builder.append(" payable {");
        _builder.newLineIfNotEmpty();
        {
          ArrayList<String> _expressionIdentified_8 = function.getExpressionIdentified();
          boolean _tripleNotEquals_4 = (_expressionIdentified_8 != null);
          if (_tripleNotEquals_4) {
            {
              ArrayList<String> _expressionIdentified_9 = function.getExpressionIdentified();
              for(final String expression_4 : _expressionIdentified_9) {
                _builder.append("\t");
                _builder.append(expression_4, "\t");
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("}\t");
        _builder.newLine();
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos de entrada: La pregunta de duraci�n de tiempo del modelo qa y el intercambio de valor que contiene esa pregunta
   * Descripci�n:  Crea una propiedad limitDate que ser� la fecha l�mite para llevar a cabo el intercambio de valor,
   * una funci�n modifyDeadline que tiene el modificar onlyOwner para modificar la propiedad limitData que recibe como par�metro la propiedad uint limit
   * Argumento de salida: Ninguno
   */
  public void generateSmaCEstablishDeadlineFunction(final TimeValueExchangeDurationQuestion timeValueExchangeQuestion, final ValueExchangePersonalized valueExchangePersonalized) {
    final Function function = new Function("modifyDeadline", "public", false, "", "");
    final Property inputParam = new Property();
    inputParam.setType("uint");
    inputParam.setName("limit");
    ArrayList<Property> _arrayList = new ArrayList<Property>();
    function.setInputParamsIdentified(_arrayList);
    ArrayList<String> _arrayList_1 = new ArrayList<String>();
    function.setExpressionIdentified(_arrayList_1);
    ArrayList<String> _arrayList_2 = new ArrayList<String>();
    function.setModifiersIdentified(_arrayList_2);
    function.getInputParamsIdentified().add(inputParam);
    final String unitTime = timeValueExchangeQuestion.getAnswerUnitTime().getLiteral();
    function.getExpressionIdentified().add("require(limit >= 1,\'Invalid number\')");
    function.getExpressionIdentified().add(("limit = limit * 1 " + unitTime));
    function.getExpressionIdentified().add("limitDate = now + limit");
    function.setValueExchangePersonalizedAssociated(valueExchangePersonalized);
    this.preProcessor.createPropertyAddressOwner(this.propertiesIdentified);
    function.getModifiersIdentified().add("OnlyOwner");
    this.preProcessor.addFunctionToListContractFunctions(this.functionsIdentified, function);
  }
  
  /**
   * Argumentos de entrada: La pregunta de duraci�n de tiempo del modelo qa y el intercambio de valor que contiene esa pregunta
   * Descripci�n:  Crea una propiedad limitDate que ser� la fecha l�mite para llevar a cabo el intercambio de valor,
   * una funci�n modifyDeadline que tiene el modificar onlyOwner para modificar la propiedad limitData que recibe como par�metro la propiedad uint limit
   * Argumento de salida: Ninguno
   */
  public void generateSmaCEstablishStartEnableFunction(final TimeStartValueExchangeQuestion timeValueExchangeQuestion, final ValueExchangePersonalized valueExchangePersonalized) {
    final Function function = new Function("modifyStartTime", "public", false, "", "");
    final Property inputParam = new Property();
    inputParam.setType("uint");
    inputParam.setName("limit");
    ArrayList<Property> _arrayList = new ArrayList<Property>();
    function.setInputParamsIdentified(_arrayList);
    ArrayList<String> _arrayList_1 = new ArrayList<String>();
    function.setExpressionIdentified(_arrayList_1);
    ArrayList<String> _arrayList_2 = new ArrayList<String>();
    function.setModifiersIdentified(_arrayList_2);
    function.getInputParamsIdentified().add(inputParam);
    final String unitTime = timeValueExchangeQuestion.getAnswerUnitTime().getLiteral();
    function.getExpressionIdentified().add("require(limit >= 1,\'Invalid number\')");
    function.getExpressionIdentified().add(("limit = limit * 1 " + unitTime));
    function.getExpressionIdentified().add("limitStart = now + limit");
    function.setValueExchangePersonalizedAssociated(valueExchangePersonalized);
    this.preProcessor.createPropertyAddressOwner(this.propertiesIdentified);
    function.getModifiersIdentified().add("OnlyOwner");
    this.preProcessor.addFunctionToListContractFunctions(this.functionsIdentified, function);
  }
  
  /**
   * Argumentos de entrada: La pregunta de si el intercambio de valor es duradero del modelo qa y el intercambio de valor que contiene esa pregunta
   * Descripci�n:  Crea una funcion selfdestruct junto con el modificador OnlyOwner para que el due�o del contrato pueda eliminar este
   * Argumento de salida: Ninguno
   */
  public void generateSmaCSelfdestructFunction(final RepeatValueExchangeQuestion repeatValueExchangeQuestion, final ValueExchangePersonalized valueExchangePersonalized) {
    final Function function = new Function("disableSmartContract", "public", false, "", "");
    final Property inputParam = new Property();
    inputParam.setType("address ");
    inputParam.setName("addressRefundBalanceContract");
    ArrayList<Property> _arrayList = new ArrayList<Property>();
    function.setInputParamsIdentified(_arrayList);
    ArrayList<String> _arrayList_1 = new ArrayList<String>();
    function.setExpressionIdentified(_arrayList_1);
    ArrayList<String> _arrayList_2 = new ArrayList<String>();
    function.setModifiersIdentified(_arrayList_2);
    function.getInputParamsIdentified().add(inputParam);
    function.getExpressionIdentified().add("require(addressRefundBalanceContract != address(0),\'Invalid address\')");
    function.getExpressionIdentified().add("selfdestruct(addressRefundBalanceContract)");
    function.setValueExchangePersonalizedAssociated(valueExchangePersonalized);
    this.preProcessor.createPropertyAddressOwner(this.propertiesIdentified);
    function.getModifiersIdentified().add("OnlyOwner");
    boolean enc = false;
    for (final Function functionIdentified : this.functionsIdentified) {
      boolean _equals = functionIdentified.getName().equals(function.getName());
      if (_equals) {
        enc = true;
      }
    }
    if ((enc == false)) {
      this.preProcessor.addFunctionToListContractFunctions(this.functionsIdentified, function);
    }
  }
  
  /**
   * Argumentos de entrada: La pregunta de la tasa sobre el intercambio de valor y el intercambio de valor asociado a esa pregunta
   * Descripci�n:  Crea una propiedad uint para la tasa y una propiedad address para recoger a qui�n cobra dicha tasa
   * Argumento de salida: Ninguno
   */
  public boolean generateControlFeeProperty(final TaxQuestion taxQuestion) {
    boolean _xblockexpression = false;
    {
      final Property propertyTax = new Property();
      final Property propertyCollectedTax = new Property();
      propertyTax.setName(taxQuestion.getAnswer());
      propertyTax.setType("uint");
      propertyTax.setComment("This attribute has been created to represent the tax to which an exchange of value is subject");
      propertyCollectedTax.setName(taxQuestion.getAnswerSubSentence());
      propertyCollectedTax.setType("address ");
      propertyCollectedTax.setComment("This attribute has been created to represent the beneficiary actor of the rate/tax to which an exchange of value is subject.");
      this.propertiesIdentified.add(propertyTax);
      _xblockexpression = this.propertiesIdentified.add(propertyCollectedTax);
    }
    return _xblockexpression;
  }
  
  /**
   * Argumentos de entrada: La pregunta de duraci�n de tiempo del modelo qa y el intercambio de valor que contiene esa pregunta
   * Descripci�n:  Crea una propiedad limitDate que ser� la fecha l�mite para llevar a cabo el intercambio de valor,
   * una funci�n modifyDeadline que tiene el modificar onlyOwner para modificar la propiedad limitData que recibe como par�metro la propiedad uint limit
   * Argumento de salida: Ninguno
   */
  public void generateControlTimeProperty(final TimeValueExchangeDurationQuestion timeValueExchangeQuestion, final ValueExchangePersonalized valueExchangePersonalized) {
    final Property propertyLimitDate = new Property();
    propertyLimitDate.setName("limitDate");
    propertyLimitDate.setType("uint");
    propertyLimitDate.setComment("This attribute/property has been generated based on the qa model question");
    this.propertiesIdentified.add(propertyLimitDate);
    int _answer = timeValueExchangeQuestion.getAnswer();
    String _plus = ("limitDate = now + " + Integer.valueOf(_answer));
    String _plus_1 = (_plus + " * 1 ");
    String _literal = timeValueExchangeQuestion.getAnswerUnitTime().getLiteral();
    String _plus_2 = (_plus_1 + _literal);
    this.expressionsConstructorIdentified.add(_plus_2);
    final String condition = "now < limitDate";
    this.preProcessor.defineSmaCModifier(this.modifiersIdentified, "deadlineOver", condition, "Deadline is over to carry out this action.");
    valueExchangePersonalized.getModifiersIdentified().add("DeadlineOver");
    this.generateSmaCEstablishDeadlineFunction(timeValueExchangeQuestion, valueExchangePersonalized);
  }
  
  /**
   * Argumentos de entrada: La pregunta de duraci�n de tiempo del modelo qa y el intercambio de valor que contiene esa pregunta
   * Descripci�n:  Crea una propiedad limitStart que ser� la fecha l�mite para llevar a cabo el intercambio de valor,
   * un modificador isEnable que verifica que el tiempo actual ha sobrepasado la fecha (Ej: venta de entradas tal d�a)
   * Argumento de salida: Ninguno
   */
  public void generateStartControlTimeProperty(final TimeStartValueExchangeQuestion timeValueExchangeQuestion, final ValueExchangePersonalized valueExchangePersonalized) {
    final Property propertyLimitDate = new Property();
    propertyLimitDate.setName("limitStart");
    propertyLimitDate.setType("uint");
    propertyLimitDate.setComment("This attribute/property has been generated based on the qa model question");
    this.propertiesIdentified.add(propertyLimitDate);
    int _answer = timeValueExchangeQuestion.getAnswer();
    String _plus = ("limitStart = now + " + Integer.valueOf(_answer));
    String _plus_1 = (_plus + " * 1 ");
    String _literal = timeValueExchangeQuestion.getAnswerUnitTime().getLiteral();
    String _plus_2 = (_plus_1 + _literal);
    this.expressionsConstructorIdentified.add(_plus_2);
    final String condition = "now >= limitStart";
    this.preProcessor.defineSmaCModifier(this.modifiersIdentified, "isEnable", condition, "The amount of time established to carry out this action has not passed.");
    valueExchangePersonalized.getModifiersIdentified().add("IsEnable");
    this.generateSmaCEstablishStartEnableFunction(timeValueExchangeQuestion, valueExchangePersonalized);
  }
  
  /**
   * Argumentos de entrada: La pregunta de la tasa/impuesto del modelo qa y el intercambio de valor que contiene esa pregunta
   * Descripci�n:  Crea una propiedad new que ser� la fecha l�mite para llevar a cabo el intercambio de valor,
   * un modificador isEnable que verifica que el tiempo actual ha sobrepasado la fecha (Ej: venta de entradas tal d�a)
   * Argumento de salida: Ninguno
   */
  public void generateFeeActorReceiptFunction(final TaxQuestion taxQuestion, final ValueExchangePersonalized valueExchangePersonalized) {
    String _name = valueExchangePersonalized.getValueObject().getName();
    String _plus = ("collectFee" + _name);
    final Function functionGetFee = this.preProcessor.createFunction(_plus, "private", false, "", "");
    String _name_1 = valueExchangePersonalized.getValueObject().getName();
    String _plus_1 = ("modifyFee" + _name_1);
    final Function functionSetFee = this.preProcessor.createFunction(_plus_1, "public", false, "", "");
    final Function functionSetCollectorFee = this.preProcessor.createFunction("registerCollectorFee", "public", false, "", "");
    String _answerSubSentence = taxQuestion.getAnswerSubSentence();
    String _plus_2 = (_answerSubSentence + ".transfer(");
    String _answer = taxQuestion.getAnswer();
    String _plus_3 = (_plus_2 + _answer);
    final String expressionGetFee = (_plus_3 + ")");
    String _answer_1 = taxQuestion.getAnswer();
    final String expressionSetFee = (_answer_1 + " = newFeeValue");
    String _answerSubSentence_1 = taxQuestion.getAnswerSubSentence();
    final String expressionSetCollectorFee = (_answerSubSentence_1 + " = newCollector");
    ArrayList<String> _arrayList = new ArrayList<String>();
    functionGetFee.setExpressionIdentified(_arrayList);
    ArrayList<String> _arrayList_1 = new ArrayList<String>();
    functionSetFee.setExpressionIdentified(_arrayList_1);
    ArrayList<String> _arrayList_2 = new ArrayList<String>();
    functionSetCollectorFee.setExpressionIdentified(_arrayList_2);
    functionGetFee.getExpressionIdentified().add(expressionGetFee);
    functionSetFee.getExpressionIdentified().add("require(newFeeValue >= 0,\'Invalid number\')");
    functionSetFee.getExpressionIdentified().add(expressionSetFee);
    functionSetCollectorFee.getExpressionIdentified().add("require(newCollector != address(0),\'Invalid address\')");
    functionSetCollectorFee.getExpressionIdentified().add(expressionSetCollectorFee);
    final Property propertyNewFee = new Property();
    propertyNewFee.setName("newFeeValue");
    propertyNewFee.setType("uint");
    final Property propertyNewCollector = new Property();
    propertyNewCollector.setName("newCollector");
    propertyNewCollector.setType("address ");
    ArrayList<Property> _arrayList_3 = new ArrayList<Property>();
    functionSetFee.setInputParamsIdentified(_arrayList_3);
    ArrayList<String> _arrayList_4 = new ArrayList<String>();
    functionSetFee.setModifiersIdentified(_arrayList_4);
    ArrayList<Property> _arrayList_5 = new ArrayList<Property>();
    functionSetCollectorFee.setInputParamsIdentified(_arrayList_5);
    ArrayList<String> _arrayList_6 = new ArrayList<String>();
    functionSetCollectorFee.setModifiersIdentified(_arrayList_6);
    functionSetFee.getInputParamsIdentified().add(propertyNewFee);
    functionSetCollectorFee.getInputParamsIdentified().add(propertyNewCollector);
    ArrayList<String> _modifiersIdentified = functionSetFee.getModifiersIdentified();
    String _answerSubSentence_2 = taxQuestion.getAnswerSubSentence();
    String _plus_4 = ("Only" + _answerSubSentence_2);
    String _plus_5 = (_plus_4 + "CollectFee");
    _modifiersIdentified.add(_plus_5);
    functionSetCollectorFee.getModifiersIdentified().add("OnlyOwner");
    String _answerSubSentence_3 = taxQuestion.getAnswerSubSentence();
    String _plus_6 = ("Only" + _answerSubSentence_3);
    String _plus_7 = (_plus_6 + "CollectFee");
    String _answerSubSentence_4 = taxQuestion.getAnswerSubSentence();
    String _plus_8 = (_answerSubSentence_4 + " == msg.sender");
    String _answerSubSentence_5 = taxQuestion.getAnswerSubSentence();
    String _plus_9 = ("Only " + _answerSubSentence_5);
    String _plus_10 = (_plus_9 + " can collect the fee");
    this.preProcessor.defineSmaCModifier(this.modifiersIdentified, _plus_7, _plus_8, _plus_10);
    this.preProcessor.addFunctionToListContractFunctions(this.functionsIdentified, functionGetFee);
    this.preProcessor.addFunctionToListContractFunctions(this.functionsIdentified, functionSetFee);
    this.preProcessor.addFunctionToListContractFunctions(this.functionsIdentified, functionSetCollectorFee);
  }
  
  /**
   * Argumentos de entrada: La pregunta de la edad del modelo qa y el intercambio de valor que contiene esa pregunta
   * Descripci�n:  Crea un modificador IsAdult que comprueba si la edad del usuario es > o igual a la indicada
   * Argumento de salida: Ninguno
   */
  public CharSequence generateControlLegalAge(final AgeQuestion ageQuestion, final ValueExchangePersonalized valueExchangePersonalized) {
    StringConcatenation _builder = new StringConcatenation();
    String condition = "";
    _builder.newLineIfNotEmpty();
    {
      boolean _equals = valueExchangePersonalized.geteObjectActorSend().eClass().getName().equals("ElementaryActor");
      if (_equals) {
        String _replace = StringExtensions.toFirstUpper(valueExchangePersonalized.geteObjectActorSend().getName()).replace(" ", "");
        String _plus = ("actor_" + _replace);
        String _plus_1 = (_plus + ".age >= ");
        String _condition = condition = _plus_1;
        _builder.append(_condition);
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        String _condition_1 = condition;
        int _answer = ageQuestion.getAnswer();
        String _plus_2 = condition = (_condition_1 + Integer.valueOf(_answer));
        _builder.append(_plus_2, "    ");
        _builder.newLineIfNotEmpty();
      } else {
        boolean _equals_1 = valueExchangePersonalized.geteObjectActorSend().eClass().getName().equals("MarketSegment");
        if (_equals_1) {
          String _replace_1 = StringExtensions.toFirstUpper(valueExchangePersonalized.geteObjectActorSend().getName()).replace(" ", "");
          String _plus_3 = ("actorSet_" + _replace_1);
          String _plus_4 = (_plus_3 + "[msg.sender].age >= ");
          String _condition_2 = condition = _plus_4;
          _builder.append(_condition_2);
          _builder.newLineIfNotEmpty();
          _builder.append("    ");
          String _condition_3 = condition;
          int _answer_1 = ageQuestion.getAnswer();
          String _plus_5 = condition = (_condition_3 + Integer.valueOf(_answer_1));
          _builder.append(_plus_5, "    ");
          _builder.newLineIfNotEmpty();
        }
      }
    }
    String _replace_2 = StringExtensions.toFirstUpper(valueExchangePersonalized.getActorSend().toString().trim()).replace(" ", "");
    String _plus_6 = ("isAdult" + _replace_2);
    this.preProcessor.defineSmaCModifier(this.modifiersIdentified, _plus_6, condition, "The user does not meet the legal age to carry out this action.");
    _builder.newLineIfNotEmpty();
    ArrayList<String> _modifiersIdentified = valueExchangePersonalized.getModifiersIdentified();
    String _replace_3 = StringExtensions.toFirstUpper(valueExchangePersonalized.getActorSend().toString().trim()).replace(" ", "");
    String _plus_7 = ("IsAdult" + _replace_3);
    boolean _add = _modifiersIdentified.add(_plus_7);
    _builder.append(_add);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos de entrada: La pregunta de la tasa/impuesto del modelo qa y el intercambio de valor que contiene esa pregunta
   * Descripci�n:  Crea una propiedad new que ser� la fecha l�mite para llevar a cabo el intercambio de valor,
   * un modificador isEnable que verifica que el tiempo actual ha sobrepasado la fecha (Ej: venta de entradas tal d�a)
   * Argumento de salida: Ninguno
   */
  public void generateControlMinimumAmount(final MinimumAmountQuestion minimumAmountQuestion, final ValueExchangePersonalized valueExchangePersonalized) {
    final Property property = new Property();
    property.setType("uint");
    property.setName(valueExchangePersonalized.getValueObject().getName());
    property.setInitialization(Integer.valueOf(minimumAmountQuestion.getAnswer()).toString());
    property.setComment("This attribute/property has been generated based on the qa model question");
    this.propertiesIdentified.add(property);
    String _name = property.getName();
    final String condition = ("msg.sender.balance > " + _name);
    this.preProcessor.defineSmaCModifier(this.modifiersIdentified, "hasTheMinimumBalance", condition, "The user\'s balance is less than the minimum amount required.");
    valueExchangePersonalized.getModifiersIdentified().add("HasTheMinimumBalance");
    String _name_1 = valueExchangePersonalized.getValueObject().getName();
    String _plus = ("setMinimumAmount" + _name_1);
    final Function functionSetMinimumAmount = this.preProcessor.createFunction(_plus, "public", false, "", "");
    String _name_2 = property.getName();
    final String expressionSetMinimumAmount = (_name_2 + " = newMinimumAmount");
    final Property propertyNewFee = new Property();
    propertyNewFee.setName("newMinimumAmount");
    propertyNewFee.setType("uint");
    ArrayList<Property> _arrayList = new ArrayList<Property>();
    functionSetMinimumAmount.setInputParamsIdentified(_arrayList);
    functionSetMinimumAmount.getInputParamsIdentified().add(propertyNewFee);
    ArrayList<String> _arrayList_1 = new ArrayList<String>();
    functionSetMinimumAmount.setExpressionIdentified(_arrayList_1);
    ArrayList<String> _arrayList_2 = new ArrayList<String>();
    functionSetMinimumAmount.setModifiersIdentified(_arrayList_2);
    functionSetMinimumAmount.getModifiersIdentified().add("OnlyOwner");
    functionSetMinimumAmount.getExpressionIdentified().add(expressionSetMinimumAmount);
    this.preProcessor.addFunctionToListContractFunctions(this.functionsIdentified, functionSetMinimumAmount);
  }
  
  /**
   * Argumentos de entrada: Los intercambios de valor identificados ya con sus preguntas asociadas
   * Descripci�n:  Por cada pregunta que contenga el intercambio de valor va creando informaci�n para asociarla al contrato
   * Argumento de salida: Ninguno
   */
  public void processInfoModelQA(final ArrayList<ValueExchangePersonalized> valuesExchangeIdentified, final ContractPersonalized contractPersonalized) {
    for (final ValueExchangePersonalized valueExchangeIdentified : valuesExchangeIdentified) {
      ValueExchange _valueExchangeSmaCQA = valueExchangeIdentified.getValueExchangeSmaCQA();
      boolean _tripleNotEquals = (_valueExchangeSmaCQA != null);
      if (_tripleNotEquals) {
        ArrayList<String> _arrayList = new ArrayList<String>();
        valueExchangeIdentified.setModifiersIdentified(_arrayList);
        LegalQuestion _legalQuestion = valueExchangeIdentified.getValueExchangeSmaCQA().getLegalQuestion();
        boolean _tripleNotEquals_1 = (_legalQuestion != null);
        if (_tripleNotEquals_1) {
          AgeQuestion _ageQuestion = valueExchangeIdentified.getValueExchangeSmaCQA().getLegalQuestion().getAgeQuestion();
          boolean _tripleNotEquals_2 = (_ageQuestion != null);
          if (_tripleNotEquals_2) {
            valueExchangeIdentified.setInsertPropertyAge(true);
            this.generateControlLegalAge(valueExchangeIdentified.getValueExchangeSmaCQA().getLegalQuestion().getAgeQuestion(), valueExchangeIdentified);
          }
          TaxQuestion _taxQuestion = valueExchangeIdentified.getValueExchangeSmaCQA().getLegalQuestion().getTaxQuestion();
          boolean _tripleNotEquals_3 = (_taxQuestion != null);
          if (_tripleNotEquals_3) {
            this.generateControlFeeProperty(valueExchangeIdentified.getValueExchangeSmaCQA().getLegalQuestion().getTaxQuestion());
            this.generateFeeActorReceiptFunction(valueExchangeIdentified.getValueExchangeSmaCQA().getLegalQuestion().getTaxQuestion(), valueExchangeIdentified);
          }
        }
        DataQuestion _dataQuestion = valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion();
        boolean _tripleNotEquals_4 = (_dataQuestion != null);
        if (_tripleNotEquals_4) {
          ValueObjectQuestion _valueObjectTypeValueExchange = valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getValueObjectTypeValueExchange();
          boolean _tripleNotEquals_5 = (_valueObjectTypeValueExchange != null);
          if (_tripleNotEquals_5) {
            boolean _equals = valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getValueObjectTypeValueExchange().getClass().equals(ValueObjectTokenQuestionImpl.class);
            if (_equals) {
              boolean _controlCreateERCToken = this.preProcessor.controlCreateERCToken(valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getValueObjectTypeValueExchange(), this.registerTokens);
              boolean _equals_1 = (_controlCreateERCToken == false);
              if (_equals_1) {
                this.token = this.preProcessor.createERCToken(this.inputResourceToken, this.fsaToken, this.contextToken, valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getValueObjectTypeValueExchange());
                contractPersonalized.getTokensContract().add(this.token);
                this.registerTokens.add(this.token);
              } else {
                String message = "A smart contract has already been created before to represent the digital asset with name and symbol. Are you sure you want to create a new file with the same parameters?";
                int opcion = this.wizardIU.showDialogConfirm(message);
                if ((opcion == 0)) {
                  this.token = this.preProcessor.createERCToken(this.inputResourceToken, this.fsaToken, this.contextToken, valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getValueObjectTypeValueExchange());
                  contractPersonalized.getTokensContract().add(this.token);
                  this.registerTokens.add(this.token);
                }
              }
            } else {
              boolean _equals_2 = valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getValueObjectTypeValueExchange().getClass().equals(ValueObjectTangibleQuestionImpl.class);
              if (_equals_2) {
                this.structsValueObjectIdentified.add(this.preProcessor.createStructValueObject(valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getValueObjectTypeValueExchange(), valueExchangeIdentified));
              } else {
                this.insertEnableRightValueObject = true;
              }
            }
          }
          TimeValueExchangeDurationQuestion _timeDurationValueExchange = valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getTimeDurationValueExchange();
          boolean _tripleNotEquals_6 = (_timeDurationValueExchange != null);
          if (_tripleNotEquals_6) {
            this.generateControlTimeProperty(valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getTimeDurationValueExchange(), valueExchangeIdentified);
          }
          TimeStartValueExchangeQuestion _timeStartValueExchange = valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getTimeStartValueExchange();
          boolean _tripleNotEquals_7 = (_timeStartValueExchange != null);
          if (_tripleNotEquals_7) {
            this.generateStartControlTimeProperty(valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getTimeStartValueExchange(), valueExchangeIdentified);
          }
          RepeatValueExchangeQuestion _repeatValueExchange = valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getRepeatValueExchange();
          boolean _tripleNotEquals_8 = (_repeatValueExchange != null);
          if (_tripleNotEquals_8) {
            String _answer = valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getRepeatValueExchange().getAnswer();
            boolean _tripleNotEquals_9 = (_answer != "yes");
            if (_tripleNotEquals_9) {
              this.generateSmaCSelfdestructFunction(valueExchangeIdentified.getValueExchangeSmaCQA().getDataQuestion().getRepeatValueExchange(), valueExchangeIdentified);
            }
          }
        }
        EconomyQuestion _economyQuestion = valueExchangeIdentified.getValueExchangeSmaCQA().getEconomyQuestion();
        boolean _tripleNotEquals_10 = (_economyQuestion != null);
        if (_tripleNotEquals_10) {
          MinimumAmountQuestion _minimumAmountQuestion = valueExchangeIdentified.getValueExchangeSmaCQA().getEconomyQuestion().getMinimumAmountQuestion();
          boolean _tripleNotEquals_11 = (_minimumAmountQuestion != null);
          if (_tripleNotEquals_11) {
            this.generateControlMinimumAmount(valueExchangeIdentified.getValueExchangeSmaCQA().getEconomyQuestion().getMinimumAmountQuestion(), valueExchangeIdentified);
          }
        }
      }
    }
  }
  
  /**
   * Argumentos de entrada: Nombre del Token
   * Descripci�n:  Crea la funci�n para poder acu�ar nuevos tokens
   * Argumento de salida: Ninguno
   */
  public CharSequence generateMintFunction(final String nameToken) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("function mint");
    _builder.append(nameToken);
    _builder.append("(address to, uint amount) external{");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("require(msg.sender == owner, \"Only owner mint new amount tokens\");");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("require(to != address(0), \"ERC20: mint to the zero address\");");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("_mint(to,amount);");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Argumentos de entrada: Nombre del Token
   * Descripci�n:  Crea la funci�n para poder quemar tokens en circulaci�n
   * Argumento de salida: Ninguno
   */
  public CharSequence generateBurnFunction(final String nameToken) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("function burn");
    _builder.append(nameToken);
    _builder.append("(uint amount) external{");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("require(msg.sender == owner, \"Only owner burn new amount tokens\");");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("require(msg.sender != address(0), \"Invalid address\");");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("require(amount > 0, \"Amount can�t be 0 or less\");");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("_burn(msg.sender,amount);");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Argumentos de entrada:El primero (input) es el modelo e3value
   * Descripci�n: Proceso de transformaci�n de un e3value sin modelo qa (Questions & Answers) -->  Modelo SmaC (.sce extension)
   * Argumento de salida: Ninguno
   */
  @Override
  public void doGenerate(final Resource input, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    final Resource input2 = input;
    System.out.println(IteratorExtensions.<EObject>head(input.getAllContents()).toString());
    input2.toString();
    EObject _head = IteratorExtensions.<EObject>head(input.getAllContents());
    final E3ValueDiagram root = ((E3ValueDiagram) _head);
    String _string = input.getURI().toString();
    int _lastIndexOf = input.getURI().toString().lastIndexOf("/");
    int _plus = (_lastIndexOf + 1);
    final String nameFile = _string.substring(_plus, input.getURI().toString().lastIndexOf("."));
    final String pathBlockly = input.getURI().path().toString().replace(".e3value", ".sce");
    this.initialMessage = (((("Welcome to the transformation process between e3value model to SmaC model" + "\n") + 
      "Input e3value model: ") + nameFile) + ".e3value\n");
    fsa.generateFile(pathBlockly, this.generateSmaC_File(root, input, nameFile));
  }
  
  /**
   * Argumentos de entrada:El primero (input) es el modelo e3value y el �ltimo (inputSmaCQA) es el modelo qa
   * Descripci�n: Proceso de transformaci�n de un e3value con modelo qa (Questions & Answers) -->  Modelo SmaC (.sce extension)
   * Argumento de salida: Ninguno
   */
  public void doGenerateSmaC(final Resource input, final IFileSystemAccess2 fsa, final IGeneratorContext context, final Resource inputSmaCQA) {
    EObject _head = IteratorExtensions.<EObject>head(input.getAllContents());
    final E3ValueDiagram rootE3value = ((E3ValueDiagram) _head);
    String _string = input.getURI().toString();
    int _lastIndexOf = input.getURI().toString().lastIndexOf("/");
    int _plus = (_lastIndexOf + 1);
    final String nameFileSmaC = _string.substring(_plus, input.getURI().toString().lastIndexOf("."));
    final String pathSmaC = input.getURI().path().toString().replace(".e3value", ".sce");
    EObject _head_1 = IteratorExtensions.<EObject>head(inputSmaCQA.getAllContents());
    final Model rootSmaCQA = ((Model) _head_1);
    this.pathSmaCQA = inputSmaCQA.getURI().path().toString();
    String _string_1 = inputSmaCQA.getURI().toString();
    int _lastIndexOf_1 = inputSmaCQA.getURI().toString().lastIndexOf("/");
    int _plus_1 = (_lastIndexOf_1 + 1);
    final String nameFileQA = _string_1.substring(_plus_1, inputSmaCQA.getURI().toString().lastIndexOf("."));
    this.fsaToken = fsa;
    this.contextToken = context;
    this.inputResourceToken = input;
    this.initialMessage = ((((((("Welcome to the transformation process between e3value models and the qa model associated with a SmaC model" + "\n") + 
      "Input e3value model: ") + nameFileSmaC) + ".e3value\n") + 
      "Input qa model: ") + nameFileQA) + ".qa");
    fsa.generateFile(pathSmaC, this.generateSmaC_File(rootE3value, input, nameFileSmaC, rootSmaCQA));
  }
}
