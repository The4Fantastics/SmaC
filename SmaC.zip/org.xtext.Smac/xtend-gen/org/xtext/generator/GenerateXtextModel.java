package org.xtext.generator;

import com.google.common.base.Objects;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.xtext.generator.GeneratorTextModelFile;
import org.xtext.smaC.AbstractContract;
import org.xtext.smaC.Assert;
import org.xtext.smaC.Clause;
import org.xtext.smaC.Company;
import org.xtext.smaC.Condition;
import org.xtext.smaC.Constructor;
import org.xtext.smaC.Contract;
import org.xtext.smaC.DeclarationFunctionAbstractContract;
import org.xtext.smaC.DeclarationFunctionInterface;
import org.xtext.smaC.DoWhileLoop;
import org.xtext.smaC.Element;
import org.xtext.smaC.Event;
import org.xtext.smaC.File;
import org.xtext.smaC.ForLoop;
import org.xtext.smaC.Import;
import org.xtext.smaC.InputParam;
import org.xtext.smaC.Interface;
import org.xtext.smaC.Library;
import org.xtext.smaC.Mapping;
import org.xtext.smaC.MappingDeclaration;
import org.xtext.smaC.Modifier;
import org.xtext.smaC.OutputParam;
import org.xtext.smaC.PersonalizedStruct;
import org.xtext.smaC.Properties;
import org.xtext.smaC.Restriction;
import org.xtext.smaC.RestrictionClause;
import org.xtext.smaC.RestrictionGas;
import org.xtext.smaC.StorageData;
import org.xtext.smaC.UnDeterminedLoop;
import org.xtext.smaC.User;
import org.xtext.smaC.Visibility;
import org.xtext.smaC.WhileLoop;

@SuppressWarnings("all")
public class GenerateXtextModel {
  private final GeneratorTextModelFile loader = new GeneratorTextModelFile();
  
  /**
   * Argumentos de entrada:El objeto de la clase e3value diagram (raiz del e3value), el propio modelo e3value, y el nombre del fichero.
   * Descripci�n: Analiza previamente los port out para crear los intercambios de valor, luego se completa la informaci�n de estos con los port in y posteriormente se a�aden a un contrato
   * A continuaci�n, se presenta el asistente de creaci�n para personalizar un poco la transformaci�n y generar el fichero a partir del e3value
   * Argumento de salida: Ninguno
   */
  public CharSequence generateSmaC_File(final File file) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("pragma solidity ");
    String _symbolComparationVersions = this.getSymbolComparationVersions(file);
    _builder.append(_symbolComparationVersions);
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    {
      int _size = file.getImports().size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        _builder.append("\t");
        CharSequence _generateImport = this.generateImport(file.getImports());
        _builder.append(_generateImport, "\t");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_1 = file.getLibrary().size();
      boolean _greaterThan_1 = (_size_1 > 0);
      if (_greaterThan_1) {
        _builder.append("\t");
        CharSequence _generateLibrary = this.generateLibrary(file.getLibrary());
        _builder.append(_generateLibrary, "\t");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_2 = file.getInterfaces().size();
      boolean _greaterThan_2 = (_size_2 > 0);
      if (_greaterThan_2) {
        _builder.append("\t");
        CharSequence _generateInterface = this.generateInterface(file.getInterfaces());
        _builder.append(_generateInterface, "\t");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_3 = file.getAbstractContracts().size();
      boolean _greaterThan_3 = (_size_3 > 0);
      if (_greaterThan_3) {
        _builder.append("\t");
        CharSequence _generateAbstractContract = this.generateAbstractContract(file.getAbstractContracts());
        _builder.append(_generateAbstractContract, "\t");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_4 = file.getContracts().size();
      boolean _greaterThan_4 = (_size_4 > 0);
      if (_greaterThan_4) {
        {
          EList<Contract> _contracts = file.getContracts();
          for(final Contract contract : _contracts) {
            {
              int _size_5 = contract.getSuperType().size();
              boolean _greaterThan_5 = (_size_5 > 0);
              if (_greaterThan_5) {
                _builder.append("contract ");
                String _name = contract.getName();
                _builder.append(_name);
                _builder.append(" is ");
                String _generateHeredityElementsContract = this.generateHeredityElementsContract(contract.getSuperType());
                _builder.append(_generateHeredityElementsContract);
                _builder.append(" {");
                _builder.newLineIfNotEmpty();
              } else {
                _builder.append("contract ");
                String _name_1 = contract.getName();
                _builder.append(_name_1);
                _builder.append(" {");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_6 = contract.getLocalEnumerators().size();
              boolean _greaterThan_6 = (_size_6 > 0);
              if (_greaterThan_6) {
                _builder.append("\t");
                String _generateEnum = this.generateEnum(contract.getLocalEnumerators());
                _builder.append(_generateEnum, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_7 = contract.getLocalProperties().size();
              boolean _greaterThan_7 = (_size_7 > 0);
              if (_greaterThan_7) {
                _builder.append("\t");
                String _generateProperties = this.generateProperties(contract.getLocalProperties());
                _builder.append(_generateProperties, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_8 = contract.getLocalMappingProperties().size();
              boolean _greaterThan_8 = (_size_8 > 0);
              if (_greaterThan_8) {
                _builder.append("\t");
                CharSequence _generateMappingProperties = this.generateMappingProperties(contract.getLocalMappingProperties());
                _builder.append(_generateMappingProperties, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_9 = contract.getStructs().size();
              boolean _greaterThan_9 = (_size_9 > 0);
              if (_greaterThan_9) {
                _builder.append("\t");
                CharSequence _generatePersonalizedStruct = this.generatePersonalizedStruct(contract.getStructs());
                _builder.append(_generatePersonalizedStruct, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_10 = contract.getStructsUser().size();
              boolean _greaterThan_10 = (_size_10 > 0);
              if (_greaterThan_10) {
                _builder.append("\t");
                CharSequence _generateUserStruct = this.generateUserStruct(contract.getStructsUser());
                _builder.append(_generateUserStruct, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_11 = contract.getStructsCompany().size();
              boolean _greaterThan_11 = (_size_11 > 0);
              if (_greaterThan_11) {
                _builder.append("\t");
                CharSequence _generateCompanyStruct = this.generateCompanyStruct(contract.getStructsCompany());
                _builder.append(_generateCompanyStruct, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_12 = contract.getConstructors().size();
              boolean _greaterThan_12 = (_size_12 > 0);
              if (_greaterThan_12) {
                _builder.append("\t");
                String _generateEnum_1 = this.generateEnum(contract.getLocalEnumerators());
                _builder.append(_generateEnum_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_13 = contract.getModifiers().size();
              boolean _greaterThan_13 = (_size_13 > 0);
              if (_greaterThan_13) {
                _builder.append("\t");
                CharSequence _generateModifier = this.generateModifier(contract.getModifiers());
                _builder.append(_generateModifier, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_14 = contract.getEvents().size();
              boolean _greaterThan_14 = (_size_14 > 0);
              if (_greaterThan_14) {
                _builder.append("\t");
                CharSequence _generateEvent = this.generateEvent(contract.getEvents());
                _builder.append(_generateEvent, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_15 = contract.getClauses().size();
              boolean _greaterThan_15 = (_size_15 > 0);
              if (_greaterThan_15) {
                _builder.append("\t");
                CharSequence _generateClause = this.generateClause(contract.getClauses());
                _builder.append(_generateClause, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("}");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de elementos que hereda el contrato
   * Descripci�n: Genera un string con el nombre de los elementos que hereda
   * Par�metro de salida: El string con los elementos que hereda
   */
  public String generateHeredityElementsContract(final EList<Element> elements) {
    String stringElementsHeredity = "";
    for (final Element element : elements) {
      int _size = elements.size();
      int _minus = (_size - 1);
      boolean _equals = element.equals(elements.get(_minus));
      boolean _not = (!_equals);
      if (_not) {
        String _stringElementsHeredity = stringElementsHeredity;
        String _name = element.getName();
        String _plus = (_name + ", ");
        stringElementsHeredity = (_stringElementsHeredity + _plus);
      } else {
        String _stringElementsHeredity_1 = stringElementsHeredity;
        String _name_1 = element.getName();
        stringElementsHeredity = (_stringElementsHeredity_1 + _name_1);
      }
    }
    return stringElementsHeredity;
  }
  
  /**
   * Par�metros de entrada: El objeto File que es la raiz del metamodelo y contiene los dem�s elementos
   * Descripci�n: Obtiene los datos de la versi�n contenida en File para plasmarla
   * Par�metro de salida: Los datos de la versi�n del fichero del smart contract
   */
  public String getSymbolComparationVersions(final File file) {
    String symbol = "";
    String _symbol = file.getVersion().getSymbol();
    boolean _tripleNotEquals = (_symbol != null);
    if (_tripleNotEquals) {
      symbol = file.getVersion().getSymbol();
      boolean _equals = symbol.equals("greater");
      if (_equals) {
        symbol = ">";
      } else {
        boolean _equals_1 = symbol.equals("greater_equal");
        if (_equals_1) {
          symbol = ">=";
        }
      }
    }
    String _numberVersion2 = file.getVersion().getNumberVersion2();
    boolean _tripleNotEquals_1 = (_numberVersion2 != null);
    if (_tripleNotEquals_1) {
      boolean _equals_2 = file.getVersion().getNumberVersion2().toString().equals("0.0.0");
      boolean _not = (!_equals_2);
      if (_not) {
        String symbolComparation = file.getVersion().getSymbolComparation();
        boolean _equals_3 = symbolComparation.equals("less");
        if (_equals_3) {
          symbolComparation = "<";
        }
        boolean _equals_4 = symbolComparation.equals("greater");
        if (_equals_4) {
          symbolComparation = ">";
        }
        boolean _equals_5 = symbolComparation.equals("less_equal");
        if (_equals_5) {
          symbolComparation = "<=";
        }
        String _numberVersion = file.getVersion().getNumberVersion();
        String _plus = (symbol + _numberVersion);
        String _plus_1 = (_plus + symbolComparation);
        String _numberVersion2_1 = file.getVersion().getNumberVersion2();
        return (_plus_1 + _numberVersion2_1);
      }
    } else {
      String _string = file.getVersion().getNumberVersion().toString();
      return (symbol + _string);
    }
    return null;
  }
  
  /**
   * Par�metros de entrada: La lista de imports que contiene el elemento File que representa un fichero que contiene smart contracts
   * Descripci�n: Genera en la plantilla los imports contenidos en File
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateImport(final EList<Import> imports) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Import importSmaC : imports) {
        {
          String _alias = importSmaC.getAlias();
          boolean _tripleNotEquals = (_alias != null);
          if (_tripleNotEquals) {
            _builder.append("import ");
            String _name = importSmaC.getName();
            _builder.append(_name);
            _builder.append(" as ");
            String _alias_1 = importSmaC.getAlias();
            _builder.append(_alias_1);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("import ");
            String _name_1 = importSmaC.getName();
            _builder.append(_name_1);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada:La lista de librer�as que contiene el elemento File que representa un fichero que contiene smart contracts
   * Descripci�n:Genera en la plantilla las librer�as contenidos en File
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateLibrary(final EList<Library> libraries) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Library library : libraries) {
        _builder.append("library ");
        String _name = library.getName();
        _builder.append(_name);
        _builder.append(" {");
        _builder.newLineIfNotEmpty();
        {
          int _size = library.getStructs().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("\t");
            CharSequence _generatePersonalizedStruct = this.generatePersonalizedStruct(library.getStructs());
            _builder.append(_generatePersonalizedStruct, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_1 = library.getEnums().size();
          boolean _greaterThan_1 = (_size_1 > 0);
          if (_greaterThan_1) {
            _builder.append("\t");
            String _generateEnum = this.generateEnum(library.getEnums());
            _builder.append(_generateEnum, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_2 = library.getFunctions().size();
          boolean _greaterThan_2 = (_size_2 > 0);
          if (_greaterThan_2) {
            _builder.append("\t");
            CharSequence _generateClause = this.generateClause(library.getFunctions());
            _builder.append(_generateClause, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada:La lista de interfaces que contiene el elemento File que representa un fichero que contiene smart contracts
   * Descripci�n:Genera en la plantilla los imports contenidos en File
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateInterface(final EList<Interface> interfaces) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Interface interfaceSmaC : interfaces) {
        _builder.append("interface ");
        String _name = interfaceSmaC.getName();
        _builder.append(_name);
        _builder.append(" {");
        _builder.newLineIfNotEmpty();
        {
          int _size = interfaceSmaC.getInterfaceEvents().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("\t");
            CharSequence _generateEvent = this.generateEvent(interfaceSmaC.getInterfaceEvents());
            _builder.append(_generateEvent, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_1 = interfaceSmaC.getInterfaceFunction().size();
          boolean _greaterThan_1 = (_size_1 > 0);
          if (_greaterThan_1) {
            _builder.append("\t");
            CharSequence _generateInterfaceClause = this.generateInterfaceClause(interfaceSmaC.getInterfaceFunction());
            _builder.append(_generateInterfaceClause, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de abstracts contracts que contiene el elemento File que representa un fichero que contiene smart contracts
   * Descripci�n: Genera en la plantilla los abstracts contracts contenidos en File junto con su contenido asociado
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateAbstractContract(final EList<AbstractContract> abstractContracts) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final AbstractContract abstractContract : abstractContracts) {
        {
          int _size = abstractContract.getSuperType().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("abstract contract ");
            String _name = abstractContract.getName();
            _builder.append(_name);
            _builder.append(" is ");
            String _generateHeredityElementsContract = this.generateHeredityElementsContract(abstractContract.getSuperType());
            _builder.append(_generateHeredityElementsContract);
            _builder.append("{");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("abstract contract ");
            String _name_1 = abstractContract.getName();
            _builder.append(_name_1);
            _builder.append("{");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_1 = abstractContract.getEvents().size();
          boolean _greaterThan_1 = (_size_1 > 0);
          if (_greaterThan_1) {
            CharSequence _generateEvent = this.generateEvent(abstractContract.getEvents());
            _builder.append(_generateEvent);
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_2 = abstractContract.getClauses().size();
          boolean _greaterThan_2 = (_size_2 > 0);
          if (_greaterThan_2) {
            CharSequence _generateAbstractClause = this.generateAbstractClause(abstractContract.getClauses());
            _builder.append(_generateAbstractClause);
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de par�metros de entrada del elemento que recibe esta funci�n
   * Descripci�n: Genera un string con los datos de los par�metros de entrada del elemento que se est� procesando
   * Par�metro de salida: El string que recoge todos los par�metros de entrada del elemento
   */
  public String generateInputParams(final EList<InputParam> inputParams) {
    String stringInputParams = "";
    for (final InputParam inputParam : inputParams) {
      {
        String _array = inputParam.getArray();
        boolean _tripleNotEquals = (_array != null);
        if (_tripleNotEquals) {
          String _stringInputParams = stringInputParams;
          String _type = inputParam.getType();
          String _plus = (_type + " ");
          String _array_1 = inputParam.getArray();
          String _plus_1 = (_plus + _array_1);
          String _plus_2 = (_plus_1 + " ");
          String _valueInput = inputParam.getValueInput();
          String _plus_3 = (_plus_2 + _valueInput);
          stringInputParams = (_stringInputParams + _plus_3);
        } else {
          String _stringInputParams_1 = stringInputParams;
          String _type_1 = inputParam.getType();
          String _plus_4 = (_type_1 + " ");
          String _valueInput_1 = inputParam.getValueInput();
          String _plus_5 = (_plus_4 + _valueInput_1);
          stringInputParams = (_stringInputParams_1 + _plus_5);
        }
        int _size = inputParams.size();
        int _minus = (_size - 1);
        boolean _equals = inputParam.equals(inputParams.get(_minus));
        boolean _not = (!_equals);
        if (_not) {
          String _stringInputParams_2 = stringInputParams;
          stringInputParams = (_stringInputParams_2 + ", ");
        }
      }
    }
    return stringInputParams;
  }
  
  /**
   * Par�metros de entrada: La lista de par�metros de salida de una funci�n que recibe esta funci�n
   * Descripci�n: Genera un string con los datos de los par�metros de salida del elemento que se est� procesando
   * Par�metro de salida: El string que recoge todos los par�metros de salida del elemento
   */
  public String generateOutputParams(final EList<OutputParam> outputParams) {
    String stringOutputParams = "";
    for (final OutputParam outputParam : outputParams) {
      {
        String _value = outputParam.getValue();
        boolean _tripleNotEquals = (_value != null);
        if (_tripleNotEquals) {
          String _type = outputParam.getType();
          boolean _tripleNotEquals_1 = (_type != null);
          if (_tripleNotEquals_1) {
            String _array = outputParam.getArray();
            boolean _tripleNotEquals_2 = (_array != null);
            if (_tripleNotEquals_2) {
              String _stringOutputParams = stringOutputParams;
              String _type_1 = outputParam.getType();
              String _plus = (_type_1 + " ");
              String _array_1 = outputParam.getArray();
              String _plus_1 = (_plus + _array_1);
              String _plus_2 = (_plus_1 + " ");
              String _value_1 = outputParam.getValue();
              String _plus_3 = (_plus_2 + _value_1);
              stringOutputParams = (_stringOutputParams + _plus_3);
            } else {
              String _stringOutputParams_1 = stringOutputParams;
              String _type_2 = outputParam.getType();
              String _plus_4 = (_type_2 + " ");
              String _value_2 = outputParam.getValue();
              String _plus_5 = (_plus_4 + _value_2);
              stringOutputParams = (_stringOutputParams_1 + _plus_5);
            }
          } else {
            String _stringOutputParams_2 = stringOutputParams;
            String _value_3 = outputParam.getValue();
            stringOutputParams = (_stringOutputParams_2 + _value_3);
          }
        } else {
          String _type_3 = outputParam.getType();
          boolean _tripleNotEquals_3 = (_type_3 != null);
          if (_tripleNotEquals_3) {
            String _array_2 = outputParam.getArray();
            boolean _tripleNotEquals_4 = (_array_2 != null);
            if (_tripleNotEquals_4) {
              String _stringOutputParams_3 = stringOutputParams;
              String _type_4 = outputParam.getType();
              String _plus_6 = (_type_4 + " ");
              String _array_3 = outputParam.getArray();
              String _plus_7 = (_plus_6 + _array_3);
              stringOutputParams = (_stringOutputParams_3 + _plus_7);
            } else {
              String _stringOutputParams_4 = stringOutputParams;
              String _type_5 = outputParam.getType();
              stringOutputParams = (_stringOutputParams_4 + _type_5);
            }
          }
        }
        int _length = ((Object[])Conversions.unwrapArray(outputParams, Object.class)).length;
        int _minus = (_length - 1);
        boolean _equals = outputParam.equals(outputParams.get(_minus));
        boolean _not = (!_equals);
        if (_not) {
          String _stringOutputParams_5 = stringOutputParams;
          stringOutputParams = (_stringOutputParams_5 + ", ");
        }
      }
    }
    return stringOutputParams;
  }
  
  /**
   * Par�metros de entrada: La lista de enum del elemento File que recibe esta funci�n
   * Descripci�n: Genera un string con los datos de los enumeradores y sus valores
   * Par�metro de salida: El string que recoge todos los enumeradores y sus valores
   */
  public String generateEnum(final EList<org.xtext.smaC.Enum> enums) {
    String stringEnumerators = "";
    String stringEnumeratorValues = "{";
    for (final org.xtext.smaC.Enum enumerator : enums) {
      {
        EList<String> _values = enumerator.getValues();
        for (final String value : _values) {
          EList<String> _values_1 = enumerator.getValues();
          int _size = enumerator.getValues().size();
          int _minus = (_size - 1);
          boolean _equals = value.equals(_values_1.get(_minus));
          boolean _not = (!_equals);
          if (_not) {
            String _stringEnumeratorValues = stringEnumeratorValues;
            stringEnumeratorValues = (_stringEnumeratorValues + (value + ","));
          } else {
            String _stringEnumeratorValues_1 = stringEnumeratorValues;
            stringEnumeratorValues = (_stringEnumeratorValues_1 + value);
          }
        }
        String _stringEnumeratorValues_2 = stringEnumeratorValues;
        stringEnumeratorValues = (_stringEnumeratorValues_2 + ("}" + ";"));
        String _stringEnumerators = stringEnumerators;
        String _nameEnumerator = enumerator.getNameEnumerator();
        String _plus = ("enum " + _nameEnumerator);
        String _plus_1 = (_plus + " ");
        String _plus_2 = (_plus_1 + stringEnumeratorValues);
        String _plus_3 = (_plus_2 + "\n");
        stringEnumerators = (_stringEnumerators + _plus_3);
      }
    }
    return stringEnumerators;
  }
  
  /**
   * Par�metros de entrada: La lista de structs personalizados del elemento File
   * Descripci�n: Genera una plantilla con los datos del struct que se han definido en el elemento File
   * Par�metro de salida: Ninguno
   */
  public CharSequence generatePersonalizedStruct(final EList<PersonalizedStruct> personalizedStructs) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final PersonalizedStruct struct : personalizedStructs) {
        _builder.append("struct ");
        String _string = struct.getName().toString();
        _builder.append(_string);
        _builder.append("{");
        _builder.newLineIfNotEmpty();
        {
          int _size = struct.getProperties().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("\t");
            String _generateProperties = this.generateProperties(struct.getProperties());
            _builder.append(_generateProperties, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_1 = struct.getMapping().size();
          boolean _greaterThan_1 = (_size_1 > 0);
          if (_greaterThan_1) {
            _builder.append("\t");
            CharSequence _generateMappingProperties = this.generateMappingProperties(struct.getMapping());
            _builder.append(_generateMappingProperties, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_2 = struct.getStructs().size();
          boolean _greaterThan_2 = (_size_2 > 0);
          if (_greaterThan_2) {
            _builder.append("\t");
            Object _generatePersonalizedStruct = this.generatePersonalizedStruct(struct.getStructs());
            _builder.append(_generatePersonalizedStruct, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de user structs  del elemento File
   * Descripci�n: Genera una plantilla con los datos de todos los user struct que se han definido en el elemento File junto con sus propiedades
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateUserStruct(final EList<User> userStructs) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final User struct : userStructs) {
        _builder.append("struct User{");
        _builder.newLine();
        {
          int _size = struct.getProperties().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("\t");
            String _generateProperties = this.generateProperties(struct.getProperties());
            _builder.append(_generateProperties, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_1 = struct.getMapping().size();
          boolean _greaterThan_1 = (_size_1 > 0);
          if (_greaterThan_1) {
            _builder.append("\t");
            CharSequence _generateMappingProperties = this.generateMappingProperties(struct.getMapping());
            _builder.append(_generateMappingProperties, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_2 = struct.getStructs().size();
          boolean _greaterThan_2 = (_size_2 > 0);
          if (_greaterThan_2) {
            _builder.append("\t");
            CharSequence _generatePersonalizedStruct = this.generatePersonalizedStruct(struct.getStructs());
            _builder.append(_generatePersonalizedStruct, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de company structs  del elemento File
   * Descripci�n: Genera una plantilla con los datos de todos los company struct que se han definido en el elemento File junto con sus propiedades
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateCompanyStruct(final EList<Company> companyStructs) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Company struct : companyStructs) {
        _builder.append("struct Company{\t\t\t");
        _builder.newLine();
        {
          int _size = struct.getProperties().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("\t");
            String _generateProperties = this.generateProperties(struct.getProperties());
            _builder.append(_generateProperties, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_1 = struct.getMapping().size();
          boolean _greaterThan_1 = (_size_1 > 0);
          if (_greaterThan_1) {
            _builder.append("\t");
            CharSequence _generateMappingProperties = this.generateMappingProperties(struct.getMapping());
            _builder.append(_generateMappingProperties, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_2 = struct.getStructs().size();
          boolean _greaterThan_2 = (_size_2 > 0);
          if (_greaterThan_2) {
            _builder.append("\t");
            CharSequence _generatePersonalizedStruct = this.generatePersonalizedStruct(struct.getStructs());
            _builder.append(_generatePersonalizedStruct, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La propiedad que se est� procesando en la funci�n "generateProperties"
   * Descripci�n: Obtiene los datos de la propiedad y genera un string seg�n los datos que en encuentre en ella
   * Par�metro de salida: El string con los datos de la propiedad
   */
  public String generateProperties(final EList<Properties> properties) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Properties property : properties) {
        {
          String _constant = property.getConstant();
          boolean _tripleNotEquals = (_constant != null);
          if (_tripleNotEquals) {
            {
              String _constant_1 = property.getConstant();
              boolean _equals = Objects.equal(_constant_1, "constant");
              if (_equals) {
                {
                  StorageData _storageData = property.getStorageData();
                  boolean _tripleNotEquals_1 = (_storageData != null);
                  if (_tripleNotEquals_1) {
                    {
                      Visibility _visibility = property.getVisibility();
                      boolean _tripleNotEquals_2 = (_visibility != null);
                      if (_tripleNotEquals_2) {
                        {
                          String _array = property.getArray();
                          boolean _tripleNotEquals_3 = (_array != null);
                          if (_tripleNotEquals_3) {
                            {
                              String _inicialization = property.getInicialization();
                              boolean _tripleNotEquals_4 = (_inicialization != null);
                              if (_tripleNotEquals_4) {
                                String _type = property.getType();
                                _builder.append(_type);
                                _builder.append(" ");
                                String _array_1 = property.getArray();
                                _builder.append(_array_1);
                                _builder.append(" ");
                                String _constant_2 = property.getConstant();
                                _builder.append(_constant_2);
                                _builder.append(" ");
                                String _string = property.getVisibility().getLiteral().toString();
                                _builder.append(_string);
                                _builder.append(" ");
                                String _string_1 = property.getStorageData().getLiteral().toString();
                                _builder.append(_string_1);
                                _builder.append(" ");
                                String _name = property.getName();
                                _builder.append(_name);
                                _builder.append(" = ");
                                String _inicialization_1 = property.getInicialization();
                                _builder.append(_inicialization_1);
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              } else {
                                String _type_1 = property.getType();
                                _builder.append(_type_1);
                                _builder.append(" ");
                                String _array_2 = property.getArray();
                                _builder.append(_array_2);
                                _builder.append(" ");
                                String _constant_3 = property.getConstant();
                                _builder.append(_constant_3);
                                _builder.append(" ");
                                String _string_2 = property.getVisibility().getLiteral().toString();
                                _builder.append(_string_2);
                                _builder.append(" ");
                                String _string_3 = property.getStorageData().getLiteral().toString();
                                _builder.append(_string_3);
                                _builder.append(" ");
                                String _name_1 = property.getName();
                                _builder.append(_name_1);
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          } else {
                            {
                              String _inicialization_2 = property.getInicialization();
                              boolean _tripleNotEquals_5 = (_inicialization_2 != null);
                              if (_tripleNotEquals_5) {
                                String _type_2 = property.getType();
                                _builder.append(_type_2);
                                _builder.append(" ");
                                String _constant_4 = property.getConstant();
                                _builder.append(_constant_4);
                                _builder.append(" ");
                                String _string_4 = property.getVisibility().getLiteral().toString();
                                _builder.append(_string_4);
                                _builder.append(" ");
                                String _string_5 = property.getStorageData().getLiteral().toString();
                                _builder.append(_string_5);
                                _builder.append(" ");
                                String _name_2 = property.getName();
                                _builder.append(_name_2);
                                _builder.append(" = ");
                                String _inicialization_3 = property.getInicialization();
                                _builder.append(_inicialization_3);
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              } else {
                                String _type_3 = property.getType();
                                _builder.append(_type_3);
                                _builder.append(" ");
                                String _constant_5 = property.getConstant();
                                _builder.append(_constant_5);
                                _builder.append(" ");
                                String _string_6 = property.getVisibility().getLiteral().toString();
                                _builder.append(_string_6);
                                _builder.append(" ");
                                String _string_7 = property.getStorageData().getLiteral().toString();
                                _builder.append(_string_7);
                                _builder.append(" ");
                                String _name_3 = property.getName();
                                _builder.append(_name_3);
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    {
                      Visibility _visibility_1 = property.getVisibility();
                      boolean _tripleNotEquals_6 = (_visibility_1 != null);
                      if (_tripleNotEquals_6) {
                        {
                          String _array_3 = property.getArray();
                          boolean _tripleNotEquals_7 = (_array_3 != null);
                          if (_tripleNotEquals_7) {
                            {
                              String _inicialization_4 = property.getInicialization();
                              boolean _tripleNotEquals_8 = (_inicialization_4 != null);
                              if (_tripleNotEquals_8) {
                                String _type_4 = property.getType();
                                _builder.append(_type_4);
                                _builder.append(" ");
                                String _constant_6 = property.getConstant();
                                _builder.append(_constant_6);
                                _builder.append(" ");
                                String _array_4 = property.getArray();
                                _builder.append(_array_4);
                                _builder.append(" ");
                                String _string_8 = property.getVisibility().getLiteral().toString();
                                _builder.append(_string_8);
                                _builder.append(" ");
                                String _name_4 = property.getName();
                                _builder.append(_name_4);
                                _builder.append(" = ");
                                String _inicialization_5 = property.getInicialization();
                                _builder.append(_inicialization_5);
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              } else {
                                String _type_5 = property.getType();
                                _builder.append(_type_5);
                                _builder.append(" ");
                                String _constant_7 = property.getConstant();
                                _builder.append(_constant_7);
                                _builder.append(" ");
                                String _array_5 = property.getArray();
                                _builder.append(_array_5);
                                _builder.append(" ");
                                String _string_9 = property.getVisibility().getLiteral().toString();
                                _builder.append(_string_9);
                                _builder.append(" ");
                                String _name_5 = property.getName();
                                _builder.append(_name_5);
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          } else {
                            {
                              String _inicialization_6 = property.getInicialization();
                              boolean _tripleNotEquals_9 = (_inicialization_6 != null);
                              if (_tripleNotEquals_9) {
                                String _type_6 = property.getType();
                                _builder.append(_type_6);
                                _builder.append(" ");
                                String _constant_8 = property.getConstant();
                                _builder.append(_constant_8);
                                _builder.append(" ");
                                String _name_6 = property.getName();
                                _builder.append(_name_6);
                                _builder.append(" = ");
                                String _inicialization_7 = property.getInicialization();
                                _builder.append(_inicialization_7);
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              } else {
                                String _type_7 = property.getType();
                                _builder.append(_type_7);
                                _builder.append(" ");
                                String _constant_9 = property.getConstant();
                                _builder.append(_constant_9);
                                _builder.append(" ");
                                String _name_7 = property.getName();
                                _builder.append(_name_7);
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            {
              StorageData _storageData_1 = property.getStorageData();
              boolean _tripleNotEquals_10 = (_storageData_1 != null);
              if (_tripleNotEquals_10) {
                {
                  Visibility _visibility_2 = property.getVisibility();
                  boolean _tripleNotEquals_11 = (_visibility_2 != null);
                  if (_tripleNotEquals_11) {
                    {
                      String _array_6 = property.getArray();
                      boolean _tripleNotEquals_12 = (_array_6 != null);
                      if (_tripleNotEquals_12) {
                        {
                          String _inicialization_8 = property.getInicialization();
                          boolean _tripleNotEquals_13 = (_inicialization_8 != null);
                          if (_tripleNotEquals_13) {
                            String _type_8 = property.getType();
                            _builder.append(_type_8);
                            _builder.append(" ");
                            String _array_7 = property.getArray();
                            _builder.append(_array_7);
                            _builder.append(" ");
                            String _string_10 = property.getVisibility().getLiteral().toString();
                            _builder.append(_string_10);
                            _builder.append(" ");
                            String _string_11 = property.getStorageData().getLiteral().toString();
                            _builder.append(_string_11);
                            _builder.append(" ");
                            String _name_8 = property.getName();
                            _builder.append(_name_8);
                            _builder.append(" = ");
                            String _inicialization_9 = property.getInicialization();
                            _builder.append(_inicialization_9);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            String _type_9 = property.getType();
                            _builder.append(_type_9);
                            _builder.append(" ");
                            String _array_8 = property.getArray();
                            _builder.append(_array_8);
                            _builder.append(" ");
                            String _string_12 = property.getVisibility().getLiteral().toString();
                            _builder.append(_string_12);
                            _builder.append(" ");
                            String _string_13 = property.getStorageData().getLiteral().toString();
                            _builder.append(_string_13);
                            _builder.append(" ");
                            String _name_9 = property.getName();
                            _builder.append(_name_9);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      } else {
                        {
                          String _inicialization_10 = property.getInicialization();
                          boolean _tripleNotEquals_14 = (_inicialization_10 != null);
                          if (_tripleNotEquals_14) {
                            String _type_10 = property.getType();
                            _builder.append(_type_10);
                            _builder.append(" ");
                            String _string_14 = property.getVisibility().getLiteral().toString();
                            _builder.append(_string_14);
                            _builder.append(" ");
                            String _string_15 = property.getStorageData().getLiteral().toString();
                            _builder.append(_string_15);
                            _builder.append(" ");
                            String _name_10 = property.getName();
                            _builder.append(_name_10);
                            _builder.append(" = ");
                            String _inicialization_11 = property.getInicialization();
                            _builder.append(_inicialization_11);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            String _type_11 = property.getType();
                            _builder.append(_type_11);
                            _builder.append(" ");
                            String _string_16 = property.getVisibility().getLiteral().toString();
                            _builder.append(_string_16);
                            _builder.append(" ");
                            String _string_17 = property.getStorageData().getLiteral().toString();
                            _builder.append(_string_17);
                            _builder.append(" ");
                            String _name_11 = property.getName();
                            _builder.append(_name_11);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                {
                  Visibility _visibility_3 = property.getVisibility();
                  boolean _tripleNotEquals_15 = (_visibility_3 != null);
                  if (_tripleNotEquals_15) {
                    {
                      String _array_9 = property.getArray();
                      boolean _tripleNotEquals_16 = (_array_9 != null);
                      if (_tripleNotEquals_16) {
                        {
                          String _inicialization_12 = property.getInicialization();
                          boolean _tripleNotEquals_17 = (_inicialization_12 != null);
                          if (_tripleNotEquals_17) {
                            String _type_12 = property.getType();
                            _builder.append(_type_12);
                            _builder.append(" ");
                            String _array_10 = property.getArray();
                            _builder.append(_array_10);
                            _builder.append(" ");
                            String _string_18 = property.getVisibility().getLiteral().toString();
                            _builder.append(_string_18);
                            _builder.append(" ");
                            String _name_12 = property.getName();
                            _builder.append(_name_12);
                            _builder.append(" = ");
                            String _inicialization_13 = property.getInicialization();
                            _builder.append(_inicialization_13);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            String _type_13 = property.getType();
                            _builder.append(_type_13);
                            _builder.append(" ");
                            String _array_11 = property.getArray();
                            _builder.append(_array_11);
                            _builder.append(" ");
                            String _string_19 = property.getVisibility().getLiteral().toString();
                            _builder.append(_string_19);
                            _builder.append(" ");
                            String _name_13 = property.getName();
                            _builder.append(_name_13);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      } else {
                        {
                          String _inicialization_14 = property.getInicialization();
                          boolean _tripleNotEquals_18 = (_inicialization_14 != null);
                          if (_tripleNotEquals_18) {
                            String _type_14 = property.getType();
                            _builder.append(_type_14);
                            _builder.append(" ");
                            String _name_14 = property.getName();
                            _builder.append(_name_14);
                            _builder.append(" = ");
                            String _inicialization_15 = property.getInicialization();
                            _builder.append(_inicialization_15);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          } else {
                            String _type_15 = property.getType();
                            _builder.append(_type_15);
                            _builder.append(" ");
                            String _name_15 = property.getName();
                            _builder.append(_name_15);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return _builder.toString();
  }
  
  /**
   * Par�metros de entrada: La lista de mapping properties que tiene el elemento que se est� procesando
   * Descripci�n: Genera la plantilla con los datos de los mapping properties que recorre el bucle
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateMappingProperties(final EList<Mapping> mappingProperties) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Mapping mappingProperty : mappingProperties) {
        {
          MappingDeclaration _valueIdentifier = mappingProperty.getType().getValueIdentifier();
          boolean _tripleNotEquals = (_valueIdentifier != null);
          if (_tripleNotEquals) {
            {
              if (((mappingProperty.getInicialization() == null) || (mappingProperty.getInicialization() == ""))) {
                {
                  StorageData _storageData = mappingProperty.getStorageData();
                  boolean _tripleEquals = (_storageData == null);
                  if (_tripleEquals) {
                    {
                      String _array = mappingProperty.getArray();
                      boolean _tripleEquals_1 = (_array == null);
                      if (_tripleEquals_1) {
                        String _generateMappingDeclaration = this.loader.generateMappingDeclaration(mappingProperty.getType());
                        _builder.append(_generateMappingDeclaration);
                        _builder.append(" ");
                        String _literal = mappingProperty.getVisibility().getLiteral();
                        _builder.append(_literal);
                        _builder.append(" ");
                        String _nameMapping = mappingProperty.getNameMapping();
                        _builder.append(_nameMapping);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      } else {
                        String _generateMappingDeclaration_1 = this.loader.generateMappingDeclaration(mappingProperty.getType());
                        _builder.append(_generateMappingDeclaration_1);
                        _builder.append(" ");
                        String _literal_1 = mappingProperty.getVisibility().getLiteral();
                        _builder.append(_literal_1);
                        _builder.append(" ");
                        String _array_1 = mappingProperty.getArray();
                        _builder.append(_array_1);
                        _builder.append(" ");
                        String _nameMapping_1 = mappingProperty.getNameMapping();
                        _builder.append(_nameMapping_1);
                        _builder.append(";\t");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  } else {
                    {
                      String _array_2 = mappingProperty.getArray();
                      boolean _tripleEquals_2 = (_array_2 == null);
                      if (_tripleEquals_2) {
                        String _generateMappingDeclaration_2 = this.loader.generateMappingDeclaration(mappingProperty.getType());
                        _builder.append(_generateMappingDeclaration_2);
                        _builder.append(" ");
                        String _array_3 = mappingProperty.getArray();
                        _builder.append(_array_3);
                        _builder.append(" ");
                        String _literal_2 = mappingProperty.getVisibility().getLiteral();
                        _builder.append(_literal_2);
                        _builder.append(" ");
                        String _literal_3 = mappingProperty.getStorageData().getLiteral();
                        _builder.append(_literal_3);
                        _builder.append(" ");
                        String _nameMapping_2 = mappingProperty.getNameMapping();
                        _builder.append(_nameMapping_2);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      } else {
                        String _generateMappingDeclaration_3 = this.loader.generateMappingDeclaration(mappingProperty.getType());
                        _builder.append(_generateMappingDeclaration_3);
                        _builder.append(" ");
                        String _array_4 = mappingProperty.getArray();
                        _builder.append(_array_4);
                        _builder.append(" ");
                        String _literal_4 = mappingProperty.getVisibility().getLiteral();
                        _builder.append(_literal_4);
                        _builder.append(" ");
                        String _literal_5 = mappingProperty.getStorageData().getLiteral();
                        _builder.append(_literal_5);
                        _builder.append(" ");
                        String _nameMapping_3 = mappingProperty.getNameMapping();
                        _builder.append(_nameMapping_3);
                        _builder.append(";\t");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
          } else {
            {
              if (((mappingProperty.getInicialization() == null) || (mappingProperty.getInicialization() == ""))) {
                {
                  StorageData _storageData_1 = mappingProperty.getStorageData();
                  boolean _tripleEquals_3 = (_storageData_1 == null);
                  if (_tripleEquals_3) {
                    {
                      String _array_5 = mappingProperty.getArray();
                      boolean _tripleEquals_4 = (_array_5 == null);
                      if (_tripleEquals_4) {
                        String _generateMappingDeclaration_4 = this.loader.generateMappingDeclaration(mappingProperty.getType());
                        _builder.append(_generateMappingDeclaration_4);
                        _builder.append(" ");
                        String _literal_6 = mappingProperty.getVisibility().getLiteral();
                        _builder.append(_literal_6);
                        _builder.append(" ");
                        String _nameMapping_4 = mappingProperty.getNameMapping();
                        _builder.append(_nameMapping_4);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      } else {
                        String _generateMappingDeclaration_5 = this.loader.generateMappingDeclaration(mappingProperty.getType());
                        _builder.append(_generateMappingDeclaration_5);
                        _builder.append(" ");
                        String _literal_7 = mappingProperty.getVisibility().getLiteral();
                        _builder.append(_literal_7);
                        _builder.append(" ");
                        String _array_6 = mappingProperty.getArray();
                        _builder.append(_array_6);
                        _builder.append(" ");
                        String _nameMapping_5 = mappingProperty.getNameMapping();
                        _builder.append(_nameMapping_5);
                        _builder.append(";\t");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  } else {
                    {
                      String _array_7 = mappingProperty.getArray();
                      boolean _tripleEquals_5 = (_array_7 == null);
                      if (_tripleEquals_5) {
                        String _generateMappingDeclaration_6 = this.loader.generateMappingDeclaration(mappingProperty.getType());
                        _builder.append(_generateMappingDeclaration_6);
                        _builder.append(" ");
                        String _array_8 = mappingProperty.getArray();
                        _builder.append(_array_8);
                        _builder.append(" ");
                        String _literal_8 = mappingProperty.getVisibility().getLiteral();
                        _builder.append(_literal_8);
                        _builder.append(" ");
                        String _literal_9 = mappingProperty.getStorageData().getLiteral();
                        _builder.append(_literal_9);
                        _builder.append(" ");
                        String _nameMapping_6 = mappingProperty.getNameMapping();
                        _builder.append(_nameMapping_6);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      } else {
                        String _generateMappingDeclaration_7 = this.loader.generateMappingDeclaration(mappingProperty.getType());
                        _builder.append(_generateMappingDeclaration_7);
                        _builder.append(" ");
                        String _array_9 = mappingProperty.getArray();
                        _builder.append(_array_9);
                        _builder.append(" ");
                        String _literal_10 = mappingProperty.getVisibility().getLiteral();
                        _builder.append(_literal_10);
                        _builder.append(" ");
                        String _literal_11 = mappingProperty.getStorageData().getLiteral();
                        _builder.append(_literal_11);
                        _builder.append(" ");
                        String _nameMapping_7 = mappingProperty.getNameMapping();
                        _builder.append(_nameMapping_7);
                        _builder.append(";\t");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de funciones que tiene una interfaz del elemento File
   * Descripci�n: Genera la plantilla con los datos de la declaraci�n de la funci�n
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateInterfaceClause(final EList<DeclarationFunctionInterface> interfaceclauses) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final DeclarationFunctionInterface clause : interfaceclauses) {
        {
          int _size = clause.getInputParams().size();
          boolean _equals = (_size == 0);
          if (_equals) {
            {
              int _size_1 = clause.getOutputParams().size();
              boolean _greaterThan = (_size_1 > 0);
              if (_greaterThan) {
                {
                  String _modifier = clause.getModifier();
                  boolean _tripleNotEquals = (_modifier != null);
                  if (_tripleNotEquals) {
                    _builder.append("function ");
                    String _name = clause.getName();
                    _builder.append(_name);
                    _builder.append("() ");
                    String _modifier_1 = clause.getModifier();
                    _builder.append(_modifier_1);
                    _builder.append(" returns(");
                    String _generateOutputParams = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams);
                    _builder.append(") returns(");
                    String _generateOutputParams_1 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_1);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_1 = clause.getName();
                    _builder.append(_name_1);
                    _builder.append("() returns(");
                    String _generateOutputParams_2 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_2);
                    _builder.append(")returns(");
                    String _generateOutputParams_3 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_3);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t\t\t");
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              } else {
                {
                  String _modifier_2 = clause.getModifier();
                  boolean _tripleNotEquals_1 = (_modifier_2 != null);
                  if (_tripleNotEquals_1) {
                    _builder.append("function ");
                    String _name_2 = clause.getName();
                    _builder.append(_name_2);
                    _builder.append("() ");
                    String _modifier_3 = clause.getModifier();
                    _builder.append(_modifier_3);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_3 = clause.getName();
                    _builder.append(_name_3);
                    _builder.append("(){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t\t\t");
                    _builder.newLine();
                    _builder.append("}\t\t");
                    _builder.newLine();
                  }
                }
              }
            }
          } else {
            {
              int _size_2 = clause.getOutputParams().size();
              boolean _greaterThan_1 = (_size_2 > 0);
              if (_greaterThan_1) {
                {
                  String _modifier_4 = clause.getModifier();
                  boolean _tripleNotEquals_2 = (_modifier_4 != null);
                  if (_tripleNotEquals_2) {
                    _builder.append("function ");
                    String _name_4 = clause.getName();
                    _builder.append(_name_4);
                    _builder.append("(");
                    String _generateInputParams = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams);
                    _builder.append(") ");
                    String _modifier_5 = clause.getModifier();
                    _builder.append(_modifier_5);
                    _builder.append(" returns(");
                    String _generateOutputParams_4 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_4);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_5 = clause.getName();
                    _builder.append(_name_5);
                    _builder.append("(");
                    String _generateInputParams_1 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_1);
                    _builder.append(") returns(");
                    String _generateOutputParams_5 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_5);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              } else {
                {
                  String _modifier_6 = clause.getModifier();
                  boolean _tripleNotEquals_3 = (_modifier_6 != null);
                  if (_tripleNotEquals_3) {
                    _builder.append("function ");
                    String _name_6 = clause.getName();
                    _builder.append(_name_6);
                    _builder.append("(");
                    String _generateInputParams_2 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_2);
                    _builder.append(") ");
                    String _modifier_7 = clause.getModifier();
                    _builder.append(_modifier_7);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_7 = clause.getName();
                    _builder.append(_name_7);
                    _builder.append("(");
                    String _generateInputParams_3 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_3);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de funciones que tiene un abstract contract del elemento File
   * Descripci�n: Genera la plantilla con los datos de la declaraci�n de la funci�n
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateAbstractClause(final EList<DeclarationFunctionAbstractContract> abstratcclauses) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final DeclarationFunctionAbstractContract clause : abstratcclauses) {
        {
          int _size = clause.getInputParams().size();
          boolean _equals = (_size == 0);
          if (_equals) {
            {
              int _size_1 = clause.getOutputParams().size();
              boolean _greaterThan = (_size_1 > 0);
              if (_greaterThan) {
                {
                  String _modifier = clause.getModifier();
                  boolean _tripleNotEquals = (_modifier != null);
                  if (_tripleNotEquals) {
                    _builder.append("function ");
                    String _name = clause.getName();
                    _builder.append(_name);
                    _builder.append("() virtual ");
                    String _string = clause.getVisibility().toString();
                    _builder.append(_string);
                    _builder.append(" ");
                    String _modifier_1 = clause.getModifier();
                    _builder.append(_modifier_1);
                    _builder.append(" returns(");
                    String _generateOutputParams = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_1 = clause.getName();
                    _builder.append(_name_1);
                    _builder.append("() virtual returns(");
                    String _generateOutputParams_1 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_1);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t\t\t");
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              } else {
                {
                  String _modifier_2 = clause.getModifier();
                  boolean _tripleNotEquals_1 = (_modifier_2 != null);
                  if (_tripleNotEquals_1) {
                    _builder.append("function ");
                    String _name_2 = clause.getName();
                    _builder.append(_name_2);
                    _builder.append("() virtual ");
                    String _string_1 = clause.getVisibility().toString();
                    _builder.append(_string_1);
                    _builder.append(" ");
                    String _modifier_3 = clause.getModifier();
                    _builder.append(_modifier_3);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_3 = clause.getName();
                    _builder.append(_name_3);
                    _builder.append("() virtual ");
                    String _string_2 = clause.getVisibility().toString();
                    _builder.append(_string_2);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              }
            }
          } else {
            {
              int _size_2 = clause.getOutputParams().size();
              boolean _greaterThan_1 = (_size_2 > 0);
              if (_greaterThan_1) {
                {
                  String _modifier_4 = clause.getModifier();
                  boolean _tripleNotEquals_2 = (_modifier_4 != null);
                  if (_tripleNotEquals_2) {
                    _builder.append("function ");
                    String _name_4 = clause.getName();
                    _builder.append(_name_4);
                    _builder.append("(");
                    String _generateInputParams = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams);
                    _builder.append(") virtual ");
                    String _string_3 = clause.getVisibility().toString();
                    _builder.append(_string_3);
                    _builder.append(" ");
                    String _modifier_5 = clause.getModifier();
                    _builder.append(_modifier_5);
                    _builder.append(" returns(");
                    String _generateOutputParams_2 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_2);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_5 = clause.getName();
                    _builder.append(_name_5);
                    _builder.append("(");
                    String _generateInputParams_1 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_1);
                    _builder.append(") virtual ");
                    String _string_4 = clause.getVisibility().toString();
                    _builder.append(_string_4);
                    _builder.append(" returns(");
                    String _generateOutputParams_3 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_3);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              } else {
                {
                  String _modifier_6 = clause.getModifier();
                  boolean _tripleNotEquals_3 = (_modifier_6 != null);
                  if (_tripleNotEquals_3) {
                    _builder.append("function ");
                    String _name_6 = clause.getName();
                    _builder.append(_name_6);
                    _builder.append("(");
                    String _generateInputParams_2 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_2);
                    _builder.append(") virtual ");
                    String _string_5 = clause.getVisibility().toString();
                    _builder.append(_string_5);
                    _builder.append(" ");
                    String _modifier_7 = clause.getModifier();
                    _builder.append(_modifier_7);
                    _builder.append(" {");
                    _builder.newLineIfNotEmpty();
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_7 = clause.getName();
                    _builder.append(_name_7);
                    _builder.append("(");
                    String _generateInputParams_3 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_3);
                    _builder.append(") virtual ");
                    String _string_6 = clause.getVisibility().toString();
                    _builder.append(_string_6);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.newLine();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de funciones que tiene el elemento Contract
   * Descripci�n: Genera la plantilla con los datos de la declaraci�n de la funci�n
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateClause(final EList<Clause> clauses) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Clause clause : clauses) {
        {
          int _size = clause.getInputParams().size();
          boolean _equals = (_size == 0);
          if (_equals) {
            {
              int _size_1 = clause.getOutputParams().size();
              boolean _greaterThan = (_size_1 > 0);
              if (_greaterThan) {
                {
                  int _size_2 = clause.getPersonalizedModifier().size();
                  boolean _greaterThan_1 = (_size_2 > 0);
                  if (_greaterThan_1) {
                    _builder.append("function ");
                    String _name = clause.getName();
                    _builder.append(_name);
                    _builder.append("() ");
                    String _string = clause.getVisibilityAccess().toString();
                    _builder.append(_string);
                    _builder.append(" ");
                    String _generatePersonalizedModifier = this.generatePersonalizedModifier(clause.getPersonalizedModifier());
                    _builder.append(_generatePersonalizedModifier);
                    _builder.append(" returns(");
                    String _generateOutputParams = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    CharSequence _generateBodyClause = this.generateBodyClause(clause);
                    _builder.append(_generateBodyClause, "\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_1 = clause.getName();
                    _builder.append(_name_1);
                    _builder.append("() ");
                    String _string_1 = clause.getVisibilityAccess().toString();
                    _builder.append(_string_1);
                    _builder.append(" returns(");
                    String _generateOutputParams_1 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_1);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    CharSequence _generateBodyClause_1 = this.generateBodyClause(clause);
                    _builder.append(_generateBodyClause_1, "\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              } else {
                {
                  int _size_3 = clause.getPersonalizedModifier().size();
                  boolean _greaterThan_2 = (_size_3 > 0);
                  if (_greaterThan_2) {
                    _builder.append("function ");
                    String _name_2 = clause.getName();
                    _builder.append(_name_2);
                    _builder.append("() ");
                    String _string_2 = clause.getVisibilityAccess().toString();
                    _builder.append(_string_2);
                    _builder.append(" ");
                    String _generatePersonalizedModifier_1 = this.generatePersonalizedModifier(clause.getPersonalizedModifier());
                    _builder.append(_generatePersonalizedModifier_1);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    CharSequence _generateBodyClause_2 = this.generateBodyClause(clause);
                    _builder.append(_generateBodyClause_2, "\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_3 = clause.getName();
                    _builder.append(_name_3);
                    _builder.append("() ");
                    String _string_3 = clause.getVisibilityAccess().toString();
                    _builder.append(_string_3);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    CharSequence _generateBodyClause_3 = this.generateBodyClause(clause);
                    _builder.append(_generateBodyClause_3, "\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              }
            }
          } else {
            {
              int _size_4 = clause.getOutputParams().size();
              boolean _greaterThan_3 = (_size_4 > 0);
              if (_greaterThan_3) {
                {
                  int _size_5 = clause.getPersonalizedModifier().size();
                  boolean _greaterThan_4 = (_size_5 > 0);
                  if (_greaterThan_4) {
                    _builder.append("function ");
                    String _name_4 = clause.getName();
                    _builder.append(_name_4);
                    _builder.append("(");
                    String _generateInputParams = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams);
                    _builder.append(") ");
                    String _string_4 = clause.getVisibilityAccess().toString();
                    _builder.append(_string_4);
                    _builder.append(" ");
                    String _generatePersonalizedModifier_2 = this.generatePersonalizedModifier(clause.getPersonalizedModifier());
                    _builder.append(_generatePersonalizedModifier_2);
                    _builder.append(" returns(");
                    String _generateOutputParams_2 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_2);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    CharSequence _generateBodyClause_4 = this.generateBodyClause(clause);
                    _builder.append(_generateBodyClause_4, "\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_5 = clause.getName();
                    _builder.append(_name_5);
                    _builder.append("(");
                    String _generateInputParams_1 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_1);
                    _builder.append(") ");
                    String _string_5 = clause.getVisibilityAccess().toString();
                    _builder.append(_string_5);
                    _builder.append(" returns(");
                    String _generateOutputParams_3 = this.generateOutputParams(clause.getOutputParams());
                    _builder.append(_generateOutputParams_3);
                    _builder.append("){");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    CharSequence _generateBodyClause_5 = this.generateBodyClause(clause);
                    _builder.append(_generateBodyClause_5, "\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              } else {
                {
                  int _size_6 = clause.getPersonalizedModifier().size();
                  boolean _greaterThan_5 = (_size_6 > 0);
                  if (_greaterThan_5) {
                    _builder.append("function ");
                    String _name_6 = clause.getName();
                    _builder.append(_name_6);
                    _builder.append("(");
                    String _generateInputParams_2 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_2);
                    _builder.append(") ");
                    String _string_6 = clause.getVisibilityAccess().toString();
                    _builder.append(_string_6);
                    _builder.append(" ");
                    String _generatePersonalizedModifier_3 = this.generatePersonalizedModifier(clause.getPersonalizedModifier());
                    _builder.append(_generatePersonalizedModifier_3);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    CharSequence _generateBodyClause_6 = this.generateBodyClause(clause);
                    _builder.append(_generateBodyClause_6, "\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("}");
                    _builder.newLine();
                  } else {
                    _builder.append("function ");
                    String _name_7 = clause.getName();
                    _builder.append(_name_7);
                    _builder.append("(");
                    String _generateInputParams_3 = this.generateInputParams(clause.getInputParams());
                    _builder.append(_generateInputParams_3);
                    _builder.append(") ");
                    String _string_7 = clause.getVisibilityAccess().toString();
                    _builder.append(_string_7);
                    _builder.append("{");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    CharSequence _generateBodyClause_7 = this.generateBodyClause(clause);
                    _builder.append(_generateBodyClause_7, "\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("}");
                    _builder.newLine();
                  }
                }
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La funci�n que se est� procesando
   * Descripci�n: Genera la plantilla con el cuerpo de la funci�n en base a que encuentre los distintos elementos que lo pueden componer
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateBodyClause(final Clause clause) {
    StringConcatenation _builder = new StringConcatenation();
    {
      int _size = clause.getProperties().size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        String _generateProperties = this.generateProperties(clause.getProperties());
        _builder.append(_generateProperties);
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_1 = clause.getRestriction().size();
      boolean _greaterThan_1 = (_size_1 > 0);
      if (_greaterThan_1) {
        CharSequence _generateRestrictionClause = this.generateRestrictionClause(clause.getRestriction());
        _builder.append(_generateRestrictionClause);
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_2 = clause.getConditions().size();
      boolean _greaterThan_2 = (_size_2 > 0);
      if (_greaterThan_2) {
        CharSequence _generateCondition = this.generateCondition(clause.getConditions());
        _builder.append(_generateCondition);
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_3 = clause.getUndeterminedloops().size();
      boolean _greaterThan_3 = (_size_3 > 0);
      if (_greaterThan_3) {
        this.generateUndeterminedLoop(clause.getUndeterminedloops());
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_4 = clause.getDeterminedloops().size();
      boolean _greaterThan_4 = (_size_4 > 0);
      if (_greaterThan_4) {
        CharSequence _generateLoopFor = this.generateLoopFor(clause.getDeterminedloops());
        _builder.append(_generateLoopFor);
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_5 = clause.getExpressions().size();
      boolean _greaterThan_5 = (_size_5 > 0);
      if (_greaterThan_5) {
        CharSequence _generateExpressions = this.generateExpressions(clause.getExpressions());
        _builder.append(_generateExpressions);
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_6 = clause.getEvent().size();
      boolean _greaterThan_6 = (_size_6 > 0);
      if (_greaterThan_6) {
        CharSequence _generateEvent = this.generateEvent(clause.getEvent());
        _builder.append(_generateEvent);
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de constructores que tiene el elemento Contract
   * Descripci�n: Genera la plantilla con los datos de la declaraci�n de la funci�n
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateConstructors(final EList<Constructor> constructors) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Constructor constructor : constructors) {
        {
          int _size = constructor.getInputParams().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("constructor (");
            String _generateInputParams = this.generateInputParams(constructor.getInputParams());
            _builder.append(_generateInputParams);
            _builder.append("){");
            _builder.newLineIfNotEmpty();
            {
              int _size_1 = constructor.getRestrictions().size();
              boolean _greaterThan_1 = (_size_1 > 0);
              if (_greaterThan_1) {
                _builder.append("\t");
                CharSequence _generateRestrictionClause = this.generateRestrictionClause(constructor.getRestrictions());
                _builder.append(_generateRestrictionClause, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_2 = constructor.getConditions().size();
              boolean _greaterThan_2 = (_size_2 > 0);
              if (_greaterThan_2) {
                _builder.append("\t");
                CharSequence _generateCondition = this.generateCondition(constructor.getConditions());
                _builder.append(_generateCondition, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_3 = constructor.getUndeterminedLoops().size();
              boolean _greaterThan_3 = (_size_3 > 0);
              if (_greaterThan_3) {
                _builder.append("\t");
                this.generateUndeterminedLoop(constructor.getUndeterminedLoops());
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_4 = constructor.getDeterminedLoops().size();
              boolean _greaterThan_4 = (_size_4 > 0);
              if (_greaterThan_4) {
                _builder.append("\t");
                CharSequence _generateLoopFor = this.generateLoopFor(constructor.getDeterminedLoops());
                _builder.append(_generateLoopFor, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_5 = constructor.getAttributesInitialization().size();
              boolean _greaterThan_5 = (_size_5 > 0);
              if (_greaterThan_5) {
                _builder.append("\t");
                CharSequence _generateExpressions = this.generateExpressions(constructor.getAttributesInitialization());
                _builder.append(_generateExpressions, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("}");
            _builder.newLine();
          } else {
            _builder.append("constructor (){");
            _builder.newLine();
            {
              int _size_6 = constructor.getRestrictions().size();
              boolean _greaterThan_6 = (_size_6 > 0);
              if (_greaterThan_6) {
                _builder.append("\t");
                CharSequence _generateRestrictionClause_1 = this.generateRestrictionClause(constructor.getRestrictions());
                _builder.append(_generateRestrictionClause_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_7 = constructor.getConditions().size();
              boolean _greaterThan_7 = (_size_7 > 0);
              if (_greaterThan_7) {
                _builder.append("\t");
                CharSequence _generateCondition_1 = this.generateCondition(constructor.getConditions());
                _builder.append(_generateCondition_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_8 = constructor.getUndeterminedLoops().size();
              boolean _greaterThan_8 = (_size_8 > 0);
              if (_greaterThan_8) {
                _builder.append("\t");
                this.generateUndeterminedLoop(constructor.getUndeterminedLoops());
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_9 = constructor.getDeterminedLoops().size();
              boolean _greaterThan_9 = (_size_9 > 0);
              if (_greaterThan_9) {
                _builder.append("\t");
                CharSequence _generateLoopFor_1 = this.generateLoopFor(constructor.getDeterminedLoops());
                _builder.append(_generateLoopFor_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_10 = constructor.getAttributesInitialization().size();
              boolean _greaterThan_10 = (_size_10 > 0);
              if (_greaterThan_10) {
                _builder.append("\t");
                CharSequence _generateExpressions_1 = this.generateExpressions(constructor.getAttributesInitialization());
                _builder.append(_generateExpressions_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("}");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de eventos que tiene el elemento Contract
   * Descripci�n: Genera la plantilla con los datos de la declaraci�n del evento y sus par�metros de entrada si los tuviese
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateEvent(final EList<Event> events) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Event event : events) {
        {
          int _size = event.getInputParams().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("event ");
            String _name = event.getName();
            _builder.append(_name);
            _builder.append(" (");
            String _generateInputParams = this.generateInputParams(event.getInputParams());
            _builder.append(_generateInputParams);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("event ");
            String _name_1 = event.getName();
            _builder.append(_name_1);
            _builder.append("();");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de expresiones emit event que tiene el elemento que lo esta procesando
   * Descripci�n: Genera la plantilla con los datos de expresi�n de emitir un evento
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateEmitEvent(final EList<Event> events) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Event event : events) {
        {
          int _size = event.getInputParams().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("emit ");
            String _name = event.getName();
            _builder.append(_name);
            _builder.append(" (");
            String _generateInputParams = this.generateInputParams(event.getInputParams());
            _builder.append(_generateInputParams);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("emit ");
            String _name_1 = event.getName();
            _builder.append(_name_1);
            _builder.append("();");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de modificadores personalizados que tiene una funci�n
   * Descripci�n: Genera un string con el nombre del modificador y sus par�metros de entrada si los tuviese
   * Par�metro de salida: El string con los datos de todos los modificadores y sus par�metros de entrada
   */
  public String generatePersonalizedModifier(final EList<Modifier> modifiers) {
    String modifiersPersonalized = "";
    for (final Modifier modifier : modifiers) {
      EList<InputParam> _inputParams = modifier.getInputParams();
      boolean _tripleNotEquals = (_inputParams != null);
      if (_tripleNotEquals) {
        String _modifiersPersonalized = modifiersPersonalized;
        String _name = modifier.getName();
        String _plus = (_name + "(");
        String _generateInputParams = this.generateInputParams(modifier.getInputParams());
        String _plus_1 = (_plus + _generateInputParams);
        String _plus_2 = (_plus_1 + ") ");
        modifiersPersonalized = (_modifiersPersonalized + _plus_2);
      } else {
        String _modifiersPersonalized_1 = modifiersPersonalized;
        String _name_1 = modifier.getName();
        String _plus_3 = (_name_1 + "()");
        modifiersPersonalized = (_modifiersPersonalized_1 + _plus_3);
      }
    }
    return modifiersPersonalized;
  }
  
  /**
   * Par�metros de entrada: La lista de modificadores que tiene el elemento Contract
   * Descripci�n: Genera la plantilla con los datos del modificador
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateModifier(final EList<Modifier> modifiers) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Modifier modifier : modifiers) {
        {
          int _size = modifier.getInputParams().size();
          boolean _equals = (_size == 0);
          if (_equals) {
            _builder.append("modifier ");
            String _name = modifier.getName();
            _builder.append(_name);
            _builder.append("(){");
            _builder.newLineIfNotEmpty();
            {
              EList<RestrictionClause> _conditionRestricion = modifier.getConditionRestricion();
              boolean _tripleNotEquals = (_conditionRestricion != null);
              if (_tripleNotEquals) {
                _builder.append("\t");
                CharSequence _generateRestrictionClause = this.generateRestrictionClause(modifier.getConditionRestricion());
                _builder.append(_generateRestrictionClause, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              EList<Condition> _conditionsBeforeMark = modifier.getConditionsBeforeMark();
              boolean _tripleNotEquals_1 = (_conditionsBeforeMark != null);
              if (_tripleNotEquals_1) {
                _builder.append("\t");
                CharSequence _generateCondition = this.generateCondition(modifier.getConditionsBeforeMark());
                _builder.append(_generateCondition, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              EList<String> _expressionsAssignValueBeforeMark = modifier.getExpressionsAssignValueBeforeMark();
              boolean _tripleNotEquals_2 = (_expressionsAssignValueBeforeMark != null);
              if (_tripleNotEquals_2) {
                _builder.append("\t");
                CharSequence _generateExpressions = this.generateExpressions(modifier.getExpressionsAssignValueBeforeMark());
                _builder.append(_generateExpressions, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              if (((modifier.getConditionsAfterMark().size() == 0) && (modifier.getExpressionsAssignValueAfterMark().size() == 0))) {
                _builder.append("\t");
                _builder.append("_;");
                _builder.newLine();
              } else {
                {
                  EList<Condition> _conditionsAfterMark = modifier.getConditionsAfterMark();
                  boolean _tripleNotEquals_3 = (_conditionsAfterMark != null);
                  if (_tripleNotEquals_3) {
                    _builder.append("\t");
                    CharSequence _generateCondition_1 = this.generateCondition(modifier.getConditionsAfterMark());
                    _builder.append(_generateCondition_1, "\t");
                    _builder.newLineIfNotEmpty();
                  }
                }
                {
                  EList<String> _expressionsAssignValueAfterMark = modifier.getExpressionsAssignValueAfterMark();
                  boolean _tripleNotEquals_4 = (_expressionsAssignValueAfterMark != null);
                  if (_tripleNotEquals_4) {
                    _builder.append("\t");
                    CharSequence _generateExpressions_1 = this.generateExpressions(modifier.getExpressionsAssignValueAfterMark());
                    _builder.append(_generateExpressions_1, "\t");
                    _builder.newLineIfNotEmpty();
                  }
                }
                _builder.append("\t");
                _builder.append("_;");
                _builder.newLine();
              }
            }
            _builder.append("}");
            _builder.newLine();
          } else {
            _builder.append("modifier ");
            String _name_1 = modifier.getName();
            _builder.append(_name_1);
            _builder.append("(");
            String _generateInputParams = this.generateInputParams(modifier.getInputParams());
            _builder.append(_generateInputParams);
            _builder.append("){");
            _builder.newLineIfNotEmpty();
            {
              EList<RestrictionClause> _conditionRestricion_1 = modifier.getConditionRestricion();
              boolean _tripleNotEquals_5 = (_conditionRestricion_1 != null);
              if (_tripleNotEquals_5) {
                _builder.append("\t");
                CharSequence _generateRestrictionClause_1 = this.generateRestrictionClause(modifier.getConditionRestricion());
                _builder.append(_generateRestrictionClause_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              EList<Condition> _conditionsBeforeMark_1 = modifier.getConditionsBeforeMark();
              boolean _tripleNotEquals_6 = (_conditionsBeforeMark_1 != null);
              if (_tripleNotEquals_6) {
                _builder.append("\t");
                CharSequence _generateCondition_2 = this.generateCondition(modifier.getConditionsBeforeMark());
                _builder.append(_generateCondition_2, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              EList<String> _expressionsAssignValueBeforeMark_1 = modifier.getExpressionsAssignValueBeforeMark();
              boolean _tripleNotEquals_7 = (_expressionsAssignValueBeforeMark_1 != null);
              if (_tripleNotEquals_7) {
                _builder.append("\t");
                CharSequence _generateExpressions_2 = this.generateExpressions(modifier.getExpressionsAssignValueBeforeMark());
                _builder.append(_generateExpressions_2, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              if (((modifier.getConditionsAfterMark().size() == 0) && (modifier.getExpressionsAssignValueAfterMark().size() == 0))) {
                _builder.append("\t");
                _builder.append("_;");
                _builder.newLine();
              } else {
                {
                  EList<Condition> _conditionsAfterMark_1 = modifier.getConditionsAfterMark();
                  boolean _tripleNotEquals_8 = (_conditionsAfterMark_1 != null);
                  if (_tripleNotEquals_8) {
                    _builder.append("\t");
                    CharSequence _generateCondition_3 = this.generateCondition(modifier.getConditionsAfterMark());
                    _builder.append(_generateCondition_3, "\t");
                    _builder.newLineIfNotEmpty();
                  }
                }
                {
                  EList<String> _expressionsAssignValueAfterMark_1 = modifier.getExpressionsAssignValueAfterMark();
                  boolean _tripleNotEquals_9 = (_expressionsAssignValueAfterMark_1 != null);
                  if (_tripleNotEquals_9) {
                    _builder.append("\t");
                    CharSequence _generateExpressions_3 = this.generateExpressions(modifier.getExpressionsAssignValueAfterMark());
                    _builder.append(_generateExpressions_3, "\t");
                    _builder.newLineIfNotEmpty();
                  }
                }
                _builder.append("\t");
                _builder.append("_;");
                _builder.newLine();
              }
            }
            _builder.append("}");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de restricciones del elemento que se est� procesando
   * Descripci�n: Identifica que tipo de restricci�n es y llama a su funci�n correspondiente para generar la plantilla con los datos de la restricci�n
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateRestrictionClause(final EList<RestrictionClause> restrictionsClause) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final RestrictionClause restriction : restrictionsClause) {
        String _generateRestriction = this.loader.generateRestriction(restriction, this);
        _builder.append(_generateRestriction);
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  public CharSequence generateRestrictionGas(final EList<RestrictionGas> restrictionsGas) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final RestrictionGas restrictionGas : restrictionsGas) {
        {
          String _message = restrictionGas.getMessage();
          boolean _tripleNotEquals = (_message != null);
          if (_tripleNotEquals) {
            _builder.append("require(");
            String _expr1 = restrictionGas.getExpr1();
            _builder.append(_expr1);
            _builder.append(" ");
            String _string = restrictionGas.getOperator().toString();
            _builder.append(_string);
            _builder.append(" ");
            String _amount = restrictionGas.getAmount();
            _builder.append(_amount);
            _builder.append(" ");
            String _string_1 = restrictionGas.getTypeCoin().toString();
            _builder.append(_string_1);
            _builder.append(", ");
            String _message_1 = restrictionGas.getMessage();
            _builder.append(_message_1);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("require(");
            String _expr1_1 = restrictionGas.getExpr1();
            _builder.append(_expr1_1);
            _builder.append(" ");
            String _string_2 = restrictionGas.getOperator().toString();
            _builder.append(_string_2);
            _builder.append(" ");
            String _amount_1 = restrictionGas.getAmount();
            _builder.append(_amount_1);
            _builder.append(" ");
            String _string_3 = restrictionGas.getTypeCoin().toString();
            _builder.append(_string_3);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  public CharSequence generateRestrictionGas(final RestrictionGas restrictionGas) {
    StringConcatenation _builder = new StringConcatenation();
    {
      String _message = restrictionGas.getMessage();
      boolean _tripleNotEquals = (_message != null);
      if (_tripleNotEquals) {
        _builder.append("require(");
        String _expr1 = restrictionGas.getExpr1();
        _builder.append(_expr1);
        _builder.append(" ");
        String _string = restrictionGas.getOperator().toString();
        _builder.append(_string);
        _builder.append(" ");
        String _amount = restrictionGas.getAmount();
        _builder.append(_amount);
        _builder.append(" ");
        String _string_1 = restrictionGas.getTypeCoin().toString();
        _builder.append(_string_1);
        _builder.append(", ");
        String _message_1 = restrictionGas.getMessage();
        _builder.append(_message_1);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("require(");
        String _expr1_1 = restrictionGas.getExpr1();
        _builder.append(_expr1_1);
        _builder.append(" ");
        String _string_2 = restrictionGas.getOperator().toString();
        _builder.append(_string_2);
        _builder.append(" ");
        String _amount_1 = restrictionGas.getAmount();
        _builder.append(_amount_1);
        _builder.append(" ");
        String _string_3 = restrictionGas.getTypeCoin().toString();
        _builder.append(_string_3);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  public CharSequence generateNormalRestriction(final EList<Restriction> restrictions) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Restriction restriction : restrictions) {
        {
          String _message = restriction.getMessage();
          boolean _tripleNotEquals = (_message != null);
          if (_tripleNotEquals) {
            _builder.append("require(");
            String _expr1 = restriction.getExpr1();
            _builder.append(_expr1);
            _builder.append(" ");
            String _string = restriction.getOperator().toString();
            _builder.append(_string);
            _builder.append(" ");
            String _expr2 = restriction.getExpr2();
            _builder.append(_expr2);
            _builder.append(", ");
            String _message_1 = restriction.getMessage();
            _builder.append(_message_1);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("require(");
            String _expr1_1 = restriction.getExpr1();
            _builder.append(_expr1_1);
            _builder.append(" ");
            String _string_1 = restriction.getOperator().toString();
            _builder.append(_string_1);
            _builder.append(" ");
            String _expr2_1 = restriction.getExpr2();
            _builder.append(_expr2_1);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  public CharSequence generateNormalRestriction(final Restriction restriction) {
    StringConcatenation _builder = new StringConcatenation();
    {
      String _message = restriction.getMessage();
      boolean _tripleNotEquals = (_message != null);
      if (_tripleNotEquals) {
        _builder.append("require(");
        String _expr1 = restriction.getExpr1();
        _builder.append(_expr1);
        _builder.append(" ");
        String _string = restriction.getOperator().toString();
        _builder.append(_string);
        _builder.append(" ");
        String _expr2 = restriction.getExpr2();
        _builder.append(_expr2);
        _builder.append(", ");
        String _message_1 = restriction.getMessage();
        _builder.append(_message_1);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("require(");
        String _expr1_1 = restriction.getExpr1();
        _builder.append(_expr1_1);
        _builder.append(" ");
        String _string_1 = restriction.getOperator().toString();
        _builder.append(_string_1);
        _builder.append(" ");
        String _expr2_1 = restriction.getExpr2();
        _builder.append(_expr2_1);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada:La lista de restricciones de tipo assert que contiene el elemento
   * Descripci�n: Genera la plantilla para la restricci�n assert
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateAssertRestrictions(final EList<Assert> restrictions) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Assert restriction : restrictions) {
        _builder.append("assert(");
        String _expr1 = restriction.getExpr1();
        _builder.append(_expr1);
        _builder.append(" ");
        String _string = restriction.getOperator().toString();
        _builder.append(_string);
        _builder.append(" ");
        String _expr2 = restriction.getExpr2();
        _builder.append(_expr2);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La restricci�n assert que ha identificado
   * Descripci�n: Genera la plantilla con los datos de la restricci�n assert
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateAssertRestriction(final Assert restriction) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("assert(");
    String _expr1 = restriction.getExpr1();
    _builder.append(_expr1);
    _builder.append(" ");
    String _string = restriction.getOperator().toString();
    _builder.append(_string);
    _builder.append(" ");
    String _expr2 = restriction.getExpr2();
    _builder.append(_expr2);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de sentencias condicionales que contiene el elemento
   * Descripci�n: Genera las condiciones y los datos asociados a estas
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateCondition(final EList<Condition> conditions) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final Condition condition : conditions) {
        _builder.append("if(");
        String _condition = condition.getCondition();
        _builder.append(_condition);
        _builder.append("){");
        _builder.newLineIfNotEmpty();
        {
          int _size = condition.getProperties().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            _builder.append("\t");
            String _generateProperties = this.generateProperties(condition.getProperties());
            _builder.append(_generateProperties, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_1 = condition.getConditionalExpr().size();
          boolean _greaterThan_1 = (_size_1 > 0);
          if (_greaterThan_1) {
            _builder.append("\t");
            Object _generateCondition = this.generateCondition(condition.getConditionalExpr());
            _builder.append(_generateCondition, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_2 = condition.getUndeterminedloops().size();
          boolean _greaterThan_2 = (_size_2 > 0);
          if (_greaterThan_2) {
            _builder.append("\t");
            this.generateUndeterminedLoop(condition.getUndeterminedloops());
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_3 = condition.getDeterminedloops().size();
          boolean _greaterThan_3 = (_size_3 > 0);
          if (_greaterThan_3) {
            _builder.append("\t");
            CharSequence _generateLoopFor = this.generateLoopFor(condition.getDeterminedloops());
            _builder.append(_generateLoopFor, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_4 = condition.getExpressions().size();
          boolean _greaterThan_4 = (_size_4 > 0);
          if (_greaterThan_4) {
            _builder.append("\t");
            CharSequence _generateExpressions = this.generateExpressions(condition.getExpressions());
            _builder.append(_generateExpressions, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size_5 = condition.getEvent().size();
          boolean _greaterThan_5 = (_size_5 > 0);
          if (_greaterThan_5) {
            _builder.append("\t");
            CharSequence _generateEmitEvent = this.generateEmitEvent(condition.getEvent());
            _builder.append(_generateEmitEvent, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        {
          int _size_6 = condition.getConditionalExprElse().size();
          boolean _greaterThan_6 = (_size_6 > 0);
          if (_greaterThan_6) {
            _builder.append("else{");
            _builder.newLine();
            {
              int _size_7 = condition.getPropertiesElse().size();
              boolean _greaterThan_7 = (_size_7 > 0);
              if (_greaterThan_7) {
                _builder.append("\t");
                String _generateProperties_1 = this.generateProperties(condition.getPropertiesElse());
                _builder.append(_generateProperties_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_8 = condition.getConditionalExprElse().size();
              boolean _greaterThan_8 = (_size_8 > 0);
              if (_greaterThan_8) {
                _builder.append("\t");
                Object _generateCondition_1 = this.generateCondition(condition.getConditionalExprElse());
                _builder.append(_generateCondition_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_9 = condition.getUndeterminedloopsElse().size();
              boolean _greaterThan_9 = (_size_9 > 0);
              if (_greaterThan_9) {
                _builder.append("\t");
                this.generateUndeterminedLoop(condition.getUndeterminedloopsElse());
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_10 = condition.getDeterminedloopsElse().size();
              boolean _greaterThan_10 = (_size_10 > 0);
              if (_greaterThan_10) {
                _builder.append("\t");
                CharSequence _generateLoopFor_1 = this.generateLoopFor(condition.getDeterminedloopsElse());
                _builder.append(_generateLoopFor_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_11 = condition.getExpressionsElse().size();
              boolean _greaterThan_11 = (_size_11 > 0);
              if (_greaterThan_11) {
                _builder.append("\t");
                CharSequence _generateExpressions_1 = this.generateExpressions(condition.getExpressionsElse());
                _builder.append(_generateExpressions_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              int _size_12 = condition.getEventElse().size();
              boolean _greaterThan_12 = (_size_12 > 0);
              if (_greaterThan_12) {
                _builder.append("\t");
                CharSequence _generateEmitEvent_1 = this.generateEmitEvent(condition.getEventElse());
                _builder.append(_generateEmitEvent_1, "\t");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("}");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada:La lista de bucles que contiene el elemento
   * Descripci�n: Identifica que clase de bucle es y llama a la funci�n correspondiente para generar su plantilla
   * Par�metro de salida: Ninguno
   */
  public void generateUndeterminedLoop(final EList<UnDeterminedLoop> loops) {
    for (final UnDeterminedLoop loop : loops) {
      this.loader.generateLoop(loop, this);
    }
  }
  
  /**
   * Par�metros de entrada: El bucle do while de la lista que se que se est� procesando
   * Descripci�n: Genera la plantilla con los datosdel bucle while que tiene el elemento que se est� procesando
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateDoWhile(final DoWhileLoop doWhileLoop) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("do{");
    _builder.newLine();
    _builder.append("\t");
    CharSequence _generateRestrictionGas = this.generateRestrictionGas(doWhileLoop.getGasrestriction());
    _builder.append(_generateRestrictionGas, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateRestrictionClause = this.generateRestrictionClause(doWhileLoop.getRestriction());
    _builder.append(_generateRestrictionClause, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateLoopFor = this.generateLoopFor(doWhileLoop.getDeterminedloops());
    String _plus = (_generateLoopFor + "\n");
    String _plus_1 = (_plus + "\t");
    _builder.append(_plus_1, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateCondition = this.generateCondition(doWhileLoop.getConditions());
    String _plus_2 = (_generateCondition + "\n");
    String _plus_3 = (_plus_2 + "\t");
    _builder.append(_plus_3, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateExpressions = this.generateExpressions(doWhileLoop.getExpressions());
    _builder.append(_generateExpressions, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateEmitEvent = this.generateEmitEvent(doWhileLoop.getEvent());
    _builder.append(_generateEmitEvent, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("while(");
    String _condition = doWhileLoop.getCondition();
    _builder.append(_condition);
    _builder.append(")}");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Par�metros de entrada: El bucle while de la lista que se que se est� procesando
   * Descripci�n: Genera la plantilla con los datos del bucle while que tiene el elemento que se est� procesando
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateWhile(final WhileLoop whileLoop) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("while(");
    String _condition = whileLoop.getCondition();
    _builder.append(_condition);
    _builder.append("){");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateRestrictionGas = this.generateRestrictionGas(whileLoop.getGasrestriction());
    _builder.append(_generateRestrictionGas, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateRestrictionClause = this.generateRestrictionClause(whileLoop.getRestriction());
    _builder.append(_generateRestrictionClause, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateLoopFor = this.generateLoopFor(whileLoop.getDeterminedloops());
    String _plus = (_generateLoopFor + "\n");
    String _plus_1 = (_plus + "\t");
    _builder.append(_plus_1, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateCondition = this.generateCondition(whileLoop.getConditions());
    String _plus_2 = (_generateCondition + "\n");
    String _plus_3 = (_plus_2 + "\t");
    _builder.append(_plus_3, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateExpressions = this.generateExpressions(whileLoop.getExpressions());
    _builder.append(_generateExpressions, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    CharSequence _generateEmitEvent = this.generateEmitEvent(whileLoop.getEvent());
    _builder.append(_generateEmitEvent, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de bucles for que tiene el elemento que se est� procesando
   * Descripci�n: Genera la plantilla con los datos de los bucles FOR que tiene el elemento que se est� procesando
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateLoopFor(final EList<ForLoop> forLoops) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final ForLoop forLoop : forLoops) {
        _builder.append("for(");
        String _typeCounter = forLoop.getTypeCounter();
        _builder.append(_typeCounter);
        _builder.append(" ");
        String _nameCounter = forLoop.getNameCounter();
        _builder.append(_nameCounter);
        _builder.append(" = ");
        int _value = forLoop.getValue();
        _builder.append(_value);
        _builder.append(";");
        String _condition = forLoop.getCondition();
        _builder.append(_condition);
        _builder.append(";");
        String _nameCounter_1 = forLoop.getNameCounter();
        _builder.append(_nameCounter_1);
        _builder.append("++){");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        CharSequence _generateRestrictionGas = this.generateRestrictionGas(forLoop.getGasrestriction());
        _builder.append(_generateRestrictionGas, "\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        CharSequence _generateRestrictionClause = this.generateRestrictionClause(forLoop.getRestriction());
        _builder.append(_generateRestrictionClause, "\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        Object _generateLoopFor = this.generateLoopFor(forLoop.getDeterminedloops());
        String _plus = (_generateLoopFor + "\n");
        _builder.append(_plus, "\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        Object _generateCondition = this.generateCondition(forLoop.getConditions());
        String _plus_1 = (_generateCondition + "\n");
        _builder.append(_plus_1, "\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        CharSequence _generateExpressions = this.generateExpressions(forLoop.getExpressions());
        _builder.append(_generateExpressions, "\t");
        _builder.newLineIfNotEmpty();
        _builder.append("}");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Par�metros de entrada: La lista de expresiones del elemento que se est� procesando
   * Descripci�n: Genera la plantilla con las expresiones del elemento que se est�n procesando
   * Par�metro de salida: Ninguno
   */
  public CharSequence generateExpressions(final EList<String> expressions) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final String expression : expressions) {
        {
          boolean _contains = expression.contains(";");
          boolean _not = (!_contains);
          if (_not) {
            _builder.append(expression);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append(expression);
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos de entrada:El primero (input) es el modelo e3value
   * Descripci�n: Proceso de transformaci�n de un e3value sin modelo qa (Questions & Answers) -->  Modelo SmaC (.sce extension)
   * Argumento de salida: Ninguno
   */
  public Resource doGenerate(final Resource input, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    Resource _xblockexpression = null;
    {
      EObject _head = IteratorExtensions.<EObject>head(input.getAllContents());
      final File root = ((File) _head);
      final String pathBlockly = input.getURI().path();
      _xblockexpression = this.loader.createFile(this.generateSmaC_File(root).toString(), pathBlockly);
    }
    return _xblockexpression;
  }
}
