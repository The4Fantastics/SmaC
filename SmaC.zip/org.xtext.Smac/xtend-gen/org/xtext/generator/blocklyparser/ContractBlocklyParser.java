package org.xtext.generator.blocklyparser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.ConstructorBlocklyParser;
import org.xtext.generator.blocklyparser.EventBlocklyParser;
import org.xtext.generator.blocklyparser.FunctionBlocklyParser;
import org.xtext.generator.blocklyparser.ModifierBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.PropertyBlocklyParser;
import org.xtext.smaC.Clause;
import org.xtext.smaC.Company;
import org.xtext.smaC.Constructor;
import org.xtext.smaC.Contract;
import org.xtext.smaC.Element;
import org.xtext.smaC.Event;
import org.xtext.smaC.File;
import org.xtext.smaC.Library;
import org.xtext.smaC.Mapping;
import org.xtext.smaC.Modifier;
import org.xtext.smaC.PersonalizedStruct;
import org.xtext.smaC.Properties;
import org.xtext.smaC.User;

@SuppressWarnings("all")
public class ContractBlocklyParser {
  private ConstructorBlocklyParser parserConstructor = new ConstructorBlocklyParser();
  
  private EventBlocklyParser parserEvent = new EventBlocklyParser();
  
  private ModifierBlocklyParser parserModifier = new ModifierBlocklyParser();
  
  private FunctionBlocklyParser parserFunction = new FunctionBlocklyParser();
  
  private PropertyBlocklyParser parserProperty = new PropertyBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private final String nameLocalProperty = "localProperty";
  
  private final String nameLocalMapping = "localMappingProperty";
  
  private final String nameStruct = "struct";
  
  private final String nameUserStruct = "user_struct";
  
  private final String nameCompanyStruct = "company_struct";
  
  private final String nameConstructor = "constructor";
  
  private final String nameModifier = "modifier";
  
  private final String nameEvent = "event";
  
  private final String nameLibrary = "importLibrary";
  
  private final String nameEnumerator = "enumerator";
  
  public CharSequence defineBlockContract(final File file) {
    StringConcatenation _builder = new StringConcatenation();
    {
      EList<Contract> _contracts = file.getContracts();
      for(final Contract contract : _contracts) {
        _builder.append("<block type=\"contract\">");
        _builder.newLine();
        _builder.append("<field name=\"name\">");
        String _name = contract.getName();
        _builder.append(_name);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        {
          int _size = contract.getSuperType().size();
          boolean _greaterThan = (_size > 0);
          if (_greaterThan) {
            {
              int _size_1 = contract.getSuperType().size();
              boolean _equals = (_size_1 == 1);
              if (_equals) {
                _builder.append("\t\t    ");
                _builder.append("<value name=\"namecontractfather\">");
                _builder.newLine();
                _builder.append("<block type=\"contract_father\">");
                _builder.newLine();
                _builder.append("  ");
                _builder.append("<field name=\"name\">");
                String _name_1 = contract.getSuperType().get(0).getName();
                _builder.append(_name_1, "  ");
                _builder.append("</field>");
                _builder.newLineIfNotEmpty();
                _builder.append("</block>");
                _builder.newLine();
                _builder.append("\t\t\t");
                _builder.append("</value>");
                _builder.newLine();
              } else {
                _builder.append("\t\t    ");
                _builder.append("<value name=\"namecontractfather\">");
                _builder.newLine();
                {
                  EList<Element> _superType = contract.getSuperType();
                  for(final Element contractInherance : _superType) {
                    _builder.append("<block type=\"contract_father\">");
                    _builder.newLine();
                    _builder.append("  ");
                    _builder.append("<field name=\"name\">");
                    String _name_2 = contractInherance.getName();
                    _builder.append(_name_2, "  ");
                    _builder.append("</field>");
                    _builder.newLineIfNotEmpty();
                    {
                      EList<Element> _superType_1 = contract.getSuperType();
                      int _size_2 = contract.getSuperType().size();
                      int _minus = (_size_2 - 1);
                      boolean _equals_1 = contractInherance.getName().equals(_superType_1.get(_minus).getName());
                      boolean _not = (!_equals_1);
                      if (_not) {
                        _builder.append("  ");
                        _builder.append("<value name=\"contracts_inherit\">");
                        _builder.newLine();
                      }
                    }
                  }
                }
                {
                  EList<Element> _superType_2 = contract.getSuperType();
                  for(final Element contractInherance_1 : _superType_2) {
                    _builder.append("\t");
                    _builder.append("</block>");
                    _builder.newLine();
                    _builder.append("</value>");
                    _builder.newLine();
                  }
                }
              }
            }
          }
        }
        _builder.append("\t");
        _builder.append("<statement name=\"contract_elements\">  ");
        _builder.newLine();
        {
          EList<Library> _libraries = contract.getLibraries();
          for(final Library library : _libraries) {
            CharSequence _generateBlockUsingLibrary = this.generateBlockUsingLibrary(library);
            _builder.append(_generateBlockUsingLibrary);
            _builder.newLineIfNotEmpty();
            _builder.append("<next>");
            _builder.newLine();
          }
        }
        {
          EList<Properties> _localProperties = contract.getLocalProperties();
          for(final Properties property : _localProperties) {
            CharSequence _identifyTypeProperty = this.parserProperty.identifyTypeProperty(property);
            _builder.append(_identifyTypeProperty);
            _builder.newLineIfNotEmpty();
            {
              if (((!property.equals(contract.getLocalProperties().get((contract.getLocalProperties().size() - 1)))) || (property.equals(contract.getLocalProperties().get((contract.getLocalProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        {
          EList<Mapping> _localMappingProperties = contract.getLocalMappingProperties();
          for(final Mapping propertymapping : _localMappingProperties) {
            CharSequence _identifyMappingProperty = this.parserProperty.identifyMappingProperty(propertymapping);
            _builder.append(_identifyMappingProperty);
            _builder.newLineIfNotEmpty();
            {
              if (((!propertymapping.equals(contract.getLocalMappingProperties().get((contract.getLocalMappingProperties().size() - 1)))) || (propertymapping.equals(contract.getLocalMappingProperties().get((contract.getLocalMappingProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalMapping, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        {
          EList<PersonalizedStruct> _structs = contract.getStructs();
          for(final PersonalizedStruct struct : _structs) {
            Object _generateStruct = this.parserProperty.generateStruct(struct);
            _builder.append(_generateStruct);
            _builder.newLineIfNotEmpty();
            {
              if (((!struct.equals(contract.getStructs().get((contract.getStructs().size() - 1)))) || (struct.equals(contract.getStructs().get((contract.getStructs().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameStruct, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        {
          EList<User> _structsUser = contract.getStructsUser();
          for(final User struct_1 : _structsUser) {
            CharSequence _generateUserStruct = this.parserProperty.generateUserStruct(struct_1);
            _builder.append(_generateUserStruct);
            _builder.newLineIfNotEmpty();
            {
              if (((!struct_1.equals(contract.getStructsUser().get((contract.getStructsUser().size() - 1)))) || (struct_1.equals(contract.getStructsUser().get((contract.getStructsUser().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameUserStruct, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        {
          EList<Company> _structsCompany = contract.getStructsCompany();
          for(final Company struct_2 : _structsCompany) {
            CharSequence _generateCompanyStruct = this.parserProperty.generateCompanyStruct(struct_2);
            _builder.append(_generateCompanyStruct);
            _builder.newLineIfNotEmpty();
            {
              if (((!struct_2.equals(contract.getStructsCompany().get((contract.getStructsCompany().size() - 1)))) || (struct_2.equals(contract.getStructsCompany().get((contract.getStructsCompany().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameCompanyStruct, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        {
          EList<org.xtext.smaC.Enum> _localEnumerators = contract.getLocalEnumerators();
          for(final org.xtext.smaC.Enum enumerator : _localEnumerators) {
            CharSequence _generateEnumerator = this.parserProperty.generateEnumerator(enumerator);
            _builder.append(_generateEnumerator);
            _builder.newLineIfNotEmpty();
            {
              if (((!enumerator.equals(contract.getLocalEnumerators().get((contract.getLocalEnumerators().size() - 1)))) || (enumerator.equals(contract.getLocalEnumerators().get((contract.getLocalEnumerators().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameEnumerator, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        _builder.append("\t");
        {
          EList<Constructor> _constructors = contract.getConstructors();
          for(final Constructor constructor : _constructors) {
            _builder.append("\t\t");
            CharSequence _defineHeadBlockConstructor = this.parserConstructor.defineHeadBlockConstructor(constructor);
            _builder.append(_defineHeadBlockConstructor, "\t");
            _builder.newLineIfNotEmpty();
            {
              if (((!constructor.equals(contract.getConstructors().get((contract.getConstructors().size() - 1)))) || (constructor.equals(contract.getConstructors().get((contract.getConstructors().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameConstructor, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        _builder.append("\t");
        {
          EList<Modifier> _modifiers = contract.getModifiers();
          for(final Modifier modifier : _modifiers) {
            _builder.append("\t\t");
            CharSequence _defineModifier = this.parserModifier.defineModifier(modifier);
            _builder.append(_defineModifier, "\t");
            _builder.newLineIfNotEmpty();
            {
              if (((!modifier.equals(contract.getModifiers().get((contract.getModifiers().size() - 1)))) || (modifier.equals(contract.getModifiers().get((contract.getModifiers().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameModifier, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        _builder.append("\t");
        {
          EList<Event> _events = contract.getEvents();
          for(final Event event : _events) {
            _builder.append("\t\t");
            CharSequence _defineBlockEvent = this.parserEvent.defineBlockEvent(event);
            _builder.append(_defineBlockEvent, "\t");
            _builder.newLineIfNotEmpty();
            {
              if (((!event.equals(contract.getEvents().get((contract.getEvents().size() - 1)))) || (event.equals(contract.getEvents().get((contract.getEvents().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameEvent, contract)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
        {
          EList<Clause> _clauses = contract.getClauses();
          for(final Clause function : _clauses) {
            _builder.append("       ");
            CharSequence _defineFunction = this.parserFunction.defineFunction(function);
            _builder.append(_defineFunction, "       ");
            _builder.newLineIfNotEmpty();
            {
              EList<Clause> _clauses_1 = contract.getClauses();
              int _size_3 = contract.getClauses().size();
              int _minus_1 = (_size_3 - 1);
              boolean _equals_2 = function.equals(_clauses_1.get(_minus_1));
              boolean _not_1 = (!_equals_2);
              if (_not_1) {
                _builder.append(" \t   \t<next>");
                _builder.newLineIfNotEmpty();
              } else {
                _builder.append("</block>");
                _builder.newLine();
              }
            }
          }
        }
        _builder.append("\t");
        CharSequence _closeTags = this.parserCommonFunctions.closeTags(contract.getClauses().size());
        _builder.append(_closeTags, "\t");
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(contract.getEvents().size(), this.parserCommonFunctions.controlMoreElements(this.nameEvent, contract));
        _builder.append(_closeTagsDistinctElements);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getModifiers().size(), this.parserCommonFunctions.controlMoreElements(this.nameModifier, contract));
        _builder.append(_closeTagsDistinctElements_1);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getConstructors().size(), this.parserCommonFunctions.controlMoreElements(this.nameConstructor, contract));
        _builder.append(_closeTagsDistinctElements_2);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getLocalEnumerators().size(), this.parserCommonFunctions.controlMoreElements(this.nameEnumerator, contract));
        _builder.append(_closeTagsDistinctElements_3);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_4 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getStructsCompany().size(), this.parserCommonFunctions.controlMoreElements(this.nameCompanyStruct, contract));
        _builder.append(_closeTagsDistinctElements_4);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_5 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getStructsUser().size(), this.parserCommonFunctions.controlMoreElements(this.nameUserStruct, contract));
        _builder.append(_closeTagsDistinctElements_5);
        _builder.append("\t");
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_6 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getStructs().size(), this.parserCommonFunctions.controlMoreElements(this.nameStruct, contract));
        _builder.append(_closeTagsDistinctElements_6);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_7 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getLocalMappingProperties().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalMapping, contract));
        _builder.append(_closeTagsDistinctElements_7);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_8 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getLocalProperties().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, contract));
        _builder.append(_closeTagsDistinctElements_8);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_9 = this.parserCommonFunctions.closeTagsDistinctElements(contract.getLibraries().size(), this.parserCommonFunctions.controlMoreElements(this.nameLibrary, contract));
        _builder.append(_closeTagsDistinctElements_9);
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("</statement> ");
        _builder.newLine();
        _builder.append("    ");
        {
          EList<Contract> _contracts_1 = file.getContracts();
          int _size_4 = file.getContracts().size();
          int _minus_2 = (_size_4 - 1);
          boolean _equals_3 = contract.equals(_contracts_1.get(_minus_2));
          boolean _not_2 = (!_equals_3);
          if (_not_2) {
            _builder.append("   \t\t<next>");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("</block>");
            _builder.append("    ");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("    ");
    {
      int _size_5 = file.getContracts().size();
      boolean _greaterThan_1 = (_size_5 > 1);
      if (_greaterThan_1) {
        _builder.append(" ");
        _builder.append("    \t");
        CharSequence _closeTags_1 = this.parserCommonFunctions.closeTags(file.getContracts().size());
        _builder.append(_closeTags_1, "    ");
        _builder.append("    ");
      }
    }
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateBlockUsingLibrary(final Library library) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_usinglibrary\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"name\">");
    String _name = library.getName();
    _builder.append(_name, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("<field name=\"alias\">");
    _builder.append("*", "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
}
