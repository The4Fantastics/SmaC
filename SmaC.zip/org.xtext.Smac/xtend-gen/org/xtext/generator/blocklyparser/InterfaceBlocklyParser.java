package org.xtext.generator.blocklyparser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.EventBlocklyParser;
import org.xtext.generator.blocklyparser.FunctionBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.smaC.DeclarationFunctionInterface;
import org.xtext.smaC.Event;
import org.xtext.smaC.Interface;

@SuppressWarnings("all")
public class InterfaceBlocklyParser {
  private FunctionBlocklyParser parserFunction = new FunctionBlocklyParser();
  
  private EventBlocklyParser parserEvent = new EventBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private final String nameEvent = "event";
  
  /**
   * Argumentos: La library a parsear
   * Descripci�n:Genera el bloque library contenido en un fichero .sce y llama a los parseadores de las properties,enum o functions si la library contuviera alguno de estos
   * Salida: Ninguna
   */
  public CharSequence defineBlockInterface(final Interface interfaceFile) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"interface\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"name\">");
    String _name = interfaceFile.getName();
    _builder.append(_name, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("<statement name=\"interface_functions\">");
    _builder.newLine();
    _builder.append("  \t");
    {
      EList<Event> _interfaceEvents = interfaceFile.getInterfaceEvents();
      for(final Event event : _interfaceEvents) {
        _builder.append("\t\t\t\t");
        CharSequence _defineBlockEvent = this.parserEvent.defineBlockEvent(event);
        _builder.append(_defineBlockEvent, "  \t");
        _builder.newLineIfNotEmpty();
        {
          if (((!event.equals(interfaceFile.getInterfaceEvents().get((interfaceFile.getInterfaceEvents().size() - 1)))) || (event.equals(interfaceFile.getInterfaceEvents().get((interfaceFile.getInterfaceEvents().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameEvent, interfaceFile)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<DeclarationFunctionInterface> _interfaceFunction = interfaceFile.getInterfaceFunction();
      for(final DeclarationFunctionInterface function : _interfaceFunction) {
        _builder.append("\t\t\t");
        CharSequence _defineInterfaceFunction = this.parserFunction.defineInterfaceFunction(function);
        _builder.append(_defineInterfaceFunction, "\t\t\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t\t");
        {
          EList<DeclarationFunctionInterface> _interfaceFunction_1 = interfaceFile.getInterfaceFunction();
          int _size = interfaceFile.getInterfaceFunction().size();
          int _minus = (_size - 1);
          boolean _equals = function.equals(_interfaceFunction_1.get(_minus));
          boolean _not = (!_equals);
          if (_not) {
            _builder.append("\t\t \t   \t<next>");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("</block>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t\t\t");
    CharSequence _closeTags = this.parserCommonFunctions.closeTags(interfaceFile.getInterfaceFunction().size());
    _builder.append(_closeTags, "\t\t\t");
    _builder.append("\t\t\t");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(interfaceFile.getInterfaceEvents().size(), this.parserCommonFunctions.controlMoreElements(this.nameEvent, interfaceFile));
    _builder.append(_closeTagsDistinctElements, "\t\t\t");
    _builder.append("\t\t</statement>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
}
