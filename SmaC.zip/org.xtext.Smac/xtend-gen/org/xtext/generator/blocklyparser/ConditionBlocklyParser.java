package org.xtext.generator.blocklyparser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.EventBlocklyParser;
import org.xtext.generator.blocklyparser.ExpressionBlocklyParser;
import org.xtext.generator.blocklyparser.LoopBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.PropertyBlocklyParser;
import org.xtext.smaC.Condition;
import org.xtext.smaC.Event;
import org.xtext.smaC.ForLoop;
import org.xtext.smaC.Properties;
import org.xtext.smaC.UnDeterminedLoop;

@SuppressWarnings("all")
public class ConditionBlocklyParser {
  private ExpressionBlocklyParser parserExpression = new ExpressionBlocklyParser();
  
  private LoopBlocklyParser parserLoop = new LoopBlocklyParser();
  
  private EventBlocklyParser parserEvent = new EventBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private PropertyBlocklyParser parserProperty = new PropertyBlocklyParser();
  
  private final String nameLocalProperty = "localProperty";
  
  private final String nameUndeterminedLoop = "undeterminedLoop";
  
  private final String nameDeterminedLoop = "determinedLoop";
  
  private final String nameEmitEvent = "emitEvent";
  
  private final String nameCondition = "condition";
  
  private final String nameUndeterminedLoopElse = "undeterminedLoopElse";
  
  private final String nameDeterminedLoopElse = "determinedLoopElse";
  
  private final String nameConditionLoopElse = "conditionLoopElse";
  
  private final String nameEmitEventElse = "emitEventElse";
  
  /**
   * Argumentos:La condici�n a parsear
   * Descripci�n: Se construye el bloque de la condici�n y llama a los parseadores de los elementos contenidos dentro del IF
   * Salida: Ninguna
   */
  public Object createBlockCondition(final Condition condition) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_ifcondition\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<value name=\"condition\">");
    _builder.newLine();
    _builder.append("      ");
    CharSequence _identifyExpressionRecursive = this.parserExpression.identifyExpressionRecursive(condition.getCondition());
    _builder.append(_identifyExpressionRecursive, "      ");
    _builder.newLineIfNotEmpty();
    _builder.append("    ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<statement name=\"actionsif\">");
    _builder.newLine();
    {
      EList<Properties> _properties = condition.getProperties();
      for(final Properties property : _properties) {
        CharSequence _identifyTypeProperty = this.parserProperty.identifyTypeProperty(property);
        _builder.append(_identifyTypeProperty);
        _builder.newLineIfNotEmpty();
        {
          if (((!property.equals(condition.getProperties().get((condition.getProperties().size() - 1)))) || (property.equals(condition.getProperties().get((condition.getProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<ForLoop> _determinedloops = condition.getDeterminedloops();
      for(final ForLoop determinedLoop : _determinedloops) {
        CharSequence _createBlockDeterminedLoop = this.parserLoop.createBlockDeterminedLoop(determinedLoop);
        _builder.append(_createBlockDeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!determinedLoop.equals(condition.getDeterminedloops().get((condition.getDeterminedloops().size() - 1)))) || (determinedLoop.equals(condition.getDeterminedloops().get((condition.getDeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<UnDeterminedLoop> _undeterminedloops = condition.getUndeterminedloops();
      for(final UnDeterminedLoop undeterminedLoop : _undeterminedloops) {
        Object _createBlockUndeterminedLoop = this.parserLoop.createBlockUndeterminedLoop(undeterminedLoop);
        _builder.append(_createBlockUndeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!undeterminedLoop.equals(condition.getUndeterminedloops().get((condition.getUndeterminedloops().size() - 1)))) || (undeterminedLoop.equals(condition.getUndeterminedloops().get((condition.getUndeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Condition> _conditionalExpr = condition.getConditionalExpr();
      for(final Condition conditionInside : _conditionalExpr) {
        Object _createBlockCondition = this.createBlockCondition(conditionInside);
        _builder.append(_createBlockCondition);
        _builder.append("\t  \t\t\t");
        {
          if (((!conditionInside.equals(condition.getConditionalExpr().get((condition.getConditionalExpr().size() - 1)))) || (conditionInside.equals(condition.getConditionalExpr().get((condition.getConditionalExpr().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameCondition, condition)))) {
            _builder.newLineIfNotEmpty();
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Event> _event = condition.getEvent();
      for(final Event emitEventExpression : _event) {
        _builder.append("      ");
        CharSequence _defineExpressionEmitEvent = this.parserEvent.defineExpressionEmitEvent(emitEventExpression, condition);
        _builder.append(_defineExpressionEmitEvent, "      ");
        _builder.newLineIfNotEmpty();
        {
          if (((!emitEventExpression.equals(condition.getEvent().get((condition.getEvent().size() - 1)))) || (emitEventExpression.equals(condition.getEvent().get((condition.getEvent().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameEmitEvent, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("      ");
    CharSequence _identifyExpressions = this.parserExpression.identifyExpressions(condition.getExpressions());
    _builder.append(_identifyExpressions, "      ");
    _builder.newLineIfNotEmpty();
    _builder.append("      ");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(condition.getEvent().size(), this.parserCommonFunctions.controlMoreElements(this.nameEmitEvent, condition));
    _builder.append(_closeTagsDistinctElements, "      ");
    _builder.append("\t\t      ");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getConditionalExpr().size(), this.parserCommonFunctions.controlMoreElements(this.nameCondition, condition));
    _builder.append(_closeTagsDistinctElements_1, "      ");
    _builder.append("\t\t      ");
    CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getUndeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, condition));
    _builder.append(_closeTagsDistinctElements_2, "      ");
    _builder.append("\t\t      ");
    CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getDeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, condition));
    _builder.append(_closeTagsDistinctElements_3, "      ");
    _builder.append("\t\t\t  ");
    CharSequence _closeTagsDistinctElements_4 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getProperties().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, condition));
    _builder.append(_closeTagsDistinctElements_4, "      ");
    _builder.newLineIfNotEmpty();
    _builder.append("    ");
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Argumentos: Condici�n con el else que se va a proceder a parsear
   * Descripci�n: Se construye el bloque para el ELSE de la condici�n que recibe de entrada en la funci�n, se llama al parseador de los distintos contenidos que hay en el ELSE
   * Salida: Ninguna
   */
  public CharSequence createBlockElseCondition(final Condition condition) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("\t    ");
    _builder.append("<block type=\"block_elsecondition\">");
    _builder.newLine();
    _builder.append("\t    ");
    _builder.append("<statement name=\"actionselse\">");
    _builder.newLine();
    {
      EList<Properties> _propertiesElse = condition.getPropertiesElse();
      for(final Properties property : _propertiesElse) {
        CharSequence _identifyTypeProperty = this.parserProperty.identifyTypeProperty(property);
        _builder.append(_identifyTypeProperty);
        _builder.newLineIfNotEmpty();
        {
          if (((!property.equals(condition.getProperties().get((condition.getProperties().size() - 1)))) || (property.equals(condition.getProperties().get((condition.getProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<ForLoop> _determinedloopsElse = condition.getDeterminedloopsElse();
      for(final ForLoop determinedLoop : _determinedloopsElse) {
        CharSequence _createBlockDeterminedLoop = this.parserLoop.createBlockDeterminedLoop(determinedLoop);
        _builder.append(_createBlockDeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!determinedLoop.equals(condition.getDeterminedloopsElse().get((condition.getDeterminedloopsElse().size() - 1)))) || (determinedLoop.equals(condition.getDeterminedloopsElse().get((condition.getDeterminedloopsElse().size() - 1))) && this.parserCommonFunctions.controlElseElements(this.nameDeterminedLoopElse, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<UnDeterminedLoop> _undeterminedloopsElse = condition.getUndeterminedloopsElse();
      for(final UnDeterminedLoop undeterminedLoop : _undeterminedloopsElse) {
        Object _createBlockUndeterminedLoop = this.parserLoop.createBlockUndeterminedLoop(undeterminedLoop);
        _builder.append(_createBlockUndeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!undeterminedLoop.equals(condition.getUndeterminedloopsElse().get((condition.getUndeterminedloopsElse().size() - 1)))) || (undeterminedLoop.equals(condition.getUndeterminedloopsElse().get((condition.getUndeterminedloopsElse().size() - 1))) && this.parserCommonFunctions.controlElseElements(this.nameUndeterminedLoopElse, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Condition> _conditionalExprElse = condition.getConditionalExprElse();
      for(final Condition conditionLoop : _conditionalExprElse) {
        Object _createBlockCondition = this.createBlockCondition(conditionLoop);
        _builder.append(_createBlockCondition);
        _builder.newLineIfNotEmpty();
        {
          if (((!conditionLoop.equals(condition.getConditionalExprElse().get((condition.getConditionalExprElse().size() - 1)))) || (conditionLoop.equals(condition.getConditionalExprElse().get((condition.getConditionalExprElse().size() - 1))) && this.parserCommonFunctions.controlElseElements(this.nameConditionLoopElse, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Event> _eventElse = condition.getEventElse();
      for(final Event emitEventExpression : _eventElse) {
        CharSequence _defineExpressionEmitEvent = this.parserEvent.defineExpressionEmitEvent(emitEventExpression, condition);
        _builder.append(_defineExpressionEmitEvent);
        _builder.newLineIfNotEmpty();
        {
          if (((!emitEventExpression.equals(condition.getEventElse().get((condition.getEventElse().size() - 1)))) || (emitEventExpression.equals(condition.getEventElse().get((condition.getEventElse().size() - 1))) && this.parserCommonFunctions.controlElseElements(this.nameEmitEventElse, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append(" \t\t");
    CharSequence _identifyExpressions = this.parserExpression.identifyExpressions(condition.getExpressionsElse());
    _builder.append(_identifyExpressions, " \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append(" \t\t");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(condition.getEventElse().size(), this.parserCommonFunctions.controlMoreElements(this.nameEmitEvent, condition));
    _builder.append(_closeTagsDistinctElements, " \t\t");
    _builder.append(" \t    ");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getConditionalExprElse().size(), this.parserCommonFunctions.controlElseElements(this.nameConditionLoopElse, condition));
    _builder.append(_closeTagsDistinctElements_1, " \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append(" \t    ");
    CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getUndeterminedloopsElse().size(), this.parserCommonFunctions.controlElseElements(this.nameUndeterminedLoopElse, condition));
    _builder.append(_closeTagsDistinctElements_2, " \t    ");
    _builder.newLineIfNotEmpty();
    _builder.append(" \t    ");
    CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getDeterminedloopsElse().size(), this.parserCommonFunctions.controlElseElements(this.nameDeterminedLoopElse, condition));
    _builder.append(_closeTagsDistinctElements_3, " \t    ");
    _builder.newLineIfNotEmpty();
    _builder.append(" \t    ");
    CharSequence _closeTagsDistinctElements_4 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getPropertiesElse().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, condition));
    _builder.append(_closeTagsDistinctElements_4, " \t    ");
    _builder.newLineIfNotEmpty();
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
}
