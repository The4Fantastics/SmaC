package org.xtext.generator.blocklyparser;

import com.google.common.base.Objects;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Extension;
import org.xtext.generator.blocklyparser.ConditionBlocklyParser;
import org.xtext.generator.blocklyparser.EventBlocklyParser;
import org.xtext.generator.blocklyparser.ExpressionBlocklyParser;
import org.xtext.generator.blocklyparser.LoopBlocklyParser;
import org.xtext.generator.blocklyparser.ParamBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.PropertyBlocklyParser;
import org.xtext.generator.blocklyparser.RestrictionClauseBlocklyParser;
import org.xtext.smaC.Clause;
import org.xtext.smaC.Condition;
import org.xtext.smaC.Event;
import org.xtext.smaC.ForLoop;
import org.xtext.smaC.InputModifier;
import org.xtext.smaC.InputParam;
import org.xtext.smaC.Mapping;
import org.xtext.smaC.Modifier;
import org.xtext.smaC.Properties;
import org.xtext.smaC.RestrictionClause;
import org.xtext.smaC.UnDeterminedLoop;

@SuppressWarnings("all")
public class FunctionBlocklyParser {
  private ParamBlocklyParser parserParam = new ParamBlocklyParser();
  
  private PropertyBlocklyParser parserProperty = new PropertyBlocklyParser();
  
  private ExpressionBlocklyParser parserExpression = new ExpressionBlocklyParser();
  
  private RestrictionClauseBlocklyParser parserRestriction = new RestrictionClauseBlocklyParser();
  
  private ConditionBlocklyParser parserCondition = new ConditionBlocklyParser();
  
  private LoopBlocklyParser parserLoop = new LoopBlocklyParser();
  
  private EventBlocklyParser parserEvent = new EventBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private final String nameRestriction = "restriction";
  
  private final String nameEmitEvent = "emitEvent";
  
  private final String nameLocalProperty = "localProperty";
  
  private final String nameLocalMapping = "localMappingProperty";
  
  private final String nameUndeterminedLoop = "undeterminedLoop";
  
  private final String nameDeterminedLoop = "determinedLoop";
  
  private final String nameCondition = "condition";
  
  private final String namePredefinedFunctions = "predefinedFunction";
  
  /**
   * Argumentos:La funci�n a parsear
   * Descripci�n: Se construye el bloque para la funci�n (clause) que recibe de entrada en la funci�n, se parsean tambi�n los par�metros de entrada que recibe la funci�n y su contenido
   * Salida: Ninguna
   */
  public CharSequence defineFunction(final Clause function) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"clause\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _name = function.getName();
    _builder.append(_name);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"values_visibility\">");
    String _string = function.getVisibilityAccess().toString();
    _builder.append(_string);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    {
      InputModifier _predefinedModifier = function.getPredefinedModifier();
      boolean _tripleNotEquals = (_predefinedModifier != null);
      if (_tripleNotEquals) {
        _builder.append(" \t<field name=\"values_inputmodifier\">");
        String _string_1 = function.getPredefinedModifier().toString();
        _builder.append(_string_1);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size = function.getPersonalizedModifier().size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        _builder.append(" \t<value name=\"modifiers\">");
        _builder.newLineIfNotEmpty();
        _builder.append(" \t\t");
        @Extension
        ArrayList<InputParam> listaParametrosEntradaModificadores = CollectionLiterals.<InputParam>newArrayList();
        _builder.append(" \t\t");
        {
          EList<Modifier> _personalizedModifier = function.getPersonalizedModifier();
          for(final Modifier inputModifier : _personalizedModifier) {
            _builder.append(" \t\t\t");
            {
              EList<InputParam> _inputParams = inputModifier.getInputParams();
              for(final InputParam inputParam : _inputParams) {
                _builder.newLineIfNotEmpty();
                _builder.append(" \t\t");
                boolean _add = listaParametrosEntradaModificadores.add(inputParam);
                _builder.append(_add, " \t\t");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("        ");
        {
          EList<Modifier> _personalizedModifier_1 = function.getPersonalizedModifier();
          for(final Modifier inputModifier_1 : _personalizedModifier_1) {
            _builder.append("        \t");
            ArrayList<InputParam> lista2 = CollectionLiterals.<InputParam>newArrayList();
            _builder.newLineIfNotEmpty();
            _builder.append("        ");
            _builder.append("\t");
            int _size_1 = inputModifier_1.getInputParams().size();
            ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size_1, true);
            for (final Integer i : _doubleDotLessThan) {
              if ((listaParametrosEntradaModificadores != null)) {
                lista2.add(listaParametrosEntradaModificadores.get((i).intValue()));
              }
            }
            _builder.append("      \t");
            _builder.newLineIfNotEmpty();
            _builder.append("        ");
            _builder.append("\t");
            CharSequence _generateInputModifier = this.generateInputModifier(inputModifier_1, lista2);
            _builder.append(_generateInputModifier, "        \t");
            _builder.append("  ");
            _builder.newLineIfNotEmpty();
            {
              int _size_2 = lista2.size();
              boolean _greaterThan_1 = (_size_2 > 0);
              if (_greaterThan_1) {
                _builder.append("        ");
                _builder.append("\t");
                boolean _removeAll = listaParametrosEntradaModificadores.removeAll(lista2);
                _builder.append(_removeAll, "        \t");
                _builder.append("   ");
                _builder.newLineIfNotEmpty();
              }
            }
            {
              EList<Modifier> _personalizedModifier_2 = function.getPersonalizedModifier();
              int _size_3 = function.getPersonalizedModifier().size();
              int _minus = (_size_3 - 1);
              boolean _equals = inputModifier_1.equals(_personalizedModifier_2.get(_minus));
              boolean _not = (!_equals);
              if (_not) {
                _builder.append("<value name=\"modifier\">");
                _builder.newLine();
              }
            }
          }
        }
        _builder.append("        ");
        CharSequence _closeTagsValuesEnumerator = this.closeTagsValuesEnumerator(function.getPersonalizedModifier().size());
        _builder.append(_closeTagsValuesEnumerator, "        ");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      int _size_4 = function.getInputParams().size();
      boolean _greaterThan_2 = (_size_4 > 0);
      if (_greaterThan_2) {
        _builder.append("\t<value name=\"inputparams_function\">");
        _builder.newLineIfNotEmpty();
        CharSequence _defineInputParams = this.parserParam.defineInputParams(function.getInputParams());
        _builder.append(_defineInputParams);
        _builder.newLineIfNotEmpty();
        _builder.append("</value>\t");
        _builder.newLine();
      }
    }
    {
      int _size_5 = function.getOutputParams().size();
      boolean _greaterThan_3 = (_size_5 > 0);
      if (_greaterThan_3) {
        _builder.append("\t<value name=\"returns_values\">");
        _builder.newLineIfNotEmpty();
        CharSequence _defineOutputParam = this.parserParam.defineOutputParam(function.getOutputParams());
        _builder.append(_defineOutputParam);
        _builder.newLineIfNotEmpty();
        _builder.append("</value>");
        _builder.newLine();
      }
    }
    _builder.append("<statement name=\"elements_function\">\t\t");
    _builder.newLine();
    {
      EList<RestrictionClause> _restriction = function.getRestriction();
      for(final RestrictionClause restriction : _restriction) {
        CharSequence _identifyRestriction = this.parserRestriction.identifyRestriction(restriction);
        _builder.append(_identifyRestriction);
        _builder.newLineIfNotEmpty();
        {
          if (((!restriction.equals(function.getRestriction().get((function.getRestriction().size() - 1)))) || (restriction.equals(function.getRestriction().get((function.getRestriction().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameRestriction, function)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Properties> _properties = function.getProperties();
      for(final Properties localProperty : _properties) {
        CharSequence _identifyTypeProperty = this.parserProperty.identifyTypeProperty(localProperty);
        _builder.append(_identifyTypeProperty);
        _builder.newLineIfNotEmpty();
        {
          if (((!localProperty.equals(function.getProperties().get((function.getProperties().size() - 1)))) || (localProperty.equals(function.getProperties().get((function.getProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, function)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Mapping> _mappingProperties = function.getMappingProperties();
      for(final Mapping mappingLocalProperty : _mappingProperties) {
        CharSequence _identifyMappingProperty = this.parserProperty.identifyMappingProperty(mappingLocalProperty);
        _builder.append(_identifyMappingProperty);
        _builder.newLineIfNotEmpty();
        {
          if (((!mappingLocalProperty.equals(function.getMappingProperties().get((function.getMappingProperties().size() - 1)))) || (mappingLocalProperty.equals(function.getMappingProperties().get((function.getMappingProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalMapping, function)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<UnDeterminedLoop> _undeterminedloops = function.getUndeterminedloops();
      for(final UnDeterminedLoop undeterminedLoop : _undeterminedloops) {
        Object _createBlockUndeterminedLoop = this.parserLoop.createBlockUndeterminedLoop(undeterminedLoop);
        _builder.append(_createBlockUndeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!undeterminedLoop.equals(function.getUndeterminedloops().get((function.getUndeterminedloops().size() - 1)))) || (undeterminedLoop.equals(function.getUndeterminedloops().get((function.getUndeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, function)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<ForLoop> _determinedloops = function.getDeterminedloops();
      for(final ForLoop determinedLoop : _determinedloops) {
        CharSequence _createBlockDeterminedLoop = this.parserLoop.createBlockDeterminedLoop(determinedLoop);
        _builder.append(_createBlockDeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!determinedLoop.equals(function.getDeterminedloops().get((function.getDeterminedloops().size() - 1)))) || (determinedLoop.equals(function.getDeterminedloops().get((function.getDeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, function)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Condition> _conditions = function.getConditions();
      for(final Condition condition : _conditions) {
        Object _createBlockCondition = this.parserCondition.createBlockCondition(condition);
        _builder.append(_createBlockCondition);
        _builder.append("\t\t");
        _builder.append("\t\t");
        {
          boolean _controlElseConditionElements = this.parserCommonFunctions.controlElseConditionElements(condition);
          if (_controlElseConditionElements) {
            _builder.newLineIfNotEmpty();
            _builder.append("<next>");
            _builder.append("\t\t");
            CharSequence _createBlockElseCondition = this.parserCondition.createBlockElseCondition(condition);
            _builder.append(_createBlockElseCondition);
            _builder.append("\t\t");
          }
        }
        _builder.newLineIfNotEmpty();
        {
          if (((!condition.equals(function.getConditions().get((function.getConditions().size() - 1)))) || (condition.equals(function.getConditions().get((function.getConditions().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameCondition, function)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<String> _predefinedFunctions = function.getPredefinedFunctions();
      for(final String predefinedFunction : _predefinedFunctions) {
        CharSequence _identifyPredefiniedFunction = this.parserExpression.identifyPredefiniedFunction(predefinedFunction);
        _builder.append(_identifyPredefiniedFunction);
        _builder.append("\t\t");
        {
          if (((!predefinedFunction.equals(function.getPredefinedFunctions().get((function.getPredefinedFunctions().size() - 1)))) || (predefinedFunction.equals(function.getPredefinedFunctions().get((function.getPredefinedFunctions().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.namePredefinedFunctions, function)))) {
            _builder.newLineIfNotEmpty();
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Event> _event = function.getEvent();
      for(final Event emitEventExpression : _event) {
        CharSequence _defineExpressionEmitEvent = this.parserEvent.defineExpressionEmitEvent(emitEventExpression, function);
        _builder.append(_defineExpressionEmitEvent);
        _builder.newLineIfNotEmpty();
        {
          if (((!emitEventExpression.equals(function.getEvent().get((function.getEvent().size() - 1)))) || (emitEventExpression.equals(function.getEvent().get((function.getEvent().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameEmitEvent, function)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    CharSequence _identifyExpressions = this.parserExpression.identifyExpressions(function.getExpressions());
    _builder.append(_identifyExpressions);
    _builder.newLineIfNotEmpty();
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(function.getEvent().size(), this.parserCommonFunctions.controlMoreElements(this.nameEmitEvent, function));
    _builder.append(_closeTagsDistinctElements);
    _builder.append("\t");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(function.getPredefinedFunctions().size(), this.parserCommonFunctions.controlMoreElements(this.namePredefinedFunctions, function));
    _builder.append(_closeTagsDistinctElements_1);
    _builder.append("\t");
    {
      boolean _controlElseInConditionsElements = this.parserCommonFunctions.controlElseInConditionsElements(function.getConditions());
      boolean _equals_1 = (_controlElseInConditionsElements == false);
      if (_equals_1) {
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(function.getConditions().size(), this.parserCommonFunctions.controlMoreElements(this.nameCondition, function));
        _builder.append(_closeTagsDistinctElements_2);
        _builder.append("\t");
      } else {
        _builder.newLineIfNotEmpty();
      }
    }
    CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(function.getDeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, function));
    _builder.append(_closeTagsDistinctElements_3);
    _builder.append("\t");
    CharSequence _closeTagsDistinctElements_4 = this.parserCommonFunctions.closeTagsDistinctElements(function.getUndeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, function));
    _builder.append(_closeTagsDistinctElements_4);
    _builder.append("\t");
    CharSequence _closeTagsDistinctElements_5 = this.parserCommonFunctions.closeTagsDistinctElements(function.getMappingProperties().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalMapping, function));
    _builder.append(_closeTagsDistinctElements_5);
    _builder.newLineIfNotEmpty();
    CharSequence _closeTagsDistinctElements_6 = this.parserCommonFunctions.closeTagsDistinctElements(function.getProperties().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, function));
    _builder.append(_closeTagsDistinctElements_6);
    _builder.newLineIfNotEmpty();
    CharSequence _closeTagsDistinctElements_7 = this.parserCommonFunctions.closeTagsDistinctElements(function.getRestriction().size(), this.parserCommonFunctions.controlMoreElements(this.nameRestriction, function));
    _builder.append(_closeTagsDistinctElements_7);
    _builder.newLineIfNotEmpty();
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Argumentos:Modificador a parsear que recibe la funci�n
   * Descripci�n: Se construye el bloque para el modificador que recibe de entrada en la funci�n, se parsean tambi�n los par�metros de entrada que recibe el modificador
   * Salida: Ninguna
   */
  private CharSequence generateInputModifier(final Modifier inputmodifier, final List<InputParam> inputsmodifier) {
    CharSequence _xblockexpression = null;
    {
      String textInputsModifier = "";
      for (int i = 0; (i < inputmodifier.getInputParams().size()); i++) {
        {
          InputParam input = inputsmodifier.get(i);
          if ((((!Objects.equal(input.getTypeSingularInput(), "")) || (input.getTypeSingularInput() != null)) && ((input.getValueInput() == null) || (input.getValueInput() == "")))) {
            String _textInputsModifier = textInputsModifier;
            String _typeSingularInput = input.getTypeSingularInput();
            textInputsModifier = (_textInputsModifier + _typeSingularInput);
          } else {
            String _textInputsModifier_1 = textInputsModifier;
            String _valueInput = input.getValueInput();
            textInputsModifier = (_textInputsModifier_1 + _valueInput);
          }
          int _size = inputmodifier.getInputParams().size();
          boolean _greaterThan = (_size > 1);
          if (_greaterThan) {
            String _textInputsModifier_2 = textInputsModifier;
            textInputsModifier = (_textInputsModifier_2 + ",");
          }
        }
      }
      CharSequence _xifexpression = null;
      int _size = inputsmodifier.size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("<block type=\"block_inputmodifier\">");
        _builder.newLine();
        _builder.append("\t\t \t");
        _builder.append("<field name=\"value\">");
        String _name = inputmodifier.getName();
        String _plus = (_name + "(");
        String _plus_1 = (_plus + textInputsModifier);
        String _plus_2 = (_plus_1 + ")");
        _builder.append(_plus_2, "\t\t \t");
        _builder.append("</field>");
        _xifexpression = _builder;
      } else {
        StringConcatenation _builder_1 = new StringConcatenation();
        _builder_1.append("<block type=\"block_inputmodifier\">");
        _builder_1.newLine();
        _builder_1.append("\t\t \t");
        _builder_1.append("<field name=\"value\">");
        String _name_1 = inputmodifier.getName();
        _builder_1.append(_name_1, "\t\t \t");
        _builder_1.append("</field>");
        _xifexpression = _builder_1;
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  /**
   * Argumentos:Numero de modificadores personalizados que recibe como entrada la funci�n
   * Descripci�n:Seg�n la cantidad de modificadores personalizados cierra las etiquetas <block> y <value> de la construcci�n de los bloques para dichos modificadores
   * Salida: Ninguna
   */
  private CharSequence closeTagsValuesEnumerator(final int numberInputModifiers) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if ((numberInputModifiers != 0)) {
        final int[] elementsToClose = new int[numberInputModifiers];
        _builder.newLineIfNotEmpty();
        {
          for(final int element : elementsToClose) {
            _builder.append("\t  \t");
            _builder.append("</block>");
            _builder.newLine();
            _builder.append("</value>");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
}
