package org.xtext.generator.blocklyparser;

import com.google.common.base.Objects;
import java.util.List;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.VariablesBlocklyParser;

@SuppressWarnings("all")
public class ExpressionBlocklyParser {
  private final String identifierFunctionSelfdestruct = "selfdestruct";
  
  private final String identifierFunctionKeccak256 = "keccack256";
  
  private final String identifierFunctionSha3 = "sha3";
  
  private final String identifierFunctionSha256 = "sha256";
  
  private final String identifierFunctionAbyEncodedPackage = "abi.encodePacked";
  
  private final String identifierFunctionAbyEncode = "abi.encode";
  
  private final String identifierFunctionAbyEncodeWithSignature = "abi.encodeWithSignature";
  
  private final String identifierFunctionAbyDecode = "abi.decode";
  
  private final String identifierFunctionAssert = "assert";
  
  private final String identifierFunctionRevert = "revert";
  
  private final String identifierFunctionDelete = "delete";
  
  private final String identifierFunctionLog = "log";
  
  private final String identifySecondsUnitTime = "seconds";
  
  private final String identifyMinutesUnitTime = "minutes";
  
  private final String identifyHoursUnitTime = "hours";
  
  private final String identifyDaysUnitTime = "days";
  
  private final String identifyWeeksUnitTime = "weeks";
  
  private final String identifyYearsUnitTime = "years";
  
  private final String identifyEtherUnitCoin = "ether";
  
  private final String identifyWeiUnitCoin = "wei";
  
  private final String identifyGweiUnitCoin = "gwei";
  
  private final String identifyPweiUnitCoin = "pwei";
  
  private final String identifyFinneyUnitCoin = "finney";
  
  private final String identifySzaboUnitCoin = "szabo";
  
  private final String operatorLogicalAnd = "&&";
  
  private final String operatorLogicalOr = "||";
  
  private final String operatorEqual = "==";
  
  private final String operatorNotEqual = "!=";
  
  private final String operatorGreater = ">";
  
  private final String operatorGreaterEqual = ">=";
  
  private final String operatorLessEqual = "<=";
  
  private final String operatorLess = "<";
  
  private final String operatorAssignValue = "=";
  
  private final String operatorAssignPlusValue = "+=";
  
  private final String operatorAssignMinunValue = "-=";
  
  private final String operatorAssignMultValue = "*=";
  
  private final String operatorAssignDivValue = "/=";
  
  private final String operatorAssignModValue = "%=";
  
  private final String operatorAssignShiftLeftValue = "<<=";
  
  private final String operatorAssignShiftRightValue = ">>=";
  
  private final String operatorShiftLeft = "<<";
  
  private final String operatorShiftRight = ">>";
  
  private final String operatorNegation = "!";
  
  private final String operatorPlus = "+";
  
  private final String operatorMinun = "-";
  
  private final String operatorMult = "*";
  
  private final String operatorPotence = "**";
  
  private final String operatorDiv = "/";
  
  private final String operatorMod = "%";
  
  private final String operatorBitOr = "|";
  
  private final String operatorBitAnd = "&";
  
  private final String operatorBitExclusiveOr = "^";
  
  private final String operatorBitNegation = "~";
  
  private final String identifierVar = "var";
  
  private final String identifierAssembly = "assembly";
  
  private final String identifierLetAssembly = "let";
  
  private final String operatorAssembly = ":=";
  
  private final String identifierReturn = "return";
  
  private final String identifierNew = "new";
  
  private final String openParenthesis = "(";
  
  private final String closeParenthesis = ")";
  
  private VariablesBlocklyParser parserVariablesBlockly = new VariablesBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  public CharSequence identifyExpressions(final List<String> expressions) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final String expression : expressions) {
        CharSequence _identifyExpressionRecursive = this.identifyExpressionRecursive(expression);
        _builder.append(_identifyExpressionRecursive);
        _builder.newLineIfNotEmpty();
        {
          int _size = expressions.size();
          int _minus = (_size - 1);
          boolean _equals = expression.equals(expressions.get(_minus));
          boolean _not = (!_equals);
          if (_not) {
            _builder.append("\t\t\t<next>");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("</block>");
            _builder.newLine();
          }
        }
      }
    }
    CharSequence _closeTags = this.parserCommonFunctions.closeTags(expressions.size());
    _builder.append(_closeTags);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  public CharSequence identifyExpressionRecursive(final String expression) {
    CharSequence _xblockexpression = null;
    {
      String[] expressionSeparate = null;
      CharSequence _switchResult = null;
      boolean _matched = false;
      boolean _contains = expression.contains(this.operatorLogicalAnd);
      if (_contains) {
        _matched=true;
        CharSequence _xblockexpression_1 = null;
        {
          expressionSeparate = expression.toString().split(this.operatorLogicalAnd, 2);
          _xblockexpression_1 = this.generateComparationOperatorBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorLogicalAnd);
        }
        _switchResult = _xblockexpression_1;
      }
      if (!_matched) {
        boolean _contains_1 = expression.contains(this.operatorLogicalOr);
        if (_contains_1) {
          _matched=true;
          CharSequence _xblockexpression_2 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorLogicalOr, 2);
            _xblockexpression_2 = this.generateComparationOperatorBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorLogicalOr);
          }
          _switchResult = _xblockexpression_2;
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierVar) && expression.toString().startsWith((this.identifierVar + "")))) {
          _matched=true;
          _switchResult = this.generateVarBlock(expression);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierReturn) && expression.toString().startsWith((this.identifierReturn + " ")))) {
          _matched=true;
          _switchResult = this.generateReturnBlock(expression);
        }
      }
      if (!_matched) {
        if ((((expression.startsWith(this.openParenthesis) && expression.endsWith(this.closeParenthesis)) && (!expression.contains(","))) && ((!expression.contains(this.operatorLogicalAnd)) || (!expression.contains(this.operatorLogicalOr))))) {
          _matched=true;
          StringConcatenation _builder = new StringConcatenation();
          CharSequence _generateParenthesisBlock = this.generateParenthesisBlock(expression);
          _builder.append(_generateParenthesisBlock);
          _switchResult = _builder;
        }
      }
      if (!_matched) {
        boolean _contains_2 = expression.contains(this.operatorEqual);
        if (_contains_2) {
          _matched=true;
          CharSequence _xblockexpression_3 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorEqual, 2);
            _xblockexpression_3 = this.generateLogicalComparationExpressionBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorEqual);
          }
          _switchResult = _xblockexpression_3;
        }
      }
      if (!_matched) {
        boolean _contains_3 = expression.contains(this.operatorNotEqual);
        if (_contains_3) {
          _matched=true;
          CharSequence _xblockexpression_4 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorNotEqual, 2);
            _xblockexpression_4 = this.generateLogicalComparationExpressionBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorNotEqual);
          }
          _switchResult = _xblockexpression_4;
        }
      }
      if (!_matched) {
        boolean _contains_4 = expression.contains(this.operatorAssignShiftLeftValue);
        if (_contains_4) {
          _matched=true;
          CharSequence _xblockexpression_5 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorAssignShiftLeftValue, 2);
            _xblockexpression_5 = this.generateAssignValueBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorAssignShiftLeftValue);
          }
          _switchResult = _xblockexpression_5;
        }
      }
      if (!_matched) {
        boolean _contains_5 = expression.contains(this.operatorAssignShiftRightValue);
        if (_contains_5) {
          _matched=true;
          CharSequence _xblockexpression_6 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorAssignShiftRightValue, 2);
            _xblockexpression_6 = this.generateAssignValueBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorAssignShiftRightValue);
          }
          _switchResult = _xblockexpression_6;
        }
      }
      if (!_matched) {
        boolean _contains_6 = expression.contains(this.operatorShiftLeft);
        if (_contains_6) {
          _matched=true;
          CharSequence _xblockexpression_7 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorShiftLeft, 2);
            _xblockexpression_7 = this.generateShiftExpressionBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorShiftLeft);
          }
          _switchResult = _xblockexpression_7;
        }
      }
      if (!_matched) {
        boolean _contains_7 = expression.contains(this.operatorShiftRight);
        if (_contains_7) {
          _matched=true;
          CharSequence _xblockexpression_8 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorShiftRight, 2);
            _xblockexpression_8 = this.generateShiftExpressionBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorShiftRight);
          }
          _switchResult = _xblockexpression_8;
        }
      }
      if (!_matched) {
        boolean _contains_8 = expression.contains(this.operatorGreater);
        if (_contains_8) {
          _matched=true;
          CharSequence _xblockexpression_9 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorGreater, 2);
            _xblockexpression_9 = this.generateArithmeticalLogicalComparationExpressionBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorGreater);
          }
          _switchResult = _xblockexpression_9;
        }
      }
      if (!_matched) {
        boolean _contains_9 = expression.contains(this.operatorGreaterEqual);
        if (_contains_9) {
          _matched=true;
          CharSequence _xblockexpression_10 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorGreaterEqual, 2);
            _xblockexpression_10 = this.generateArithmeticalLogicalComparationExpressionBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorGreaterEqual);
          }
          _switchResult = _xblockexpression_10;
        }
      }
      if (!_matched) {
        boolean _contains_10 = expression.contains(this.operatorLessEqual);
        if (_contains_10) {
          _matched=true;
          CharSequence _xblockexpression_11 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorLessEqual, 2);
            _xblockexpression_11 = this.generateArithmeticalLogicalComparationExpressionBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorLessEqual);
          }
          _switchResult = _xblockexpression_11;
        }
      }
      if (!_matched) {
        boolean _contains_11 = expression.contains(this.operatorLess);
        if (_contains_11) {
          _matched=true;
          CharSequence _xblockexpression_12 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorLess, 2);
            _xblockexpression_12 = this.generateArithmeticalLogicalComparationExpressionBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorLess);
          }
          _switchResult = _xblockexpression_12;
        }
      }
      if (!_matched) {
        boolean _contains_12 = expression.contains(this.operatorAssignPlusValue);
        if (_contains_12) {
          _matched=true;
          CharSequence _xblockexpression_13 = null;
          {
            expressionSeparate = expression.toString().split("\\+=", 2);
            _xblockexpression_13 = this.generateAssignValueBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorAssignPlusValue);
          }
          _switchResult = _xblockexpression_13;
        }
      }
      if (!_matched) {
        boolean _contains_13 = expression.contains(this.operatorAssignMinunValue);
        if (_contains_13) {
          _matched=true;
          CharSequence _xblockexpression_14 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorAssignMinunValue, 2);
            _xblockexpression_14 = this.generateAssignValueBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorAssignMinunValue);
          }
          _switchResult = _xblockexpression_14;
        }
      }
      if (!_matched) {
        boolean _contains_14 = expression.contains(this.operatorAssignMultValue);
        if (_contains_14) {
          _matched=true;
          CharSequence _xblockexpression_15 = null;
          {
            expressionSeparate = expression.toString().split("\\*=", 2);
            _xblockexpression_15 = this.generateAssignValueBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorAssignMultValue);
          }
          _switchResult = _xblockexpression_15;
        }
      }
      if (!_matched) {
        boolean _contains_15 = expression.contains(this.operatorAssignDivValue);
        if (_contains_15) {
          _matched=true;
          CharSequence _xblockexpression_16 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorAssignValue, 2);
            _xblockexpression_16 = this.generateAssignValueBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorAssignDivValue);
          }
          _switchResult = _xblockexpression_16;
        }
      }
      if (!_matched) {
        boolean _contains_16 = expression.contains(this.operatorAssignModValue);
        if (_contains_16) {
          _matched=true;
          CharSequence _xblockexpression_17 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorAssignModValue, 2);
            _xblockexpression_17 = this.generateAssignValueBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorAssignModValue);
          }
          _switchResult = _xblockexpression_17;
        }
      }
      if (!_matched) {
        boolean _contains_17 = expression.contains(this.operatorAssignValue);
        if (_contains_17) {
          _matched=true;
          CharSequence _xblockexpression_18 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorAssignValue, 2);
            _xblockexpression_18 = this.generateAssignValueBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorAssignValue);
          }
          _switchResult = _xblockexpression_18;
        }
      }
      if (!_matched) {
        if ((expression.contains(this.operatorNegation) && (!expression.contains(this.operatorNotEqual)))) {
          _matched=true;
          _switchResult = this.generateNegationBlock(expression);
        }
      }
      if (!_matched) {
        boolean _contains_18 = expression.contains(this.operatorPlus);
        if (_contains_18) {
          _matched=true;
          CharSequence _xblockexpression_19 = null;
          {
            expressionSeparate = expression.toString().split("\\+", 2);
            _xblockexpression_19 = this.generateArithmethicalBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorPlus);
          }
          _switchResult = _xblockexpression_19;
        }
      }
      if (!_matched) {
        boolean _contains_19 = expression.contains(this.operatorMinun);
        if (_contains_19) {
          _matched=true;
          CharSequence _xblockexpression_20 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorMinun, 2);
            _xblockexpression_20 = this.generateArithmethicalBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorMinun);
          }
          _switchResult = _xblockexpression_20;
        }
      }
      if (!_matched) {
        boolean _contains_20 = expression.contains(this.operatorMult);
        if (_contains_20) {
          _matched=true;
          CharSequence _xblockexpression_21 = null;
          {
            expressionSeparate = expression.toString().split("\\*", 2);
            _xblockexpression_21 = this.generateArithmethicalBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorMult);
          }
          _switchResult = _xblockexpression_21;
        }
      }
      if (!_matched) {
        boolean _contains_21 = expression.contains(this.operatorPotence);
        if (_contains_21) {
          _matched=true;
          CharSequence _xblockexpression_22 = null;
          {
            expressionSeparate = expression.toString().split("\\**", 2);
            _xblockexpression_22 = this.generateArithmethicalBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorPotence);
          }
          _switchResult = _xblockexpression_22;
        }
      }
      if (!_matched) {
        boolean _contains_22 = expression.contains(this.operatorDiv);
        if (_contains_22) {
          _matched=true;
          CharSequence _xblockexpression_23 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorDiv, 2);
            _xblockexpression_23 = this.generateArithmethicalBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorDiv);
          }
          _switchResult = _xblockexpression_23;
        }
      }
      if (!_matched) {
        boolean _contains_23 = expression.contains(this.operatorMod);
        if (_contains_23) {
          _matched=true;
          CharSequence _xblockexpression_24 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorMod, 2);
            _xblockexpression_24 = this.generateArithmethicalBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorMod);
          }
          _switchResult = _xblockexpression_24;
        }
      }
      if (!_matched) {
        boolean _contains_24 = expression.contains(this.operatorBitAnd);
        if (_contains_24) {
          _matched=true;
          CharSequence _xblockexpression_25 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorBitAnd, 2);
            _xblockexpression_25 = this.generateBitComparationBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorBitAnd);
          }
          _switchResult = _xblockexpression_25;
        }
      }
      if (!_matched) {
        boolean _contains_25 = expression.contains(this.operatorBitOr);
        if (_contains_25) {
          _matched=true;
          CharSequence _xblockexpression_26 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorBitOr, 2);
            _xblockexpression_26 = this.generateBitComparationBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorBitOr);
          }
          _switchResult = _xblockexpression_26;
        }
      }
      if (!_matched) {
        boolean _contains_26 = expression.contains(this.operatorBitNegation);
        if (_contains_26) {
          _matched=true;
          CharSequence _xblockexpression_27 = null;
          {
            expressionSeparate = expression.toString().split(this.operatorBitNegation, 2);
            _xblockexpression_27 = this.generateBitComparationBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorBitNegation);
          }
          _switchResult = _xblockexpression_27;
        }
      }
      if (!_matched) {
        boolean _contains_27 = expression.contains(this.operatorBitExclusiveOr);
        if (_contains_27) {
          _matched=true;
          CharSequence _xblockexpression_28 = null;
          {
            expressionSeparate = expression.toString().split("\\^", 2);
            _xblockexpression_28 = this.generateBitComparationBlock((expressionSeparate[0]).toString().trim(), (expressionSeparate[1]).toString().replace(";", "").trim(), this.operatorBitExclusiveOr);
          }
          _switchResult = _xblockexpression_28;
        }
      }
      if (!_matched) {
        boolean _startsWith = expression.startsWith(this.identifierAssembly);
        if (_startsWith) {
          _matched=true;
          _switchResult = this.generateAssemblyExpression(expression);
        }
      }
      if (!_matched) {
        if ((((((expression.contains(this.openParenthesis) && expression.contains(this.closeParenthesis)) && expression.contains(",")) && (!expression.contains("."))) && Character.valueOf(expression.charAt(0)).toString().equals(this.openParenthesis)) && Character.valueOf(expression.charAt((expression.length() - 1))).toString().equals(this.closeParenthesis))) {
          _matched=true;
          _switchResult = this.generateTupleBlock(expression);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierNew) && expression.toString().startsWith((this.identifierNew + "")))) {
          _matched=true;
          _switchResult = this.generateNewExpressionBlock(expression);
        }
      }
      if (!_matched) {
        boolean _contains_28 = expression.contains(this.identifySecondsUnitTime);
        if (_contains_28) {
          _matched=true;
          _switchResult = this.generateTimeExpressionBlock(expression, this.identifySecondsUnitTime);
        }
      }
      if (!_matched) {
        boolean _contains_29 = expression.contains(this.identifyMinutesUnitTime);
        if (_contains_29) {
          _matched=true;
          _switchResult = this.generateTimeExpressionBlock(expression, this.identifyMinutesUnitTime);
        }
      }
      if (!_matched) {
        boolean _contains_30 = expression.contains(this.identifyHoursUnitTime);
        if (_contains_30) {
          _matched=true;
          _switchResult = this.generateTimeExpressionBlock(expression, this.identifyHoursUnitTime);
        }
      }
      if (!_matched) {
        boolean _contains_31 = expression.contains(this.identifyDaysUnitTime);
        if (_contains_31) {
          _matched=true;
          _switchResult = this.generateTimeExpressionBlock(expression, this.identifyDaysUnitTime);
        }
      }
      if (!_matched) {
        boolean _contains_32 = expression.contains(this.identifyWeeksUnitTime);
        if (_contains_32) {
          _matched=true;
          _switchResult = this.generateTimeExpressionBlock(expression, this.identifyWeeksUnitTime);
        }
      }
      if (!_matched) {
        boolean _contains_33 = expression.contains(this.identifyYearsUnitTime);
        if (_contains_33) {
          _matched=true;
          _switchResult = this.generateTimeExpressionBlock(expression, this.identifyYearsUnitTime);
        }
      }
      if (!_matched) {
        boolean _contains_34 = expression.contains(this.identifyEtherUnitCoin);
        if (_contains_34) {
          _matched=true;
          _switchResult = this.generateCoinExpressionBlock(expression, this.identifyEtherUnitCoin);
        }
      }
      if (!_matched) {
        boolean _contains_35 = expression.contains(this.identifyGweiUnitCoin);
        if (_contains_35) {
          _matched=true;
          _switchResult = this.generateCoinExpressionBlock(expression, this.identifyGweiUnitCoin);
        }
      }
      if (!_matched) {
        boolean _contains_36 = expression.contains(this.identifyPweiUnitCoin);
        if (_contains_36) {
          _matched=true;
          _switchResult = this.generateCoinExpressionBlock(expression, this.identifyPweiUnitCoin);
        }
      }
      if (!_matched) {
        boolean _contains_37 = expression.contains(this.identifyWeiUnitCoin);
        if (_contains_37) {
          _matched=true;
          _switchResult = this.generateCoinExpressionBlock(expression, this.identifyWeiUnitCoin);
        }
      }
      if (!_matched) {
        boolean _contains_38 = expression.contains(this.identifyFinneyUnitCoin);
        if (_contains_38) {
          _matched=true;
          _switchResult = this.generateCoinExpressionBlock(expression, this.identifyFinneyUnitCoin);
        }
      }
      if (!_matched) {
        boolean _contains_39 = expression.contains(this.identifySzaboUnitCoin);
        if (_contains_39) {
          _matched=true;
          _switchResult = this.generateCoinExpressionBlock(expression, this.identifySzaboUnitCoin);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierFunctionSelfdestruct) && expression.startsWith(this.identifierFunctionSelfdestruct))) {
          _matched=true;
          _switchResult = this.generateSelfdestructBlock(expression);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierFunctionAssert) || expression.startsWith(this.identifierFunctionAssert))) {
          _matched=true;
          _switchResult = this.generateAssertBlock(expression);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierFunctionRevert) || expression.startsWith(this.identifierFunctionRevert))) {
          _matched=true;
          _switchResult = this.generateRevertBlock(expression);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierFunctionDelete) || expression.startsWith(this.identifierFunctionDelete))) {
          _matched=true;
          _switchResult = this.generateDeleteBlock(expression);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierFunctionKeccak256) || expression.startsWith(this.identifierFunctionKeccak256))) {
          _matched=true;
          _switchResult = this.generateKeccakInputBlock(expression);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierFunctionAbyEncodedPackage) || expression.startsWith(this.identifierFunctionAbyEncodedPackage))) {
          _matched=true;
          _switchResult = this.generateAbyEncodeInputBlock(expression);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierFunctionSha256) || expression.startsWith(this.identifierFunctionSha256))) {
          _matched=true;
          _switchResult = this.generateShaInputBlock(expression, this.identifierFunctionSha256);
        }
      }
      if (!_matched) {
        if ((expression.contains(this.identifierFunctionSha3) || expression.startsWith(this.identifierFunctionSha3))) {
          _matched=true;
          _switchResult = this.generateShaInputBlock(expression, this.identifierFunctionSha3);
        }
      }
      if (!_matched) {
        boolean _contains_40 = expression.toString().contains(";");
        boolean _not = (!_contains_40);
        if (_not) {
          _matched=true;
          _switchResult = this.generatePersonalizedInputExpressionBlock(expression.replace(";", ""));
        }
      }
      if (!_matched) {
        boolean _contains_41 = expression.toString().contains(";");
        if (_contains_41) {
          _matched=true;
          _switchResult = this.generatePersonalizedExpressionBlock(expression.replace(";", ""));
        }
      }
      if (!_matched) {
        _switchResult = this.parserVariablesBlockly.identifyBlockVariables(expression);
      }
      _xblockexpression = _switchResult;
    }
    return _xblockexpression;
  }
  
  public CharSequence generateComparationOperatorBlock(final String expression1, final String expression2, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"comparation_logicalexpression\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"operators\">");
    _builder.append(operator, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("<value name=\"value1_logicalexpression\">");
    _builder.newLine();
    _builder.append("    ");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression1);
    _builder.append(_identifyExpressionRecursive, "    ");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<value name=\"value1_logicalexpression\">");
    _builder.newLine();
    _builder.append("    ");
    Object _identifyExpressionRecursive_1 = this.identifyExpressionRecursive(expression2);
    _builder.append(_identifyExpressionRecursive_1, "    ");
    _builder.append("\t\t      ");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea el bloque para una expresion l�gica con el operador (== o !=) ya conocido
   */
  public CharSequence generateLogicalComparationExpressionBlock(final String expression1, final String expression2, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("\t  ");
    _builder.append("<block type=\"comparation_expression\">");
    _builder.newLine();
    _builder.append("<field name=\"operators\">");
    _builder.append(operator);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<value name=\"value1_expression\">");
    _builder.newLine();
    _builder.append("\t      ");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression1);
    _builder.append(_identifyExpressionRecursive, "\t      ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("\t    ");
    _builder.append("<value name=\"value2_expression\">");
    _builder.newLine();
    _builder.append("\t      ");
    Object _identifyExpressionRecursive_1 = this.identifyExpressionRecursive(expression2);
    _builder.append(_identifyExpressionRecursive_1, "\t      ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("\t  ");
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea el bloque para una expresion desplazadora con el operador (<< o >>) ya conocido
   */
  private CharSequence generateShiftExpressionBlock(final String expression1, final String expression2, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    CharSequence _switchResult = null;
    boolean _matched = false;
    if (Objects.equal(operator, this.operatorShiftLeft)) {
      _matched=true;
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("<field name=\"operators\">&lt;&lt;</field>");
      _switchResult = _builder_1;
    }
    if (!_matched) {
      StringConcatenation _builder_2 = new StringConcatenation();
      _builder_2.append("<field name=\"operators\">&gt;&gt;</field>");
      _switchResult = _builder_2;
    }
    _builder.append(_switchResult);
    _builder.newLineIfNotEmpty();
    _builder.append("<block type=\"shift_expression\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"operators\">");
    _builder.append(operator, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("<value name=\"value1_shiftexpression\">");
    _builder.newLine();
    _builder.append("      ");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression1);
    _builder.append(_identifyExpressionRecursive, "      ");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<value name=\"value2_shiftexpression\">");
    _builder.newLine();
    _builder.append("    ");
    Object _identifyExpressionRecursive_1 = this.identifyExpressionRecursive(expression2);
    _builder.append(_identifyExpressionRecursive_1, "    ");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append(" \t ");
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea el bloque para una expresion l�gica ar�tmetica con el operador (>,>=,< o <=) ya conocido
   */
  public CharSequence generateArithmeticalLogicalComparationExpressionBlock(final String expression1, final String expression2, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"comparation_arithmeticalexpression\">");
    _builder.newLine();
    _builder.append("        ");
    CharSequence _switchResult = null;
    boolean _matched = false;
    if (Objects.equal(operator, this.operatorGreater)) {
      _matched=true;
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("<field name=\"operators\">&gt;</field>");
      _switchResult = _builder_1;
    }
    if (!_matched) {
      if (Objects.equal(operator, this.operatorGreaterEqual)) {
        _matched=true;
        StringConcatenation _builder_2 = new StringConcatenation();
        _builder_2.append("<field name=\"operators\">&gt;=</field>");
        _switchResult = _builder_2;
      }
    }
    if (!_matched) {
      if (Objects.equal(operator, this.operatorLess)) {
        _matched=true;
        StringConcatenation _builder_3 = new StringConcatenation();
        _builder_3.append("<field name=\"operators\">&lt;</field>");
        _switchResult = _builder_3;
      }
    }
    if (!_matched) {
      StringConcatenation _builder_4 = new StringConcatenation();
      _builder_4.append("<field name=\"operators\">&lt;=</field>");
      _switchResult = _builder_4;
    }
    _builder.append(_switchResult, "        ");
    _builder.newLineIfNotEmpty();
    _builder.append("<value name=\"value1_arithmeticalcomparationexpression\">");
    _builder.newLine();
    _builder.append("  ");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression1);
    _builder.append(_identifyExpressionRecursive, "  ");
    _builder.newLineIfNotEmpty();
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("<value name=\"value2_arithmeticalcomparationexpression\">");
    _builder.newLine();
    _builder.append("  ");
    Object _identifyExpressionRecursive_1 = this.identifyExpressionRecursive(expression2);
    _builder.append(_identifyExpressionRecursive_1, "  ");
    _builder.newLineIfNotEmpty();
    _builder.append("</value>   ");
    _builder.newLine();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea el bloque para una expresion ar�tmetica
   */
  private CharSequence generateArithmethicalBlock(final String expression1, final String expression2, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"arithmetical_expression\">");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("<field name=\"operators\">");
    _builder.append(operator, " ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("   ");
    _builder.append("<value name=\"value1_arithmeticalexpression\">");
    _builder.newLine();
    _builder.append("  \t");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression1);
    _builder.append(_identifyExpressionRecursive, "  \t");
    _builder.newLineIfNotEmpty();
    _builder.append("   ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<value name=\"value2_arithmeticalexpression\">");
    _builder.newLine();
    _builder.append("     ");
    Object _identifyExpressionRecursive_1 = this.identifyExpressionRecursive(expression2);
    _builder.append(_identifyExpressionRecursive_1, "     ");
    _builder.newLineIfNotEmpty();
    _builder.append("   ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea el bloque para una expresion de comparation bit
   */
  private CharSequence generateBitComparationBlock(final String expression1, final String expression2, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"bitwise_expression\">");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<field name=\"operators\">");
    _builder.append(operator, "   ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("   ");
    _builder.append("<value name=\"value1_bitwiseexpression\">");
    _builder.newLine();
    _builder.append("    ");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression1);
    _builder.append(_identifyExpressionRecursive, "    ");
    _builder.newLineIfNotEmpty();
    _builder.append("   ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<value name=\"value2_bitwiseexpression\">");
    _builder.newLine();
    _builder.append("     ");
    Object _identifyExpressionRecursive_1 = this.identifyExpressionRecursive(expression2);
    _builder.append(_identifyExpressionRecursive_1, "     ");
    _builder.newLineIfNotEmpty();
    _builder.append("   ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea el bloque para una expresi�n de asignaci�n de valor
   */
  private CharSequence generateAssignValueBlock(final String expression1, final String expression2, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"assign_value_expression\">");
    _builder.newLine();
    _builder.append("<field name=\"operators\">");
    _builder.append(operator);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<value name=\"value1_assignexpression\">");
    _builder.newLine();
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression1);
    _builder.append(_identifyExpressionRecursive);
    _builder.newLineIfNotEmpty();
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("<value name=\"value2_assignexpression\">");
    _builder.newLine();
    Object _identifyExpressionRecursive_1 = this.identifyExpressionRecursive(expression2);
    _builder.append(_identifyExpressionRecursive_1);
    _builder.newLineIfNotEmpty();
    _builder.append("</value>\t\t");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Comprueba si la expression es una expresi�n de tiempo y si es cierto crea el bloque para dicha expresi�n
   */
  private CharSequence generateReturnBlock(final String expression) {
    CharSequence _xblockexpression = null;
    {
      String[] expressionReturnSeparate = expression.toString().split(this.identifierReturn, 2);
      String expression2 = (expressionReturnSeparate[1]).toString().replace(";", "").trim();
      expression2 = expression2.replaceAll(" ", "").trim();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"return_clause\">");
      _builder.newLine();
      _builder.append("\t\t  ");
      _builder.append("<value name=\"values\">");
      _builder.newLine();
      _builder.append("\t\t   ");
      Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression2);
      _builder.append(_identifyExpressionRecursive, "\t\t   ");
      _builder.newLineIfNotEmpty();
      _builder.append("\t\t  ");
      _builder.append("</value>");
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Comprueba si la expression es una expresi�n de tiempo y si es cierto crea el bloque para dicha expresi�n
   */
  private CharSequence generateTimeExpressionBlock(final String expression, final String unitTime) {
    CharSequence _xblockexpression = null;
    {
      String[] expressionReturnSeparate = expression.toString().split(unitTime, 2);
      String expression1 = (expressionReturnSeparate[0]).toString().replace(";", "").trim();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"time_expression\">");
      _builder.newLine();
      _builder.append("\t     ");
      _builder.append("<field name=\"time_value\">");
      _builder.append(expression1, "\t     ");
      _builder.append("</field>");
      _builder.newLineIfNotEmpty();
      _builder.append("\t     ");
      _builder.append("<field name=\"time_unity\">");
      _builder.append(unitTime, "\t     ");
      _builder.append("</field>");
      _builder.newLineIfNotEmpty();
      _builder.append("\t   ");
      _builder.append("</block>");
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Comprueba si la expression es una expresi�n de tiempo y si es cierto crea el bloque para dicha expresi�n
   */
  private CharSequence generateCoinExpressionBlock(final String expression, final String unitCoin) {
    CharSequence _xblockexpression = null;
    {
      String[] expressionReturnSeparate = expression.toString().split(unitCoin, 2);
      String expression1 = (expressionReturnSeparate[0]).toString().replace(";", "").trim();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"coin_expression\">");
      _builder.newLine();
      _builder.append("\t  \t");
      _builder.append("<field name=\"amount_coin\">");
      _builder.append(expression1, "\t  \t");
      _builder.append("</field>");
      _builder.newLineIfNotEmpty();
      _builder.append("\t  \t");
      _builder.append("<field name=\"type_coin\">");
      _builder.append(unitCoin, "\t  \t");
      _builder.append("</field>");
      _builder.newLineIfNotEmpty();
      _builder.append("\t   ");
      _builder.append("</block>");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  private CharSequence generateTupleBlock(final String expression) {
    CharSequence _xblockexpression = null;
    {
      String[] expressionTupleSeparate = expression.toString().replace(this.openParenthesis, "").toString().replace(this.closeParenthesis, "").toString().split(",");
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"tuple\">");
      _builder.newLine();
      _builder.append("       ");
      _builder.append("<value name=\"values\">");
      _builder.newLine();
      {
        for(final String expressionWithoutComma : expressionTupleSeparate) {
          Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expressionWithoutComma);
          _builder.append(_identifyExpressionRecursive);
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("       ");
      _builder.append("</value>");
      _builder.newLine();
      _builder.append("       ");
      _builder.append("</block>");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  private CharSequence generateParenthesisBlock(final String expression) {
    CharSequence _xblockexpression = null;
    {
      String _string = expression.toString();
      int _indexOf = expression.toString().indexOf(this.openParenthesis);
      int _plus = (_indexOf + 1);
      String expression1 = _string.substring(_plus, expression.toString().lastIndexOf(this.closeParenthesis));
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"parenthesis_expression\">");
      _builder.newLine();
      _builder.append("\t   ");
      _builder.append("<value name=\"value\">");
      _builder.newLine();
      _builder.append("        ");
      Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression1);
      _builder.append(_identifyExpressionRecursive, "        ");
      _builder.newLineIfNotEmpty();
      _builder.append("\t   ");
      _builder.append("</value>");
      _builder.newLine();
      _builder.append("\t   ");
      _builder.append("</block>");
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  private CharSequence generateSelfdestructBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"selfdestruct_function\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"value_parameter\">");
    String _replace = expression.toString().replace(this.identifierFunctionSelfdestruct, "").toString().replace(";", "");
    _builder.append(_replace, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  public CharSequence identifyPredefiniedFunction(final String expression) {
    CharSequence _switchResult = null;
    boolean _matched = false;
    boolean _contains = expression.contains(this.identifierFunctionSelfdestruct);
    if (_contains) {
      _matched=true;
      _switchResult = this.generateSelfdestructBlock(expression);
    }
    if (!_matched) {
      boolean _contains_1 = expression.contains(this.identifierFunctionKeccak256);
      if (_contains_1) {
        _matched=true;
        _switchResult = this.generateKeccakBlock(expression);
      }
    }
    if (!_matched) {
      boolean _contains_2 = expression.contains(this.identifierFunctionSha256);
      if (_contains_2) {
        _matched=true;
        _switchResult = this.generateShaBlock(expression, this.identifierFunctionSha256);
      }
    }
    if (!_matched) {
      boolean _contains_3 = expression.contains(this.identifierFunctionSha3);
      if (_contains_3) {
        _matched=true;
        _switchResult = this.generateShaBlock(expression, this.identifierFunctionSha3);
      }
    }
    if (!_matched) {
      boolean _contains_4 = expression.contains(this.identifierFunctionAbyEncodedPackage);
      if (_contains_4) {
        _matched=true;
        _switchResult = this.generateAbyEncodeBlock(expression);
      }
    }
    if (!_matched) {
      _switchResult = null;
    }
    return _switchResult;
  }
  
  private CharSequence generateAbyEncodeBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"abyencode_function\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"value_parameter\">");
    String _replace = expression.toString().replace(this.identifierFunctionAbyEncodedPackage, "").toString().replace(";", "");
    _builder.append(_replace, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateShaBlock(final String expression, final String nameFunction) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"sha_function\">");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<field name=\"name\">");
    _builder.append(nameFunction, "   ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("   ");
    _builder.append("<field name=\"value_parameter\">");
    String _replace = expression.toString().replace(nameFunction, "").toString().replace(";", "");
    _builder.append(_replace, "   ");
    _builder.append("</field>\t");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateKeccakBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"keccak_function\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<field name=\"value_parameter\">");
    String _replace = expression.toString().replace(this.identifierFunctionKeccak256, "").toString().replace(";", "");
    _builder.append(_replace, "\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateAbyEncodeInputBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"abyencode_inputfunction\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"value_parameter\">");
    String _replace = expression.toString().replace(this.identifierFunctionAbyEncodedPackage, "").toString().replace(";", "");
    _builder.append(_replace, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateShaInputBlock(final String expression, final String nameFunction) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"sha_inputfunction\">");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<field name=\"name\">");
    _builder.append(nameFunction, "   ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("   ");
    _builder.append("<field name=\"value_parameter\">");
    String _replace = expression.toString().replace(nameFunction, "").toString().replace(";", "");
    _builder.append(_replace, "   ");
    _builder.append("</field>\t");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateKeccakInputBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"keccak_inputfunction\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<field name=\"value_parameter\">");
    String _replace = expression.toString().replace(this.identifierFunctionKeccak256, "").toString().replace(";", "");
    _builder.append(_replace, "\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateAssertBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"assert_function\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"value_parameter\">");
    String _replace = expression.toString().replace(this.identifierFunctionAssert, "").toString().replace(";", "");
    _builder.append(_replace, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateRevertBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"revert_expression\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"value_revertexpression\">");
    String _replace = expression.toString().replace(this.identifierFunctionRevert, "").toString().replace(";", "");
    _builder.append(_replace, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateDeleteBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"deleteexpression\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"value_deleteexpression\">");
    String _replace = expression.toString().replace(this.identifierFunctionDelete, "").toString().replace(";", "");
    _builder.append(_replace, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateNumberValueBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_number\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"value\">");
    String _string = expression.toString();
    _builder.append(_string, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateNegationBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_negation\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<value name=\"value\">");
    _builder.newLine();
    _builder.append("\t");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression.toString().substring(1));
    _builder.append(_identifyExpressionRecursive, "\t");
    _builder.append("\t  </value>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateNewExpressionBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_new\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<value name=\"value\">");
    _builder.newLine();
    _builder.append("\t");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression.toString().substring(3).trim());
    _builder.append(_identifyExpressionRecursive, "\t");
    _builder.append("\t  </value>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generatePersonalizedInputExpressionBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    CharSequence _identifyBlockVariables = this.parserVariablesBlockly.identifyBlockVariables(expression);
    _builder.append(_identifyBlockVariables);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generatePersonalizedExpressionBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"personalized_expression\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"values_expression\">");
    _builder.append(expression, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Crea el bloque para una expresion de creacion de variable
   */
  private CharSequence generateVarBlock(final String expression) {
    CharSequence _xblockexpression = null;
    {
      String operator = "";
      String expression1 = "";
      String expression2 = "";
      String[] expressionVarSeparate = null;
      boolean _matched = false;
      boolean _contains = expression.contains(this.operatorAssignPlusValue);
      if (_contains) {
        _matched=true;
        operator = this.operatorAssignPlusValue;
        expressionVarSeparate = expression.toString().split("\\+=", 2);
        expression1 = (expressionVarSeparate[0]).toString().replace(this.identifierVar, "").trim();
        expression2 = (expressionVarSeparate[1]).toString().replace(";", "").trim();
      }
      if (!_matched) {
        boolean _contains_1 = expression.contains(this.operatorAssignMinunValue);
        if (_contains_1) {
          _matched=true;
          operator = this.operatorAssignMinunValue;
          expressionVarSeparate = expression.toString().split(this.operatorAssignMinunValue, 2);
          expression1 = (expressionVarSeparate[0]).toString().replace(this.identifierVar, "").trim();
          expression2 = (expressionVarSeparate[1]).toString().replace(";", "").trim();
        }
      }
      if (!_matched) {
        boolean _contains_2 = expression.contains(this.operatorAssignMultValue);
        if (_contains_2) {
          _matched=true;
          operator = this.operatorAssignMultValue;
          expressionVarSeparate = expression.toString().split("\\*=", 2);
          expression1 = (expressionVarSeparate[0]).toString().replace(this.identifierVar, "").trim();
          expression2 = (expressionVarSeparate[1]).toString().replace(";", "").trim();
        }
      }
      if (!_matched) {
        boolean _contains_3 = expression.contains(this.operatorAssignDivValue);
        if (_contains_3) {
          _matched=true;
          operator = this.operatorAssignDivValue;
          expressionVarSeparate = expression.toString().split(this.operatorAssignDivValue, 2);
          expression1 = (expressionVarSeparate[0]).toString().replace(this.identifierVar, "").trim();
          expression2 = (expressionVarSeparate[1]).toString().replace(";", "").trim();
        }
      }
      if (!_matched) {
        boolean _contains_4 = expression.contains(this.operatorAssignModValue);
        if (_contains_4) {
          _matched=true;
          operator = this.operatorAssignModValue;
          expressionVarSeparate = expression.toString().split(this.operatorAssignModValue, 2);
          expression1 = (expressionVarSeparate[0]).toString().replace(this.identifierVar, "").trim();
          expression2 = (expressionVarSeparate[1]).toString().replace(";", "").trim();
        }
      }
      if (!_matched) {
        boolean _contains_5 = expression.contains(this.operatorAssignShiftLeftValue);
        if (_contains_5) {
          _matched=true;
          operator = this.operatorAssignShiftLeftValue;
          expressionVarSeparate = expression.toString().split(this.operatorAssignShiftLeftValue, 2);
          expression1 = (expressionVarSeparate[0]).toString().replace(this.identifierVar, "").trim();
          expression2 = (expressionVarSeparate[1]).toString().replace(";", "").trim();
        }
      }
      if (!_matched) {
        boolean _contains_6 = expression.contains(this.operatorAssignShiftRightValue);
        if (_contains_6) {
          _matched=true;
          operator = this.operatorAssignShiftRightValue;
          expressionVarSeparate = expression.toString().split(this.operatorAssignShiftRightValue, 2);
          expression1 = (expressionVarSeparate[0]).toString().replace(this.identifierVar, "").trim();
          expression2 = (expressionVarSeparate[1]).toString().replace(";", "").trim();
        }
      }
      if (!_matched) {
        {
          expressionVarSeparate = expression.toString().split(this.operatorAssignValue, 2);
          expression1 = (expressionVarSeparate[0]).toString().replace(this.identifierVar, "").trim();
          expression2 = (expressionVarSeparate[1]).toString().replace(";", "").trim();
          operator = this.operatorAssignValue;
        }
      }
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"var_expression\">");
      _builder.newLine();
      _builder.append("<field name=\"name\">");
      _builder.append(expression1);
      _builder.append("</field>");
      _builder.newLineIfNotEmpty();
      _builder.append("<value name=\"expression_varexpression\">");
      _builder.newLine();
      _builder.append("  ");
      _builder.append("<block type=\"assing_value_expression1inputs\">");
      _builder.newLine();
      _builder.append("    ");
      _builder.append("<field name=\"operators\">");
      _builder.append(this.operatorAssignValue, "    ");
      _builder.append("</field>");
      _builder.newLineIfNotEmpty();
      _builder.append("    ");
      _builder.append("<value name=\"value1_assingexpression\">");
      _builder.newLine();
      _builder.append("    ");
      Object _identifyExpressionRecursive = this.identifyExpressionRecursive((expressionVarSeparate[1]).toString().replace(";", "").trim());
      _builder.append(_identifyExpressionRecursive, "    ");
      _builder.newLineIfNotEmpty();
      _builder.append("\t  \t\t");
      _builder.append("</value>");
      _builder.newLine();
      _builder.append("  ");
      _builder.append("</block>");
      _builder.newLine();
      _builder.append("</value>");
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  private CharSequence generateAssemblyExpression(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_assembly\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<statement name=\"assembly_values\">");
    _builder.newLine();
    _builder.append("\t\t");
    Object _identifyExpressionRecursive = this.identifyExpressionRecursive(expression.toString().substring(this.identifierAssembly.length()).trim());
    _builder.append(_identifyExpressionRecursive, "\t\t");
    _builder.append("\t  \t</statement>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateLetAssemblyExpression(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_let_expression\" id=\"aW(9SzkS0y=8j.F%B24I\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<field name=\"name_var_let\">name</field>");
    _builder.newLine();
    _builder.append("\t\t\t");
    CharSequence _identifyExpressionRecursive = this.identifyExpressionRecursive(expression.toString().substring(3).trim());
    _builder.append(_identifyExpressionRecursive, "\t\t\t");
    _builder.append("\t  \t</statement>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  public CharSequence identifyExpressionInsideModifier(final String expression) {
    return this.identifyExpressionRecursive(expression);
  }
}
