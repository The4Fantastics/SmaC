package org.xtext.generator.blocklyparser;

import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class VariablesBlocklyParser {
  private final String variableMsgSender = "msg.sender";
  
  private final String variableMsgValue = "msg.value";
  
  private final String variableMsgBalance = "msg.balance";
  
  private final String variableMsgGas = "msg.gas";
  
  private final String variableMsgData = "msg.data";
  
  private final String variableMsgSig = "msg.sig";
  
  private final String variableBlockDifficulty = "block.difficulty";
  
  private final String variableBlockNumber = "block.number";
  
  private final String variableBlockTimestamp = "block.timestamp";
  
  private final String variableBlockCoinbase = "block.coinbase";
  
  private final String variableBlockGasLimit = "block.gaslimit";
  
  private final String variableBlockBlockhash = "block.blockhash";
  
  private final String variableTxAmount = "tx.amount";
  
  private final String variableTxOrigin = "tx.origin";
  
  private final String variableTxGasLeft = "tx.gasleft";
  
  private final String variableTxGasPrice = "tx.gasprice";
  
  private final String variableThis = "this";
  
  private final String variableThisBalance = "this.balance";
  
  private final String valueTrueBoolean = "true";
  
  private final String valueFalseBoolean = "false";
  
  private final String valueNull = "null";
  
  private final String valueNow = "now";
  
  private final String openCloseString = "\"";
  
  public CharSequence identifyBlockVariables(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    CharSequence _switchResult = null;
    boolean _matched = false;
    boolean _equals = expression.toString().equals(this.variableMsgSender);
    if (_equals) {
      _matched=true;
      StringConcatenation _builder_1 = new StringConcatenation();
      CharSequence _generateBlocklyMSGVariable = this.generateBlocklyMSGVariable(expression);
      _builder_1.append(_generateBlocklyMSGVariable);
      _switchResult = _builder_1;
    }
    if (!_matched) {
      boolean _equals_1 = expression.toString().equals(this.variableMsgValue);
      if (_equals_1) {
        _matched=true;
        StringConcatenation _builder_2 = new StringConcatenation();
        CharSequence _generateBlocklyMSGVariable_1 = this.generateBlocklyMSGVariable(expression);
        _builder_2.append(_generateBlocklyMSGVariable_1);
        _switchResult = _builder_2;
      }
    }
    if (!_matched) {
      boolean _equals_2 = expression.toString().equals(this.variableMsgBalance);
      if (_equals_2) {
        _matched=true;
        StringConcatenation _builder_3 = new StringConcatenation();
        CharSequence _generateBlocklyMSGVariable_2 = this.generateBlocklyMSGVariable(expression);
        _builder_3.append(_generateBlocklyMSGVariable_2);
        _switchResult = _builder_3;
      }
    }
    if (!_matched) {
      boolean _equals_3 = expression.toString().equals(this.variableMsgGas);
      if (_equals_3) {
        _matched=true;
        StringConcatenation _builder_4 = new StringConcatenation();
        CharSequence _generateBlocklyMSGVariable_3 = this.generateBlocklyMSGVariable(expression);
        _builder_4.append(_generateBlocklyMSGVariable_3);
        _switchResult = _builder_4;
      }
    }
    if (!_matched) {
      boolean _equals_4 = expression.toString().equals(this.variableMsgData);
      if (_equals_4) {
        _matched=true;
        StringConcatenation _builder_5 = new StringConcatenation();
        CharSequence _generateBlocklyMSGVariable_4 = this.generateBlocklyMSGVariable(expression);
        _builder_5.append(_generateBlocklyMSGVariable_4);
        _switchResult = _builder_5;
      }
    }
    if (!_matched) {
      boolean _equals_5 = expression.toString().equals(this.variableMsgSig);
      if (_equals_5) {
        _matched=true;
        StringConcatenation _builder_6 = new StringConcatenation();
        CharSequence _generateBlocklyMSGVariable_5 = this.generateBlocklyMSGVariable(expression);
        _builder_6.append(_generateBlocklyMSGVariable_5);
        _switchResult = _builder_6;
      }
    }
    if (!_matched) {
      boolean _equals_6 = expression.toString().equals(this.variableBlockDifficulty);
      if (_equals_6) {
        _matched=true;
        StringConcatenation _builder_7 = new StringConcatenation();
        CharSequence _generateBlocklyBlockVariable = this.generateBlocklyBlockVariable(expression);
        _builder_7.append(_generateBlocklyBlockVariable);
        _switchResult = _builder_7;
      }
    }
    if (!_matched) {
      boolean _equals_7 = expression.toString().equals(this.variableBlockNumber);
      if (_equals_7) {
        _matched=true;
        StringConcatenation _builder_8 = new StringConcatenation();
        CharSequence _generateBlocklyBlockVariable_1 = this.generateBlocklyBlockVariable(expression);
        _builder_8.append(_generateBlocklyBlockVariable_1);
        _switchResult = _builder_8;
      }
    }
    if (!_matched) {
      boolean _equals_8 = expression.toString().equals(this.variableBlockTimestamp);
      if (_equals_8) {
        _matched=true;
        StringConcatenation _builder_9 = new StringConcatenation();
        CharSequence _generateBlocklyBlockVariable_2 = this.generateBlocklyBlockVariable(expression);
        _builder_9.append(_generateBlocklyBlockVariable_2);
        _switchResult = _builder_9;
      }
    }
    if (!_matched) {
      boolean _equals_9 = expression.toString().equals(this.variableBlockCoinbase);
      if (_equals_9) {
        _matched=true;
        StringConcatenation _builder_10 = new StringConcatenation();
        CharSequence _generateBlocklyBlockVariable_3 = this.generateBlocklyBlockVariable(expression);
        _builder_10.append(_generateBlocklyBlockVariable_3);
        _switchResult = _builder_10;
      }
    }
    if (!_matched) {
      boolean _equals_10 = expression.toString().equals(this.variableBlockGasLimit);
      if (_equals_10) {
        _matched=true;
        StringConcatenation _builder_11 = new StringConcatenation();
        CharSequence _generateBlocklyBlockVariable_4 = this.generateBlocklyBlockVariable(expression);
        _builder_11.append(_generateBlocklyBlockVariable_4);
        _switchResult = _builder_11;
      }
    }
    if (!_matched) {
      boolean _equals_11 = expression.toString().equals(this.variableBlockBlockhash);
      if (_equals_11) {
        _matched=true;
        StringConcatenation _builder_12 = new StringConcatenation();
        CharSequence _generateBlocklyBlockVariable_5 = this.generateBlocklyBlockVariable(expression);
        _builder_12.append(_generateBlocklyBlockVariable_5);
        _switchResult = _builder_12;
      }
    }
    if (!_matched) {
      boolean _equals_12 = expression.toString().equals(this.variableTxAmount);
      if (_equals_12) {
        _matched=true;
        StringConcatenation _builder_13 = new StringConcatenation();
        CharSequence _generateBlocklyTxVariable = this.generateBlocklyTxVariable(expression);
        _builder_13.append(_generateBlocklyTxVariable);
        _switchResult = _builder_13;
      }
    }
    if (!_matched) {
      boolean _equals_13 = expression.toString().equals(this.variableTxOrigin);
      if (_equals_13) {
        _matched=true;
        StringConcatenation _builder_14 = new StringConcatenation();
        CharSequence _generateBlocklyTxVariable_1 = this.generateBlocklyTxVariable(expression);
        _builder_14.append(_generateBlocklyTxVariable_1);
        _switchResult = _builder_14;
      }
    }
    if (!_matched) {
      boolean _equals_14 = expression.toString().equals(this.variableTxGasPrice);
      if (_equals_14) {
        _matched=true;
        StringConcatenation _builder_15 = new StringConcatenation();
        CharSequence _generateBlocklyTxVariable_2 = this.generateBlocklyTxVariable(expression);
        _builder_15.append(_generateBlocklyTxVariable_2);
        _switchResult = _builder_15;
      }
    }
    if (!_matched) {
      boolean _equals_15 = expression.toString().equals(this.variableTxGasLeft);
      if (_equals_15) {
        _matched=true;
        StringConcatenation _builder_16 = new StringConcatenation();
        CharSequence _generateBlocklyTxVariable_3 = this.generateBlocklyTxVariable(expression);
        _builder_16.append(_generateBlocklyTxVariable_3);
        _switchResult = _builder_16;
      }
    }
    if (!_matched) {
      boolean _equals_16 = expression.toString().equals(this.valueFalseBoolean);
      if (_equals_16) {
        _matched=true;
        StringConcatenation _builder_17 = new StringConcatenation();
        CharSequence _generateBooleanValueBlock = this.generateBooleanValueBlock(expression);
        _builder_17.append(_generateBooleanValueBlock);
        _switchResult = _builder_17;
      }
    }
    if (!_matched) {
      boolean _equals_17 = expression.toString().equals(this.valueTrueBoolean);
      if (_equals_17) {
        _matched=true;
        StringConcatenation _builder_18 = new StringConcatenation();
        CharSequence _generateBooleanValueBlock_1 = this.generateBooleanValueBlock(expression);
        _builder_18.append(_generateBooleanValueBlock_1);
        _switchResult = _builder_18;
      }
    }
    if (!_matched) {
      boolean _equals_18 = expression.toString().equals(this.valueNull);
      if (_equals_18) {
        _matched=true;
        StringConcatenation _builder_19 = new StringConcatenation();
        CharSequence _generateNullBlock = this.generateNullBlock(expression);
        _builder_19.append(_generateNullBlock);
        _switchResult = _builder_19;
      }
    }
    if (!_matched) {
      boolean _equals_19 = expression.toString().equals(this.valueNow);
      if (_equals_19) {
        _matched=true;
        StringConcatenation _builder_20 = new StringConcatenation();
        CharSequence _generateNowBlock = this.generateNowBlock();
        _builder_20.append(_generateNowBlock);
        _switchResult = _builder_20;
      }
    }
    if (!_matched) {
      boolean _equals_20 = expression.toString().equals(this.variableThis);
      if (_equals_20) {
        _matched=true;
        StringConcatenation _builder_21 = new StringConcatenation();
        CharSequence _generateThisBlock = this.generateThisBlock(expression);
        _builder_21.append(_generateThisBlock);
        _switchResult = _builder_21;
      }
    }
    if (!_matched) {
      boolean _equals_21 = expression.toString().equals(this.variableThisBalance);
      if (_equals_21) {
        _matched=true;
        StringConcatenation _builder_22 = new StringConcatenation();
        CharSequence _generateThisBlock_1 = this.generateThisBlock(expression);
        _builder_22.append(_generateThisBlock_1);
        _switchResult = _builder_22;
      }
    }
    if (!_matched) {
      boolean _contains = expression.toString().contains((this.variableThis + "."));
      if (_contains) {
        _matched=true;
        StringConcatenation _builder_23 = new StringConcatenation();
        CharSequence _generateThisExpressionBlock = this.generateThisExpressionBlock(expression);
        _builder_23.append(_generateThisExpressionBlock);
        _switchResult = _builder_23;
      }
    }
    if (!_matched) {
      boolean _contains_1 = expression.toString().contains(this.openCloseString);
      if (_contains_1) {
        _matched=true;
        StringConcatenation _builder_24 = new StringConcatenation();
        CharSequence _generateTextBlock = this.generateTextBlock(expression);
        _builder_24.append(_generateTextBlock);
        _switchResult = _builder_24;
      }
    }
    if (!_matched) {
      StringConcatenation _builder_25 = new StringConcatenation();
      CharSequence _generatePersonalizedInputExpressionBlock = this.generatePersonalizedInputExpressionBlock(expression.trim());
      _builder_25.append(_generatePersonalizedInputExpressionBlock);
      _switchResult = _builder_25;
    }
    _builder.append(_switchResult);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence generateBlocklyMSGVariable(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"msgvariables\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"msgvariables\">");
    String _trim = expression.trim();
    _builder.append(_trim, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateBlocklyBlockVariable(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"blockvariables\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"values_blockvariables\">");
    String _trim = expression.trim();
    _builder.append(_trim, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateBlocklyTxVariable(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"txvariables\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"values_txvariables\">");
    String _trim = expression.trim();
    _builder.append(_trim, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateBooleanValueBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_boolean\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<field name=\"values\">");
    _builder.append(expression, "\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateTextBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_text\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"value\">");
    String _replace = expression.toString().replace("\"", "");
    _builder.append(_replace, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateNullBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_null\">");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateNowBlock() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_now\"/>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateThisBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_this\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<field name=\"thisvalues\">");
    _builder.append(expression, "    ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("</block>\t \t ");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generateThisExpressionBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_thisexpression\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<field name=\"value\">");
    _builder.append(expression, "\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence generatePersonalizedInputExpressionBlock(final String expression) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"personalized_inputexpression\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<field name=\"values_expression\">");
    _builder.append(expression, "\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
}
