package org.xtext.generator.blocklyparser;

import com.google.common.base.Objects;
import java.util.List;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.TypesBlocklyParser;
import org.xtext.smaC.InputParam;
import org.xtext.smaC.OutputParam;
import org.xtext.smaC.StorageData;

@SuppressWarnings("all")
public class ParamBlocklyParser {
  private final String typeBool = "bool";
  
  private final String typeUint = "uint";
  
  private final String typeInt = "int";
  
  private final String typeFloat = "float";
  
  private final String typeAddress = "address";
  
  private final String typeAddressPayable = "address payable";
  
  private final String typeBytes = "bytes";
  
  private final String typeChar = "char";
  
  private final String typeString = "string";
  
  private TypesBlocklyParser parserTypes = new TypesBlocklyParser();
  
  private final String nameFieldName = "name";
  
  private final String nameFieldValueIdentifier = "valueIdentifier";
  
  private final String nameFieldVisibility = "visibility";
  
  private final String nameFieldArray = "array";
  
  private final String nameFieldKey = "key";
  
  private final String nameFieldValue = "value";
  
  private final String nameFieldStorageData = "storageData";
  
  private String type = "";
  
  private String constant = "";
  
  private String inicialization = "";
  
  private String name = "";
  
  private String key = "";
  
  private String visibility = "";
  
  private String value = "";
  
  private String array = "";
  
  private String storagedata = "";
  
  private String valueIdentifier = "";
  
  private int counter = 0;
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  public CharSequence defineInputParams(final List<InputParam> inputparams) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"inputparam\">");
    _builder.newLine();
    _builder.append("     ");
    _builder.append("<statement name=\"inputparams\">");
    _builder.newLine();
    {
      for(final InputParam inputparam : inputparams) {
        {
          boolean _contains = inputparam.toString().contains("nameMapping:");
          boolean _not = (!_contains);
          if (_not) {
            {
              if (((!inputparam.toString().contains("indexed:null")) || (!inputparam.toString().equals("storageData:null")))) {
                CharSequence _defineLongInputParam = this.defineLongInputParam(inputparam);
                _builder.append(_defineLongInputParam);
                _builder.newLineIfNotEmpty();
              } else {
                CharSequence _defineShortInputParam = this.defineShortInputParam(inputparam);
                _builder.append(_defineShortInputParam);
                _builder.newLineIfNotEmpty();
              }
            }
          } else {
            _builder.append("           ");
            CharSequence _defineShortMappingInputParam = this.defineShortMappingInputParam(inputparam);
            _builder.append(_defineShortMappingInputParam, "           ");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          int _size = inputparams.size();
          int _minus = (_size - 1);
          boolean _equals = inputparam.equals(inputparams.get(_minus));
          boolean _not_1 = (!_equals);
          if (_not_1) {
            _builder.append("    \t   \t\t<next>");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("</block>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t");
    CharSequence _closeTags = this.parserCommonFunctions.closeTags(inputparams.size());
    _builder.append(_closeTags, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append(" ");
    _builder.append("</statement>");
    _builder.newLine();
    _builder.append("</block>\t\t");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence defineLongInputParam(final InputParam input) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"input_param\">");
    _builder.newLine();
    {
      String _type = input.getType();
      boolean _tripleNotEquals = (_type != null);
      if (_tripleNotEquals) {
        _builder.append("<value name=\"type\">");
        _builder.newLine();
        _builder.append(" ");
        CharSequence _controlGenerateTypeBlock = this.parserTypes.controlGenerateTypeBlock(input.getType());
        _builder.append(_controlGenerateTypeBlock, " ");
        _builder.newLineIfNotEmpty();
        _builder.append("</value>");
        _builder.newLine();
      }
    }
    _builder.append("<field name=\"indexed\">TRUE</field>");
    _builder.newLine();
    _builder.append("<field name=\"storagedata_values\">");
    StorageData _storageData = input.getStorageData();
    _builder.append(_storageData);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"name\">");
    String _valueInput = input.getValueInput();
    _builder.append(_valueInput);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    {
      if (((input.getArray() != null) && (!Objects.equal(input.getArray(), "")))) {
        CharSequence _generateFieldArray = this.generateFieldArray(input);
        _builder.append(_generateFieldArray);
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * Argumento: La propiedad que tiene dimensiones de array
   * Descripci�n: En primer lugar transforma la cadena donde contiene las dimensiones en un array para poder ir estrayendo dimensi�n por dimensi�n.
   * En caso de ser par es que es din�mico porque no tiene un �ndice est�tico, en caso de ser impar es est�tico porque tiene un �ndice (n�mero) entre los corchetes
   */
  private CharSequence generateFieldArray(final InputParam input) {
    CharSequence _xblockexpression = null;
    {
      this.cleanCounter(0);
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<value name=\"array_dimension\">");
      _builder.newLine();
      String arrayTransform = input.getArray().toString().replace("]", "],");
      _builder.append("\t\t");
      String[] array = arrayTransform.toString().split(",");
      _builder.append("\t\t");
      {
        for(final String arrayDimension : array) {
          _builder.newLineIfNotEmpty();
          {
            int _length = arrayDimension.length();
            int _modulo = (_length % 2);
            boolean _equals = (_modulo == 0);
            if (_equals) {
              CharSequence _generateDynamicArrayBlock = this.generateDynamicArrayBlock(array, this.counter);
              _builder.append(_generateDynamicArrayBlock);
              _builder.newLineIfNotEmpty();
            } else {
              String _string = arrayDimension.toString();
              int _indexOf = arrayDimension.toString().indexOf("[");
              int _plus = (_indexOf + 1);
              CharSequence _generateStaticArrayBlock = this.generateStaticArrayBlock(_string.substring(_plus, arrayDimension.toString().indexOf("]")), array, this.counter);
              _builder.append(_generateStaticArrayBlock);
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      final String[] _converted_array = (String[])array;
      CharSequence _closeTagsArray = this.closeTagsArray(((List<String>)Conversions.doWrapArray(_converted_array)).size());
      _builder.append(_closeTagsArray);
      _builder.newLineIfNotEmpty();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  private int addCounterElementsArrayDimension() {
    return this.counter = (this.counter + 1);
  }
  
  private int cleanCounter(final int number) {
    return this.counter = number;
  }
  
  /**
   * Argumento: La dimensi�n del array est�tico, el array de dimensiones de la propiedad, la posici�n actual de la dimensi�n que se va a parsear
   * Descripci�n:Genera el bloque del array est�tico, si no es el �ltimo a�ade una etiqueta de dimensi�n para a�adir la dimensi�n est�tica/din�mica que viene
   */
  private CharSequence generateStaticArrayBlock(final String dimension, final String[] array, final int position) {
    CharSequence _xblockexpression = null;
    {
      this.addCounterElementsArrayDimension();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"array_property\">");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("<field name=\"cells\">");
      _builder.append(dimension, "\t");
      _builder.append("</field>");
      _builder.newLineIfNotEmpty();
      {
        int _size = ((List<String>)Conversions.doWrapArray(array)).size();
        int _minus = (_size - 1);
        boolean _notEquals = (position != _minus);
        if (_notEquals) {
          _builder.append("<value name=\"plus_dimension\">\t");
          _builder.newLine();
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Argumento: El array de dimensiones de la propiedad, la posici�n actual de la dimensi�n que se va a parsear
   * Descripci�n: Genera el bloque del array din�mico, si no es el �ltimo a�ade una etiqueta de dimensi�n para a�adir la dimensi�n est�tica/din�mica que viene
   */
  private CharSequence generateDynamicArrayBlock(final String[] array, final int position) {
    CharSequence _xblockexpression = null;
    {
      this.addCounterElementsArrayDimension();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"dynamic_array\">");
      _builder.newLine();
      {
        int _size = ((List<String>)Conversions.doWrapArray(array)).size();
        int _minus = (_size - 1);
        boolean _notEquals = (position != _minus);
        if (_notEquals) {
          _builder.append("<value name=\"dimension\">\t");
          _builder.newLine();
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Argumento: Numero de dimensiones del array a cerrar
   * Descripci�n: Cierra las etiquetas <next> y <block> de cuando se crearon los bloques de los array est�ticos/din�micos
   */
  private CharSequence closeTagsArray(final int numDimensionsInputParam) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if ((numDimensionsInputParam != 0)) {
        final int[] elementsToClose = new int[numDimensionsInputParam];
        _builder.newLineIfNotEmpty();
        {
          for(final int element : elementsToClose) {
            _builder.append("  ");
            _builder.append("</block>");
            _builder.newLine();
            _builder.append("</value>");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  private CharSequence defineShortInputParam(final InputParam input) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"inputparamshortidentifier\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _valueInput = input.getValueInput();
    _builder.append(_valueInput);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    {
      String _type = input.getType();
      boolean _tripleNotEquals = (_type != null);
      if (_tripleNotEquals) {
        _builder.append("     ");
        _builder.append("<value name=\"type\">");
        _builder.newLine();
        _builder.append("     ");
        _builder.append(" ");
        CharSequence _controlGenerateTypeBlock = this.parserTypes.controlGenerateTypeBlock(input.getType());
        _builder.append(_controlGenerateTypeBlock, "      ");
        _builder.newLineIfNotEmpty();
        _builder.append("     ");
        _builder.append("</value>");
        _builder.newLine();
      }
    }
    {
      if (((input.getArray() != null) && (!Objects.equal(input.getArray(), "")))) {
        CharSequence _generateFieldArray = this.generateFieldArray(input);
        _builder.append(_generateFieldArray);
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  private CharSequence defineShortMappingInputParam(final InputParam input) {
    StringConcatenation _builder = new StringConcatenation();
    String[] arrayCamposOcultos = input.toString().substring(input.toString().indexOf("array:"), input.toString().lastIndexOf(")")).split(",");
    _builder.newLineIfNotEmpty();
    CharSequence _calculateFieldsHiddenMapping = this.calculateFieldsHiddenMapping(arrayCamposOcultos);
    _builder.append(_calculateFieldsHiddenMapping);
    _builder.newLineIfNotEmpty();
    _builder.append("<block type=\"inputparamshortidentifier\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"name\">");
    String _valueInput = input.getValueInput();
    _builder.append(_valueInput, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("<value name=\"type\">");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("<block type=\"type_mapping\">");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<value name=\"key\">");
    _builder.newLine();
    _builder.append("       ");
    CharSequence _controlGenerateTypeBlock = this.parserTypes.controlGenerateTypeBlock(this.key);
    _builder.append(_controlGenerateTypeBlock, "       ");
    _builder.newLineIfNotEmpty();
    _builder.append("      ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("<value name=\"value\">");
    _builder.newLine();
    _builder.append("       ");
    CharSequence _controlGenerateTypeBlock_1 = this.parserTypes.controlGenerateTypeBlock(this.value);
    _builder.append(_controlGenerateTypeBlock_1, "       ");
    _builder.append(" ");
    _builder.newLineIfNotEmpty();
    _builder.append("      ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("</block>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("</value>");
    _builder.newLine();
    {
      if (((input.getArray() != null) && (!Objects.equal(input.getArray(), "")))) {
        CharSequence _generateFieldArray = this.generateFieldArray(input);
        _builder.append(_generateFieldArray);
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * Calcula los valores de las propiedades mapping
   */
  private CharSequence calculateFieldsHiddenMapping(final String[] arrayCamposOcultos) {
    StringConcatenation _builder = new StringConcatenation();
    for (int i = 0; (i < arrayCamposOcultos.length); i++) {
      {
        String campo = arrayCamposOcultos[i];
        String[] claveValor = campo.toString().split(":");
        boolean _equals = (claveValor[0]).toString().trim().equals(this.nameFieldKey);
        if (_equals) {
          this.key = (claveValor[1]).toString().trim();
        }
        boolean _equals_1 = (claveValor[0]).toString().trim().equals(this.nameFieldValue);
        if (_equals_1) {
          this.value = (claveValor[1]).toString().trim();
        }
        boolean _equals_2 = (claveValor[0]).toString().trim().equals(this.nameFieldVisibility);
        if (_equals_2) {
          this.visibility = (claveValor[1]).toString().trim();
        }
        boolean _equals_3 = (claveValor[0]).toString().trim().equals(this.nameFieldName);
        if (_equals_3) {
          this.name = (claveValor[1]).toString().trim();
        }
        boolean _equals_4 = (claveValor[0]).toString().trim().equals(this.nameFieldStorageData);
        if (_equals_4) {
          this.storagedata = (claveValor[1]).toString().trim();
        }
        boolean _equals_5 = (claveValor[0]).toString().trim().equals(this.nameFieldValueIdentifier);
        if (_equals_5) {
          this.valueIdentifier = (claveValor[1]).toString().trim();
        }
      }
    }
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  public CharSequence defineOutputParam(final List<OutputParam> outputparams) {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final OutputParam outputparam : outputparams) {
        {
          if (((outputparam.getType() != null) && (outputparam.getValue() != null))) {
            CharSequence _defineOutputParam = this.defineOutputParam(outputparam);
            _builder.append(_defineOutputParam);
            _builder.newLineIfNotEmpty();
          } else {
            {
              if (((outputparam.getType() != null) && (outputparam.getValue() == null))) {
                CharSequence _controlGenerateTypeBlock = this.parserTypes.controlGenerateTypeBlock(outputparam.getType().toString());
                _builder.append(_controlGenerateTypeBlock);
                _builder.append("\t\t\t\t");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  private CharSequence defineOutputParam(final OutputParam param) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"outputparam\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"name\">");
    String _value = param.getValue();
    _builder.append(_value, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("<value name=\"value_type_outputparam\">");
    _builder.newLine();
    _builder.append("     ");
    CharSequence _controlGenerateTypeBlock = this.parserTypes.controlGenerateTypeBlock(param.getType().toString());
    _builder.append(_controlGenerateTypeBlock, "     ");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("</block>\t\t");
    _builder.newLine();
    return _builder;
  }
  
  private Object comprobacionInputParams(final List<InputParam> inputparams) {
    return null;
  }
}
