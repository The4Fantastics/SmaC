package org.xtext.generator.blocklyparser;

import com.google.common.base.Objects;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.xtext.generator.blocklyparser.ExpressionBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.TypesBlocklyParser;
import org.xtext.smaC.Company;
import org.xtext.smaC.Mapping;
import org.xtext.smaC.MappingDeclaration;
import org.xtext.smaC.PersonalizedStruct;
import org.xtext.smaC.Properties;
import org.xtext.smaC.StorageData;
import org.xtext.smaC.User;
import org.xtext.smaC.Visibility;

@SuppressWarnings("all")
public class PropertyBlocklyParser {
  private final String nameUintProperty = "PropertyUInteger";
  
  private final String nameIntProperty = "PropertyInteger";
  
  private final String nameBooleanProperty = "PropertyBoolean";
  
  private final String nameAddressProperty = "PropertyAddress";
  
  private final String nameBytesProperty = "PropertyBytes";
  
  private final String nameFloatProperty = "PropertyFloat";
  
  private final String nameCharProperty = "PropertyChar";
  
  private final String nameTextProperty = "PropertyString";
  
  private final String nameIdentifierProperty = "PropertyIdentifier";
  
  private final String nameMappingProperty = "PropertyMapping";
  
  private final String nameUserProperty = "PropertyUser";
  
  private final String nameCompanyProperty = "PropertyCompany";
  
  private final String nameFieldType = "type";
  
  private final String nameFieldConstant = "constant";
  
  private final String nameFieldInicialization = "inicialization";
  
  private final String nameFieldName = "name";
  
  private final String nameFieldNameMapping = "nameMapping";
  
  private final String nameFieldValueIdentifier = "valueIdentifier";
  
  private final String nameFieldVisibility = "visibility";
  
  private final String nameFieldArray = "array";
  
  private final String nameFieldKey = "key";
  
  private final String nameFieldValue = "value";
  
  private final String nameFieldStorageData = "storageData";
  
  private final String nameLocalProperty = "localProperty";
  
  private final String nameLocalMapping = "localMappingProperty";
  
  private final String nameStruct = "struct";
  
  private final String nameUserStruct = "user_struct";
  
  private String type = "";
  
  private String nameMapping = "";
  
  private String constant = "";
  
  private String inicialization = "";
  
  private String name = "";
  
  private String key = "";
  
  private String visibility = "";
  
  private String value = "";
  
  private String array = "";
  
  private String storagedata = "";
  
  private String valueIdentifier = "";
  
  private int counter = 0;
  
  private ExpressionBlocklyParser parserExpressions = new ExpressionBlocklyParser();
  
  private TypesBlocklyParser parserTypes = new TypesBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  public CharSequence identifyTypeProperty(final Properties property) {
    StringConcatenation _builder = new StringConcatenation();
    String[] arrayCamposOcultos = property.toString().substring(property.toString().indexOf("type:"), property.toString().lastIndexOf(")")).split(",");
    _builder.newLineIfNotEmpty();
    CharSequence _calculateFieldsHidden = this.calculateFieldsHidden(arrayCamposOcultos);
    _builder.append(_calculateFieldsHidden);
    _builder.newLineIfNotEmpty();
    CharSequence _switchResult = null;
    String _name = property.eClass().getName();
    boolean _matched = false;
    if (Objects.equal(_name, this.nameUintProperty)) {
      _matched=true;
      StringConcatenation _builder_1 = new StringConcatenation();
      {
        if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
          _builder_1.append("<block type=\"number_shortproperty\">");
          _builder_1.newLine();
          _builder_1.append("<field name=\"numbertype_property\">");
          String _string = this.type.toString();
          _builder_1.append(_string);
          _builder_1.append("</field>");
          _builder_1.newLineIfNotEmpty();
          CharSequence _generateShortPropertyBlock = this.generateShortPropertyBlock(property);
          _builder_1.append(_generateShortPropertyBlock);
          _builder_1.newLineIfNotEmpty();
        } else {
          _builder_1.append("<block type=\"number_property\">");
          _builder_1.newLine();
          _builder_1.append("<field name=\"numbertype_property\">");
          String _string_1 = this.type.toString();
          _builder_1.append(_string_1);
          _builder_1.append("</field>");
          _builder_1.newLineIfNotEmpty();
          CharSequence _generateFieldConstant = this.generateFieldConstant(this.constant);
          _builder_1.append(_generateFieldConstant);
          _builder_1.newLineIfNotEmpty();
          CharSequence _generateLongPropertyBlock = this.generateLongPropertyBlock(property);
          _builder_1.append(_generateLongPropertyBlock);
          _builder_1.newLineIfNotEmpty();
        }
      }
      _switchResult = _builder_1;
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameIntProperty)) {
        _matched=true;
        StringConcatenation _builder_2 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_2.append("<block type=\"number_shortproperty\">");
            _builder_2.newLine();
            _builder_2.append("<field name=\"numbertype_property\">");
            String _string_2 = this.type.toString();
            _builder_2.append(_string_2);
            _builder_2.append("</field>");
            _builder_2.newLineIfNotEmpty();
            CharSequence _generateShortPropertyBlock_1 = this.generateShortPropertyBlock(property);
            _builder_2.append(_generateShortPropertyBlock_1);
            _builder_2.newLineIfNotEmpty();
          } else {
            _builder_2.append("<block type=\"number_property\">");
            _builder_2.newLine();
            _builder_2.append("<field name=\"numbertype_property\">");
            String _string_3 = this.type.toString();
            _builder_2.append(_string_3);
            _builder_2.append("</field>");
            _builder_2.newLineIfNotEmpty();
            CharSequence _generateFieldConstant_1 = this.generateFieldConstant(this.constant);
            _builder_2.append(_generateFieldConstant_1);
            _builder_2.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_1 = this.generateLongPropertyBlock(property);
            _builder_2.append(_generateLongPropertyBlock_1);
            _builder_2.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_2;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameFloatProperty)) {
        _matched=true;
        StringConcatenation _builder_3 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_3.newLineIfNotEmpty();
            _builder_3.append("<block type=\"number_shortproperty\">");
            _builder_3.newLine();
            _builder_3.append("<field name=\"numbertype_property\">");
            String _string_4 = this.type.toString();
            _builder_3.append(_string_4);
            _builder_3.append("</field>");
            _builder_3.newLineIfNotEmpty();
            CharSequence _generateShortPropertyBlock_2 = this.generateShortPropertyBlock(property);
            _builder_3.append(_generateShortPropertyBlock_2);
            _builder_3.newLineIfNotEmpty();
          } else {
            _builder_3.append("<block type=\"number_property\">");
            _builder_3.newLine();
            _builder_3.append("<field name=\"numbertype_property\">float_property</field>");
            _builder_3.newLine();
            CharSequence _generateFieldConstant_2 = this.generateFieldConstant(this.constant);
            _builder_3.append(_generateFieldConstant_2);
            _builder_3.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_2 = this.generateLongPropertyBlock(property);
            _builder_3.append(_generateLongPropertyBlock_2);
            _builder_3.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_3;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameBooleanProperty)) {
        _matched=true;
        StringConcatenation _builder_4 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_4.append("<block type=\"boolean_shortproperty\">");
            _builder_4.newLine();
            CharSequence _generateShortPropertyBlock_3 = this.generateShortPropertyBlock(property);
            _builder_4.append(_generateShortPropertyBlock_3);
            _builder_4.newLineIfNotEmpty();
          } else {
            _builder_4.append("<block type=\"boolean_property\">");
            _builder_4.newLine();
            _builder_4.append("\t\t  \t\t");
            CharSequence _generateFieldConstant_3 = this.generateFieldConstant(this.constant);
            _builder_4.append(_generateFieldConstant_3, "\t\t  \t\t");
            _builder_4.newLineIfNotEmpty();
            _builder_4.append("\t\t  \t\t");
            CharSequence _generateLongPropertyBlock_3 = this.generateLongPropertyBlock(property);
            _builder_4.append(_generateLongPropertyBlock_3, "\t\t  \t\t");
            _builder_4.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_4;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameAddressProperty)) {
        _matched=true;
        StringConcatenation _builder_5 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_5.append("<block type=\"address_shortproperty\">");
            _builder_5.newLine();
            _builder_5.append("<field name=\"addresstype_values\">");
            String _string_5 = this.type.toString();
            _builder_5.append(_string_5);
            _builder_5.append("</field>");
            _builder_5.newLineIfNotEmpty();
            CharSequence _generateShortPropertyBlock_4 = this.generateShortPropertyBlock(property);
            _builder_5.append(_generateShortPropertyBlock_4);
            _builder_5.newLineIfNotEmpty();
          } else {
            _builder_5.append("<block type=\"address_property\">");
            _builder_5.newLine();
            _builder_5.append("<field name=\"addresstype_values\">");
            String _string_6 = this.type.toString();
            _builder_5.append(_string_6);
            _builder_5.append("</field>");
            _builder_5.newLineIfNotEmpty();
            CharSequence _generateFieldConstant_4 = this.generateFieldConstant(this.constant);
            _builder_5.append(_generateFieldConstant_4);
            _builder_5.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_4 = this.generateLongPropertyBlock(property);
            _builder_5.append(_generateLongPropertyBlock_4);
            _builder_5.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_5;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameBytesProperty)) {
        _matched=true;
        StringConcatenation _builder_6 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_6.append("<block type=\"byte_shortproperty\">");
            _builder_6.newLine();
            _builder_6.append("<field name=\"byte_type\">");
            String _string_7 = this.type.toString();
            _builder_6.append(_string_7);
            _builder_6.append("</field>");
            _builder_6.newLineIfNotEmpty();
            CharSequence _generateShortPropertyBlock_5 = this.generateShortPropertyBlock(property);
            _builder_6.append(_generateShortPropertyBlock_5);
            _builder_6.newLineIfNotEmpty();
          } else {
            _builder_6.append("<block type=\"byte_property\">");
            _builder_6.newLine();
            _builder_6.append("<field name=\"byte_type\">");
            String _string_8 = this.type.toString();
            _builder_6.append(_string_8);
            _builder_6.append("</field>");
            _builder_6.newLineIfNotEmpty();
            CharSequence _generateFieldConstant_5 = this.generateFieldConstant(this.constant);
            _builder_6.append(_generateFieldConstant_5);
            _builder_6.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_5 = this.generateLongPropertyBlock(property);
            _builder_6.append(_generateLongPropertyBlock_5);
            _builder_6.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_6;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameCharProperty)) {
        _matched=true;
        StringConcatenation _builder_7 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_7.append("<block type=\"text_shortproperty\">");
            _builder_7.newLine();
            _builder_7.append("<field name=\"type\">");
            _builder_7.append(this.type);
            _builder_7.append("</field>");
            _builder_7.newLineIfNotEmpty();
            CharSequence _generateShortPropertyBlock_6 = this.generateShortPropertyBlock(property);
            _builder_7.append(_generateShortPropertyBlock_6);
            _builder_7.newLineIfNotEmpty();
          } else {
            _builder_7.append("<block type=\"text_property\">");
            _builder_7.newLine();
            _builder_7.append("<field name=\"type\">char_type</field>");
            _builder_7.newLine();
            CharSequence _generateFieldConstant_6 = this.generateFieldConstant(this.constant);
            _builder_7.append(_generateFieldConstant_6);
            _builder_7.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_6 = this.generateLongPropertyBlock(property);
            _builder_7.append(_generateLongPropertyBlock_6);
            _builder_7.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_7;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameTextProperty)) {
        _matched=true;
        StringConcatenation _builder_8 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_8.append("<block type=\"text_shortproperty\">");
            _builder_8.newLine();
            _builder_8.append("<field name=\"type\">");
            _builder_8.append(this.type);
            _builder_8.append("</field>");
            _builder_8.newLineIfNotEmpty();
            CharSequence _generateShortPropertyBlock_7 = this.generateShortPropertyBlock(property);
            _builder_8.append(_generateShortPropertyBlock_7);
            _builder_8.newLineIfNotEmpty();
          } else {
            _builder_8.append("<block type=\"text_property\">");
            _builder_8.newLine();
            _builder_8.append("<field name=\"type\">string_type</field>");
            _builder_8.newLine();
            CharSequence _generateFieldConstant_7 = this.generateFieldConstant(this.constant);
            _builder_8.append(_generateFieldConstant_7);
            _builder_8.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_7 = this.generateLongPropertyBlock(property);
            _builder_8.append(_generateLongPropertyBlock_7);
            _builder_8.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_8;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameUserProperty)) {
        _matched=true;
        StringConcatenation _builder_9 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_9.append("<block type=\"user_shortproperty\">");
            _builder_9.newLine();
            _builder_9.append("<field name=\"type\">");
            _builder_9.append(this.type);
            _builder_9.append("</field>");
            _builder_9.newLineIfNotEmpty();
            CharSequence _generateShortPropertyBlock_8 = this.generateShortPropertyBlock(property);
            _builder_9.append(_generateShortPropertyBlock_8);
            _builder_9.newLineIfNotEmpty();
          } else {
            _builder_9.append("<block type=\"user_property\">");
            _builder_9.newLine();
            CharSequence _generateFieldConstant_8 = this.generateFieldConstant(this.constant);
            _builder_9.append(_generateFieldConstant_8);
            _builder_9.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_8 = this.generateLongPropertyBlock(property);
            _builder_9.append(_generateLongPropertyBlock_8);
            _builder_9.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_9;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameCompanyProperty)) {
        _matched=true;
        StringConcatenation _builder_10 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_10.append("<block type=\"company_shortproperty\">");
            _builder_10.newLine();
            CharSequence _generateShortPropertyBlock_9 = this.generateShortPropertyBlock(property);
            _builder_10.append(_generateShortPropertyBlock_9);
            _builder_10.newLineIfNotEmpty();
          } else {
            _builder_10.append("<block type=\"company_property\">");
            _builder_10.newLine();
            CharSequence _generateFieldConstant_9 = this.generateFieldConstant(this.constant);
            _builder_10.append(_generateFieldConstant_9);
            _builder_10.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_9 = this.generateLongPropertyBlock(property);
            _builder_10.append(_generateLongPropertyBlock_9);
            _builder_10.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_10;
      }
    }
    if (!_matched) {
      if (Objects.equal(_name, this.nameIdentifierProperty)) {
        _matched=true;
        StringConcatenation _builder_11 = new StringConcatenation();
        {
          if (((property.getVisibility().toString().trim().equals("public") && property.getStorageData().toString().equals("memory")) && (((property.getConstant() == null) || property.getConstant().equals("null")) || property.getConstant().equals("")))) {
            _builder_11.append("<block type=\"identifier_shortproperty\">");
            _builder_11.newLine();
            _builder_11.append("<field name=\"type\">");
            String _string_9 = this.type.toString();
            _builder_11.append(_string_9);
            _builder_11.append("</field>");
            _builder_11.newLineIfNotEmpty();
            CharSequence _generateShortPropertyBlock_10 = this.generateShortPropertyBlock(property);
            _builder_11.append(_generateShortPropertyBlock_10);
            _builder_11.newLineIfNotEmpty();
          } else {
            _builder_11.append("<block type=\"identifier_property\">");
            _builder_11.newLine();
            _builder_11.append("<field name=\"type\">");
            String _string_10 = this.type.toString();
            _builder_11.append(_string_10);
            _builder_11.append("</field>");
            _builder_11.newLineIfNotEmpty();
            CharSequence _generateFieldConstant_10 = this.generateFieldConstant(this.constant);
            _builder_11.append(_generateFieldConstant_10);
            _builder_11.newLineIfNotEmpty();
            CharSequence _generateLongPropertyBlock_10 = this.generateLongPropertyBlock(property);
            _builder_11.append(_generateLongPropertyBlock_10);
            _builder_11.newLineIfNotEmpty();
          }
        }
        _switchResult = _builder_11;
      }
    }
    if (!_matched) {
      StringConcatenation _builder_12 = new StringConcatenation();
      _switchResult = _builder_12;
    }
    _builder.append(_switchResult);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos:La propiedad a parsear
   * Descripci�n: Se construye el bloque de la propiedad de forma corta
   * Salida: Ninguna
   */
  private CharSequence generateShortPropertyBlock(final Properties property) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if (((property.getArray() != null) && (property.getArray() != ""))) {
        _builder.append("        ");
        CharSequence _generateFieldArray = this.generateFieldArray(property);
        _builder.append(_generateFieldArray, "        ");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("<field name=\"name\">");
    String _name = property.getName();
    _builder.append(_name);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("        ");
    CharSequence _generateFieldAssignValueExpression = this.generateFieldAssignValueExpression();
    _builder.append(_generateFieldAssignValueExpression, "        ");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos:La propiedad a parsear
   * Descripci�n: Se construye el bloque de la propiedad de forma extendida
   * Salida: Ninguna
   */
  private CharSequence generateLongPropertyBlock(final Properties property) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if (((property.getArray() != null) && (property.getArray() != ""))) {
        CharSequence _generateFieldArray = this.generateFieldArray(property);
        _builder.append(_generateFieldArray);
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.append("<field name=\"values_visibility\">");
    Visibility _visibility = property.getVisibility();
    _builder.append(_visibility, "\t\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("<field name=\"storagedata_values\">");
    StorageData _storageData = property.getStorageData();
    _builder.append(_storageData, "\t\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("<field name=\"name\">");
    _builder.append(this.name, "\t\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    CharSequence _generateFieldAssignValueExpression = this.generateFieldAssignValueExpression();
    _builder.append(_generateFieldAssignValueExpression);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence calculateFieldsHidden(final String[] arrayCamposOcultos) {
    StringConcatenation _builder = new StringConcatenation();
    String _cleanFields = this.cleanFields();
    _builder.append(_cleanFields);
    _builder.newLineIfNotEmpty();
    for (int i = 0; (i < arrayCamposOcultos.length); i++) {
      {
        String campo = arrayCamposOcultos[i];
        String[] claveValor = campo.toString().split(":");
        boolean _equals = (claveValor[0]).toString().trim().equals(this.nameFieldType);
        if (_equals) {
          this.type = (claveValor[1]).toString().trim();
        }
        boolean _equals_1 = (claveValor[0]).toString().trim().equals(this.nameFieldConstant);
        if (_equals_1) {
          this.constant = (claveValor[1]).toString().trim();
        }
        boolean _equals_2 = (claveValor[0]).toString().trim().equals(this.nameFieldName);
        if (_equals_2) {
          this.name = (claveValor[1]).toString().trim();
        }
        boolean _equals_3 = (claveValor[0]).toString().trim().equals(this.nameFieldInicialization);
        if (_equals_3) {
          this.inicialization = (claveValor[1]).toString().trim();
        }
        boolean _equals_4 = (claveValor[0]).toString().trim().equals(this.nameFieldValueIdentifier);
        if (_equals_4) {
          this.valueIdentifier = (claveValor[1]).toString().trim();
        }
      }
    }
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private String cleanFields() {
    return this.inicialization = "";
  }
  
  /**
   * Argumento: String del valor constant de la propiedad
   * Descripci�n:Comprueba si contiene la palabra constant para marcar en el bloque de la propiedad blockly el campo CONSTANT
   * Salida: Ninguna
   */
  private CharSequence generateFieldConstant(final String constant) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if (((constant.equals(null) || Objects.equal(constant, "")) || constant.equals("null"))) {
        _builder.append("<field name=\"constant\">FALSE</field>");
        _builder.newLine();
      } else {
        _builder.append("<field name=\"constant\">TRUE</field>");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Argumento: La propiedad que tiene dimensiones de array
   * Descripci�n: En primer lugar transforma la cadena donde contiene las dimensiones en un array para poder ir estrayendo dimensi�n por dimensi�n.
   * En caso de ser par es que es din�mico porque no tiene un �ndice est�tico, en caso de ser impar es est�tico porque tiene un �ndice (n�mero) entre los corchetes
   */
  private CharSequence generateFieldArray(final Properties property) {
    CharSequence _xblockexpression = null;
    {
      this.cleanCounter(0);
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<value name=\"arraydimension\">");
      _builder.newLine();
      String arrayTransform = property.getArray().toString().replace("]", "],");
      _builder.append("\t\t");
      String[] array = arrayTransform.toString().split(",");
      _builder.append("\t\t");
      {
        for(final String arrayDimension : array) {
          _builder.newLineIfNotEmpty();
          {
            int _length = arrayDimension.length();
            int _modulo = (_length % 2);
            boolean _equals = (_modulo == 0);
            if (_equals) {
              _builder.append("\t\t\t");
              CharSequence _generateDynamicArrayBlock = this.generateDynamicArrayBlock(array, this.counter);
              _builder.append(_generateDynamicArrayBlock);
              _builder.newLineIfNotEmpty();
            } else {
              String _string = arrayDimension.toString();
              int _indexOf = arrayDimension.toString().indexOf("[");
              int _plus = (_indexOf + 1);
              CharSequence _generateStaticArrayBlock = this.generateStaticArrayBlock(_string.substring(_plus, arrayDimension.toString().indexOf("]")), array, this.counter);
              _builder.append(_generateStaticArrayBlock);
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      final String[] _converted_array = (String[])array;
      CharSequence _closeTagsArray = this.closeTagsArray(((List<String>)Conversions.doWrapArray(_converted_array)).size());
      _builder.append(_closeTagsArray);
      _builder.newLineIfNotEmpty();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Argumento: Ninguno
   * Descripci�n: Aumenta el contador de dimensiones para comprobar en el m�todo generateFieldArray si es el �ltimo
   * Salida:Ninguno
   */
  private int addCounterElementsArrayDimension() {
    return this.counter = (this.counter + 1);
  }
  
  /**
   * Argumento: Recibe un 0 siempre para limpiar el contador de dimensiones
   * Descripci�n: Limpia el contador de dimensiones para la siguiente propiedad
   */
  private int cleanCounter(final int number) {
    return this.counter = number;
  }
  
  /**
   * Argumento: La dimensi�n del array est�tico, el array de dimensiones de la propiedad, la posici�n actual de la dimensi�n que se va a parsear
   * Descripci�n:Genera el bloque del array est�tico, si no es el �ltimo a�ade una etiqueta de dimensi�n para a�adir la dimensi�n est�tica/din�mica que viene
   */
  private CharSequence generateStaticArrayBlock(final String dimension, final String[] array, final int position) {
    CharSequence _xblockexpression = null;
    {
      this.addCounterElementsArrayDimension();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"array_property\">");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("<field name=\"cells\">");
      _builder.append(dimension, "\t");
      _builder.append("</field>");
      _builder.newLineIfNotEmpty();
      {
        int _size = ((List<String>)Conversions.doWrapArray(array)).size();
        int _minus = (_size - 1);
        boolean _notEquals = (position != _minus);
        if (_notEquals) {
          _builder.append("<value name=\"plus_dimension\">\t");
          _builder.newLine();
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Argumento: El array de dimensiones de la propiedad, la posici�n actual de la dimensi�n que se va a parsear
   * Descripci�n: Genera el bloque del array din�mico, si no es el �ltimo a�ade una etiqueta de dimensi�n para a�adir la dimensi�n est�tica/din�mica que viene
   */
  private CharSequence generateDynamicArrayBlock(final String[] array, final int position) {
    CharSequence _xblockexpression = null;
    {
      this.addCounterElementsArrayDimension();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<block type=\"dynamic_array\">");
      _builder.newLine();
      {
        int _size = ((List<String>)Conversions.doWrapArray(array)).size();
        int _minus = (_size - 1);
        boolean _notEquals = (position != _minus);
        if (_notEquals) {
          _builder.append("<value name=\"dimension\">\t");
          _builder.newLine();
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Argumento: Numero de dimensiones del array a cerrar
   * Descripci�n: Cierra las etiquetas <next> y <block> de cuando se crearon los bloques de los array est�ticos/din�micos
   */
  private CharSequence closeTagsArray(final int numDimensionsProperty) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if ((numDimensionsProperty != 0)) {
        final int[] elementsToClose = new int[numDimensionsProperty];
        _builder.newLineIfNotEmpty();
        {
          for(final int element : elementsToClose) {
            _builder.append("  ");
            _builder.append("</block>");
            _builder.newLine();
            _builder.append("</value>");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Argumento: La propiedad que tiene dimensiones de array
   * Descripci�n: En primer lugar transforma la cadena donde contiene las dimensiones en un array para poder ir estrayendo dimensi�n por dimensi�n.
   * En caso de ser par es que es din�mico porque no tiene un �ndice est�tico, en caso de ser impar es est�tico porque tiene un �ndice (n�mero) entre los corchetes
   */
  private CharSequence generateFieldArrayMapping(final String property) {
    CharSequence _xblockexpression = null;
    {
      this.cleanCounter(0);
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("<value name=\"arraydimension\">");
      _builder.newLine();
      String arrayTransform = property.toString().replace("]", "],");
      _builder.append("\t\t");
      String[] array = arrayTransform.toString().split(",");
      _builder.append("\t\t");
      {
        for(final String arrayDimension : array) {
          _builder.newLineIfNotEmpty();
          {
            int _length = arrayDimension.length();
            int _modulo = (_length % 2);
            boolean _equals = (_modulo == 0);
            if (_equals) {
              CharSequence _generateDynamicArrayBlock = this.generateDynamicArrayBlock(array, this.counter);
              _builder.append(_generateDynamicArrayBlock);
              _builder.newLineIfNotEmpty();
            } else {
              String _string = arrayDimension.toString();
              int _indexOf = arrayDimension.toString().indexOf("[");
              int _plus = (_indexOf + 1);
              CharSequence _generateStaticArrayBlock = this.generateStaticArrayBlock(_string.substring(_plus, arrayDimension.toString().indexOf("]")), array, this.counter);
              _builder.append(_generateStaticArrayBlock);
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      final String[] _converted_array = (String[])array;
      CharSequence _closeTagsArray = this.closeTagsArray(((List<String>)Conversions.doWrapArray(_converted_array)).size());
      _builder.append(_closeTagsArray);
      _builder.newLineIfNotEmpty();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  private CharSequence generateFieldAssignValueExpression() {
    StringConcatenation _builder = new StringConcatenation();
    {
      if ((((this.inicialization != null) && (!this.inicialization.equals("null"))) && (!this.inicialization.equals("")))) {
        _builder.append("<value name=\"valueproperty\">");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("<block type=\"assing_value_expression1inputs\"> ");
        _builder.newLine();
        _builder.append("\t\t");
        _builder.append("<field name=\"operators\">");
        _builder.append("=", "\t\t");
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("<value name=\"value1_assignexpression\">");
        _builder.newLine();
        _builder.append("\t      \t");
        CharSequence _identifyExpressionRecursive = this.parserExpressions.identifyExpressionRecursive(this.inicialization);
        _builder.append(_identifyExpressionRecursive, "\t      \t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t");
        _builder.append("</value>");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("</block>");
        _builder.newLine();
        _builder.append("</value>");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos:Un string con los valores de la propiedad mappong
   * Descripci�n: Extracci�n del string que recibe de entrada de los valores de las propiedades mapping
   * Salida: Ninguna
   */
  private CharSequence calculateFieldsHiddenMapping(final String[] arrayCamposOcultos) {
    StringConcatenation _builder = new StringConcatenation();
    for (int i = 0; (i < arrayCamposOcultos.length); i++) {
      {
        String campo = arrayCamposOcultos[i];
        String[] claveValor = campo.toString().split(":");
        boolean _equals = (claveValor[0]).toString().trim().equals(this.nameFieldKey);
        if (_equals) {
          this.key = (claveValor[1]).toString().trim();
        }
        boolean _equals_1 = (claveValor[0]).toString().trim().equals(this.nameFieldValue);
        if (_equals_1) {
          this.value = (claveValor[1]).toString().trim();
        }
        boolean _equals_2 = (claveValor[0]).toString().trim().equals(this.nameFieldConstant);
        if (_equals_2) {
          this.constant = (claveValor[1]).toString().trim();
        }
        boolean _equals_3 = (claveValor[0]).toString().trim().equals(this.nameFieldArray);
        if (_equals_3) {
          this.array = (claveValor[1]).toString().trim();
        }
        boolean _equals_4 = (claveValor[0]).toString().trim().equals(this.nameFieldVisibility);
        if (_equals_4) {
          this.visibility = (claveValor[1]).toString().trim();
        }
        boolean _equals_5 = (claveValor[0]).toString().trim().equals(this.nameFieldName);
        if (_equals_5) {
          this.name = (claveValor[1]).toString().trim();
        }
        boolean _equals_6 = (claveValor[0]).toString().trim().equals(this.nameFieldNameMapping);
        if (_equals_6) {
          this.nameMapping = (claveValor[1]).toString().trim();
        }
        boolean _equals_7 = (claveValor[0]).toString().trim().equals(this.nameFieldStorageData);
        if (_equals_7) {
          this.storagedata = (claveValor[1]).toString().trim();
        }
        boolean _equals_8 = (claveValor[0]).toString().trim().equals(this.nameFieldInicialization);
        if (_equals_8) {
          this.inicialization = (claveValor[1]).toString().trim();
        }
        boolean _equals_9 = (claveValor[0]).toString().trim().equals(this.nameFieldValueIdentifier);
        if (_equals_9) {
          this.valueIdentifier = (claveValor[1]).toString().trim();
        }
      }
    }
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos:La propiedad mapping a parsear
   * Descripci�n: Se construye el bloque de la propiedad mapping ya sea de forma extendida o corta seg�n los par�metros que se obtengan
   * Salida: Ninguna
   */
  public CharSequence identifyMappingProperty(final Mapping property) {
    StringConcatenation _builder = new StringConcatenation();
    Mapping _println = InputOutput.<Mapping>println(property);
    _builder.append(_println);
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    String[] arrayCamposOcultos = property.toString().substring(property.toString().indexOf("array:"), property.toString().lastIndexOf(")")).split(",");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    CharSequence _calculateFieldsHiddenMapping = this.calculateFieldsHiddenMapping(arrayCamposOcultos);
    _builder.append(_calculateFieldsHiddenMapping, "\t    ");
    _builder.append("\t   ");
    _builder.newLineIfNotEmpty();
    {
      if ((((this.visibility.equals("public") || this.visibility.equals(null)) && (this.storagedata.equals("memory") || this.storagedata.equals(null))) && ((this.constant.equals("null") || this.constant.equals(null)) || this.constant.equals("")))) {
        _builder.append("<block type=\"mapping_shortproperty\">");
        _builder.newLine();
        CharSequence _calculateKeyValueMapping = this.calculateKeyValueMapping();
        _builder.append(_calculateKeyValueMapping);
        _builder.newLineIfNotEmpty();
        {
          if ((((this.array != null) && (this.array != "")) && (!this.array.equals("null")))) {
            CharSequence _generateFieldArrayMapping = this.generateFieldArrayMapping(this.array);
            _builder.append(_generateFieldArrayMapping);
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("<field name=\"name\">");
        _builder.append(this.nameMapping);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("<block type=\"mapping_property\">");
        _builder.newLine();
        CharSequence _calculateKeyValueMapping_1 = this.calculateKeyValueMapping();
        _builder.append(_calculateKeyValueMapping_1);
        _builder.newLineIfNotEmpty();
        {
          if ((((this.array != null) && (this.array != "")) && (!this.array.equals("null")))) {
            CharSequence _generateFieldArrayMapping_1 = this.generateFieldArrayMapping(this.array);
            _builder.append(_generateFieldArrayMapping_1);
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t  \t");
        CharSequence _generateFieldConstant = this.generateFieldConstant(this.constant);
        _builder.append(_generateFieldConstant, "\t  \t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t  \t");
        _builder.append("<field name=\"values_visibility\">");
        _builder.append(this.visibility, "\t  \t");
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        _builder.append("<field name=\"storagedata_values\">");
        _builder.append(this.storagedata);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        _builder.append("<field name=\"name\">");
        _builder.append(this.nameMapping);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("        ");
    CharSequence _generateFieldAssignValueExpression = this.generateFieldAssignValueExpression();
    _builder.append(_generateFieldAssignValueExpression, "        ");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos:La propiedad mapping a parsear
   * Descripci�n: Se construye el bloque de la propiedad mapping ya sea de forma extendida o corta seg�n los par�metros que se obtengan
   * Salida: Ninguna
   */
  public CharSequence identifyMappingProperty(final Mapping property, final MappingDeclaration valueInterface) {
    StringConcatenation _builder = new StringConcatenation();
    Mapping _println = InputOutput.<Mapping>println(property);
    _builder.append(_println);
    _builder.newLineIfNotEmpty();
    MappingDeclaration _println_1 = InputOutput.<MappingDeclaration>println(valueInterface);
    _builder.append(_println_1);
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    String[] arrayCamposOcultos = property.toString().substring(property.toString().indexOf("array:"), property.toString().lastIndexOf(")")).split(",");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    CharSequence _calculateFieldsHiddenMapping = this.calculateFieldsHiddenMapping(arrayCamposOcultos);
    _builder.append(_calculateFieldsHiddenMapping, "\t    ");
    _builder.append("\t   ");
    _builder.newLineIfNotEmpty();
    {
      if ((((this.visibility.equals("public") || this.visibility.equals(null)) && (this.storagedata.equals("memory") || this.storagedata.equals(null))) && ((this.constant.equals("null") || this.constant.equals(null)) || this.constant.equals("")))) {
        _builder.append("<block type=\"mapping_shortproperty\">");
        _builder.newLine();
        CharSequence _calculateKeyValueMapping = this.calculateKeyValueMapping();
        _builder.append(_calculateKeyValueMapping);
        _builder.newLineIfNotEmpty();
        {
          if ((((this.array != null) && (this.array != "")) && (!this.array.equals("null")))) {
            CharSequence _generateFieldArrayMapping = this.generateFieldArrayMapping(this.array);
            _builder.append(_generateFieldArrayMapping);
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("<field name=\"name\">");
        _builder.append(this.nameMapping);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("<block type=\"mapping_property\">");
        _builder.newLine();
        CharSequence _calculateKeyValueMapping_1 = this.calculateKeyValueMapping();
        _builder.append(_calculateKeyValueMapping_1);
        _builder.newLineIfNotEmpty();
        {
          if ((((this.array != null) && (this.array != "")) && (!this.array.equals("null")))) {
            CharSequence _generateFieldArrayMapping_1 = this.generateFieldArrayMapping(this.array);
            _builder.append(_generateFieldArrayMapping_1);
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t  \t");
        CharSequence _generateFieldConstant = this.generateFieldConstant(this.constant);
        _builder.append(_generateFieldConstant, "\t  \t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t  \t");
        _builder.append("<field name=\"values_visibility\">");
        _builder.append(this.visibility, "\t  \t");
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        _builder.append("<field name=\"storagedata_values\">");
        _builder.append(this.storagedata);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        _builder.append("<field name=\"name\">");
        _builder.append(this.nameMapping);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("        ");
    CharSequence _generateFieldAssignValueExpression = this.generateFieldAssignValueExpression();
    _builder.append(_generateFieldAssignValueExpression, "        ");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos:La propiedad mapping a parsear
   * Descripci�n: Se construye el bloque de la propiedad mapping ya sea de forma extendida o corta seg�n los par�metros que se obtengan
   * Salida: Ninguna
   */
  public CharSequence identifyMappingProperty(final MappingDeclaration property) {
    StringConcatenation _builder = new StringConcatenation();
    String[] arrayCamposOcultos = property.toString().substring(property.toString().indexOf("array:"), property.toString().lastIndexOf(")")).split(",");
    _builder.newLineIfNotEmpty();
    CharSequence _calculateFieldsHiddenMapping = this.calculateFieldsHiddenMapping(arrayCamposOcultos);
    _builder.append(_calculateFieldsHiddenMapping);
    _builder.append("\t   ");
    _builder.newLineIfNotEmpty();
    {
      if ((((this.visibility.equals("public") || this.visibility.equals(null)) && (this.storagedata.equals("memory") || this.storagedata.equals(null))) && ((this.constant.equals("null") || this.constant.equals(null)) || this.constant.equals("")))) {
        _builder.append("<block type=\"mapping_shortproperty\">");
        _builder.newLine();
        CharSequence _calculateKeyValueMapping = this.calculateKeyValueMapping();
        _builder.append(_calculateKeyValueMapping);
        _builder.newLineIfNotEmpty();
        {
          if ((((this.array != null) && (this.array != "")) && (!this.array.equals("null")))) {
            CharSequence _generateFieldArrayMapping = this.generateFieldArrayMapping(this.array);
            _builder.append(_generateFieldArrayMapping);
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("<field name=\"name\">");
        String _nameMapping = property.getNameMapping();
        _builder.append(_nameMapping);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("<block type=\"mapping_property\">");
        _builder.newLine();
        CharSequence _calculateKeyValueMapping_1 = this.calculateKeyValueMapping();
        _builder.append(_calculateKeyValueMapping_1);
        _builder.newLineIfNotEmpty();
        {
          if ((((this.array != null) && (this.array != "")) && (!this.array.equals("null")))) {
            CharSequence _generateFieldArrayMapping_1 = this.generateFieldArrayMapping(this.array);
            _builder.append(_generateFieldArrayMapping_1);
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t  \t");
        CharSequence _generateFieldConstant = this.generateFieldConstant(this.constant);
        _builder.append(_generateFieldConstant, "\t  \t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t  \t");
        _builder.append("<field name=\"values_visibility\">");
        _builder.append(this.visibility, "\t  \t");
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        _builder.append("<field name=\"storagedata_values\">");
        _builder.append(this.storagedata);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        _builder.append("<field name=\"name\">");
        _builder.append(this.nameMapping);
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("        ");
    CharSequence _generateFieldAssignValueExpression = this.generateFieldAssignValueExpression();
    _builder.append(_generateFieldAssignValueExpression, "        ");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos:Ninguno
   * Descripci�n: Genera los campos key y value de las propiedades mapping
   * Salida: Ninguna
   */
  private CharSequence calculateKeyValueMapping() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<value name=\"key\">");
    _builder.newLine();
    CharSequence _controlGenerateTypeBlock = this.parserTypes.controlGenerateTypeBlock(this.key);
    _builder.append(_controlGenerateTypeBlock);
    _builder.newLineIfNotEmpty();
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("<value name=\"value\">");
    _builder.newLine();
    {
      boolean _equals = this.value.equals(null);
      boolean _not = (!_equals);
      if (_not) {
        CharSequence _controlGenerateTypeBlock_1 = this.parserTypes.controlGenerateTypeBlock(this.value);
        _builder.append(_controlGenerateTypeBlock_1);
        _builder.newLineIfNotEmpty();
      } else {
        CharSequence _controlGenerateTypeBlock_2 = this.parserTypes.controlGenerateTypeBlock(this.valueIdentifier);
        _builder.append(_controlGenerateTypeBlock_2);
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("</value>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Argumentos:Enumerador a parsear
   * Descripci�n: Se construye el bloque para el enumerador que recibe de entrada en la funci�n, se parsean tambi�n los valores que est�n contenidos en dicho enumerador
   * Salida: Ninguna
   */
  public CharSequence generateEnumerator(final org.xtext.smaC.Enum enumerator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"enum\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"name\">");
    String _nameEnumerator = enumerator.getNameEnumerator();
    _builder.append(_nameEnumerator, "  ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("<value name=\"values_enum\">");
    _builder.newLine();
    {
      EList<String> _values = enumerator.getValues();
      for(final String value : _values) {
        CharSequence _generateValueEnumerator = this.generateValueEnumerator(value, enumerator);
        _builder.append(_generateValueEnumerator);
        _builder.newLineIfNotEmpty();
        {
          EList<String> _values_1 = enumerator.getValues();
          int _size = enumerator.getValues().size();
          int _minus = (_size - 1);
          boolean _equals = value.equals(_values_1.get(_minus).toString());
          boolean _not = (!_equals);
          if (_not) {
            _builder.append("<value name=\"value\">");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("  ");
    CharSequence _closeTagsValuesEnumerator = this.closeTagsValuesEnumerator(enumerator.getValues().size());
    _builder.append(_closeTagsValuesEnumerator, "  ");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos: String con el valor que se va a meter al enumerado y el propio enumerado
   * Descripci�n: Se construye el bloque para el valor del enumerado
   * Salida: Ninguna
   */
  private CharSequence generateValueEnumerator(final String value, final org.xtext.smaC.Enum enumerator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"enum_value\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<field name=\"value_enum\">");
    String _string = value.toString();
    _builder.append(_string, "\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Argumentos:N�mero de valores que contiene el enumerador
   * Descripci�n: Se cierran las etiquetas next y block de los valores contenidos en el enumerador
   * Salida: Ninguna
   */
  private CharSequence closeTagsValuesEnumerator(final int sizeValuesEnumerator) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if ((sizeValuesEnumerator != 0)) {
        final int[] elementsToClose = new int[sizeValuesEnumerator];
        _builder.newLineIfNotEmpty();
        {
          for(final int element : elementsToClose) {
            _builder.append("  ");
            _builder.append("</block>");
            _builder.newLine();
            _builder.append("</value>");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos:Struct a parsear
   * Descripci�n: Se construye el bloque para el struct que recibe de entrada en la funci�n, se parsean tambi�n las propiedades o otros structs que contenga
   * Salida: Ninguna
   */
  public Object generateStruct(final PersonalizedStruct struct) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"personalized_struct\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _name = struct.getName();
    _builder.append(_name);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<statement name=\"properties_struct\">");
    _builder.newLine();
    {
      EList<Properties> _properties = struct.getProperties();
      for(final Properties property : _properties) {
        CharSequence _identifyTypeProperty = this.identifyTypeProperty(property);
        _builder.append(_identifyTypeProperty);
        _builder.newLineIfNotEmpty();
        {
          if (((!property.equals(struct.getProperties().get((struct.getProperties().size() - 1)))) || (property.equals(struct.getProperties().get((struct.getProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, struct)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Mapping> _mapping = struct.getMapping();
      for(final Mapping propertyMapping : _mapping) {
        CharSequence _identifyMappingProperty = this.identifyMappingProperty(propertyMapping);
        _builder.append(_identifyMappingProperty);
        _builder.newLineIfNotEmpty();
        {
          if (((!propertyMapping.equals(struct.getMapping().get((struct.getMapping().size() - 1)))) || (propertyMapping.equals(struct.getMapping().get((struct.getMapping().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameMappingProperty, struct)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<PersonalizedStruct> _structs = struct.getStructs();
      for(final PersonalizedStruct propertyStruct : _structs) {
        Object _generateStruct = this.generateStruct(propertyStruct);
        _builder.append(_generateStruct);
        _builder.newLineIfNotEmpty();
        {
          if (((!propertyStruct.equals(struct.getStructs().get((struct.getStructs().size() - 1)))) || (propertyStruct.equals(struct.getStructs().get((struct.getStructs().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameStruct, struct)))) {
            _builder.append("<next>");
            _builder.newLine();
          } else {
            _builder.append("</block>");
            _builder.newLine();
          }
        }
      }
    }
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(struct.getMapping().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalMapping, struct));
    _builder.append(_closeTagsDistinctElements);
    _builder.newLineIfNotEmpty();
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(struct.getProperties().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, struct));
    _builder.append(_closeTagsDistinctElements_1);
    _builder.newLineIfNotEmpty();
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Argumentos:Struct User a parsear
   * Descripci�n: Se construye el bloque para el User struct que recibe de entrada en la funci�n, se parsean tambi�n las propiedades o otros structs que contenga
   * Salida: Ninguna
   */
  public CharSequence generateUserStruct(final User struct) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_user\">");
    _builder.newLine();
    _builder.newLine();
    _builder.append("<statement name=\"user_values\">");
    _builder.newLine();
    {
      EList<Properties> _properties = struct.getProperties();
      for(final Properties property : _properties) {
        CharSequence _identifyTypeProperty = this.identifyTypeProperty(property);
        _builder.append(_identifyTypeProperty);
        _builder.newLineIfNotEmpty();
        {
          if (((!property.equals(struct.getProperties().get((struct.getProperties().size() - 1)))) || (property.equals(struct.getProperties().get((struct.getProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, struct)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Argumentos:Struct User a parsear
   * Descripci�n: Se construye el bloque para el User struct que recibe de entrada en la funci�n, se parsean tambi�n las propiedades o otros structs que contenga
   * Salida: Ninguna
   */
  public CharSequence generateCompanyStruct(final Company struct) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    {
      EList<Properties> _properties = struct.getProperties();
      for(final Properties property : _properties) {
        _builder.append("\t");
        CharSequence _identifyTypeProperty = this.identifyTypeProperty(property);
        _builder.append(_identifyTypeProperty, "\t");
        _builder.newLineIfNotEmpty();
        {
          if (((!property.equals(struct.getProperties().get((struct.getProperties().size() - 1)))) || (property.equals(struct.getProperties().get((struct.getProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, struct)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
}
