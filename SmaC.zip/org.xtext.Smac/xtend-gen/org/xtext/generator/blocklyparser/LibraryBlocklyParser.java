package org.xtext.generator.blocklyparser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.ExpressionBlocklyParser;
import org.xtext.generator.blocklyparser.FunctionBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.PropertyBlocklyParser;
import org.xtext.smaC.Clause;
import org.xtext.smaC.Library;
import org.xtext.smaC.PersonalizedStruct;

@SuppressWarnings("all")
public class LibraryBlocklyParser {
  private FunctionBlocklyParser parserFunction = new FunctionBlocklyParser();
  
  private ExpressionBlocklyParser parserExpressions = new ExpressionBlocklyParser();
  
  private PropertyBlocklyParser parserProperties = new PropertyBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private final String nameEnumerator = "enumerator";
  
  private final String nameLocalProperty = "localProperty";
  
  private final String nameLocalMapping = "localMappingProperty";
  
  private final String nameStruct = "struct";
  
  /**
   * Argumentos: La library a parsear
   * Descripci�n:Genera el bloque library contenido en un fichero .sce y llama a los parseadores de las properties,enum o functions si la library contuviera alguno de estos
   * Salida: Ninguna
   */
  public CharSequence defineBlockLibrary(final Library library) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"library\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _name = library.getName();
    _builder.append(_name);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<statement name=\"functions_library\">");
    _builder.newLine();
    {
      EList<PersonalizedStruct> _structs = library.getStructs();
      for(final PersonalizedStruct struct : _structs) {
        Object _generateStruct = this.parserProperties.generateStruct(struct);
        _builder.append(_generateStruct);
        _builder.newLineIfNotEmpty();
        {
          if (((!struct.equals(library.getStructs().get((library.getStructs().size() - 1)))) || (struct.equals(library.getStructs().get((library.getStructs().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameStruct, library)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<org.xtext.smaC.Enum> _enums = library.getEnums();
      for(final org.xtext.smaC.Enum enumerator : _enums) {
        _builder.append("    \t");
        CharSequence _generateEnumerator = this.parserProperties.generateEnumerator(enumerator);
        _builder.append(_generateEnumerator, "    \t");
        _builder.newLineIfNotEmpty();
        {
          if (((!enumerator.equals(library.getEnums().get((library.getEnums().size() - 1)))) || (enumerator.equals(library.getEnums().get((library.getEnums().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameEnumerator, library)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Clause> _functions = library.getFunctions();
      for(final Clause function : _functions) {
        CharSequence _defineFunction = this.parserFunction.defineFunction(function);
        _builder.append(_defineFunction);
        _builder.newLineIfNotEmpty();
        {
          EList<Clause> _functions_1 = library.getFunctions();
          int _size = library.getFunctions().size();
          int _minus = (_size - 1);
          boolean _equals = function.equals(_functions_1.get(_minus));
          boolean _not = (!_equals);
          if (_not) {
            _builder.append(" \t   \t<next>");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("</block>");
            _builder.newLine();
          }
        }
      }
    }
    CharSequence _closeTags = this.parserCommonFunctions.closeTags(library.getFunctions().size());
    _builder.append(_closeTags);
    _builder.append("\t");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(library.getEnums().size(), this.parserCommonFunctions.controlMoreElements(this.nameEnumerator, library));
    _builder.append(_closeTagsDistinctElements);
    _builder.append("\t");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(library.getStructs().size(), this.parserCommonFunctions.controlMoreElements(this.nameStruct, library));
    _builder.append(_closeTagsDistinctElements_1);
    _builder.append("\t</statement>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
}
