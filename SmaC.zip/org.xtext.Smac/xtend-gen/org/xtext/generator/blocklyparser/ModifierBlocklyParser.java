package org.xtext.generator.blocklyparser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.ConditionBlocklyParser;
import org.xtext.generator.blocklyparser.ExpressionBlocklyParser;
import org.xtext.generator.blocklyparser.ParamBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.RestrictionClauseBlocklyParser;
import org.xtext.smaC.Condition;
import org.xtext.smaC.Modifier;
import org.xtext.smaC.RestrictionClause;

@SuppressWarnings("all")
public class ModifierBlocklyParser {
  private RestrictionClauseBlocklyParser parserRestrictionClause = new RestrictionClauseBlocklyParser();
  
  private ExpressionBlocklyParser parserExpressions = new ExpressionBlocklyParser();
  
  private ConditionBlocklyParser parserCondition = new ConditionBlocklyParser();
  
  private ParamBlocklyParser parserParam = new ParamBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private final String nameRestriction = "restriction";
  
  private final String nameExpressionBeforeMark = "expressionBeforeMark";
  
  private final String nameExpressionAfterMark = "expressionAfterMark";
  
  private final String nameConditionBeforeMark = "conditionBeforeMark";
  
  private final String nameConditionAfterMark = "conditionAfterMark";
  
  public CharSequence defineModifier(final Modifier modifier) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"modifier\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _name = modifier.getName();
    _builder.append(_name);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<value name=\"inputparams\">");
    _builder.newLine();
    {
      int _size = modifier.getInputParams().size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        CharSequence _defineInputParams = this.parserParam.defineInputParams(modifier.getInputParams());
        _builder.append(_defineInputParams);
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("<statement name=\"restrictions_modifier\">");
    _builder.newLine();
    {
      EList<RestrictionClause> _conditionRestricion = modifier.getConditionRestricion();
      for(final RestrictionClause restriction : _conditionRestricion) {
        CharSequence _identifyRestriction = this.parserRestrictionClause.identifyRestriction(restriction);
        _builder.append(_identifyRestriction);
        _builder.newLineIfNotEmpty();
        {
          if (((!restriction.equals(modifier.getConditionRestricion().get((modifier.getConditionRestricion().size() - 1)))) || (restriction.equals(modifier.getConditionRestricion().get((modifier.getConditionRestricion().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameRestriction, modifier)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      int _size_1 = modifier.getConditionsBeforeMark().size();
      boolean _greaterThan_1 = (_size_1 > 0);
      if (_greaterThan_1) {
        {
          EList<Condition> _conditionsBeforeMark = modifier.getConditionsBeforeMark();
          for(final Condition condition : _conditionsBeforeMark) {
            Object _createBlockCondition = this.parserCondition.createBlockCondition(condition);
            _builder.append(_createBlockCondition);
            _builder.append("\t\t\t");
            {
              if (((!condition.equals(modifier.getConditionsBeforeMark().get((modifier.getConditionsBeforeMark().size() - 1)))) || (condition.equals(modifier.getConditionsBeforeMark().get((modifier.getConditionsBeforeMark().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameConditionBeforeMark, modifier)))) {
                _builder.newLineIfNotEmpty();
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    {
      int _size_2 = modifier.getExpressionsAssignValueBeforeMark().size();
      boolean _greaterThan_2 = (_size_2 > 0);
      if (_greaterThan_2) {
        {
          EList<String> _expressionsAssignValueBeforeMark = modifier.getExpressionsAssignValueBeforeMark();
          for(final String expressionBeforeMark : _expressionsAssignValueBeforeMark) {
            _builder.append(" \t");
            CharSequence _identifyExpressionInsideModifier = this.parserExpressions.identifyExpressionInsideModifier(expressionBeforeMark);
            _builder.append(_identifyExpressionInsideModifier, " \t");
            _builder.newLineIfNotEmpty();
            {
              if (((!expressionBeforeMark.equals(modifier.getExpressionsAssignValueBeforeMark().get((modifier.getExpressionsAssignValueBeforeMark().size() - 1)))) || (expressionBeforeMark.equals(modifier.getExpressionsAssignValueBeforeMark().get((modifier.getExpressionsAssignValueBeforeMark().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameExpressionBeforeMark, modifier)))) {
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    {
      if (((modifier.getConditionsAfterMark().size() >= 1) || (modifier.getExpressionsAssignValueAfterMark().size() >= 1))) {
        _builder.append(" \t");
        _builder.append("<block type=\"markmodifier\"/>");
        _builder.newLine();
        _builder.append(" \t");
        _builder.append("<next> ");
        _builder.newLine();
      }
    }
    {
      int _size_3 = modifier.getConditionsAfterMark().size();
      boolean _greaterThan_3 = (_size_3 > 0);
      if (_greaterThan_3) {
        {
          EList<Condition> _conditionsAfterMark = modifier.getConditionsAfterMark();
          for(final Condition condition_1 : _conditionsAfterMark) {
            Object _createBlockCondition_1 = this.parserCondition.createBlockCondition(condition_1);
            _builder.append(_createBlockCondition_1);
            _builder.append("\t\t\t");
            {
              if (((!condition_1.equals(modifier.getConditionsAfterMark().get((modifier.getConditionsAfterMark().size() - 1)))) || (condition_1.equals(modifier.getConditionsAfterMark().get((modifier.getConditionsAfterMark().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameConditionAfterMark, modifier)))) {
                _builder.newLineIfNotEmpty();
                _builder.append("<next>");
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    {
      int _size_4 = modifier.getExpressionsAssignValueAfterMark().size();
      boolean _greaterThan_4 = (_size_4 > 0);
      if (_greaterThan_4) {
        _builder.append(" \t");
        CharSequence _identifyExpressions = this.parserExpressions.identifyExpressions(modifier.getExpressionsAssignValueAfterMark());
        _builder.append(_identifyExpressions, " \t");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      if (((modifier.getConditionsAfterMark().size() == 0) && (modifier.getExpressionsAssignValueAfterMark().size() == 0))) {
        _builder.append("<next>");
        _builder.newLine();
        _builder.append("<block type=\"closemodifier\"/>");
        _builder.newLine();
        _builder.append("</next>");
        _builder.newLine();
        CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(modifier.getExpressionsAssignValueBeforeMark().size(), this.parserCommonFunctions.controlMoreElements(this.nameExpressionBeforeMark, modifier));
        _builder.append(_closeTagsDistinctElements);
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(modifier.getConditionsBeforeMark().size(), this.parserCommonFunctions.controlMoreElements(this.nameConditionBeforeMark, modifier));
        _builder.append(_closeTagsDistinctElements_1);
        _builder.newLineIfNotEmpty();
        _builder.append("    \t");
        CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(modifier.getConditionRestricion().size(), this.parserCommonFunctions.controlMoreElements(this.nameRestriction, modifier));
        _builder.append(_closeTagsDistinctElements_2, "    \t");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      if (((modifier.getConditionsAfterMark().size() > 0) || (modifier.getExpressionsAssignValueAfterMark().size() > 0))) {
        _builder.append(" \t\t");
        CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(modifier.getConditionsAfterMark().size(), this.parserCommonFunctions.controlMoreElements(this.nameConditionAfterMark, modifier));
        _builder.append(_closeTagsDistinctElements_3, " \t\t");
        _builder.newLineIfNotEmpty();
        _builder.append(" \t\t");
        _builder.append("</next>");
        _builder.append(" \t\t");
        CharSequence _closeTagsDistinctElements_4 = this.parserCommonFunctions.closeTagsDistinctElements(modifier.getExpressionsAssignValueBeforeMark().size(), this.parserCommonFunctions.controlMoreElements(this.nameExpressionBeforeMark, modifier));
        _builder.append(_closeTagsDistinctElements_4, " \t\t");
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_5 = this.parserCommonFunctions.closeTagsDistinctElements(modifier.getConditionsBeforeMark().size(), this.parserCommonFunctions.controlMoreElements(this.nameConditionBeforeMark, modifier));
        _builder.append(_closeTagsDistinctElements_5);
        _builder.newLineIfNotEmpty();
        _builder.append("    \t");
        CharSequence _closeTagsDistinctElements_6 = this.parserCommonFunctions.closeTagsDistinctElements(modifier.getConditionRestricion().size(), this.parserCommonFunctions.controlMoreElements(this.nameRestriction, modifier));
        _builder.append(_closeTagsDistinctElements_6, "    \t");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
}
