package org.xtext.generator.blocklyparser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.EventBlocklyParser;
import org.xtext.generator.blocklyparser.ExpressionBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.PropertyBlocklyParser;
import org.xtext.generator.blocklyparser.RestrictionClauseBlocklyParser;
import org.xtext.smaC.Condition;
import org.xtext.smaC.Event;
import org.xtext.smaC.ForLoop;
import org.xtext.smaC.Properties;
import org.xtext.smaC.RestrictionClause;
import org.xtext.smaC.RestrictionGas;
import org.xtext.smaC.UnDeterminedLoop;

@SuppressWarnings("all")
public class LoopBlocklyParser {
  private final String nameFieldCounter = "nameCounter";
  
  private final String nameFieldValue = "value";
  
  private final String nameFieldValueCounter = "valueCounter";
  
  private final String nameFieldCondition = "condition";
  
  private final String nameFieldExpressions = "expressions";
  
  private static String counter = "";
  
  private static String value = "";
  
  private static String valueCounter = "";
  
  private static String condition = "";
  
  private String operatorComparation = "";
  
  private static String limit = "";
  
  private final String operatorGreater = ">";
  
  private final String operatorGreaterEqual = ">=";
  
  private final String operatorLessEqual = "<=";
  
  private final String operatorLess = "<";
  
  private final String nameRestrictionGas = "restrictionGas";
  
  private final String nameRestriction = "restriction";
  
  private final String nameLocalProperty = "localProperty";
  
  private final String nameUndeterminedLoop = "undeterminedLoop";
  
  private final String nameDeterminedLoop = "determinedLoop";
  
  private final String nameConditionLoop = "conditionLoop";
  
  private final String nameUndeterminedLoopElse = "undeterminedLoopElse";
  
  private final String nameDeterminedLoopElse = "determinedLoopElse";
  
  private final String nameConditionLoopElse = "conditionLoopElse";
  
  private final String nameEmitEventElse = "emitEventElse";
  
  private ExpressionBlocklyParser parserExpression = new ExpressionBlocklyParser();
  
  private RestrictionClauseBlocklyParser parserRestrictionClause = new RestrictionClauseBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private PropertyBlocklyParser parserProperty = new PropertyBlocklyParser();
  
  private EventBlocklyParser parserEvent = new EventBlocklyParser();
  
  /**
   * Crea los bloques de los bucles WHILE y DoWhile y llama a los parseadores de las expresiones contenidas en ellos
   */
  public Object createBlockUndeterminedLoop(final UnDeterminedLoop loop) {
    StringConcatenation _builder = new StringConcatenation();
    {
      boolean _equals = loop.eClass().getName().equals("WhileLoop");
      if (_equals) {
        _builder.append("<block type=\"block_whileloop\">");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("<statement name=\"elements_while\">");
        _builder.newLine();
      } else {
        _builder.append("<block type=\"block_dowhile\">");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("<statement name=\"elements_dowhile\">");
        _builder.newLine();
      }
    }
    _builder.append("    ");
    {
      EList<RestrictionGas> _gasrestriction = loop.getGasrestriction();
      for(final RestrictionGas gasrestriction : _gasrestriction) {
        _builder.append("\t\t      \t");
        CharSequence _createGasRestriction = this.parserRestrictionClause.createGasRestriction(gasrestriction);
        _builder.append(_createGasRestriction, "    ");
        _builder.newLineIfNotEmpty();
        {
          if (((!gasrestriction.equals(loop.getGasrestriction().get((loop.getGasrestriction().size() - 1)))) || (gasrestriction.equals(loop.getGasrestriction().get((loop.getGasrestriction().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameRestrictionGas, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("    ");
    {
      EList<RestrictionClause> _restriction = loop.getRestriction();
      for(final RestrictionClause restriction : _restriction) {
        _builder.append("\t\t        ");
        CharSequence _identifyRestriction = this.parserRestrictionClause.identifyRestriction(restriction);
        _builder.append(_identifyRestriction, "    ");
        _builder.newLineIfNotEmpty();
        {
          if (((!restriction.equals(loop.getRestriction().get((loop.getRestriction().size() - 1)))) || (restriction.equals(loop.getRestriction().get((loop.getRestriction().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameRestriction, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<UnDeterminedLoop> _undeterminedloops = loop.getUndeterminedloops();
      for(final UnDeterminedLoop undeterminedLoop : _undeterminedloops) {
        Object _createBlockUndeterminedLoop = this.createBlockUndeterminedLoop(undeterminedLoop);
        _builder.append(_createBlockUndeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!undeterminedLoop.equals(loop.getUndeterminedloops().get((loop.getUndeterminedloops().size() - 1)))) || (undeterminedLoop.equals(loop.getUndeterminedloops().get((loop.getUndeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<ForLoop> _determinedloops = loop.getDeterminedloops();
      for(final ForLoop determinedLoop : _determinedloops) {
        CharSequence _createBlockDeterminedLoop = this.createBlockDeterminedLoop(determinedLoop);
        _builder.append(_createBlockDeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!determinedLoop.equals(loop.getDeterminedloops().get((loop.getDeterminedloops().size() - 1)))) || (determinedLoop.equals(loop.getDeterminedloops().get((loop.getDeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Condition> _conditions = loop.getConditions();
      for(final Condition condition : _conditions) {
        CharSequence _createBlockLoopCondition = this.createBlockLoopCondition(condition);
        _builder.append(_createBlockLoopCondition);
        _builder.newLineIfNotEmpty();
        {
          if (((!condition.equals(loop.getConditions().get((loop.getConditions().size() - 1)))) || (condition.equals(loop.getConditions().get((loop.getConditions().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameConditionLoop, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("  \t  \t\t  ");
    CharSequence _identifyExpressions = this.parserExpression.identifyExpressions(loop.getExpressions());
    _builder.append(_identifyExpressions, "  \t  \t\t  ");
    _builder.newLineIfNotEmpty();
    _builder.append("  \t  \t\t  ");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(loop.getConditions().size(), this.parserCommonFunctions.controlMoreElements(this.nameConditionLoop, loop));
    _builder.append(_closeTagsDistinctElements, "  \t  \t\t  ");
    _builder.newLineIfNotEmpty();
    _builder.append("    \t\t  ");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getDeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, loop));
    _builder.append(_closeTagsDistinctElements_1, "    \t\t  ");
    _builder.newLineIfNotEmpty();
    _builder.append("    \t\t  ");
    CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getUndeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, loop));
    _builder.append(_closeTagsDistinctElements_2, "    \t\t  ");
    _builder.newLineIfNotEmpty();
    _builder.append("    \t\t      \t\t  ");
    CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getRestriction().size(), this.parserCommonFunctions.controlMoreElements(this.nameRestriction, loop));
    _builder.append(_closeTagsDistinctElements_3, "    \t\t      \t\t  ");
    _builder.newLineIfNotEmpty();
    _builder.append("    \t\t  ");
    CharSequence _closeTagsDistinctElements_4 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getGasrestriction().size(), this.parserCommonFunctions.controlMoreElements(this.nameRestrictionGas, loop));
    _builder.append(_closeTagsDistinctElements_4, "    \t\t  ");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("</statement>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<value name=\"condition\">");
    _builder.newLine();
    _builder.append("    ");
    CharSequence _identifyExpressionRecursive = this.parserExpression.identifyExpressionRecursive(loop.getCondition());
    _builder.append(_identifyExpressionRecursive, "    ");
    _builder.append("\t\t    </value>");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Crea el bloque del bucle FOR y llama a los parseadores de las expresiones contenidas en el
   */
  public CharSequence createBlockDeterminedLoop(final ForLoop loop) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_for\">");
    _builder.newLine();
    _builder.append("<field name=\"namevariable\">");
    String _nameCounter = loop.getNameCounter();
    _builder.append(_nameCounter);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"value\">");
    int _value = loop.getValue();
    _builder.append(_value);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"namevariable2\">");
    String _nameCounter_1 = loop.getNameCounter();
    _builder.append(_nameCounter_1);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    CharSequence _switchResult = null;
    String _string = loop.getCondition().toString();
    boolean _matched = false;
    boolean _contains = loop.getCondition().toString().contains(this.operatorGreater);
    if (_contains) {
      _matched=true;
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("<field name=\"operatorcomparation\">&gt;</field>");
      _builder_1.newLine();
      _builder_1.append("<field name=\"limit\">");
      String _string_1 = loop.getCondition().toString();
      int _indexOf = loop.getCondition().toString().indexOf(this.operatorGreater);
      int _plus = (_indexOf + 1);
      _builder_1.append(LoopBlocklyParser.limit = _string_1.substring(_plus));
      _builder_1.append("</field>");
      _switchResult = _builder_1;
    }
    if (!_matched) {
      boolean _contains_1 = loop.getCondition().toString().contains(this.operatorGreaterEqual);
      if (_contains_1) {
        _matched=true;
        StringConcatenation _builder_2 = new StringConcatenation();
        _builder_2.append("<field name=\"operatorcomparation\">&gt;=</field>");
        _builder_2.newLine();
        _builder_2.append("<field name=\"limit\">");
        String _string_2 = loop.getCondition().toString();
        int _indexOf_1 = loop.getCondition().toString().indexOf(this.operatorGreaterEqual);
        int _plus_1 = (_indexOf_1 + 1);
        _builder_2.append(LoopBlocklyParser.limit = _string_2.substring(_plus_1));
        _builder_2.append("</field>");
        _switchResult = _builder_2;
      }
    }
    if (!_matched) {
      boolean _contains_2 = loop.getCondition().toString().contains(this.operatorLess);
      if (_contains_2) {
        _matched=true;
        StringConcatenation _builder_3 = new StringConcatenation();
        _builder_3.append("<field name=\"operatorcomparation\">&lt;</field>");
        _builder_3.newLine();
        _builder_3.append("<field name=\"limit\">");
        String _string_3 = loop.getCondition().toString();
        int _indexOf_2 = loop.getCondition().toString().indexOf(this.operatorLess);
        int _plus_2 = (_indexOf_2 + 1);
        _builder_3.append(LoopBlocklyParser.limit = _string_3.substring(_plus_2));
        _builder_3.append("</field>");
        _switchResult = _builder_3;
      }
    }
    if (!_matched) {
      StringConcatenation _builder_4 = new StringConcatenation();
      _builder_4.append("<field name=\"operatorcomparation\">&lt;=</field>");
      _builder_4.newLine();
      _builder_4.append("<field name=\"limit\">");
      String _string_4 = loop.getCondition().toString();
      int _indexOf_3 = loop.getCondition().toString().indexOf(this.operatorLessEqual);
      int _plus_3 = (_indexOf_3 + 1);
      _builder_4.append(LoopBlocklyParser.limit = _string_4.substring(_plus_3));
      _builder_4.append("</field>");
      _switchResult = _builder_4;
    }
    _builder.append(_switchResult);
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"namevariable3\">");
    String _nameCounter_2 = loop.getNameCounter();
    _builder.append(_nameCounter_2);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"arithmeticaloperator\">++</field>");
    _builder.newLine();
    _builder.append("<statement name=\"expressions_for\">");
    _builder.newLine();
    {
      EList<RestrictionGas> _gasrestriction = loop.getGasrestriction();
      for(final RestrictionGas gasrestriction : _gasrestriction) {
        _builder.append("\t      ");
        CharSequence _createGasRestriction = this.parserRestrictionClause.createGasRestriction(gasrestriction);
        _builder.append(_createGasRestriction);
        _builder.newLineIfNotEmpty();
        {
          if (((!gasrestriction.equals(loop.getGasrestriction().get((loop.getGasrestriction().size() - 1)))) || (gasrestriction.equals(loop.getGasrestriction().get((loop.getGasrestriction().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameRestrictionGas, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t    ");
    {
      EList<RestrictionClause> _restriction = loop.getRestriction();
      for(final RestrictionClause restriction : _restriction) {
        _builder.append("\t      ");
        CharSequence _identifyRestriction = this.parserRestrictionClause.identifyRestriction(restriction);
        _builder.append(_identifyRestriction, "\t    ");
        _builder.newLineIfNotEmpty();
        {
          if (((!restriction.equals(loop.getRestriction().get((loop.getRestriction().size() - 1)))) || (restriction.equals(loop.getRestriction().get((loop.getRestriction().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameRestriction, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Properties> _properties = loop.getProperties();
      for(final Properties property : _properties) {
        CharSequence _identifyTypeProperty = this.parserProperty.identifyTypeProperty(property);
        _builder.append(_identifyTypeProperty);
        _builder.newLineIfNotEmpty();
        {
          if (((!property.equals(loop.getProperties().get((loop.getProperties().size() - 1)))) || (loop.equals(loop.getProperties().get((loop.getProperties().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<ForLoop> _determinedloops = loop.getDeterminedloops();
      for(final ForLoop determinedLoop : _determinedloops) {
        _builder.append("\t        ");
        Object _createBlockDeterminedLoop = this.createBlockDeterminedLoop(determinedLoop);
        _builder.append(_createBlockDeterminedLoop, "\t        ");
        _builder.newLineIfNotEmpty();
        {
          if (((!determinedLoop.equals(loop.getDeterminedloops().get((loop.getDeterminedloops().size() - 1)))) || (determinedLoop.equals(loop.getDeterminedloops().get((loop.getDeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<UnDeterminedLoop> _undeterminedloops = loop.getUndeterminedloops();
      for(final UnDeterminedLoop undeterminedLoop : _undeterminedloops) {
        Object _createBlockUndeterminedLoop = this.createBlockUndeterminedLoop(undeterminedLoop);
        _builder.append(_createBlockUndeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!undeterminedLoop.equals(loop.getUndeterminedloops().get((loop.getUndeterminedloops().size() - 1)))) || (undeterminedLoop.equals(loop.getUndeterminedloops().get((loop.getUndeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Condition> _conditions = loop.getConditions();
      for(final Condition condition : _conditions) {
        CharSequence _createBlockLoopCondition = this.createBlockLoopCondition(condition);
        _builder.append(_createBlockLoopCondition);
        _builder.newLineIfNotEmpty();
        {
          if (((!condition.equals(loop.getConditions().get((loop.getConditions().size() - 1)))) || (condition.equals(loop.getConditions().get((loop.getConditions().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameConditionLoop, loop)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("  \t\t");
    CharSequence _identifyExpressions = this.parserExpression.identifyExpressions(loop.getExpressions());
    _builder.append(_identifyExpressions, "  \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("  \t\t");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(loop.getConditions().size(), this.parserCommonFunctions.controlMoreElements(this.nameConditionLoop, loop));
    _builder.append(_closeTagsDistinctElements, "  \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("  \t\t");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getUndeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, loop));
    _builder.append(_closeTagsDistinctElements_1, "  \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("  \t\t");
    CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getDeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, loop));
    _builder.append(_closeTagsDistinctElements_2, "  \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("  \t\t");
    CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getProperties().size(), this.parserCommonFunctions.controlMoreElements(this.nameLocalProperty, loop));
    _builder.append(_closeTagsDistinctElements_3, "  \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("  \t\t");
    CharSequence _closeTagsDistinctElements_4 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getRestriction().size(), this.parserCommonFunctions.controlMoreElements(this.nameRestriction, loop));
    _builder.append(_closeTagsDistinctElements_4, "  \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("  \t\t");
    CharSequence _closeTagsDistinctElements_5 = this.parserCommonFunctions.closeTagsDistinctElements(loop.getGasrestriction().size(), this.parserCommonFunctions.controlMoreElements(this.nameRestrictionGas, loop));
    _builder.append(_closeTagsDistinctElements_5, "  \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea los bloques de los condicionales que aparecen dentro de los bucles
   * y llama para construir los bloques de las expressiones contenidas en las condicionales IF y ELSE
   */
  public CharSequence createBlockLoopCondition(final Condition condition) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"block_ifcondition\">");
    _builder.newLine();
    _builder.append("\t    ");
    _builder.append("<value name=\"condition\">");
    _builder.newLine();
    _builder.append("\t      ");
    CharSequence _identifyExpressionRecursive = this.parserExpression.identifyExpressionRecursive(condition.getCondition());
    _builder.append(_identifyExpressionRecursive, "\t      ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("\t    ");
    _builder.append("<statement name=\"actionsif\"> ");
    _builder.newLine();
    {
      EList<ForLoop> _determinedloops = condition.getDeterminedloops();
      for(final ForLoop determinedLoop : _determinedloops) {
        Object _createBlockDeterminedLoop = this.createBlockDeterminedLoop(determinedLoop);
        _builder.append(_createBlockDeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!determinedLoop.equals(condition.getDeterminedloops().get((condition.getDeterminedloops().size() - 1)))) || (determinedLoop.equals(condition.getDeterminedloops().get((condition.getDeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<UnDeterminedLoop> _undeterminedloops = condition.getUndeterminedloops();
      for(final UnDeterminedLoop undeterminedLoop : _undeterminedloops) {
        Object _createBlockUndeterminedLoop = this.createBlockUndeterminedLoop(undeterminedLoop);
        _builder.append(_createBlockUndeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!undeterminedLoop.equals(condition.getUndeterminedloops().get((condition.getUndeterminedloops().size() - 1)))) || (undeterminedLoop.equals(condition.getUndeterminedloops().get((condition.getUndeterminedloops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Condition> _conditionalExpr = condition.getConditionalExpr();
      for(final Condition conditionLoop : _conditionalExpr) {
        Object _createBlockLoopCondition = this.createBlockLoopCondition(conditionLoop);
        _builder.append(_createBlockLoopCondition);
        _builder.newLineIfNotEmpty();
        {
          if (((!conditionLoop.equals(condition.getConditionalExpr().get((condition.getConditionalExpr().size() - 1)))) || (conditionLoop.equals(condition.getConditionalExpr().get((condition.getConditionalExpr().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameConditionLoop, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t    ");
    CharSequence _identifyExpressions = this.parserExpression.identifyExpressions(condition.getExpressions());
    _builder.append(_identifyExpressions, "\t    ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(condition.getConditionalExpr().size(), this.parserCommonFunctions.controlMoreElements(this.nameConditionLoop, condition));
    _builder.append(_closeTagsDistinctElements, "\t    ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getUndeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, condition));
    _builder.append(_closeTagsDistinctElements_1, "\t    ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getDeterminedloops().size(), this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, condition));
    _builder.append(_closeTagsDistinctElements_2, "\t    ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t    ");
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea los bloques de los condicionales que aparecen dentro de los bucles
   * y llama para construir los bloques de las expressiones contenidas en las condicionales IF y ELSE
   */
  public CharSequence createBlockLoopElseCondition(final Condition condition) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("\t    ");
    _builder.append("<block type=\"block_elsecondition\">");
    _builder.newLine();
    _builder.append("\t    ");
    _builder.append("<statement name=\"actionselse\">");
    _builder.newLine();
    {
      EList<ForLoop> _determinedloopsElse = condition.getDeterminedloopsElse();
      for(final ForLoop determinedLoop : _determinedloopsElse) {
        CharSequence _createBlockDeterminedLoop = this.createBlockDeterminedLoop(determinedLoop);
        _builder.append(_createBlockDeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!determinedLoop.equals(condition.getDeterminedloopsElse().get((condition.getDeterminedloopsElse().size() - 1)))) || (determinedLoop.equals(condition.getDeterminedloopsElse().get((condition.getDeterminedloopsElse().size() - 1))) && this.parserCommonFunctions.controlElseElements(this.nameDeterminedLoopElse, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<UnDeterminedLoop> _undeterminedloopsElse = condition.getUndeterminedloopsElse();
      for(final UnDeterminedLoop undeterminedLoop : _undeterminedloopsElse) {
        Object _createBlockUndeterminedLoop = this.createBlockUndeterminedLoop(undeterminedLoop);
        _builder.append(_createBlockUndeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!undeterminedLoop.equals(condition.getUndeterminedloopsElse().get((condition.getUndeterminedloopsElse().size() - 1)))) || (undeterminedLoop.equals(condition.getUndeterminedloopsElse().get((condition.getUndeterminedloopsElse().size() - 1))) && this.parserCommonFunctions.controlElseElements(this.nameUndeterminedLoopElse, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Condition> _conditionalExprElse = condition.getConditionalExprElse();
      for(final Condition conditionLoop : _conditionalExprElse) {
        CharSequence _createBlockLoopCondition = this.createBlockLoopCondition(conditionLoop);
        _builder.append(_createBlockLoopCondition);
        _builder.newLineIfNotEmpty();
        {
          if (((!conditionLoop.equals(condition.getConditionalExprElse().get((condition.getConditionalExprElse().size() - 1)))) || (conditionLoop.equals(condition.getConditionalExprElse().get((condition.getConditionalExprElse().size() - 1))) && this.parserCommonFunctions.controlElseElements(this.nameConditionLoopElse, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Event> _eventElse = condition.getEventElse();
      for(final Event emitEventExpression : _eventElse) {
        CharSequence _defineExpressionEmitEvent = this.parserEvent.defineExpressionEmitEvent(emitEventExpression, condition);
        _builder.append(_defineExpressionEmitEvent);
        _builder.newLineIfNotEmpty();
        {
          if (((!emitEventExpression.equals(condition.getEventElse().get((condition.getEventElse().size() - 1)))) || (emitEventExpression.equals(condition.getEventElse().get((condition.getEventElse().size() - 1))) && this.parserCommonFunctions.controlElseElements(this.nameEmitEventElse, condition)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    CharSequence _identifyExpressions = this.parserExpression.identifyExpressions(condition.getExpressionsElse());
    _builder.append(_identifyExpressions);
    _builder.newLineIfNotEmpty();
    _builder.append(" \t    ");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(condition.getConditionalExprElse().size(), this.parserCommonFunctions.controlMoreElements(this.nameConditionLoopElse, condition));
    _builder.append(_closeTagsDistinctElements, " \t    ");
    _builder.newLineIfNotEmpty();
    _builder.append(" \t    ");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getUndeterminedloopsElse().size(), this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoopElse, condition));
    _builder.append(_closeTagsDistinctElements_1, " \t    ");
    _builder.newLineIfNotEmpty();
    _builder.append(" \t    ");
    CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(condition.getDeterminedloopsElse().size(), this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoopElse, condition));
    _builder.append(_closeTagsDistinctElements_2, " \t    ");
    _builder.newLineIfNotEmpty();
    _builder.append("        ");
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
}
