package org.xtext.generator.blocklyparser;

import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.ParamBlocklyParser;
import org.xtext.smaC.Clause;
import org.xtext.smaC.Condition;
import org.xtext.smaC.Event;

@SuppressWarnings("all")
public class EventBlocklyParser {
  private ParamBlocklyParser parserParam = new ParamBlocklyParser();
  
  /**
   * Argumentos:El evento a parsear
   * Descripci�n: Construcci�n de los bloques para los eventos y llama al parseador de par�metros de entrada si los tuviera
   * Salida: Ninguna
   */
  public CharSequence defineBlockEvent(final Event event) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"event\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _name = event.getName();
    _builder.append(_name);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    {
      int _size = event.getInputParams().size();
      boolean _notEquals = (_size != 0);
      if (_notEquals) {
        _builder.append("<value name=\"inputparams\">");
        _builder.newLine();
        _builder.append(" ");
        CharSequence _defineInputParams = this.parserParam.defineInputParams(event.getInputParams());
        _builder.append(_defineInputParams, " ");
        _builder.newLineIfNotEmpty();
        _builder.append("</value>");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos:El evento a parsear y la funci�n donde se encuentra
   * Descripci�n:Define la expresion para emitir Eventos que se pueden encontrar dentro del cuerpo de las FUNCIONES
   * Salida: Ninguna
   */
  public CharSequence defineExpressionEmitEvent(final Event event, final Clause function) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method or field inputParamsEvent is undefined for the type Clause"
      + "\nThe method or field inputParamsEvent is undefined for the type Clause"
      + "\nsize cannot be resolved"
      + "\n!= cannot be resolved");
  }
  
  /**
   * Argumentos:El evento a parsear y la condici�n(IF) donde se encuentra
   * Descripci�n:Define la expresion para emitir Eventos que se pueden encontrar dentro del cuerpo de los IF
   * Salida: Ninguna
   */
  public CharSequence defineExpressionEmitEvent(final Event event, final Condition condition) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"emit_event\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _name = event.getName();
    _builder.append(_name);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    {
      int _size = condition.getInputParamsEvent().size();
      boolean _notEquals = (_size != 0);
      if (_notEquals) {
        _builder.append("<value name=\"inputparams\">");
        _builder.newLine();
        CharSequence _defineInputParams = this.parserParam.defineInputParams(condition.getInputParamsEvent());
        _builder.append(_defineInputParams);
        _builder.newLineIfNotEmpty();
        _builder.append("</value>");
        _builder.newLine();
      }
    }
    return _builder;
  }
}
