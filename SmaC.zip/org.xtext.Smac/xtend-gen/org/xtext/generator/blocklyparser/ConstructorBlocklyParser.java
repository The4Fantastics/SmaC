package org.xtext.generator.blocklyparser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.ConditionBlocklyParser;
import org.xtext.generator.blocklyparser.ExpressionBlocklyParser;
import org.xtext.generator.blocklyparser.LoopBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.RestrictionClauseBlocklyParser;
import org.xtext.smaC.Condition;
import org.xtext.smaC.Constructor;
import org.xtext.smaC.ForLoop;
import org.xtext.smaC.RestrictionClause;
import org.xtext.smaC.UnDeterminedLoop;

@SuppressWarnings("all")
public class ConstructorBlocklyParser {
  private ExpressionBlocklyParser parserExpression = new ExpressionBlocklyParser();
  
  private RestrictionClauseBlocklyParser parserRestriction = new RestrictionClauseBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private ConditionBlocklyParser parserCondition = new ConditionBlocklyParser();
  
  private LoopBlocklyParser parserLoop = new LoopBlocklyParser();
  
  private final String nameUndeterminedLoop = "undeterminedLoop";
  
  private final String nameDeterminedLoop = "determinedLoop";
  
  private final String nameCondition = "condition";
  
  private String nameFieldPayable = "payable";
  
  private String nameFieldAttributesInitialization = "attributesInitialization";
  
  private final String nameRestriction = "restriction";
  
  public CharSequence defineHeadBlockConstructor(final Constructor constructor) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"contract_constructor\">");
    _builder.newLine();
    _builder.append("<field name=\"visibility_values\">");
    String _type = constructor.getType();
    _builder.append(_type);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    String[] campoPayable = constructor.toString().substring(constructor.toString().indexOf((this.nameFieldPayable + ":")), constructor.toString().indexOf(this.nameFieldAttributesInitialization)).split(",");
    _builder.newLineIfNotEmpty();
    String payable = (campoPayable[0]).toString().replace((this.nameFieldPayable + ":"), "").trim();
    _builder.newLineIfNotEmpty();
    {
      if ((payable.equals(null) || payable.equals("null"))) {
        _builder.append("<field name=\"payable\">FALSE</field>");
        _builder.newLine();
      } else {
        _builder.append("<field name=\"payable\">TRUE</field>");
        _builder.newLine();
      }
    }
    CharSequence _defineBodyBlockConstructor = this.defineBodyBlockConstructor(constructor);
    _builder.append(_defineBodyBlockConstructor);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence defineBodyBlockConstructor(final Constructor constructor) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<statement name=\"expressions_constructor\">");
    _builder.newLine();
    {
      EList<RestrictionClause> _restrictions = constructor.getRestrictions();
      for(final RestrictionClause restriction : _restrictions) {
        CharSequence _identifyRestriction = this.parserRestriction.identifyRestriction(restriction);
        _builder.append(_identifyRestriction);
        _builder.newLineIfNotEmpty();
        {
          if (((!restriction.equals(constructor.getRestrictions().get((constructor.getRestrictions().size() - 1)))) || (restriction.equals(constructor.getRestrictions().get((constructor.getRestrictions().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameRestriction, constructor)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Condition> _conditions = constructor.getConditions();
      for(final Condition condition : _conditions) {
        Object _createBlockCondition = this.parserCondition.createBlockCondition(condition);
        _builder.append(_createBlockCondition);
        _builder.append("\t\t\t\t");
        _builder.append("\t\t\t\t");
        {
          boolean _controlElseConditionElements = this.parserCommonFunctions.controlElseConditionElements(condition);
          if (_controlElseConditionElements) {
            _builder.newLineIfNotEmpty();
            _builder.append("<next>");
            _builder.append("\t\t\t\t");
            CharSequence _createBlockElseCondition = this.parserCondition.createBlockElseCondition(condition);
            _builder.append(_createBlockElseCondition);
            _builder.append("\t\t\t\t");
          }
        }
        _builder.newLineIfNotEmpty();
        {
          if (((!condition.equals(constructor.getConditions().get((constructor.getConditions().size() - 1)))) || (condition.equals(constructor.getConditions().get((constructor.getConditions().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameCondition, constructor)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<ForLoop> _determinedLoops = constructor.getDeterminedLoops();
      for(final ForLoop determinedLoop : _determinedLoops) {
        CharSequence _createBlockDeterminedLoop = this.parserLoop.createBlockDeterminedLoop(determinedLoop);
        _builder.append(_createBlockDeterminedLoop);
        _builder.newLineIfNotEmpty();
        {
          if (((!determinedLoop.equals(constructor.getDeterminedLoops().get((constructor.getDeterminedLoops().size() - 1)))) || (determinedLoop.equals(constructor.getDeterminedLoops().get((constructor.getDeterminedLoops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, constructor)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<UnDeterminedLoop> _undeterminedLoops = constructor.getUndeterminedLoops();
      for(final UnDeterminedLoop undeterminedLoop : _undeterminedLoops) {
        _builder.append("\t  \t");
        Object _createBlockUndeterminedLoop = this.parserLoop.createBlockUndeterminedLoop(undeterminedLoop);
        _builder.append(_createBlockUndeterminedLoop, "\t  \t");
        _builder.newLineIfNotEmpty();
        {
          if (((!undeterminedLoop.equals(constructor.getUndeterminedLoops().get((constructor.getUndeterminedLoops().size() - 1)))) || (undeterminedLoop.equals(constructor.getUndeterminedLoops().get((constructor.getUndeterminedLoops().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, constructor)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    CharSequence _identifyExpressions = this.parserExpression.identifyExpressions(constructor.getAttributesInitialization());
    _builder.append(_identifyExpressions);
    _builder.append("\t\t");
    _builder.newLineIfNotEmpty();
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(constructor.getDeterminedLoops().size(), this.parserCommonFunctions.controlMoreElements(this.nameDeterminedLoop, constructor));
    _builder.append(_closeTagsDistinctElements);
    _builder.append("\t\t");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(constructor.getUndeterminedLoops().size(), this.parserCommonFunctions.controlMoreElements(this.nameUndeterminedLoop, constructor));
    _builder.append(_closeTagsDistinctElements_1);
    _builder.append("\t\t");
    {
      boolean _controlElseInConditionsElements = this.parserCommonFunctions.controlElseInConditionsElements(constructor.getConditions());
      boolean _equals = (_controlElseInConditionsElements == false);
      if (_equals) {
        _builder.newLineIfNotEmpty();
        CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(constructor.getConditions().size(), this.parserCommonFunctions.controlMoreElements(this.nameCondition, constructor));
        _builder.append(_closeTagsDistinctElements_2);
        _builder.append("\t\t");
      } else {
        _builder.newLineIfNotEmpty();
      }
    }
    CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(constructor.getRestrictions().size(), this.parserCommonFunctions.controlMoreElements(this.nameRestriction, constructor));
    _builder.append(_closeTagsDistinctElements_3);
    _builder.newLineIfNotEmpty();
    _builder.append("</statement>");
    _builder.newLine();
    return _builder;
  }
}
