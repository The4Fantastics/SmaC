package org.xtext.generator.blocklyparser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.ConstructorBlocklyParser;
import org.xtext.generator.blocklyparser.EventBlocklyParser;
import org.xtext.generator.blocklyparser.FunctionBlocklyParser;
import org.xtext.generator.blocklyparser.ModifierBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.generator.blocklyparser.PropertyBlocklyParser;
import org.xtext.smaC.AbstractContract;
import org.xtext.smaC.DeclarationFunctionAbstractContract;
import org.xtext.smaC.Element;
import org.xtext.smaC.Event;

@SuppressWarnings("all")
public class AbstractContractBlocklyParser {
  private ConstructorBlocklyParser parserConstructor = new ConstructorBlocklyParser();
  
  private EventBlocklyParser parserEvent = new EventBlocklyParser();
  
  private ModifierBlocklyParser parserModifier = new ModifierBlocklyParser();
  
  private FunctionBlocklyParser parserFunction = new FunctionBlocklyParser();
  
  private PropertyBlocklyParser parserProperty = new PropertyBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private final String nameLocalProperty = "localProperty";
  
  private final String nameLocalMapping = "localMappingProperty";
  
  private final String nameStruct = "struct";
  
  private final String nameUserStruct = "user_struct";
  
  private final String nameCompanyStruct = "company_struct";
  
  private final String nameConstructor = "constructor";
  
  private final String nameModifier = "modifier";
  
  private final String nameEvent = "event";
  
  private final String nameLibrary = "importLibrary";
  
  private final String nameEnumerator = "enumerator";
  
  private final String nameabstractContract = "abstract";
  
  public CharSequence defineBlockAbstractContract(final AbstractContract abstractcontract) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"abstract_contract\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _name = abstractcontract.getName();
    _builder.append(_name);
    _builder.append("</field>\t");
    _builder.newLineIfNotEmpty();
    {
      int _size = abstractcontract.getSuperType().size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        {
          int _size_1 = abstractcontract.getSuperType().size();
          boolean _equals = (_size_1 == 1);
          if (_equals) {
            _builder.append("\t\t    ");
            _builder.append("<value name=\"namecontractfather\">");
            _builder.newLine();
            _builder.append("<block type=\"contract_father\">");
            _builder.newLine();
            _builder.append("  ");
            _builder.append("<field name=\"name\">");
            String _name_1 = abstractcontract.getSuperType().get(0).getName();
            _builder.append(_name_1, "  ");
            _builder.append("</field>");
            _builder.newLineIfNotEmpty();
            _builder.append("</block>");
            _builder.newLine();
            _builder.append("\t\t\t");
            _builder.append("</value>");
            _builder.newLine();
          } else {
            _builder.append("\t\t    ");
            _builder.append("<value name=\"namecontractfather\">");
            _builder.newLine();
            {
              EList<Element> _superType = abstractcontract.getSuperType();
              for(final Element contractInherance : _superType) {
                _builder.append("<block type=\"contract_father\">");
                _builder.newLine();
                _builder.append("  ");
                _builder.append("<field name=\"name\">");
                String _name_2 = contractInherance.getName();
                _builder.append(_name_2, "  ");
                _builder.append("</field>");
                _builder.newLineIfNotEmpty();
                {
                  EList<Element> _superType_1 = abstractcontract.getSuperType();
                  int _size_2 = abstractcontract.getSuperType().size();
                  int _minus = (_size_2 - 1);
                  boolean _equals_1 = contractInherance.getName().equals(_superType_1.get(_minus).getName());
                  boolean _not = (!_equals_1);
                  if (_not) {
                    _builder.append("  ");
                    _builder.append("<value name=\"contracts_inherit\">");
                    _builder.newLine();
                  }
                }
              }
            }
            {
              EList<Element> _superType_2 = abstractcontract.getSuperType();
              for(final Element contractInherance_1 : _superType_2) {
                _builder.append("\t");
                _builder.append("</block>");
                _builder.newLine();
                _builder.append("</value>");
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    _builder.append("<statement name=\"contract_elements\">  ");
    _builder.newLine();
    _builder.append(" \t");
    {
      EList<Event> _events = abstractcontract.getEvents();
      for(final Event event : _events) {
        _builder.append("\t\t");
        CharSequence _defineBlockEvent = this.parserEvent.defineBlockEvent(event);
        _builder.append(_defineBlockEvent, " \t");
        _builder.newLineIfNotEmpty();
        {
          if (((!event.equals(abstractcontract.getEvents().get((abstractcontract.getEvents().size() - 1)))) || (event.equals(abstractcontract.getEvents().get((abstractcontract.getEvents().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameEvent, abstractcontract)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<DeclarationFunctionAbstractContract> _clauses = abstractcontract.getClauses();
      for(final DeclarationFunctionAbstractContract function : _clauses) {
        _builder.append("       ");
        CharSequence _defineAbstractContractFunction = this.parserFunction.defineAbstractContractFunction(function);
        _builder.append(_defineAbstractContractFunction, "       ");
        _builder.newLineIfNotEmpty();
        {
          EList<DeclarationFunctionAbstractContract> _clauses_1 = abstractcontract.getClauses();
          int _size_3 = abstractcontract.getClauses().size();
          int _minus_1 = (_size_3 - 1);
          boolean _equals_2 = function.equals(_clauses_1.get(_minus_1));
          boolean _not_1 = (!_equals_2);
          if (_not_1) {
            _builder.append(" \t   \t<next>");
            _builder.newLineIfNotEmpty();
          } else {
            _builder.append("</block>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("\t");
    CharSequence _closeTags = this.parserCommonFunctions.closeTags(abstractcontract.getClauses().size());
    _builder.append(_closeTags, "\t");
    _builder.newLineIfNotEmpty();
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(abstractcontract.getEvents().size(), this.parserCommonFunctions.controlMoreElements(this.nameEvent, abstractcontract));
    _builder.append(_closeTagsDistinctElements);
    _builder.newLineIfNotEmpty();
    _builder.append("    ");
    _builder.append("</statement> ");
    _builder.newLine();
    return _builder;
  }
}
