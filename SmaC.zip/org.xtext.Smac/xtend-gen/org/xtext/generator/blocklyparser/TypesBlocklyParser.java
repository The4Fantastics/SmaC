package org.xtext.generator.blocklyparser;

import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class TypesBlocklyParser {
  private final String typeBool = "bool";
  
  private final String typeUint = "uint";
  
  private final String typeInt = "int";
  
  private final String typeFloat = "float";
  
  private final String typeAddress = "address";
  
  private final String typeAddressPayable = "address payable";
  
  private final String typeBytes = "bytes";
  
  private final String typeChar = "char";
  
  private final String typeString = "string";
  
  public CharSequence controlGenerateTypeBlock(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    CharSequence _switchResult = null;
    boolean _matched = false;
    if ((type.toString().contains(this.typeUint) && type.toString().startsWith(this.typeUint))) {
      _matched=true;
      StringConcatenation _builder_1 = new StringConcatenation();
      CharSequence _defineBlockTypeUInt = this.defineBlockTypeUInt(type);
      _builder_1.append(_defineBlockTypeUInt);
      _switchResult = _builder_1;
    }
    if (!_matched) {
      if ((type.toString().contains(this.typeInt) && type.toString().startsWith(this.typeInt))) {
        _matched=true;
        StringConcatenation _builder_2 = new StringConcatenation();
        CharSequence _defineBlockTypeInt = this.defineBlockTypeInt(type);
        _builder_2.append(_defineBlockTypeInt);
        _switchResult = _builder_2;
      }
    }
    if (!_matched) {
      if ((type.toString().equals(this.typeBool) && type.toString().startsWith(this.typeBool))) {
        _matched=true;
        StringConcatenation _builder_3 = new StringConcatenation();
        CharSequence _defineBlockTypeBoolean = this.defineBlockTypeBoolean();
        _builder_3.append(_defineBlockTypeBoolean);
        _switchResult = _builder_3;
      }
    }
    if (!_matched) {
      if ((type.toString().equals(this.typeFloat) && type.toString().startsWith(this.typeFloat))) {
        _matched=true;
        StringConcatenation _builder_4 = new StringConcatenation();
        CharSequence _defineBlockTypeFloat = this.defineBlockTypeFloat();
        _builder_4.append(_defineBlockTypeFloat);
        _switchResult = _builder_4;
      }
    }
    if (!_matched) {
      if ((type.toString().contains(this.typeBytes) && type.toString().startsWith(this.typeBytes))) {
        _matched=true;
        StringConcatenation _builder_5 = new StringConcatenation();
        CharSequence _defineBlockTypeByte = this.defineBlockTypeByte(type);
        _builder_5.append(_defineBlockTypeByte);
        _switchResult = _builder_5;
      }
    }
    if (!_matched) {
      if ((type.toString().contains(this.typeAddressPayable) && type.toString().startsWith(this.typeAddressPayable))) {
        _matched=true;
        StringConcatenation _builder_6 = new StringConcatenation();
        CharSequence _defineBlockTypeAddress = this.defineBlockTypeAddress(type);
        _builder_6.append(_defineBlockTypeAddress);
        _switchResult = _builder_6;
      }
    }
    if (!_matched) {
      if ((type.toString().contains(this.typeAddress) && type.toString().startsWith(this.typeAddress))) {
        _matched=true;
        StringConcatenation _builder_7 = new StringConcatenation();
        CharSequence _defineBlockTypeAddress_1 = this.defineBlockTypeAddress(type);
        _builder_7.append(_defineBlockTypeAddress_1);
        _switchResult = _builder_7;
      }
    }
    if (!_matched) {
      if ((type.toString().equals(this.typeChar) && type.toString().startsWith(this.typeChar))) {
        _matched=true;
        StringConcatenation _builder_8 = new StringConcatenation();
        CharSequence _defineBlockTypeText = this.defineBlockTypeText(type);
        _builder_8.append(_defineBlockTypeText);
        _switchResult = _builder_8;
      }
    }
    if (!_matched) {
      if ((type.toString().equals(this.typeString) && type.toString().startsWith(this.typeString))) {
        _matched=true;
        StringConcatenation _builder_9 = new StringConcatenation();
        CharSequence _defineBlockTypeText_1 = this.defineBlockTypeText(type);
        _builder_9.append(_defineBlockTypeText_1);
        _switchResult = _builder_9;
      }
    }
    if (!_matched) {
      StringConcatenation _builder_10 = new StringConcatenation();
      CharSequence _defineBlockTypePersonalized = this.defineBlockTypePersonalized(type);
      _builder_10.append(_defineBlockTypePersonalized);
      _switchResult = _builder_10;
    }
    _builder.append(_switchResult);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  private CharSequence defineBlockTypeUInt(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("\t\t  ");
    _builder.append("<block type=\"type_uint\">");
    _builder.newLine();
    _builder.append("<field name=\"uint_options\">");
    _builder.append(type);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t  ");
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence defineBlockTypeInt(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("\t\t  ");
    _builder.append("<block type=\"type_int\">");
    _builder.newLine();
    _builder.append("<field name=\"int_options\">");
    _builder.append(type);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t   ");
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence defineBlockTypeFloat() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"type_float\">");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<field name=\"float_options\">float</field>");
    _builder.newLine();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence defineBlockTypeBoolean() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"type_bool\">");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<field name=\"bool_options\">bool</field>");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence defineBlockTypeByte(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"type_byte\" >");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<field name=\"bytes_options\">");
    _builder.append(type, "   ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append(" ");
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence defineBlockTypeAddress(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"type_address\" >");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<field name=\"address_options\">");
    _builder.append(type, "   ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append(" ");
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence defineBlockTypeText(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"type_text\" >");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<field name=\"typetext_options\">");
    _builder.append(type, "   ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence defineBlockTypePersonalized(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"type_identifier\">");
    _builder.newLine();
    _builder.append("   ");
    _builder.append("<field name=\"identifier_options\">");
    _builder.append(type, "   ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    return _builder;
  }
}
