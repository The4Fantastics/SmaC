package org.xtext.generator.blocklyparser;

import com.google.common.base.Objects;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.generator.blocklyparser.ExpressionBlocklyParser;
import org.xtext.smaC.Coin;
import org.xtext.smaC.RestrictionClause;
import org.xtext.smaC.RestrictionGas;

@SuppressWarnings("all")
public class RestrictionClauseBlocklyParser {
  private final String nameFieldMessage = "message";
  
  private final String nameFieldOperator = "operator";
  
  private final String nameFieldExpr1 = "expr1";
  
  private final String nameFieldExpr2 = "expr2";
  
  private String message = "";
  
  private String operator = "";
  
  private String expr1 = "";
  
  private String expr2 = "";
  
  private final String operatorEqual = "==";
  
  private final String operatorNotEqual = "!=";
  
  private final String operatorGreater = ">";
  
  private final String operatorGreaterEqual = ">=";
  
  private final String operatorLessEqual = "<=";
  
  private final String operatorLess = "<";
  
  private ExpressionBlocklyParser parserExpression = new ExpressionBlocklyParser();
  
  /**
   * Observa los campos para crear un bloque de restricci�n con o sin mensaje seg�n los valores de los campos
   */
  public CharSequence identifyRestriction(final RestrictionClause restriction) {
    StringConcatenation _builder = new StringConcatenation();
    String[] arrayCamposOcultos = restriction.toString().substring(restriction.toString().indexOf((this.nameFieldExpr1 + ":")), restriction.toString().lastIndexOf(")")).split(",");
    _builder.newLineIfNotEmpty();
    CharSequence _calculateFieldsHidden = this.calculateFieldsHidden(arrayCamposOcultos);
    _builder.append(_calculateFieldsHidden);
    _builder.newLineIfNotEmpty();
    CharSequence _createBlockRestriction = this.createBlockRestriction(restriction);
    _builder.append(_createBlockRestriction);
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Obtiene los campos expr1,expr2,operator y message de las restricciones
   */
  private CharSequence calculateFieldsHidden(final String[] arrayCamposOcultos) {
    StringConcatenation _builder = new StringConcatenation();
    for (int i = 0; (i < arrayCamposOcultos.length); i++) {
      {
        String campo = arrayCamposOcultos[i];
        if (((!campo.contains((this.nameFieldOperator + ":"))) && (!campo.contains(this.nameFieldExpr2)))) {
          String[] claveValor = campo.toString().split(":");
          boolean _equals = (claveValor[0]).toString().trim().equals(this.nameFieldMessage);
          if (_equals) {
            this.message = (claveValor[1]).toString().trim();
          }
          boolean _equals_1 = (claveValor[0]).toString().trim().equals(this.nameFieldExpr1);
          if (_equals_1) {
            this.expr1 = (claveValor[1]).toString().trim();
          }
        } else {
          String _string = campo.toString();
          int _indexOf = campo.toString().indexOf(":");
          int _plus = (_indexOf + 1);
          this.operator = _string.substring(_plus, campo.toString().indexOf(")")).trim();
          String _string_1 = campo.toString();
          int _lastIndexOf = campo.toString().lastIndexOf(":");
          int _plus_1 = (_lastIndexOf + 1);
          this.expr2 = _string_1.substring(_plus_1).trim();
        }
      }
    }
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Crea los bloques de las restricciones y llama para construir los bloques de las expressiones contenidas en las restricciones
   */
  private CharSequence createBlockRestriction(final RestrictionClause restriction) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if ((this.operator.equals(">") && (this.expr2.equals(null) || (this.expr2.equals("null") && (((this.message == null) || Objects.equal(this.message, "")) || this.message.equals("null")))))) {
        _builder.append(" ");
        _builder.append("\t<block type=\"restriction_clause\">");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("<value name=\"condition\">");
        _builder.newLine();
        _builder.append("      ");
        CharSequence _identifyExpressionRecursive = this.parserExpression.identifyExpressionRecursive(this.expr1.trim());
        _builder.append(_identifyExpressionRecursive, "      ");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("</value>");
        _builder.newLine();
      } else {
        if (((this.operator.equals(">") && (this.expr2.equals(null) || this.expr2.equals("null"))) && (((this.message != null) && (!this.message.equals("null"))) && (!Objects.equal(this.message, ""))))) {
          _builder.append(" ");
          _builder.append("    <block type=\"restriction_clausecomment\">");
          _builder.newLineIfNotEmpty();
          _builder.append("    ");
          _builder.append("<value name=\"condition\">");
          _builder.newLine();
          _builder.append("      ");
          CharSequence _identifyExpressionRecursive_1 = this.parserExpression.identifyExpressionRecursive(this.expr1.trim());
          _builder.append(_identifyExpressionRecursive_1, "      ");
          _builder.newLineIfNotEmpty();
          _builder.append("    ");
          _builder.append("</value>");
          _builder.newLine();
          _builder.append("    ");
          _builder.append("<field name=\"comment\">");
          _builder.append(this.message, "    ");
          _builder.append("</field>");
          _builder.newLineIfNotEmpty();
        } else {
          {
            if ((((this.message != null) && (!this.message.equals("null"))) && (!Objects.equal(this.message, "")))) {
              _builder.append("<block type=\"restriction_clausecomment\">");
              _builder.newLine();
              _builder.append("<field name=\"comment\">");
              _builder.append(this.message);
              _builder.append("</field>\t");
              _builder.newLineIfNotEmpty();
            } else {
              _builder.append("<block type=\"restriction_clause\">");
              _builder.newLine();
            }
          }
          _builder.append("<value name=\"condition\">");
          _builder.newLine();
          {
            if ((this.operator.equals("==") || this.operator.equals("!="))) {
              _builder.append("\t\t    ");
              CharSequence _generateLogicalComparationExpressionBlock = this.parserExpression.generateLogicalComparationExpressionBlock(this.expr1.trim(), this.expr2.trim(), this.operator);
              _builder.append(_generateLogicalComparationExpressionBlock);
              _builder.newLineIfNotEmpty();
            } else {
              _builder.append("\t\t    ");
              CharSequence _generateArithmeticalLogicalComparationExpressionBlock = this.parserExpression.generateArithmeticalLogicalComparationExpressionBlock(this.expr1.trim(), this.expr2.trim(), this.operator);
              _builder.append(_generateArithmeticalLogicalComparationExpressionBlock);
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("</value>\t \t\t");
          _builder.newLine();
        }
      }
    }
    return _builder;
  }
  
  /**
   * Crea el bloque de restricci�n de gas que aparece en los bucles para evitar que se produzcan ciclos infinitos
   */
  public CharSequence createGasRestriction(final RestrictionGas restrictiongas) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append(this.message = restrictiongas.getMessage());
    _builder.newLineIfNotEmpty();
    {
      if ((((this.message != "null") && (this.message != null)) && (this.message != ""))) {
        _builder.append("<block type=\"restriction_clausecomment\">");
        _builder.newLine();
        _builder.append("<field name=\"comment\">");
        _builder.append(this.message);
        _builder.append("</field>\t ");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("<block type=\"restriction_clause\">");
        _builder.newLine();
      }
    }
    _builder.append("      ");
    CharSequence _switchResult = null;
    boolean _matched = false;
    boolean _equals = restrictiongas.getOperator().toString().equals(this.operatorEqual);
    if (_equals) {
      _matched=true;
      StringConcatenation _builder_1 = new StringConcatenation();
      CharSequence _generateComparationExpression = this.generateComparationExpression(restrictiongas, this.operatorEqual);
      _builder_1.append(_generateComparationExpression);
      _switchResult = _builder_1;
    }
    if (!_matched) {
      boolean _equals_1 = restrictiongas.getOperator().toString().equals(this.operatorNotEqual);
      if (_equals_1) {
        _matched=true;
        StringConcatenation _builder_2 = new StringConcatenation();
        CharSequence _generateComparationExpression_1 = this.generateComparationExpression(restrictiongas, this.operatorNotEqual);
        _builder_2.append(_generateComparationExpression_1);
        _switchResult = _builder_2;
      }
    }
    if (!_matched) {
      boolean _equals_2 = restrictiongas.getOperator().toString().equals(this.operatorGreater);
      if (_equals_2) {
        _matched=true;
        StringConcatenation _builder_3 = new StringConcatenation();
        CharSequence _generateComparationArithmeticalExpression = this.generateComparationArithmeticalExpression(restrictiongas, "&gt;");
        _builder_3.append(_generateComparationArithmeticalExpression);
        _switchResult = _builder_3;
      }
    }
    if (!_matched) {
      boolean _equals_3 = restrictiongas.getOperator().toString().equals(this.operatorGreaterEqual);
      if (_equals_3) {
        _matched=true;
        StringConcatenation _builder_4 = new StringConcatenation();
        CharSequence _generateComparationArithmeticalExpression_1 = this.generateComparationArithmeticalExpression(restrictiongas, "&gt;=");
        _builder_4.append(_generateComparationArithmeticalExpression_1);
        _switchResult = _builder_4;
      }
    }
    if (!_matched) {
      boolean _equals_4 = restrictiongas.getOperator().toString().equals(this.operatorLess);
      if (_equals_4) {
        _matched=true;
        StringConcatenation _builder_5 = new StringConcatenation();
        CharSequence _generateComparationArithmeticalExpression_2 = this.generateComparationArithmeticalExpression(restrictiongas, "&lt;");
        _builder_5.append(_generateComparationArithmeticalExpression_2);
        _switchResult = _builder_5;
      }
    }
    if (!_matched) {
      boolean _equals_5 = restrictiongas.getOperator().toString().equals(this.operatorLessEqual);
      if (_equals_5) {
        _matched=true;
        StringConcatenation _builder_6 = new StringConcatenation();
        CharSequence _generateComparationArithmeticalExpression_3 = this.generateComparationArithmeticalExpression(restrictiongas, "&lt;=");
        _builder_6.append(_generateComparationArithmeticalExpression_3);
        _switchResult = _builder_6;
      }
    }
    if (!_matched) {
      StringConcatenation _builder_7 = new StringConcatenation();
      _switchResult = _builder_7;
    }
    _builder.append(_switchResult, "      ");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  /**
   * Crea el bloque para la comparaci�n l�gica  para la restricci�n de gas
   */
  private CharSequence generateComparationExpression(final RestrictionGas restriction, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<value name=\"condition\">");
    _builder.newLine();
    _builder.append("\t \t");
    _builder.append("<block type=\"comparation_expression\">");
    _builder.newLine();
    _builder.append("\t \t");
    _builder.append("<value name=\"value1_expression\">");
    _builder.newLine();
    _builder.append("       \t\t");
    CharSequence _identifyExpressionRecursive = this.parserExpression.identifyExpressionRecursive(restriction.getExpr1());
    _builder.append(_identifyExpressionRecursive, "       \t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t \t");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("\t \t");
    _builder.append("<field name=\"operators\">");
    _builder.append(operator, "\t \t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t \t");
    _builder.append("<value name=\"value2_expression\">");
    _builder.newLine();
    _builder.append("\t \t\t");
    _builder.append("<block type=\"coin_expression\">");
    _builder.newLine();
    _builder.append("\t \t\t\t");
    _builder.append("<field name=\"amount_coin\">");
    String _amount = restriction.getAmount();
    _builder.append(_amount, "\t \t\t\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t \t\t\t");
    _builder.append("<field name=\"type_coin\">");
    Coin _typeCoin = restriction.getTypeCoin();
    _builder.append(_typeCoin, "\t \t\t\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t \t\t");
    _builder.append("</block>");
    _builder.newLine();
    _builder.append("\t \t");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("\t \t");
    _builder.append("</block>");
    _builder.newLine();
    _builder.append("\t ");
    _builder.append("</value>");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Crea el bloque para la comparaci�n aritm�tica para la restricci�n de gas
   */
  private CharSequence generateComparationArithmeticalExpression(final RestrictionGas restriction, final String operator) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<value name=\"condition\">\t");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<block type=\"comparation_arithmeticalexpression\">");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<value name=\"value1_arithmeticalcomparationexpression\">");
    _builder.newLine();
    _builder.append("\t\t");
    CharSequence _identifyExpressionRecursive = this.parserExpression.identifyExpressionRecursive(restriction.getExpr1());
    _builder.append(_identifyExpressionRecursive, "\t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<field name=\"operators\">");
    _builder.append(operator, "\t\t");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("<value name=\"value2_arithmeticalcomparationexpression\">");
    _builder.newLine();
    _builder.append("\t\t    ");
    _builder.append("<block type=\"coin_expression\">");
    _builder.newLine();
    _builder.append("\t\t      ");
    _builder.append("<field name=\"amount_coin\">");
    String _amount = restriction.getAmount();
    _builder.append(_amount, "\t\t      ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t      ");
    _builder.append("<field name=\"type_coin\">");
    Coin _typeCoin = restriction.getTypeCoin();
    _builder.append(_typeCoin, "\t\t      ");
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t    ");
    _builder.append("</block>");
    _builder.newLine();
    _builder.append("\t\t ");
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("</block>");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("</value>");
    _builder.newLine();
    return _builder;
  }
}
