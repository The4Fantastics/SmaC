package org.xtext.generator.blocklyparser;

import java.util.List;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.xtext.smaC.Clause;
import org.xtext.smaC.Company;
import org.xtext.smaC.Condition;
import org.xtext.smaC.Constructor;
import org.xtext.smaC.Contract;
import org.xtext.smaC.File;
import org.xtext.smaC.ForLoop;
import org.xtext.smaC.Library;
import org.xtext.smaC.Modifier;
import org.xtext.smaC.PersonalizedStruct;
import org.xtext.smaC.UnDeterminedLoop;
import org.xtext.smaC.User;

@SuppressWarnings("all")
public class ParserCommonFunctions {
  private final String nameLocalProperty = "localProperty";
  
  private final String nameLocalMapping = "localMappingProperty";
  
  private final String nameStruct = "struct";
  
  private final String nameUserStruct = "user_struct";
  
  private final String nameCompanyStruct = "company_struct";
  
  private final String nameEnumerator = "enumerator";
  
  private final String nameConstructor = "constructor";
  
  private final String nameModifier = "modifier";
  
  private final String nameEvent = "event";
  
  private final String nameRestriction = "restriction";
  
  private final String nameRestrictionGas = "restrictionGas";
  
  private final String nameConditionLoop = "conditionLoop";
  
  private final String nameCondition = "condition";
  
  private final String nameEmitEvent = "emitEvent";
  
  private final String nameUndeterminedLoop = "undeterminedLoop";
  
  private final String nameDeterminedLoop = "determinedLoop";
  
  private final String nameUndeterminedLoopElse = "undeterminedLoopElse";
  
  private final String nameDeterminedLoopElse = "determinedLoopElse";
  
  private final String nameConditionLoopElse = "conditionLoopElse";
  
  private final String nameConditionBeforeMark = "conditionBeforeMark";
  
  private final String nameConditionAfterMark = "conditionAfterMark";
  
  private final String namePredefinedFunctions = "predefinedFunction";
  
  private final String nameFileLibrary = "library";
  
  private final String nameInterface = "interface";
  
  private final String nameImport = "import";
  
  private final String nameLibrary = "importLibrary";
  
  private final String nameExpressionBeforeMark = "expressionBeforeMark";
  
  private final String nameExpressionAfterMark = "expressionAfterMark";
  
  private final String nameEmitEventElse = "emitEventElse";
  
  private final String nameAbstractContract = "abstract";
  
  /**
   * Argumentos:Nombre del �ltimo elemento del fichero que se est� parseando y el fichero actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del fichero, calcula si hay m�s elementos de otros tipos en el fichero para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del fichero a parsear, False si no hay m�s elementos del fichero a parsear
   */
  public boolean controlMoreElements(final String nameElement, final File file) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameInterface) && ((((file.getLibrary().size() > 0) || (file.getImports().size() > 0)) || (file.getAbstractContracts().size() > 0)) || (file.getContracts().size() > 0)))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameFileLibrary) && (((file.getImports().size() > 0) || (file.getAbstractContracts().size() > 0)) || (file.getContracts().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameImport) && ((file.getAbstractContracts().size() > 0) || (file.getContracts().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameAbstractContract) && (file.getContracts().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento del fichero que se est� parseando y el fichero actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del fichero, calcula si hay m�s elementos de otros tipos en el fichero para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del fichero a parsear, False si no hay m�s elementos del fichero a parsear
   */
  public boolean controlMoreElements(final String nameElement, final Library library) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameStruct) && ((library.getEnums().size() > 0) || (library.getFunctions().size() > 0)))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameEnumerator) && (library.getFunctions().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento del contrato que se est� parseando y el contrato actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del contrato, calcula si hay m�s elementos de otros tipos en el contrato para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del contrato a parsear, False si no hay m�s elementos del contrato a parsear
   */
  public boolean controlMoreElements(final String nameElement, final Contract contract) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameLibrary) && (((((((((contract.getLibraries().size() != 0) || (contract.getLocalMappingProperties().size() != 0)) || (contract.getLocalEnumerators().size() != 0)) || (contract.getConstructors().size() != 0)) || (contract.getModifiers().size() != 0)) || (contract.getEvents().size() != 0)) || (contract.getClauses().size() != 0)) || (contract.getStructsUser().size() != 0)) || (contract.getStructsCompany().size() != 0)))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameLocalProperty) && ((((((((contract.getLocalMappingProperties().size() != 0) || (contract.getLocalEnumerators().size() != 0)) || (contract.getConstructors().size() != 0)) || (contract.getModifiers().size() != 0)) || (contract.getEvents().size() != 0)) || (contract.getClauses().size() != 0)) || (contract.getStructsUser().size() != 0)) || (contract.getStructsCompany().size() != 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameLocalMapping) && ((((((((contract.getStructs().size() != 0) || (contract.getLocalEnumerators().size() != 0)) || (contract.getConstructors().size() != 0)) || (contract.getModifiers().size() != 0)) || (contract.getEvents().size() != 0)) || (contract.getClauses().size() != 0)) || (contract.getStructsUser().size() != 0)) || (contract.getStructsCompany().size() != 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameStruct) && (((((((contract.getLocalEnumerators().size() != 0) || (contract.getConstructors().size() != 0)) || (contract.getModifiers().size() != 0)) || (contract.getEvents().size() != 0)) || (contract.getClauses().size() != 0)) || (contract.getStructsUser().size() != 0)) || (contract.getStructsCompany().size() != 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameUserStruct) && ((((((contract.getLocalEnumerators().size() != 0) || (contract.getConstructors().size() != 0)) || (contract.getModifiers().size() != 0)) || (contract.getEvents().size() != 0)) || (contract.getClauses().size() != 0)) || (contract.getStructsCompany().size() != 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameCompanyStruct) && (((((contract.getLocalEnumerators().size() != 0) || (contract.getConstructors().size() != 0)) || (contract.getModifiers().size() != 0)) || (contract.getEvents().size() != 0)) || (contract.getClauses().size() != 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameEnumerator) && (((((contract.getConstructors().size() != 0) || (contract.getEvents().size() != 0)) || (contract.getModifiers().size() != 0)) || (contract.getEvents().size() != 0)) || (contract.getClauses().size() != 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameConstructor) && (((contract.getModifiers().size() != 0) || (contract.getEvents().size() != 0)) || (contract.getClauses().size() != 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameModifier) && ((contract.getEvents().size() != 0) || (contract.getClauses().size() != 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameEvent) && (contract.getClauses().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento del constructor que se est� parseando y el constructor actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del constructor, calcula si hay m�s elementos de otros tipos en el constructor para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del constructor a parsear, False si no hay m�s elementos del constructor a parsear
   */
  public boolean controlMoreElements(final String nameElement, final Constructor constructor) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameRestriction) && (constructor.getAttributesInitialization().size() > 0))) {
      _matched=true;
      return true;
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento contenido en una funci�n que se est� parseando y la funci�n actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez de la funci�n, calcula si hay m�s elementos de otros tipos en la funci�n para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos de la funci�n a parsear, False si no hay m�s elementos de la funci�n a parsear
   */
  public boolean controlMoreElements(final String nameElement, final Clause function) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameRestriction) && ((((((((function.getProperties().size() > 0) || (function.getMappingProperties().size() > 0)) || (function.getDeterminedloops().size() > 0)) || (function.getUndeterminedloops().size() > 0)) || (function.getConditions().size() > 0)) || (function.getPredefinedFunctions().size() > 0)) || (function.getEvent().size() > 0)) || (function.getExpressions().size() > 0)))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameLocalProperty) && (((((((function.getMappingProperties().size() > 0) || (function.getDeterminedloops().size() > 0)) || (function.getUndeterminedloops().size() > 0)) || (function.getConditions().size() > 0)) || (function.getPredefinedFunctions().size() > 0)) || (function.getEvent().size() > 0)) || (function.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameLocalMapping) && ((((((function.getDeterminedloops().size() > 0) || (function.getUndeterminedloops().size() > 0)) || (function.getConditions().size() > 0)) || (function.getPredefinedFunctions().size() > 0)) || (function.getEvent().size() > 0)) || (function.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameUndeterminedLoop) && (((((function.getDeterminedloops().size() > 0) || (function.getConditions().size() > 0)) || (function.getPredefinedFunctions().size() > 0)) || (function.getEvent().size() > 0)) || (function.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameDeterminedLoop) && ((((function.getConditions().size() > 0) || (function.getPredefinedFunctions().size() > 0)) || (function.getEvent().size() > 0)) || (function.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameCondition) && (((function.getEvent().size() > 0) || (function.getPredefinedFunctions().size() > 0)) || (function.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.namePredefinedFunctions) && ((function.getEvent().size() > 0) || (function.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameEmitEvent) && (function.getExpressions().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento contenido en un bucle While o DoWhile que se est� parseando y el bucle While o DoWhile actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del bucle While o DoWhile, calcula si hay m�s elementos de otros tipos del bucle While o DoWhile para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del bucle While o DoWhile a parsear, False si no hay m�s elementos del bucle While o DoWhile a parsear
   */
  public boolean controlMoreElements(final String nameElement, final UnDeterminedLoop loop) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameRestrictionGas) && ((((((loop.getRestriction().size() > 0) || (loop.getUndeterminedloops().size() > 0)) || (loop.getDeterminedloops().size() > 0)) || (loop.getConditions().size() > 0)) || (loop.getEvent().size() > 0)) || (loop.getExpressions().size() > 0)))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameRestriction) && (((((loop.getUndeterminedloops().size() > 0) || (loop.getDeterminedloops().size() > 0)) || (loop.getConditions().size() > 0)) || (loop.getEvent().size() > 0)) || (loop.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameUndeterminedLoop) && (((loop.getDeterminedloops().size() > 0) || (loop.getConditions().size() > 0)) || (loop.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameDeterminedLoop) && ((loop.getConditions().size() > 0) || (loop.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameConditionLoop) && (loop.getExpressions().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento contenido el FOR que se est� parseando y el FOR actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del FOR, calcula si hay m�s elementos de otros tipos en el FOR para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del FOR a parsear, False si no hay m�s elementos deL FOR a parsear
   */
  public boolean controlMoreElements(final String nameElement, final ForLoop loop) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameRestrictionGas) && (((((loop.getRestriction().size() > 0) || (loop.getUndeterminedloops().size() > 0)) || (loop.getDeterminedloops().size() > 0)) || (loop.getConditions().size() > 0)) || (loop.getExpressions().size() > 0)))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameRestriction) && ((((loop.getUndeterminedloops().size() > 0) || (loop.getDeterminedloops().size() > 0)) || (loop.getConditions().size() > 0)) || (loop.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameDeterminedLoop) && (((loop.getUndeterminedloops().size() > 0) || (loop.getConditions().size() > 0)) || (loop.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameUndeterminedLoop) && ((loop.getConditions().size() > 0) || (loop.getExpressions().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameConditionLoop) && (loop.getExpressions().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento contenido en un IF que se est� parseando y el IF actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del IF, calcula si hay m�s elementos de otros tipos en el IF para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del IF a parsear, False si no hay m�s elementos del IF a parsear
   */
  public boolean controlMoreElements(final String nameElement, final Condition condition) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method or field eventIf is undefined for the type Condition"
      + "\nThe method or field eventIf is undefined for the type Condition"
      + "\nThe method or field eventIf is undefined for the type Condition"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved"
      + "\nsize cannot be resolved"
      + "\n> cannot be resolved");
  }
  
  /**
   * Argumentos:Elemento del ELSE que se acaba de parsear y la condici�n que se encuentra dentro de un BUCLE donde se encuentra el propio else
   * Descripci�n: Seg�n el elemento final que se acaba de parsear mira si hay + elementos de otros tipo dentro del ELSE a parsear
   * Salida: Devuelve true si hay m�s elementos a parsear despu�s del �ltimo que se acaba de parsear (el que recibe de entrada), false si al contrario
   */
  public boolean controlElseElements(final String nameElement, final Condition condition) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameDeterminedLoopElse) && ((((condition.getUndeterminedloopsElse().size() > 0) || (condition.getConditionalExprElse().size() > 0)) || (condition.getEventElse().size() > 0)) || (condition.getExpressionsElse().size() > 0)))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameUndeterminedLoop) && (((condition.getConditionalExprElse().size() > 0) || (condition.getEventElse().size() > 0)) || (condition.getExpressionsElse().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameConditionLoopElse) && ((condition.getEventElse().size() > 0) || (condition.getExpressionsElse().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameEmitEventElse) && (condition.getExpressionsElse().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento contenido en un modificador que se est� parseando y el modificador actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del modificador, calcula si hay m�s elementos de otros tipos en el modificador para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del modificador a parsear, False si no hay m�s elementos del modificador a parsear
   */
  public boolean controlMoreElements(final String nameElement, final Modifier modifier) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameRestriction) && ((((modifier.getConditionsBeforeMark().size() > 0) || (modifier.getExpressionsAssignValueBeforeMark().size() > 0)) || (modifier.getConditionsAfterMark().size() > 0)) || (modifier.getExpressionsAssignValueAfterMark().size() > 0)))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameConditionBeforeMark) && (((modifier.getExpressionsAssignValueBeforeMark().size() > 0) || (modifier.getConditionsAfterMark().size() > 0)) || (modifier.getExpressionsAssignValueAfterMark().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameExpressionBeforeMark) && ((modifier.getConditionsAfterMark().size() > 0) || (modifier.getExpressionsAssignValueAfterMark().size() > 0)))) {
        _matched=true;
        return true;
      }
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameConditionAfterMark) && (modifier.getExpressionsAssignValueAfterMark().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento del fichero que se est� parseando y el struct actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del fichero, calcula si hay m�s elementos de otros tipos en el fichero para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del fichero a parsear, False si no hay m�s elementos del fichero a parsear
   */
  public boolean controlMoreElements(final String nameElement, final PersonalizedStruct struct) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameLocalProperty) && (struct.getStructs().size() > 0))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameLocalMapping) && (struct.getStructs().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento del fichero que se est� parseando y el fichero actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del fichero, calcula si hay m�s elementos de otros tipos en el fichero para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del fichero a parsear, False si no hay m�s elementos del fichero a parsear
   */
  public boolean controlMoreElements(final String nameElement, final User struct) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameLocalProperty) && (struct.getStructs().size() > 0))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameLocalMapping) && (struct.getStructs().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Nombre del �ltimo elemento del fichero que se est� parseando y el fichero actual que se est� parseando
   * Descripci�n: Seg�n el elemento que se est� parseando por �ltima vez del fichero, calcula si hay m�s elementos de otros tipos en el fichero para poder a�adir la etiqueta next
   * Salida: True si hay m�s elementos del fichero a parsear, False si no hay m�s elementos del fichero a parsear
   */
  public boolean controlMoreElements(final String nameElement, final Company struct) {
    boolean _matched = false;
    if ((nameElement.equals(this.nameLocalProperty) && (struct.getStructs().size() > 0))) {
      _matched=true;
      return true;
    }
    if (!_matched) {
      if ((nameElement.equals(this.nameLocalMapping) && (struct.getStructs().size() > 0))) {
        _matched=true;
        return true;
      }
    }
    return false;
  }
  
  /**
   * Argumentos:Condici�n que se est� parseando
   * Descripci�n: Comprueba si la condici�n que se est� parseando tiene un ELSE
   * Salida: True si hay elementos del ELSE a parsear, False si no hay elementos del ELSE a parsear por lo tanto no hay ELSE
   */
  public boolean controlElseConditionElements(final Condition condition) {
    if ((((((condition.getUndeterminedloopsElse().size() > 0) || (condition.getDeterminedloopsElse().size() > 0)) || (condition.getConditionalExprElse().size() > 0)) || (condition.getEventElse().size() > 0)) || (condition.getExpressionsElse().size() > 0))) {
      return true;
    } else {
      return false;
    }
  }
  
  /**
   * Argumentos: Condiciones que se han parseado
   * Descripci�n: Comprueba si de las condiciones que se han parseado habia alguna que tuviera un ELSE para luego el cierre de etiquetas <next> y <block>
   * Salida: True si hay elementos del ELSE a parsear, False si no hay elementos del ELSE a parsear por lo tanto no hay ELSE
   */
  public boolean controlElseInConditionsElements(final List<Condition> conditions) {
    boolean findElse = false;
    for (int i = 0; (i < conditions.size()); i++) {
      {
        Condition condition = conditions.get(i);
        if ((((((condition.getUndeterminedloopsElse().size() > 0) || (condition.getDeterminedloopsElse().size() > 0)) || (condition.getConditionalExprElse().size() > 0)) || (condition.getEventElse().size() > 0)) || (condition.getExpressionsElse().size() > 0))) {
          findElse = true;
        }
      }
    }
    return findElse;
  }
  
  /**
   * Argumentos:Las condiciones(LOS IF) que tien la funci�n
   * Descripci�n: Se empieza desde la �ltima condici�n y se comprueba si tiene ELSE para llamar a su cierra de etiquetas <next> y <block>
   * Salida: Ninguna
   */
  public CharSequence closeTagsConditionsAndElse(final List<Condition> conditions, final Clause function) {
    StringConcatenation _builder = new StringConcatenation();
    {
      List<Condition> _reverse = ListExtensions.<Condition>reverse(conditions);
      for(final Condition condition : _reverse) {
        {
          if ((((((condition.getUndeterminedloopsElse().size() > 0) || (condition.getDeterminedloopsElse().size() > 0)) || (condition.getConditionalExprElse().size() > 0)) || (condition.getEventElse().size() > 0)) || (condition.getExpressionsElse().size() > 0))) {
            CharSequence _closeTagsElseBlock = this.closeTagsElseBlock(1);
            _builder.append(_closeTagsElseBlock);
            _builder.append("\t\t\t");
            CharSequence _closeTagsDistinctElements = this.closeTagsDistinctElements(1, this.controlMoreElements(this.nameCondition, function));
            _builder.append(_closeTagsDistinctElements);
            _builder.append("\t\t");
          } else {
            _builder.append("\t\t\t\t");
            _builder.newLineIfNotEmpty();
            CharSequence _closeTagsDistinctElements_1 = this.closeTagsDistinctElements(1, this.controlMoreElements(this.nameCondition, function));
            _builder.append(_closeTagsDistinctElements_1);
            _builder.append("\t\t");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos:Numero de ELSE
   * Descripci�n: Se produce el cierre de etiquetas <next> y <block> seg�n el n�mero de ELSE que hab�a
   * Salida: Ninguna
   */
  private CharSequence closeTagsElseBlock(final int number) {
    StringConcatenation _builder = new StringConcatenation();
    final int[] elementsToClose = new int[number];
    _builder.newLineIfNotEmpty();
    {
      for(final int element : elementsToClose) {
        _builder.append("</block>");
        _builder.newLine();
        _builder.append("</next>");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  public CharSequence closeTags(final int numElementsToClose) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if ((((numElementsToClose - 1) != 0) && ((numElementsToClose - 1) != (-1)))) {
        final int[] elementsToClose = new int[(numElementsToClose - 1)];
        _builder.newLineIfNotEmpty();
        {
          for(final int element : elementsToClose) {
            _builder.append("  ");
            _builder.append("</next>");
            _builder.newLine();
            _builder.append("</block>");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Argumentos:Los elementos a cerrar de ese tipo y si hay elementos de otro tipo para su parseo a Blockly
   * Descripci�n: Seg�n el n�mero de elementos de ese tipo para cerrar las etiquetas <next> y <block> y si hab�a m�s elementos a parsear despu�s del �ltimo de este se cierran las etiquetas de una forma u otra
   * Salida: Ninguna
   */
  public CharSequence closeTagsDistinctElements(final int numElementsToClose, final boolean moreElements) {
    StringConcatenation _builder = new StringConcatenation();
    {
      if (((numElementsToClose > 1) && (moreElements == true))) {
        int[] elementsToClose = new int[numElementsToClose];
        _builder.newLineIfNotEmpty();
        {
          for(final int element : elementsToClose) {
            _builder.append(" ");
            _builder.append("</next>");
            _builder.newLine();
            _builder.append("</block>");
            _builder.newLine();
          }
        }
        _builder.append("\t\t");
      } else {
        if (((numElementsToClose > 1) && (moreElements == false))) {
          _builder.append(" ");
          _builder.append("\t\t\t");
          int[] elementsToClose_1 = new int[(numElementsToClose - 1)];
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("</block>");
          _builder.newLine();
          {
            for(final int element_1 : elementsToClose_1) {
              _builder.append("\t");
              _builder.append(" ");
              _builder.append("</next>");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("</block>");
              _builder.newLine();
            }
          }
        } else {
          if (((numElementsToClose == 1) && (moreElements == true))) {
            _builder.append("\t\t\t </next>");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("</block>");
            _builder.newLine();
          } else {
            if (((numElementsToClose == 1) && (moreElements == false))) {
              _builder.append("\t\t\t</block>");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
    }
    return _builder;
  }
}
