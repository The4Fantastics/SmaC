package org.xtext.generator;

import com.google.common.base.Objects;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.xtext.smaC.File;

/**
 * Generates code from your model files on save.
 * 
 * See https://www.eclipse.org/Xtext/documentation/303_runtime_concepts.html#code-generation
 */
@SuppressWarnings("all")
public class SmaCGenerator extends AbstractGenerator {
  @Override
  public void doGenerate(final Resource resource, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    EObject _head = IteratorExtensions.<EObject>head(resource.getAllContents());
    final File root = ((File) _head);
    boolean _notEquals = (!Objects.equal(root, null));
    if (_notEquals) {
      String _replace = resource.getURI().path().toString().replace(".sce", ".dot");
      String _plus = ("Uri path: " + _replace);
      System.out.println(_plus);
      String _string = resource.getURI().toString();
      int _lastIndexOf = resource.getURI().toString().lastIndexOf("/");
      int _plus_1 = (_lastIndexOf + 1);
      final String nameFile = _string.substring(_plus_1, resource.getURI().toString().lastIndexOf("."));
      final String path = resource.getURI().path().toString().replace(".sce", ".dot");
      final String pathBlockly = resource.getURI().path().toString().replace(".sce", ".xml");
    }
  }
}
