package org.xtext.generator;

import com.google.common.base.Objects;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.xtext.generator.blocklyparser.AbstractContractBlocklyParser;
import org.xtext.generator.blocklyparser.ContractBlocklyParser;
import org.xtext.generator.blocklyparser.InterfaceBlocklyParser;
import org.xtext.generator.blocklyparser.LibraryBlocklyParser;
import org.xtext.generator.blocklyparser.ParserCommonFunctions;
import org.xtext.smaC.AbstractContract;
import org.xtext.smaC.File;
import org.xtext.smaC.Import;
import org.xtext.smaC.Interface;
import org.xtext.smaC.Library;
import org.xtext.smaC.Version;

@SuppressWarnings("all")
public class SmacBlocklyGenerator extends AbstractGenerator {
  private LibraryBlocklyParser parserLibrary = new LibraryBlocklyParser();
  
  private InterfaceBlocklyParser parserInterface = new InterfaceBlocklyParser();
  
  private ContractBlocklyParser parserContract = new ContractBlocklyParser();
  
  private AbstractContractBlocklyParser parserAbstractContract = new AbstractContractBlocklyParser();
  
  private ParserCommonFunctions parserCommonFunctions = new ParserCommonFunctions();
  
  private String operator = "";
  
  private final String nameFileLibrary = "library";
  
  private final String nameImport = "import";
  
  private final String nameFileInterface = "interface";
  
  private final String nameAbstractContract = "abstract";
  
  public CharSequence toXmlBlockly(final File file, final String nameFile) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<xml xmlns=\"https://developers.google.com/blockly/xml\">");
    _builder.newLine();
    _builder.append("<block type=\"file\" x=\"-84\" y=\"-1056\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    _builder.append(nameFile);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<value name=\"version_file\">");
    _builder.newLine();
    _builder.append("\t    ");
    CharSequence _controlVersionFile = this.controlVersionFile(file.getVersion());
    _builder.append(_controlVersionFile, "\t    ");
    _builder.newLineIfNotEmpty();
    _builder.append("</value>");
    _builder.newLine();
    _builder.append("<statement name=\"elements_file\">");
    _builder.newLine();
    {
      EList<Interface> _interfaces = file.getInterfaces();
      for(final Interface interfaceContract : _interfaces) {
        CharSequence _defineBlockInterface = this.parserInterface.defineBlockInterface(interfaceContract);
        _builder.append(_defineBlockInterface);
        _builder.newLineIfNotEmpty();
        {
          if (((!interfaceContract.equals(file.getInterfaces().get((file.getInterfaces().size() - 1)))) || (interfaceContract.equals(file.getInterfaces().get((file.getInterfaces().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameFileInterface, file)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Library> _library = file.getLibrary();
      for(final Library library : _library) {
        _builder.append("    ");
        CharSequence _defineBlockLibrary = this.parserLibrary.defineBlockLibrary(library);
        _builder.append(_defineBlockLibrary, "    ");
        _builder.newLineIfNotEmpty();
        {
          if (((!library.equals(file.getLibrary().get((file.getLibrary().size() - 1)))) || (library.equals(file.getLibrary().get((file.getLibrary().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameFileLibrary, file)))) {
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<Import> _imports = file.getImports();
      for(final Import importElement : _imports) {
        _builder.append("    ");
        CharSequence _generateBlockImport = this.generateBlockImport(importElement);
        _builder.append(_generateBlockImport, "    ");
        _builder.newLineIfNotEmpty();
        {
          if (((!importElement.equals(file.getImports().get((file.getImports().size() - 1)))) || (importElement.equals(file.getImports().get((file.getImports().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameImport, file)))) {
            _builder.append("\t \t   \t   \t");
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    {
      EList<AbstractContract> _abstractContracts = file.getAbstractContracts();
      for(final AbstractContract abstractContract : _abstractContracts) {
        CharSequence _defineBlockAbstractContract = this.parserAbstractContract.defineBlockAbstractContract(abstractContract);
        _builder.append(_defineBlockAbstractContract);
        _builder.newLineIfNotEmpty();
        {
          if (((!abstractContract.equals(file.getAbstractContracts().get((file.getImports().size() - 1)))) || (abstractContract.equals(file.getImports().get((file.getImports().size() - 1))) && this.parserCommonFunctions.controlMoreElements(this.nameAbstractContract, file)))) {
            _builder.append("\t \t   \t   \t");
            _builder.append("<next>");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("        \t");
    CharSequence _defineBlockContract = this.parserContract.defineBlockContract(file);
    _builder.append(_defineBlockContract, "        \t");
    _builder.newLineIfNotEmpty();
    _builder.append("        \t");
    CharSequence _closeTagsDistinctElements = this.parserCommonFunctions.closeTagsDistinctElements(file.getAbstractContracts().size(), this.parserCommonFunctions.controlMoreElements(this.nameAbstractContract, file));
    _builder.append(_closeTagsDistinctElements, "        \t");
    _builder.append("        \t");
    CharSequence _closeTagsDistinctElements_1 = this.parserCommonFunctions.closeTagsDistinctElements(file.getImports().size(), this.parserCommonFunctions.controlMoreElements(this.nameImport, file));
    _builder.append(_closeTagsDistinctElements_1, "        \t");
    _builder.append("        \t");
    CharSequence _closeTagsDistinctElements_2 = this.parserCommonFunctions.closeTagsDistinctElements(file.getLibrary().size(), this.parserCommonFunctions.controlMoreElements(this.nameFileLibrary, file));
    _builder.append(_closeTagsDistinctElements_2, "        \t");
    _builder.append("        \t");
    CharSequence _closeTagsDistinctElements_3 = this.parserCommonFunctions.closeTagsDistinctElements(file.getInterfaces().size(), this.parserCommonFunctions.controlMoreElements(this.nameFileInterface, file));
    _builder.append(_closeTagsDistinctElements_3, "        \t");
    _builder.append("\t\t    </statement>");
    _builder.newLineIfNotEmpty();
    _builder.append("</block>");
    _builder.newLine();
    _builder.append("</xml>");
    _builder.newLine();
    return _builder;
  }
  
  private CharSequence controlVersionFile(final Version version) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"version\">\t\t");
    _builder.newLine();
    _builder.append("<field name=\"symbolversion\">");
    String _controlSymbol = this.controlSymbol(version.getSymbol().toString());
    _builder.append(_controlSymbol);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    final String secondElementVersion = version.getNumberVersion().toString().substring(version.getNumberVersion().toString().indexOf("."), version.getNumberVersion().toString().lastIndexOf(".")).replace(".", "");
    _builder.newLineIfNotEmpty();
    final String thirdElementVersion = version.getNumberVersion().toString().substring(version.getNumberVersion().toString().lastIndexOf(".")).replace(".", "");
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"value1version\">");
    char _charAt = version.getNumberVersion().charAt(0);
    _builder.append(_charAt);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"value2version\">");
    _builder.append(secondElementVersion);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    _builder.append("<field name=\"value3version\">");
    _builder.append(thirdElementVersion);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    {
      String _symbolComparation = version.getSymbolComparation();
      boolean _notEquals = (!Objects.equal(_symbolComparation, null));
      if (_notEquals) {
        {
          if ((((version.getSymbolComparation().toString().contains(">=") || version.getSymbolComparation().toString().contains(">")) || version.getSymbolComparation().toString().contains("<=")) || version.getSymbolComparation().toString().contains("<"))) {
            _builder.append("<field name=\"symbolcomparation\">");
            String _controlSymbol_1 = this.controlSymbol(version.getSymbolComparation().toString());
            _builder.append(_controlSymbol_1);
            _builder.append("</field>");
            _builder.newLineIfNotEmpty();
            final String secondElementOptionalVersion = version.getNumberVersion2().toString().substring(version.getNumberVersion2().toString().indexOf("."), version.getNumberVersion2().toString().lastIndexOf(".")).replace(".", "");
            _builder.newLineIfNotEmpty();
            final String thirdElementOptionalVersion = version.getNumberVersion2().toString().substring(version.getNumberVersion2().toString().lastIndexOf(".")).replace(".", "");
            _builder.newLineIfNotEmpty();
            _builder.append("<field name=\"value1versionoptional\">");
            char _charAt_1 = version.getNumberVersion2().toString().charAt(0);
            _builder.append(_charAt_1);
            _builder.append("</field>");
            _builder.newLineIfNotEmpty();
            _builder.append("<field name=\"value2versionoptional\">");
            _builder.append(secondElementOptionalVersion);
            _builder.append("</field>");
            _builder.newLineIfNotEmpty();
            _builder.append("<field name=\"value3versionoptional\">");
            _builder.append(thirdElementOptionalVersion);
            _builder.append("</field>");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("</block>\t\t");
    _builder.newLine();
    return _builder;
  }
  
  private String controlSymbol(final String symbol) {
    boolean _matched = false;
    boolean _contains = symbol.toString().contains(">=");
    if (_contains) {
      _matched=true;
      this.operator = "&gt;=";
    }
    if (!_matched) {
      boolean _contains_1 = symbol.toString().contains(">");
      if (_contains_1) {
        _matched=true;
        this.operator = "&gt;";
      }
    }
    if (!_matched) {
      boolean _contains_2 = symbol.toString().contains("<=");
      if (_contains_2) {
        _matched=true;
        this.operator = "&lt;=";
      }
    }
    if (!_matched) {
      this.operator = "&lt;";
    }
    return this.operator;
  }
  
  private CharSequence generateBlockImport(final Import importElement) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<block type=\"import\">");
    _builder.newLine();
    _builder.append("<field name=\"name\">");
    String _name = importElement.getName();
    _builder.append(_name);
    _builder.append("</field>");
    _builder.newLineIfNotEmpty();
    {
      int _length = importElement.getAlias().length();
      boolean _greaterThan = (_length > 0);
      if (_greaterThan) {
        _builder.append("        ");
        _builder.append("<value name=\"alias\">");
        _builder.newLine();
        _builder.append("        ");
        _builder.append("    ");
        _builder.append("<block type=\"alias_import\">");
        _builder.newLine();
        _builder.append("        ");
        _builder.append("      ");
        _builder.append("<field name=\"alias\">");
        String _alias = importElement.getAlias();
        _builder.append(_alias, "              ");
        _builder.append("</field>");
        _builder.newLineIfNotEmpty();
        _builder.append("        ");
        _builder.append("    ");
        _builder.append("</block>");
        _builder.newLine();
        _builder.append("        ");
        _builder.append("</value>");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  @Override
  public void doGenerate(final Resource input, final IFileSystemAccess2 fsa, final IGeneratorContext context) {
    EObject _head = IteratorExtensions.<EObject>head(input.getAllContents());
    final File root = ((File) _head);
    String _string = input.getURI().toString();
    int _lastIndexOf = input.getURI().toString().lastIndexOf("/");
    int _plus = (_lastIndexOf + 1);
    final String nameFile = _string.substring(_plus, input.getURI().toString().lastIndexOf("."));
    final String pathBlockly = input.getURI().path().toString().replace(".sce", ".xml");
    fsa.generateFile(pathBlockly, this.toXmlBlockly(root, nameFile));
  }
}
