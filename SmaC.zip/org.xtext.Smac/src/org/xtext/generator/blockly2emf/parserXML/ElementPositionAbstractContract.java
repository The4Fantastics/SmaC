package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.AbstractContractImpl;
import org.xtext.smaC.impl.ContractImpl;

public class ElementPositionAbstractContract {
	
	Element position;
	ArrayList<AbstractContractImpl> contracts =  new ArrayList<AbstractContractImpl>();
	
	public ArrayList<AbstractContractImpl> getContracts() {
		return contracts;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setContract(ArrayList<AbstractContractImpl> contracts) {
		this.contracts = contracts;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
