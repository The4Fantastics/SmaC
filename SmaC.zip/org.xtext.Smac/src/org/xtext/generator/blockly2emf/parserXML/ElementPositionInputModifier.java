package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.ModifierImpl;
import org.xtext.smaC.impl.OutputParamImpl;

public class ElementPositionInputModifier {
	
	private Element position;
	private ModifierImpl inputModifier =  new ModifierImpl();
	private ArrayList<ModifierImpl> inputModifiers = new ArrayList<ModifierImpl>();
	
	public ModifierImpl getInputModifier() {
		return inputModifier;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setInputsModifiers(ArrayList<ModifierImpl> inputModifiers){
		this.inputModifiers = inputModifiers;
	}
	
	public ArrayList<ModifierImpl> getInputsModifiers(){
		return this.inputModifiers;
	}
	
	public void setInputModifier(ModifierImpl inputModifier){
		this.inputModifier = inputModifier;
	}

	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
