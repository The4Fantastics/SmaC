package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.eclipse.xtext.xtext.generator.parser.antlr.splitting.simpleExpressions.impl.ExpressionImpl;
import org.jdom2.Element;
import org.xtext.smaC.impl.MappingImpl;
import org.xtext.smaC.impl.MappingDeclarationImpl;

public class ElementPositionMapping {
	
	Element position;
	private ArrayList<MappingImpl> propertiesMapping = new ArrayList<MappingImpl>();
	
	public Element getPosition() {
		return position;
	}
	
	public void addMapping(MappingImpl actualElement) {
		this.propertiesMapping.add(actualElement);
	}
	
	public void setPropertiesMapping(ArrayList<MappingImpl>listExpressions) {
		this.propertiesMapping = listExpressions;
	}
	
	public ArrayList<MappingImpl> getPropertiesMapping() {
		return this.propertiesMapping;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
