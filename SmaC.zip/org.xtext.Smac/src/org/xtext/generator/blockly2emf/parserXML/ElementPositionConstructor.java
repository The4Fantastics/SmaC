package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.ConstructorImpl;

public class ElementPositionConstructor {
	
	Element position;
	ArrayList<ConstructorImpl> constructors =  new ArrayList<ConstructorImpl>();
	
	public ArrayList<ConstructorImpl> getConstructors() {
		return this.constructors;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setConstructor(ConstructorImpl actualElement) {
		this.constructors.add(actualElement);
	}
	
	public void setConstructors(ArrayList<ConstructorImpl> listConstructors) {
		this.constructors = listConstructors;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
