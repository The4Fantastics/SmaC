package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.RestrictionClauseImpl;
import org.xtext.smaC.impl.RestrictionImpl;

public class ElementPositionRestriction {
	
	private Element position;
	private ArrayList<RestrictionClauseImpl> restrictions = new ArrayList<RestrictionClauseImpl>();
	
	public ArrayList<RestrictionClauseImpl> getRestrictions() {
		return this.restrictions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addRestriction(RestrictionClauseImpl actualElement) {
		this.restrictions.add(actualElement);
	}
	
	public void setRestrictions(ArrayList<RestrictionClauseImpl>listRestrictions) {
		this.restrictions = listRestrictions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	

	
	
}
