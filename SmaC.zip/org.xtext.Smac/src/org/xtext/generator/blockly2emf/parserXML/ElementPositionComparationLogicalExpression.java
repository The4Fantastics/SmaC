package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.eclipse.xtext.xtext.generator.parser.antlr.splitting.simpleExpressions.impl.ExpressionImpl;
import org.jdom2.Element;
import org.xtext.smaC.ComparationOperator;

public class ElementPositionComparationLogicalExpression {
	
	private Element position;
	private String value1condition = "";
	private String value2condition = "";
	private ComparationOperator operator;
	private ArrayList<String> expressions = new ArrayList<String>();
	private String totalExpression = "";
	
	public String getValue1condition() {
		return value1condition;
	}

	public void setValue1condition(String value1condition) {
		this.value1condition = value1condition;
	}

	public String getValue2condition() {
		return value2condition;
	}

	public void setValue2condition(String value2condition) {
		this.value2condition = value2condition;
	}

	public ComparationOperator getOperator() {
		return operator;
	}

	public void setOperator(ComparationOperator operator) {
		this.operator = operator;
	}
	
	public ArrayList<String> getExpressions() {
		return this.expressions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addExpression(String actualElement) {
		this.expressions.add(actualElement);
	}
	
	public void setExpressions(ArrayList<String>listExpressions) {
		this.expressions = listExpressions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
	public String buildTotalExpression(){
		return this.totalExpression = this.value1condition + " " + this.operator.toString()  + " " + this.value2condition;
	}
	
}
