package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.ForLoopImpl;

public class ElementPositionLoopFor {
	
	private Element position;
	private ArrayList<ForLoopImpl> loops = new ArrayList<ForLoopImpl>();
	
	public ArrayList<ForLoopImpl> getLoops() {
		return this.loops;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addLoop(ForLoopImpl actualElement) {
		this.loops.add(actualElement);
	}
	
	public void setLoops(ArrayList<ForLoopImpl>listLoops) {
		this.loops = listLoops;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
