package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.EnumImpl;
import org.xtext.smaC.impl.EventImpl;

public class ElementPositionEnum {
	
	Element position;
	ArrayList<EnumImpl> enums = new ArrayList<EnumImpl>();
	
	public ArrayList<EnumImpl> getEnums() {
		return this.enums;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setEnum(EnumImpl actualElement) {
		this.enums.add(actualElement);
	}
	
	public void setEnums(ArrayList<EnumImpl>listEnums) {
		this.enums = listEnums;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
