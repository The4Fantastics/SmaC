package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.CompanyImpl;

public class ElementPositionCompany {
	
	Element position;
	ArrayList<CompanyImpl> companies = new ArrayList<CompanyImpl>();
	
	public ArrayList<CompanyImpl> getCompanies() {
		return this.companies;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setCompany(CompanyImpl actualElement) {
		this.companies.add(actualElement);
	}
	
	public void setCompanies(ArrayList<CompanyImpl> listCompanies) {
		this.companies = listCompanies;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
