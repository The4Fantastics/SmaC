package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.UserImpl;;

public class ElementPositionUser {
	
	Element position;
	ArrayList<UserImpl> users =  new ArrayList<UserImpl>();
	
	public ArrayList<UserImpl> getUsers() {
		return this.users;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setUser(UserImpl actualElement) {
		this.users.add(actualElement);
	}
	
	public void setUsers(ArrayList<UserImpl> listUsers) {
		this.users = listUsers;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
