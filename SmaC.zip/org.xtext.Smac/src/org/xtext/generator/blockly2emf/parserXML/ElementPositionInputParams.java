package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.InputParam;
import org.xtext.smaC.impl.InputParamImpl;

public class ElementPositionInputParams {
	
	private Element position;
	private ArrayList<InputParamImpl> inputParams =  new ArrayList<InputParamImpl>();
	
	public ArrayList<InputParamImpl> getInputParams() {
		return inputParams;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setInputParam(InputParamImpl inputParam){
		this.inputParams.add(inputParam);
	}
	
	public void setInputParams(ArrayList<InputParamImpl> inputParams) {
		this.inputParams.addAll(inputParams);
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
