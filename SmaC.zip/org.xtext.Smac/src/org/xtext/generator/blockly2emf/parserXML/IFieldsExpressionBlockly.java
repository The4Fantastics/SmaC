package org.xtext.generator.blockly2emf.parserXML;

public interface IFieldsExpressionBlockly {
	
	final String FIELD_NAME = "name";
	final String FIELD_COMMENT = "comment";
	final String FIELD_OPERATORS = "operators";
	final String FIELD_VALUES_EXPRESSION = "values_expression";
	final String VALUE_CONDITION = "condition";
	final String NEXT = "next";
	final String BLOCK_COMPARATION_ARITHMETHICALEXPRESSION = "comparation_arithmeticalexpression";
	final String BLOCK_PERSONALIZED_INPUT_EXPRESSION = "personalized_inputexpression";
	
}
