package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.RestrictionClauseImpl;
import org.xtext.smaC.impl.RestrictionGasImpl;
import org.xtext.smaC.impl.RestrictionImpl;

public class ElementPositionRestrictionGas {
	
	private Element position;
	private ArrayList<RestrictionGasImpl> restrictions = new ArrayList<RestrictionGasImpl>();
	
	public ArrayList<RestrictionGasImpl> getRestrictions() {
		return this.restrictions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addRestriction(RestrictionGasImpl actualElement) {
		this.restrictions.add(actualElement);
	}
	
	public void setRestrictions(ArrayList<RestrictionGasImpl>listRestrictions) {
		this.restrictions = listRestrictions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
