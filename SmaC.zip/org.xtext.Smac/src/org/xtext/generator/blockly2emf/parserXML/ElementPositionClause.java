package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.ClauseImpl;

public class ElementPositionClause {
	
	Element position;
	ArrayList<ClauseImpl> functions =  new ArrayList<ClauseImpl>();
	Boolean finishGeneration = false;
	
	public ArrayList<ClauseImpl> getClauses() {
		return functions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setClauses(ArrayList<ClauseImpl> functions) {
		this.functions = functions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}

	public boolean getFinishGeneration() {
		return this.finishGeneration;
	}
	
	public void setFinishGeneration(Boolean value) {
		this.finishGeneration = value;
	}
	
	 public String toStringFile()
	  {
		  
	    StringBuilder result = new StringBuilder(super.toString());
	    for(ClauseImpl function : this.getClauses()){
		    result.append("function ");
		    result.append(function.getName() + "(");
		    /*for(InputParamImpl inputParam : this.inputParams) {
		    	result.append(inputParam.toStringFile());
		    }*/
		    result.append(")");
		    result.append(" " + function.getVisibilityAccess().getLiteral());
		    result.append("{" + "\n");
		    /*for(Properties property : this.properties){
		    	property.toStringFile();
		    }*/
		    result.append("}" + "\n");
	    }
	    return result.toString();
	  }
	
}
