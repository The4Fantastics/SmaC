package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.eclipse.xtext.xtext.generator.parser.antlr.splitting.simpleExpressions.impl.ExpressionImpl;
import org.jdom2.Element;

public class ElementPositionExpression {
	
	private Element position;
	private ArrayList<ExpressionImpl> expressions = new ArrayList<ExpressionImpl>();
	
	public ArrayList<ExpressionImpl> getExpressions() {
		return this.expressions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addExpression(ExpressionImpl actualElement) {
		this.expressions.add(actualElement);
	}
	
	public void setExpressions(ArrayList<ExpressionImpl>listExpressions) {
		this.expressions = listExpressions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
