package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.PersonalizedStruct;
import org.xtext.smaC.impl.CompanyImpl;
import org.xtext.smaC.impl.PersonalizedStructImpl;
import org.xtext.smaC.impl.UserImpl;

public class ElementPositionStruct {
	
	Element position;
	ArrayList<PersonalizedStructImpl> structs =  new ArrayList<PersonalizedStructImpl>();
	ArrayList<UserImpl> structsUser =  new ArrayList<UserImpl>();
	ArrayList<CompanyImpl> structsCompany =  new ArrayList<CompanyImpl>();
	
	public ArrayList<PersonalizedStructImpl> getStructs() {
		return this.structs;
	}
	
	public ArrayList<UserImpl> getUserStructs() {
		return this.structsUser;
	}
	
	public ArrayList<CompanyImpl> getCompanyStructs() {
		return this.structsCompany;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setStruct(PersonalizedStructImpl actualElement) {
		this.structs.add(actualElement);
	}
	
	public void setStructUser(UserImpl actualElement) {
		this.structsUser.add(actualElement);
	}
	
	public void setStructCompany(CompanyImpl actualElement) {
		this.structsCompany.add(actualElement);
	}
	
	public void setStructs(ArrayList<PersonalizedStructImpl> listStructs) {
		this.structs = listStructs;
	}
	
	public void setUserStruct(UserImpl actualElement) {
		this.structsUser.add(actualElement);
	}
	
	public void setStructsUsers(ArrayList<UserImpl> listStructs) {
		this.structsUser = listStructs;
	}
	
	public void setCompanyStruct(CompanyImpl actualElement) {
		this.structsCompany.add(actualElement);
	}
	
	public void setStructsCompany(ArrayList<CompanyImpl> listStructs) {
		this.structsCompany = listStructs;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
