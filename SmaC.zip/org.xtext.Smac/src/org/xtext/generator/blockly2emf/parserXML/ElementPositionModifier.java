package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.ModifierImpl;

public class ElementPositionModifier {
	
	private Element position;
	private boolean finalCloseModifier = true;
	private ArrayList<ModifierImpl> modifiers = new ArrayList<ModifierImpl>();
	
	public boolean isFinalCloseModifier() {
		return finalCloseModifier;
	}

	public void setFinalCloseModifier(boolean finalCloseModifier) {
		this.finalCloseModifier = finalCloseModifier;
	}
		
	public ArrayList<ModifierImpl> getModifiers() {
		return this.modifiers;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addModifier(ModifierImpl actualElement) {
		this.modifiers.add(actualElement);
	}
	
	public void setModifiers(ArrayList<ModifierImpl>listModifiers) {
		this.modifiers = listModifiers;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
