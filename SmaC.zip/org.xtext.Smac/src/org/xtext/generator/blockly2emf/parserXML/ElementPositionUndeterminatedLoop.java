package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.UnDeterminedLoopImpl;


public class ElementPositionUndeterminatedLoop {
	
	private Element position;
	private ArrayList<UnDeterminedLoopImpl> loops = new ArrayList<UnDeterminedLoopImpl>();
	
	public ArrayList<UnDeterminedLoopImpl> getLoops() {
		return this.loops;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addLoop(UnDeterminedLoopImpl actualElement) {
		this.loops.add(actualElement);
	}
	
	public void setLoops(ArrayList<UnDeterminedLoopImpl>listLoops) {
		this.loops = listLoops;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
