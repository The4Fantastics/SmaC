package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.eclipse.xtext.xtext.generator.parser.antlr.splitting.simpleExpressions.impl.ExpressionImpl;
import org.jdom2.Element;
import org.xtext.smaC.ComparationOperator;

public class ElementPositionAssignValueExpression {
	
	private Element position;
	private String value1 = "";
	private String value2 = "";
	private String totalExpression = "";
	private ComparationOperator operator;
	private ArrayList<String> expressions = new ArrayList<String>();
	
	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(String value2) {
		this.value2 = value2;
	}

	public ComparationOperator getOperator() {
		return operator;
	}

	public void setOperator(ComparationOperator operator) {
		this.operator = operator;
	}
	
	public ArrayList<String> getExpressions() {
		return this.expressions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addExpression(String actualElement) {
		this.expressions.add(actualElement);
	}
	
	public void setExpressions(ArrayList<String>listExpressions) {
		this.expressions = listExpressions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
	public String buildTotalExpression(){
		return this.totalExpression = this.value1 + " " + this.operator.toString()  + " " + this.value2;
	}
	
}
