package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.DeclarationFunctionAbstractContract;
import org.xtext.smaC.DeclarationFunctionInterface;
import org.xtext.smaC.impl.DeclarationFunctionInterfaceImpl;

public class ElementPositionDeclarationClauseInterface {
	
	Element position;
	ArrayList<DeclarationFunctionInterfaceImpl> declarationFunctions =  new ArrayList<DeclarationFunctionInterfaceImpl>();
	Boolean finishGeneration = false;
	
	public ArrayList<DeclarationFunctionInterfaceImpl> getDeclarationFunctions() {
		return declarationFunctions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setDeclarationFunction(ArrayList<DeclarationFunctionInterfaceImpl> functions) {
		this.declarationFunctions = functions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}

		
}
