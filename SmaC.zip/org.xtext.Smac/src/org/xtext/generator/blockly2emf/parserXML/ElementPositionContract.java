package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.ContractImpl;

public class ElementPositionContract {
	
	Element position;
	ArrayList<ContractImpl> contracts =  new ArrayList<ContractImpl>();
	
	public ArrayList<ContractImpl> getContracts() {
		return contracts;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setContract(ArrayList<ContractImpl> contracts) {
		this.contracts = contracts;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
