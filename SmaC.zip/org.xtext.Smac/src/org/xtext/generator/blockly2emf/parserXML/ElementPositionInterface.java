package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.InterfaceImpl;

public class ElementPositionInterface {
	
	Element position;
	ArrayList<InterfaceImpl> interfaces =  new ArrayList<InterfaceImpl>();
	Boolean finishGeneration = false;
	
	public ArrayList<InterfaceImpl> getInterfaces() {
		return this.interfaces;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setInterfaces(ArrayList<InterfaceImpl> interfaces) {
		this.interfaces = interfaces;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}	
	
}
