package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.eclipse.xtext.xtext.generator.parser.antlr.splitting.simpleExpressions.impl.ExpressionImpl;
import org.jdom2.Element;
import org.xtext.smaC.ComparationOperator;

public class ElementPositionComparationExpression {
	
	private Element position;
	private String value1expression = "";
	private String value2expression = "";
	private String totalExpression = "";
	private ComparationOperator operator;
	private ArrayList<String> expressions = new ArrayList<String>();
	
	public String getValue1expression() {
		return value1expression;
	}

	public void setValue1expression(String value1expression) {
		this.value1expression = value1expression;
	}

	public String getValue2expression() {
		return value2expression;
	}

	public void setValue2expression(String value2expression) {
		this.value2expression = value2expression;
	}

	public ComparationOperator getOperator() {
		return operator;
	}

	public void setOperator(ComparationOperator operator) {
		this.operator = operator;
	}
	
	public ArrayList<String> getExpressions() {
		return this.expressions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void addExpression(String actualElement) {
		this.expressions.add(actualElement);
	}
	
	public void setExpressions(ArrayList<String>listExpressions) {
		this.expressions = listExpressions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
	public String getTotalExpression() {
		return this.totalExpression;
	}
		
	public String buildTotalExpression(){
		return this.totalExpression = this.value1expression + " " + this.operator.toString()  + " " + this.value2expression;
	}
	
}
