package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.LibraryImpl;

public class ElementPositionLibrary {
	
	Element position;
	ArrayList<LibraryImpl> libraries = new ArrayList<LibraryImpl>();
	ArrayList<LibraryImpl> usingLibraries = new ArrayList<LibraryImpl>();
	
	public ArrayList<LibraryImpl> getUsingLibraries() {
		return usingLibraries;
	}

	public void setUsingLibraries(ArrayList<LibraryImpl> usingLibraries) {
		this.usingLibraries = usingLibraries;
	}

	public ArrayList<LibraryImpl> getLibraries() {
		return this.libraries;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setLibrary(LibraryImpl actualElement) {
		this.libraries.add(actualElement);
	}
	
	public void setLibraries(ArrayList<LibraryImpl> libraries) {
		this.libraries = libraries;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
