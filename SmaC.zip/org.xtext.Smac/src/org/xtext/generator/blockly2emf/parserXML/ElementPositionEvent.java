package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.EventImpl;

public class ElementPositionEvent {
	
	Element position;
	ArrayList<EventImpl> events = new ArrayList<EventImpl>();
	ArrayList<EventImpl> eventsExpressions = new ArrayList<EventImpl>();
	
	public void setEventExpressions(EventImpl eventExpressions) {
		this.eventsExpressions.addAll(eventsExpressions);
	}

	public void setEventsExpressions(ArrayList<EventImpl> eventsExpressions) {
		this.eventsExpressions = eventsExpressions;
	}

	public ArrayList<EventImpl> getEvents() {
		return this.events;
	}
	
	public ArrayList<EventImpl> getExpressionsEvents() {
		return this.eventsExpressions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setEvent(EventImpl actualElement) {
		this.events.add(actualElement);
	}
	
	public void setEvents(ArrayList<EventImpl>listEvents) {
		this.events = listEvents;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
