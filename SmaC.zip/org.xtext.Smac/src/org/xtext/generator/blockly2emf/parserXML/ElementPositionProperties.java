package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.PropertyBytes;
import org.xtext.smaC.PropertyUInteger;
import org.xtext.smaC.impl.EnumImpl;
import org.xtext.smaC.impl.EventImpl;
import org.xtext.smaC.impl.PropertiesImpl;
import org.xtext.smaC.impl.PropertyAddressImpl;
import org.xtext.smaC.impl.PropertyBooleanImpl;
import org.xtext.smaC.impl.PropertyBytesImpl;
import org.xtext.smaC.impl.PropertyFloatImpl;
import org.xtext.smaC.impl.PropertyIdentifierImpl;
import org.xtext.smaC.impl.PropertyIntegerImpl;
import org.xtext.smaC.impl.PropertyStringImpl;
import org.xtext.smaC.impl.PropertyUIntegerImpl;

public class ElementPositionProperties {
	
	Element position;
	ArrayList<PropertiesImpl> properties = new ArrayList<PropertiesImpl>();
	ArrayList<PropertyBytesImpl> bytesProperties = new ArrayList<PropertyBytesImpl>();
	ArrayList<PropertyUIntegerImpl> uintProperties = new ArrayList<PropertyUIntegerImpl>();
	ArrayList<PropertyIntegerImpl> intProperties = new ArrayList<PropertyIntegerImpl>();
	ArrayList<PropertyBooleanImpl> booleanProperties = new ArrayList<PropertyBooleanImpl>();
	ArrayList<PropertyIdentifierImpl> identifierProperties = new ArrayList<PropertyIdentifierImpl>();
	ArrayList<PropertyAddressImpl> addressProperties = new ArrayList<PropertyAddressImpl>();
	ArrayList<PropertyStringImpl> stringProperties = new ArrayList<PropertyStringImpl>();
	ArrayList<PropertyFloatImpl> floatProperties = new ArrayList<PropertyFloatImpl>();
	
	
	public ArrayList<PropertyUIntegerImpl> getUintProperties() {
		return uintProperties;
	}
	
	public void setUintProperty(PropertyUIntegerImpl actualElement) {
		this.uintProperties.add(actualElement);	
	}

	public void setUintProperties(ArrayList<PropertyUIntegerImpl> uintProperties) {
		this.uintProperties = uintProperties;
	}

	public ArrayList<PropertyIntegerImpl> getIntProperties() {
		return intProperties;
	}

	public void setIntegerProperty(PropertyIntegerImpl actualElement) {
		this.intProperties.add(actualElement);
	}
	
	public void setIntProperties(ArrayList<PropertyIntegerImpl> intProperties) {
		this.intProperties = intProperties;
	}

	public ArrayList<PropertyBooleanImpl> getBooleanProperties() {
		return booleanProperties;
	}

	public void setBooleanProperty(PropertyBooleanImpl actualElement) {
		this.booleanProperties.add(actualElement);
	}
	
	public void setBooleanProperties(ArrayList<PropertyBooleanImpl> booleanProperties) {
		this.booleanProperties = booleanProperties;
	}

	public ArrayList<PropertyIdentifierImpl> getIdentifierProperties() {
		return identifierProperties;
	}
	
	public void setIdentifierProperty(PropertyIdentifierImpl actualElement) {
		this.identifierProperties.add(actualElement);
	}

	public void setIdentifierProperties(ArrayList<PropertyIdentifierImpl> identifierProperties) {
		this.identifierProperties = identifierProperties;
	}

	public ArrayList<PropertyAddressImpl> getAddressProperties() {
		return addressProperties;
	}

	public void setAddressProperty(PropertyAddressImpl actualElement) {
		this.addressProperties.add(actualElement);
	}
	
	public void setAddressProperties(ArrayList<PropertyAddressImpl> addressProperties) {
		this.addressProperties = addressProperties;
	}

	public ArrayList<PropertyStringImpl> getStringProperties() {
		return stringProperties;
	}

	public void setStringProperty(PropertyStringImpl actualElement) {
		this.stringProperties.add(actualElement);
	}
	
	public void setStringProperties(ArrayList<PropertyStringImpl> stringProperties) {
		this.stringProperties = stringProperties;
	}

	public ArrayList<PropertyFloatImpl> getFloatProperties() {
		return floatProperties;
	}

	public void setFloatProperty(PropertyFloatImpl actualElement) {
		this.floatProperties.add(actualElement);
	}
	
	public void setFloatProperties(ArrayList<PropertyFloatImpl> floatProperties) {
		this.floatProperties = floatProperties;
	}

	public ArrayList<PropertiesImpl> getProperties() {
		return properties;
	}

	public void setProperties(ArrayList<PropertiesImpl> properties) {
		this.properties = properties;
	}
	
	public ArrayList<PropertyBytesImpl> getBytesProperties() {
		return this.bytesProperties;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setByteProperty(PropertyBytesImpl actualElement) {
		this.bytesProperties.add(actualElement);
	}
	
	public void setBytesProperties(ArrayList<PropertyBytesImpl>listBytesProperties) {
		this.bytesProperties = listBytesProperties;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
