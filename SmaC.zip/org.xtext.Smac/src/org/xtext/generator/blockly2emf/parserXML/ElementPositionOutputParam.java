package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.OutputParamImpl;

public class ElementPositionOutputParam {
	
	private Element position;
	private OutputParamImpl outputParam =  new OutputParamImpl();
	
	public OutputParamImpl getOutputParam() {
		return outputParam;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setOutputParam(OutputParamImpl outputParam){
		this.outputParam = outputParam;
	}

	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
