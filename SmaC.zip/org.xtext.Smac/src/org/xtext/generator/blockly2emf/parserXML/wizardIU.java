package org.xtext.generator.blockly2emf.parserXML;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;



public class wizardIU  extends JFrame {
	
	JProgressBar progress;
	int limitProgressBar = 1300;
	int numberContractsIdentified;
	int numberValueExchangesIdentified;
	int numberActorsIdentified;
	int progressContract;
	int progressFunction;
	int progressActor;
	
	public void createFrame() {
		
        getContentPane().setBackground(new Color(238, 232, 170));
        getContentPane().setLayout(new BorderLayout());
        JPanel panelCentral = new JPanel();
		panelCentral.setVisible(true);
	    // Add the progressBar to the frame
	    this.add(panelCentral,BorderLayout.CENTER);
        setTitle("E3Value transformation to SmaC");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Set the position of the progressBar
	    progress.setBounds(400,400,165,30);
	    // Initialize the progressBar to 0   
	    progress.setValue(0);  
	    // Show the progress string
	    progress.setStringPainted(true);  
	    // Add the progressBar to the frame
	    this.add(progress,BorderLayout.SOUTH);
        setVisible(true);
        setResizable(false);
        setSize(600, 450);         
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(dim.width / 2 - this.getWidth() / 2, dim.height / 2 - this.getHeight() / 2);
	}
	

	
	public int showDialogConfirm(String message) {
		  int input = JOptionPane.showConfirmDialog(this, 
	                message, "Select an Option...",JOptionPane.YES_NO_CANCEL_OPTION);
		  //0 es S�
		  //1 es NO y 2 es CANCELAR
		  return input;
	}
	
	public void showMessageInfo(String message) {
		IconoTest icon = new IconoTest(); 
		JOptionPane.showMessageDialog(this,message, "Info", JOptionPane.DEFAULT_OPTION, icon);
	}
	
	public int showInitialMessage(String message, boolean modelQAInput){
		String[] options = {"Start", "Cancel"};
		int initialOptions;
		IconoTest icon = new IconoTest(); 
		if(modelQAInput == false) {
			message += "Info: Includes a SmaCQA model (qa.extension) associated with value exchanges," + "\n" + " the transformation process will generate more % of the SmaC model (smart contract).";
			initialOptions = JOptionPane.showOptionDialog(this,message, "Transformation process e3value model -> SmaC model", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, icon, options, options[0]);
		}
		else {
			initialOptions = JOptionPane.showOptionDialog(this,message, "Transformation process e3value model + SmaCQA model + -> SmaC model", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, icon, options, options[0]);			
		}
		return initialOptions;		
	}


	
}
