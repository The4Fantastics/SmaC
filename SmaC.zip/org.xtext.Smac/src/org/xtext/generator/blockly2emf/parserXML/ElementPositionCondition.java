package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.ConditionImpl;


public class ElementPositionCondition {
	
	Element position;
	ArrayList<ConditionImpl> conditions = new ArrayList<ConditionImpl>();
	
	public ArrayList<ConditionImpl> getConditions() {
		return this.conditions;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setCondition(ConditionImpl actualElement) {
		this.conditions.add(actualElement);
	}
	
	public void setConditions(ArrayList<ConditionImpl>listConditions) {
		this.conditions = listConditions;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
