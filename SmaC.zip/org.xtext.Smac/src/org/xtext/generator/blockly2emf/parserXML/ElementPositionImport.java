package org.xtext.generator.blockly2emf.parserXML;

import java.util.ArrayList;

import org.jdom2.Element;
import org.xtext.smaC.impl.ImportImpl;

public class ElementPositionImport {
	
	Element position;
	ArrayList<ImportImpl> imports =  new ArrayList<ImportImpl>();
	
	public ArrayList<ImportImpl> getImports() {
		return this.imports;
	}
	
	public Element getPosition() {
		return position;
	}
	
	public void setImport(ImportImpl actualElement) {
		this.imports.add(actualElement);
	}
	
	public void setImports(ArrayList<ImportImpl> listImports) {
		this.imports = listImports;
	}
	
	public void setPosition(Element position) {
		this.position = position;
	}
	
}
