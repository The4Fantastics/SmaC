package org.xtext.generator;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.io.*;
import java.io.File;
///////

import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.mwe2.language.Mwe2StandaloneSetup;
import org.eclipse.ui.contexts.IContext;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.NullProgressMonitor;

//////

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.xtext.builder.EclipseResourceFileSystemAccess2;
import org.eclipse.xtext.generator.AbstractGenerator;
import org.eclipse.xtext.generator.IFileSystemAccess;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.resource.IResourceFactory;
import org.eclipse.xtext.resource.SaveOptions;
import org.eclipse.xtext.resource.XtextResource;
import org.eclipse.xtext.resource.XtextResourceSet;
import org.eclipse.xtext.serializer.impl.Serializer;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.xtext.SmaCRuntimeModule;
import org.xtext.SmaCStandaloneSetup;
import org.xtext.generator.blockly2emf.parserXML.ElementPositionAbstractContract;
import org.xtext.generator.blockly2emf.parserXML.ElementPositionContract;
import org.xtext.generator.blockly2emf.parserXML.ElementPositionImport;
import org.xtext.generator.blockly2emf.parserXML.ElementPositionInterface;
import org.xtext.generator.blockly2emf.parserXML.ElementPositionLibrary;
import org.xtext.generator.blockly2emf.parserXML.GeneratorAbstractContract;
import org.xtext.generator.blockly2emf.parserXML.GeneratorContract;
import org.xtext.generator.blockly2emf.parserXML.GeneratorFile;
import org.xtext.generator.blockly2emf.parserXML.GeneratorImport;
import org.xtext.generator.blockly2emf.parserXML.GeneratorInterface;
import org.xtext.generator.blockly2emf.parserXML.GeneratorLibrary;
import org.xtext.generator.blockly2emf.parserXML.INameIdentifiersBlockly;
import org.xtext.*;
import org.xtext.smaC.AbstractContract;
import org.xtext.smaC.Clause;
import org.xtext.smaC.Contract;
import org.xtext.smaC.Import;
import org.xtext.smaC.Library;
import org.xtext.smaC.SmaCFactory;
import org.xtext.smaC.SmaCPackage;
import org.xtext.smaC.Version;
import org.xtext.smaC.impl.FileImpl;
import org.xtext.smaC.impl.ImportImpl;
import org.xtext.smaC.impl.InterfaceImpl;
import org.xtext.smaC.impl.LibraryImpl;
import org.xtext.smaC.impl.SmaCFactoryImpl;
import org.xtext.smaC.impl.VersionImpl;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Provider;


public class SmaclyToSmaC implements INameIdentifiersBlockly{
	
	private FileImpl file;
	private VersionImpl version;
	private LibraryImpl library;
	private static boolean existLibrary = false;
	private static boolean finishLibrary = false;
	private JFrame frame;
	private String nameFile = "";
	private IGeneratorContext context;
	private IProject proyecto;		
	public SmaclyToSmaC() {
		
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}


	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}


	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}


	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}


	public void readXml(File file, IGeneratorContext context2, IProject project) throws IOException  {
		proyecto = project;
		context = context2;
		File inputFile =  file;
        SAXBuilder saxBuilder = new SAXBuilder();
        Document document = null;
		try {
			document = saxBuilder.build(inputFile);
		} catch (JDOMException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println("Root element :" + document.getRootElement().getName());
        if(document.getRootElement().toString().contains(ROUTE_BLOCKLY)){
            nameFile = inputFile.getName().replace(".xml","");
            Element classElement = document.getRootElement();
         	List<Element> nodeList = classElement.getChildren();//OBTENEMOS NODO BLOCK_FILE QUE ES EL HIJO DEL NODO ROOT XML
         	nodeList = nodeList.get(0).getChildren();//OBTENEMOS LOS HIJOS DEL NODO BLOCK_FILE
         	System.out.println("----------------------------");
         	identifyPropertiesFile(nodeList,nameFile);    
	    }
        else{
		  JOptionPane.showMessageDialog(frame, "You don't choose Blockly xml file", "Error",JOptionPane.ERROR_MESSAGE);
	    }
	
	}
	

	private void identifyPropertiesFile(List<Element> nodeList,String nameFile) throws IOException{		
		GeneratorFile generatorFile = new GeneratorFile();
		file = generatorFile.createFile(); 
		//createEMFModel();
		FileWriter fichero = null;
		for(Element nodeHijo : nodeList) {
			String valueAtributoType = nodeHijo.getAttributes().get(0).getValue();
			if(valueAtributoType.equals(VALUE_VERSION)){
				Element nodeVersion = nodeHijo.getChildren().get(0);
				if(nodeVersion.getAttributes().get(0).getValue().toString().equals(BLOCK_VERSION) || nodeVersion.getAttributes().get(0).getValue().toString().equals(BLOCK_RANGE_VERSION)){
					version = this.generateVersion(nodeVersion);
					file.setVersion(version);					
				}	
			}
			else if(valueAtributoType.equals(STATEMENT_ELEMENTS_FILE)){
				identifyElementsFile(nodeHijo.getChildren());
			}
		}
		createXMI(nameFile);
		Resource resource = createVirtualXtextResource(file);
		GenerateXtextModel generateXtextModel = new GenerateXtextModel();
		Provider<IFileSystemAccess2> fileAccessProvider = new Provider<IFileSystemAccess2>() {
			
			@Override
			public EclipseResourceFileSystemAccess2 get() {
				// TODO Auto-generated method stub
				return new EclipseResourceFileSystemAccess2();
			}
		};
		EclipseResourceFileSystemAccess2 fsa = (EclipseResourceFileSystemAccess2) fileAccessProvider.get();
		fsa.setOutputPath("Smart Contract-src-generated");
        fsa.setProject(proyecto);
        fsa.setMonitor(new NullProgressMonitor());
		generateXtextModel.doGenerate(resource,fsa,context);
	}

	/*
	 * Par�metro de entrada: Ninguno
	 * Descripci�n de la funci�n: Crea un objeto VersionImpl()
	 * Par�metro de salida: Devuelve un objeto VersionImpl
	 */	
	private VersionImpl createVersion(){
		VersionImpl version = new VersionImpl();
		return version;
		
	}
	
	/*
	 * Par�metro de entrada: El nodo field operator de una expresi�n bitwise o de una expresi�n bitwise input.
	 * Descripci�n de la funci�n: Analiza el valor del campo field operator para saber que tipo de operador tiene la expresi�n bitwise o de una expresi�n bitwise input.
	 * Par�metro de salida: Devuelve un string con el s�mbolo del operador
	 */
	public VersionImpl generateVersion(Element node){
		List<Element>nodeList = node.getChildren();
		VersionImpl version = createVersion();
		String symbolComparation = null;
		String numVersion1 = null,numVersion2 = null,numVersion3 = null,numVersionOptional1 = "0",numVersionOptional2 = "0",numVersionOptional3 = "0";
		for(Element nodeHijoVersion: nodeList){
			if(nodeHijoVersion.getChildren().size() <= 0){
				String valorAtributo = nodeHijoVersion.getAttributes().get(0).getValue();
				if(valorAtributo.equals(FIELD_SYMBOLVERSION)){
					version.setSymbol(nodeHijoVersion.getText());
				}
				if(valorAtributo.equals(FIELD_VALUE1VERSION)){
					numVersion1 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE2VERSION)){
					numVersion2 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE3VERSION)){
					numVersion3 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_SYMBOLCOMPARATION)){
					symbolComparation =  nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE1VERSION_OPTIONAL)){
					numVersionOptional1 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE2VERSION_OPTIONAL)){
					numVersionOptional2 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE3VERSION_OPTIONAL)){
					numVersionOptional3 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_SYMBOLCOMPARATION)){
					version.setSymbol(nodeHijoVersion.getText());
				}
				if(valorAtributo.equals(FIELD_VALUE1)){
					numVersion1 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE2)){
					numVersion2 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE3)){
					numVersion3 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_SYMBOLCOMPARATION)){
					symbolComparation =  nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE1_OPTIONAL)){
					numVersionOptional1 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE2_OPTIONAL)){
					numVersionOptional2 = nodeHijoVersion.getText();
				}
				if(valorAtributo.equals(FIELD_VALUE3_OPTIONAL)){
					numVersionOptional3 = nodeHijoVersion.getText();
				}
			}
		}
		version.setNumberVersion(numVersion1 + '.' + numVersion2 + '.' + numVersion3);
		if(!(numVersionOptional1.equals("0") && numVersionOptional2.equals("0") && numVersionOptional3.equals("0"))) {//CASO DE QUE SE HAYA ESPECIFICADO QUE EL SMART CONTRACT HA DE COMPILARSE ENTRE DOS VERSIONES
			version.setSymbolComparation(symbolComparation);
			version.setNumberVersion2(numVersionOptional1 + '.' + numVersionOptional2 + '.' + numVersionOptional3);
		}
		return version;
	} 
	
	
	/*
	 * Par�metro de entrada: Los hijos del nodo statement_file
	 * Descripci�n de la funci�n: Analiza el valor de los atributos para ir sacando cada parte del fichero
	 * Par�metro de salida: Devuelve un string con el s�mbolo del operador
	 */
	private void identifyElementsFile(List<Element>nodeList){
		String atributoType = "";
		String valueAtributoType = "";
		ElementPositionLibrary elementPositionLibrary = null;
		ElementPositionImport elementPositionImport = null;
		ElementPositionInterface elementPositionInterface = new ElementPositionInterface();
		ElementPositionAbstractContract elementPositionAsbtractContract = null;
		ElementPositionContract elementPositionContract = null;
		for(Element nodeHijo:nodeList) {
			if(!nodeHijo.getName().equals(NEXT)){
				atributoType = nodeHijo.getAttributes().get(0).getName();
				valueAtributoType = nodeHijo.getAttributes().get(0).getValue();
				if(valueAtributoType.equals(BLOCK_LIBRARY)){
					GeneratorLibrary generatorLibrary = new GeneratorLibrary();
					elementPositionLibrary = generatorLibrary.generateLibrary(nodeHijo);
					for(Library libraryFile : elementPositionLibrary.getLibraries()) {
						file.getLibrary().add(libraryFile);
					}
					this.identifyElementsFile(elementPositionLibrary.getPosition().getChildren());
					break;
				}
				else if(valueAtributoType.toString().equals(BLOCK_INTERFACE)){ 
					GeneratorInterface generatorInterface = new GeneratorInterface();
					elementPositionInterface = generatorInterface.generateInterface(nodeHijo);
					for(InterfaceImpl interfaceImpl : elementPositionInterface.getInterfaces()) {
						file.getInterfaces().add(interfaceImpl);
					}
					if(elementPositionInterface.getPosition() != null){//HAY + ELEMENTOS DESPU�S DE LA INTERFAZ
						this.identifyElementsFile(elementPositionInterface.getPosition().getChildren());
						break;
					}	
				}	
				else if(valueAtributoType.toString().equals(BLOCK_IMPORT)){ 
					GeneratorImport generatorImport = new GeneratorImport();
					elementPositionImport = generatorImport.generateImports(nodeHijo);
					for(Import importImpl : elementPositionImport.getImports()) {
						file.getImports().add(importImpl);
					}
					this.identifyElementsFile(elementPositionImport.getPosition().getChildren());
					break;
				}	
				else if(valueAtributoType.equals(BLOCK_ABSTRACT_CONTRACT)){
					GeneratorAbstractContract generatorAbstractContract = new GeneratorAbstractContract();
					elementPositionAsbtractContract = generatorAbstractContract.generateContract(nodeHijo,file);
					for(AbstractContract contract : elementPositionAsbtractContract.getContracts()) {
						file.getAbstractContracts().add(contract);
					}
					break;
				}
				else if(valueAtributoType.equals(BLOCK_CONTRACT)){
					GeneratorContract generatorContract = new GeneratorContract();
					elementPositionContract = generatorContract.generateContract(nodeHijo,file);
					for(Contract contract : elementPositionContract.getContracts()) {
						file.getContracts().add(contract);
					}
					break;
				}
			}			
		}
	}
	
	
	
	
	/*
	 * Par�metro de entrada: Ninguno
	 * Descripci�n de la funci�n: Coge el fichero con todos los elementos del smart contract y crea un resource junto con la direcci�n URI que ponemos para generar un archivo XMI legible por SmaC
	 * Par�metro de salida: Ninguno
	 */
	private void createXMI(String nameFile){
		SmaCFactory factory = SmaCFactory.eINSTANCE;
	    // Register the XMI resource factory for the .sce extension
        Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
        Map<String, Object> diccionario = reg.getExtensionToFactoryMap();
        diccionario.put("sce", new SmaCFactoryImpl());
        // Obtain a new resource set
        ResourceSet resSet = new ResourceSetImpl();
        // create a resource
        System.out.println("Nombre del fichero: " + nameFile);
        Resource resource = resSet.createResource(URI
                .createURI("nuevaGeneracion/" + nameFile + ".xmi"));
        // Get the first model element and cast it to the right type, in my
        // example everything is hierarchical included in this first node
        resource.getContents().add(file);   
        // now save the content.
        
        Injector injector =  new SmaCStandaloneSetup().createInjectorAndDoEMFRegistration();
	    XtextResourceSet resourceSet = injector.getInstance(XtextResourceSet.class);
        
        
        try {
        	resource.save(diccionario);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
	}
	


	
	private XtextResource createVirtualXtextResource(EObject semanticElement) throws IOException {
		Injector xtextInjector = new SmaCStandaloneSetup().createInjectorAndDoEMFRegistration();
		IResourceFactory resourceFactory = xtextInjector.getInstance(IResourceFactory.class);
		XtextResourceSet rs = xtextInjector.getInstance(XtextResourceSet.class);
		rs.setClasspathURIContext(getClass());
		// Create virtual resource
		XtextResource xtextVirtualResource = (XtextResource) resourceFactory
				.createResource(URI
		                .createURI("nuevaGeneracion/" + nameFile + ".sce"));
		rs.getResources().add(xtextVirtualResource);

		// Populate virtual resource with the given semantic element to edit
		xtextVirtualResource.getContents().add(semanticElement);

		// Save and reparse in order to initialize virtual Xtext resource
//		ByteArrayOutputStream out = new ByteArrayOutputStream();
//		xtextVirtualResource.save(out, Collections.emptyMap());
//		xtextVirtualResource.reparse(new String(out.toByteArray()));
		//xtextVirtualResource.save(null);
		return xtextVirtualResource;
	}

	
	


}  

	