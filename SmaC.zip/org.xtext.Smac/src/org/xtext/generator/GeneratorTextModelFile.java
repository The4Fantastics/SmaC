package org.xtext.generator;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.UUID;

import javax.swing.JFileChooser;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.xtext.SmaCStandaloneSetup;
import org.xtext.smaC.DoWhileLoop;
import org.xtext.smaC.MappingDeclaration;
import org.xtext.smaC.Restriction;
import org.xtext.smaC.RestrictionClause;
import org.xtext.smaC.RestrictionGas;
import org.xtext.smaC.SmaCFactory;
import org.xtext.smaC.UnDeterminedLoop;
import org.xtext.smaC.WhileLoop;

public class GeneratorTextModelFile {

	GenerateXtextModel generator;
	
	/*
	 * Par�metro de entrada: El contenido textual obtenido de los elementos del modelo mediante Xtend
	 * Descripci�n: Creaci�n de un fichero de texto y escritura del contenido
	 * Par�metro de salida: El resource generado
	 * */
	public Resource createFile(String content,String path) {		
		
		try {
		    //Creaci�n de un fichero
		    File temp = File.createTempFile("nuevoFichero" + UUID.randomUUID(), ".sce"); 	
		    //createSelectorDirectory();
		    File fichero = new File(path);//Nombre del fichero
		    URI uri = URI.createFileURI(temp.getAbsolutePath());		
		    BufferedWriter bw = new BufferedWriter(new FileWriter(temp));
		    if (!fichero.exists()) {
		    	fichero.createNewFile();
            }
		    else {
		    	fichero.delete();
		    	fichero.createNewFile();
		    }
		    FileWriter escribir = new FileWriter(fichero, true);
		    BufferedWriter bw1 = new BufferedWriter(escribir);
		    bw.write(content);
		    bw.close();
		    bw1.write(content);
		    bw1.close();
		    // second load the resource	
		    SmaCStandaloneSetup.doSetup();	
		    temp.toString();
		    Resource res = new ResourceSetImpl().getResource(uri, true);	
		    return res;
		}
		
		catch (IOException e) {
		     System.err.println("Error loading MML model");
		     return null ; 
		}	   
		
		
	}
	
	/*
	 * Par�metro de entrada: La restriction clause para ser identificada y casteada
	 * Descripci�n: Seg�n el tipo de restricci�n que sea la castea y llama a su correspondiente funci�n para generar el texto
	 * Par�metro de salida : Ninguno
	 * */
	public String generateRestriction(RestrictionClause restriction,GenerateXtextModel inputXtextModelgenerator){
		String restriccion = "";
		if(restriction.eClass().getName().equals("Restriction")){
			Restriction res =  (Restriction) restriction;
			if(res.getMessage() == null) {
				restriccion = "require("   + res.getExpr1() + " " + res.getOperator().toString() + " " + res.getExpr2() + ")";
			}
			else {
				restriccion = "require("   + res.getExpr1() + " " + res.getOperator().toString() + " " + res.getExpr2() +  ", '" + res.getMessage()  + "')";
			}
		}
		else{
			RestrictionGas res =  (RestrictionGas) restriction;
			if(res.getMessage() == null) {
				restriccion = "require("   + res.getExpr1() + " " + res.getOperator().toString() + " " + res.getAmount() + " " + res.getTypeCoin().getLiteral() + ")";
			}
			else {
				restriccion = "require("   + res.getExpr1() + " " + res.getOperator().toString()  + " " + res.getAmount() + " " + res.getTypeCoin().getLiteral() + ", '" + res.getMessage()  + "')";
			}
		}
		return restriccion;
	}
	
	/*
	 * Par�metro de entrada: La restriction clause para ser identificada y casteada
	 * Descripci�n: Seg�n el tipo de restricci�n que sea la castea y llama a su correspondiente funci�n para generar el texto
	 * Par�metro de salida : Ninguno
	 * */
	public String generateMappingDeclaration(MappingDeclaration mapping){
		String mappingDeclaration = "";
		if(mapping.getValueIdentifier() != null) {
			mappingDeclaration += "mappin "  + mapping.getKey() +  " => " + generateMappingDeclaration(mapping.getValueIdentifier());
		}
		else{
			if(mapping.getArray() != null) {
				mappingDeclaration += "mapping "  + mapping.getKey() +  " => " + mapping.getValue().toString() +  " " + mapping.getArray().toString();
			}
			else {
				mappingDeclaration += "mapping "  + mapping.getKey() +  " => " + mapping.getValue().toString();				
			}
		}
		return mappingDeclaration;
	}
	

	/*
	 * Par�metro de entrada:El bucle no determinista que puede ser un while o un dowhile
	 * Descripci�n: Seg�n el tipo de bucle que sea lo castea y llama a su correspondiente funci�n para generar el texto
	 * Par�metro de salida : Ninguno
	 * */
	public void generateLoop(UnDeterminedLoop loop,GenerateXtextModel inputXtextModelgenerator) {
		if(loop.eClass().getName().equals("WhileLoop")){
			WhileLoop whileLoop = (WhileLoop) loop;
			generator.generateWhile(whileLoop);
		}
		else{
			DoWhileLoop doWhileLoop = (DoWhileLoop) loop;
			generator.generateDoWhile(doWhileLoop);
		}
	}


	private String createSelectorDirectory() {
		JFileChooser selectorCarpeta = new JFileChooser();
		selectorCarpeta.setCurrentDirectory(new File("."));
		selectorCarpeta.setDialogTitle("Choose directory to save the new files");
		selectorCarpeta.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		selectorCarpeta.setAcceptAllFileFilterUsed(false);
		int valor = 1;
		String ruta = "";
		while(valor != JFileChooser.APPROVE_OPTION){
			valor = selectorCarpeta.showOpenDialog(selectorCarpeta);
	        if (valor == JFileChooser.APPROVE_OPTION) {
	            ruta = selectorCarpeta.getSelectedFile().getAbsolutePath();                                        
	        } else {
	            System.out.println("No se ha seleccionado ning�n directorio");
	        }
		}
	    String carpetaSeleccionada = ruta;
		return carpetaSeleccionada;
	}
	
}