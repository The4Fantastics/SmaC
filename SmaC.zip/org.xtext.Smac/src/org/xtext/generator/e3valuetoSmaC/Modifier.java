package org.xtext.generator.e3valuetoSmaC;

public class Modifier {
	
	String name;//Nombre del modificador
	String message;//Mensaje
	String condition;//Condici�n
	Function functionAssociated;//Funci�n a la que va asociada este modificador
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public Function getFunctionAssociated() {
		return functionAssociated;
	}
	public void setFunctionAssociated(Function functionAssociated) {
		this.functionAssociated = functionAssociated;
	}
	
}
