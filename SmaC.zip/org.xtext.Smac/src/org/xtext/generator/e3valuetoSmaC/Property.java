package org.xtext.generator.e3valuetoSmaC;

import java.util.Date;

public class Property {
	
	
	private String name;
	private String type;
	private int dimension;
	private String initialization;
	private String comment = "";
	

	public String getInitialization() {
		return initialization;
	}


	public void setInitialization(String initialization) {
		this.initialization = initialization;
	}


	public Property() {

	}

	
	public Property(String name, String type, int dimension) {
		this.name = name;
		this.type =  type;
		this.dimension = dimension;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getDimension() {
		return dimension;
	}

	public void setDimension(int dimension) {
		this.dimension = dimension;
	}

	@Override
	public String toString() {
		return "Property [name=" + name + ", type=" + type + ", dimension=" + dimension + "]";
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
}
