package org.xtext.generator.e3valuetoSmaC;

import java.util.ArrayList;

import e3Value.BusinessActor;

public class ContractPersonalized {

	BusinessActor actor_x;
	int idActor_x;
	BusinessActor actor_y;
	int idActor_y;
	private ArrayList<ValueExchangePersonalized> valueExchanges = new ArrayList<ValueExchangePersonalized>();
	private ArrayList<TokenValueObject> tokensContract = new ArrayList<TokenValueObject>();
	
	public BusinessActor getActor_x() {
		return actor_x;
	}

	public void setActor_x(BusinessActor actor_x) {
		this.actor_x = actor_x;
	}

	public BusinessActor getActor_y() {
		return actor_y;
	}

	public void setActor_y(BusinessActor actor_y) {
		this.actor_y = actor_y;
	}	

	public int getIdActor_x() {
		return idActor_x;
	}

	public void setIdActor_x(int idActor_x) {
		this.idActor_x = idActor_x;
	}

	public int getIdActor_y() {
		return idActor_y;
	}

	public void setIdActor_y(int idActor_y) {
		this.idActor_y = idActor_y;
	}

	public ArrayList<ValueExchangePersonalized> getValueExchanges() {
		return valueExchanges;
	}

	public void setValueExchanges(ArrayList<ValueExchangePersonalized> valueExchanges) {
		this.valueExchanges = valueExchanges;
	}
	
	public void addValueExchange(ValueExchangePersonalized valueExchange) {
		this.valueExchanges.add(valueExchange);
	}
	
	public boolean isValueExchangeRegistered(ValueExchangePersonalized valueExchange){
		return this.valueExchanges.contains(valueExchange);
	}

	public ArrayList<TokenValueObject> getTokensContract() {
		return tokensContract;
	}

	public void setTokensContract(ArrayList<TokenValueObject> tokensContract) {
		this.tokensContract = tokensContract;
	}
	
}
