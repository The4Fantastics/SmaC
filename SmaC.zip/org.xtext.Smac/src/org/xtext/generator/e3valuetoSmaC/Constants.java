package org.xtext.generator.e3valuetoSmaC;

import java.util.ArrayList;

public class Constants {
	
	 final String TYPE_UINT = "uint";
	 final String TYPE_STRING = "string";
	 final String TYPE_ADDRESS = "address ";
	 final String TYPE_BOOLEAN = "bool";
	 final String TYPE_BYTES = "bytes";
	 final String ANSWER_YES = "yes";
	 final String ANSWER_NO = "no";
	 final String SMAC_KEYWORD_PRAGMA = "pragma";
	 final String SMAC_KEYWORD_AS = "as";
	 final String SMAC_KEYWORD_INTERFACE = "interface";
	 final String SMAC_KEYWORD_IMPORT = "import";
	 final String SMAC_KEYWORD_LIBRARY = "library";
	 final String SMAC_KEYWORD_CONTRACT = "contract";
	 final String SMAC_KEYWORD_CONSTRUCTOR = "constructor";
	 final String SMAC_KEYWORD_IS = "is";
	 final String SMAC_KEYWORD_EMIT = "emit";
	 final String SMAC_KEYWORD_FUNCTION = "function";
	 final String SMAC_KEYWORD_MODIFIER = "modifier";
	 final String SMAC_KEYWORD_EVENT = "event";
	 final String SMAC_KEYWORD_ADDRESS = "address";
	 final String SMAC_KEYWORD_UINT= "uint";
	 final String SMAC_KEYWORD_INT = "int";
	 final String SMAC_KEYWORD_BOOLEAN = "bool";
	 final String SMAC_KEYWORD_MAPPING = "mapping";
	 final String SMAC_KEYWORD_PAYABLE = "payable";
	 final String SMAC_KEYWORD_PUBLIC = "public";
	 final String SMAC_KEYWORD_PRIVATE = "private";
	 final String SMAC_KEYWORD_INTERNAL = "internal";
	 final String SMAC_KEYWORD_EXTERNAL = "external";
	 final String SMAC_KEYWORD_VIRTUAL = "virtual";
	 final String SMAC_KEYWORD_OVERRIDE = "override";
	 final String SMAC_KEYWORD_SHA = "sha";
	 final String SMAC_KEYWORD_ABYENCODE = "aby.encode";
	 final String SMAC_KEYWORD_REVERT = "revert";
	 final String SMAC_KEYWORD_SELFDESTRUCT = "selfdestruct";
	 final String SMAC_KEYWORD_MSGSENDER = "msg.sender";
	 final ArrayList<String> keywords = new ArrayList<String>();
	 
	 public Constants(){
		 keywords.add(SMAC_KEYWORD_PRAGMA);
		 keywords.add(SMAC_KEYWORD_AS);
		 keywords.add(SMAC_KEYWORD_INTERFACE);
		 keywords.add(SMAC_KEYWORD_IMPORT);
		 keywords.add(SMAC_KEYWORD_LIBRARY);
		 keywords.add(SMAC_KEYWORD_CONTRACT);
		 keywords.add(SMAC_KEYWORD_CONSTRUCTOR);
		 keywords.add(SMAC_KEYWORD_IS);
		 keywords.add(SMAC_KEYWORD_EMIT);
		 keywords.add(SMAC_KEYWORD_FUNCTION);
		 keywords.add(SMAC_KEYWORD_MODIFIER);
		 keywords.add(SMAC_KEYWORD_EVENT);
		 keywords.add(SMAC_KEYWORD_ADDRESS);
		 keywords.add(SMAC_KEYWORD_UINT);
		 keywords.add(SMAC_KEYWORD_INT);
		 keywords.add(SMAC_KEYWORD_BOOLEAN);
		 keywords.add(SMAC_KEYWORD_MAPPING);
		 keywords.add(SMAC_KEYWORD_PAYABLE);
		 keywords.add(SMAC_KEYWORD_PUBLIC);
		 keywords.add(SMAC_KEYWORD_PRIVATE);
		 keywords.add(SMAC_KEYWORD_INTERNAL);
		 keywords.add(SMAC_KEYWORD_EXTERNAL);
		 keywords.add(SMAC_KEYWORD_VIRTUAL);
		 keywords.add(SMAC_KEYWORD_OVERRIDE);
		 keywords.add(SMAC_KEYWORD_SHA);
		 keywords.add(SMAC_KEYWORD_ABYENCODE);
		 keywords.add(SMAC_KEYWORD_REVERT);
		 keywords.add(SMAC_KEYWORD_SELFDESTRUCT);
		 keywords.add(SMAC_KEYWORD_MSGSENDER);
	 }
	 
	 
	 public boolean isKeyword(String keyword) {
		 boolean enc = false;
		 for(String keywordRegistered : keywords) {
			 if(keyword.toString().equals(keywordRegistered.toString())) {
				 enc = true;
				 break;
			 }
		 }
		 return enc;
	 }

	
	
}
