package org.xtext.generator.e3valuetoSmaC;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;



public class wizardIU  extends JFrame {
	
	Constants constants = new Constants();
	JProgressBar progress;
	int limitProgressBar = 1300;
	int numberContractsIdentified;
	int numberValueExchangesIdentified;
	int numberActorsIdentified;
	int progressContract;
	int progressFunction;
	int progressActor;
	
	public void createFrame(ArrayList<ContractPersonalized>contractsIdentified) {
		
        getContentPane().setBackground(new Color(238, 232, 170));
        getContentPane().setLayout(new BorderLayout());
        JPanel panelCentral = new JPanel();
		JLabel label = new JLabel("Central");
		panelCentral.add(label);
		panelCentral.setVisible(true);
	    // Add the progressBar to the frame
	    this.add(panelCentral,BorderLayout.CENTER);
        setTitle("E3Value transformation to SmaC");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        progress = new JProgressBar(0,limitProgressBar);// Create the progressBar
        // Set the position of the progressBar
	    progress.setBounds(400,400,165,30);
	    // Initialize the progressBar to 0   
	    progress.setValue(0);  
	    // Show the progress string
	    progress.setStringPainted(true);  
	    // Add the progressBar to the frame
	    this.add(progress,BorderLayout.SOUTH);
        setVisible(true);
        setResizable(false);
        setSize(600, 450);    
        numberContractsIdentified = contractsIdentified.size();
        for(ContractPersonalized contractIdentified : contractsIdentified) {
            numberValueExchangesIdentified += contractIdentified.getValueExchanges().size();
            numberActorsIdentified += 2;
        }
	    createPorcentajeProgressBar();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(dim.width / 2 - this.getWidth() / 2, dim.height / 2 - this.getHeight() / 2);
	}
	
	public void createPorcentajeProgressBar() {
		 progressContract = (limitProgressBar-100) / numberContractsIdentified;
		 progressFunction = progressContract / numberValueExchangesIdentified;
		 progressActor = progressFunction / 2;
	}
	
	
	public int showDialogConfirm(String message) {
		  int input = JOptionPane.showConfirmDialog(this, 
	                message, "Select an Option...",JOptionPane.YES_NO_CANCEL_OPTION);
		  //0 es S�
		  //1 es NO y 2 es CANCELAR
		  return input;
	}
	
	public void showMessageInfo(String message) {
		IconoTest icon = new IconoTest(); 
		JOptionPane.showMessageDialog(this,message, "Info", JOptionPane.DEFAULT_OPTION, icon);
	}
	
	public int showInitialMessage(String message, boolean modelQAInput){
		String[] options = {"Start", "Cancel"};
		int initialOptions;
		IconoTest icon = new IconoTest(); 
		if(modelQAInput == false) {
			message += "Info: Includes a SmaCQA model (qa.extension) associated with value exchanges," + "\n" + " the transformation process will generate more % of the SmaC model (smart contract).";
			initialOptions = JOptionPane.showOptionDialog(this,message, "Transformation process e3value model -> SmaC model", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, icon, options, options[0]);
		}
		else {
			initialOptions = JOptionPane.showOptionDialog(this,message, "Transformation process e3value model + SmaCQA model + -> SmaC model", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, icon, options, options[0]);			
		}
		return initialOptions;		
	}

	public String generateJPanelVersion(){
		String[] options = {"Versions Range", "Prefixed Version"};
		IconoTest icon = new IconoTest(); 
	    int numberVersions = JOptionPane.showOptionDialog(this, "It's necessary to specify the compiler version in the smart contract." + "\n"
	                + "Do you want to set a range of versions that you can compile between or do you prefer a specific version?", "Select Compiler Solidity Version", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
	    System.out.print("NumberVersions: " + numberVersions);
	    JPanel newPanel = new JPanel(new GridBagLayout());
	    newPanel.setSize(200, 200);
		JLabel labelVersion= new JLabel("Compiler Version");
	    JTextField textVersion = new JTextField(20);
	    labelVersion.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
	    textVersion.setFont(new java.awt.Font("Arial", Font.PLAIN | Font.BOLD, 12));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);
        // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = 0;     
        newPanel.add(labelVersion, constraints);
        constraints.gridx = 1;
        newPanel.add(textVersion, constraints);  
        String version = "";
        JTextField textVersion2 = new JTextField(7);
        boolean versionOk = false;
        boolean versionOk1 = false;
        boolean versionOk2 = false;
        boolean createdPanel = false;
        while(versionOk == false) {
	        if(numberVersions == 1) { 
	        	if(createdPanel == false) {
			        constraints.gridx = 0;
			        constraints.gridy = 2;
			        constraints.gridwidth = 2;
			        constraints.anchor = GridBagConstraints.CENTER;
			        JButton button = new JButton("Tooltip about define version");
			        button.addActionListener(new ActionListener() {
			            @Override
			            public void actionPerformed(ActionEvent event) { 
			            	 JOptionPane pane = new JOptionPane();
			            	 pane.setSize(200,200);
			            	 JOptionPane.showMessageDialog(null,"This statement specifies the version of the compiler in which the contract is to be compiled." + "\n" 
			            			+ "The version's format is x1.x2.x3 (Dots are required) where:\n" + 
			            			"\r" + "x1 is 0" + "\n" + 
			            			"\r" + "x2 is a number between 0 and 9" + "\n" +
			            			"\r" + "x3 is a number between 0 and 25" + "\n" +
			            	 		" It is necessary to check if some of the logic defined in the smart contract is not supported for the specified compiler version.");
			            }
			        });       
			        newPanel.add(button, constraints);
			        newPanel.setBorder(BorderFactory.createTitledBorder(
			                BorderFactory.createEtchedBorder(), "Insert Smart Contract Compiler Version"));
			        newPanel.setVisible(true);
			        createdPanel = true;
	        	}
		        JOptionPane.showConfirmDialog(null, newPanel, 
		                "Compiler Version", JOptionPane.PLAIN_MESSAGE);  
		        versionOk = checkVersionContract(textVersion.getText());
		        if(versionOk == true) {
		        	progress.setValue(progress.getValue()+100);
		        	version =  "^" + textVersion.getText();
	        	}
		        else {
		        	  JOptionPane.showMessageDialog(null, "Invalid version", "Error Message",
		                        JOptionPane.ERROR_MESSAGE);
		        }
    		}else {
    			if(createdPanel == false) {
		            constraints.gridx = 0;
		            constraints.gridy = -1;
		            labelVersion.setText("Compiler Version Range Start");
		        	JLabel labelVersion2= new JLabel("Compiler Version Range End");
		    	    newPanel.add(labelVersion2, constraints);  	    
		            constraints.gridx = 1;
		            newPanel.add(textVersion2, constraints);
		    	    labelVersion2.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
		    	    textVersion2.setFont(new java.awt.Font("Arial", Font.PLAIN | Font.BOLD, 12));
		        	constraints.gridx = 0;
			        constraints.gridy = 2;
			        constraints.gridwidth = 2;
			        constraints.anchor = GridBagConstraints.CENTER;
			        JButton button = new JButton("Tooltip about define version");
			        button.addActionListener(new ActionListener() {
			            @Override
			            public void actionPerformed(ActionEvent event) { 
			            	 JOptionPane pane = new JOptionPane();
			            	 pane.setSize(200,200);
			            	 JOptionPane.showMessageDialog(null,"This statement specifies the versions of the compiler in which the contract is to be compiled." + "\n" 
			            			+ "The version's format is x1.x2.x3 (Dots are required) where:\n" + 
			            			"\r" + "x1 is 0" + "\n" + 
			            			"\r" + "x2 is a number between 0 and 9" + "\n" +
			            			"\r" + "x3 is a number between 0 and 25" + "\n" +
			            	 		" It is necessary to check if some of the logic defined in the smart contract is not supported for the specified compiler version.");
			            }
			        });       
			        newPanel.add(button, constraints);
			        newPanel.setBorder(BorderFactory.createTitledBorder(
			                BorderFactory.createEtchedBorder(), "Insert Smart Contract Compiler Version"));
			        newPanel.setVisible(true);
			        createdPanel = true;
    			}
		        JOptionPane.showConfirmDialog(null, newPanel, 
		                "Compiler Version", JOptionPane.PLAIN_MESSAGE); 
		        versionOk1 = checkVersionContract(textVersion.getText());
		        versionOk2 = checkVersionContract(textVersion2.getText());
		        if(versionOk1 == true && versionOk2 == true) {
		        	progress.setValue(progress.getValue()+100);
			        version =  ">" + textVersion.getText() + "<=" + textVersion2.getText();
			        versionOk = true;
	        	}
		        else {
		        	  JOptionPane.showMessageDialog(null, "Invalid version", "Error Message",
		                        JOptionPane.ERROR_MESSAGE);
		        }
    		}
        }
        return version;
	}
	
	
	private boolean checkVersionContract(String version){
		boolean badVersion = false;
		if(version.length() >= 9  || version.length() < 5) {
			return badVersion;
		}
		else if(version.charAt(0) != '0') {
			return badVersion;
		}
		else if(version.charAt(1) != '.') {
			return badVersion;
		}
		else {
			badVersion = true;
			return badVersion;
		}
	}
	
	public ArrayList<Property> generateJPanelProperty(String element){
	    ArrayList<Property> properties = new ArrayList<Property>();
	    boolean finish = false;
	    while(finish != true) {
	    	boolean ok = false;
			JLabel labelNameProperty= new JLabel("Property's name");
		    JTextField textNameProperty = new JTextField(20);
		    JLabel labelTypeProperty= new JLabel("Property's type");
		    String[] optionsToChoose = {"uint","float", "int", "bool", "address", "byte", "string","char"};
	        JComboBox<String> textTypeProperty = new JComboBox<>(optionsToChoose);
	        JFrame jFrame = new JFrame();
		    JPanel newPanel = new JPanel(new GridBagLayout());
		    newPanel.setSize(200, 200);
		    labelNameProperty.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
		    labelTypeProperty.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
		    textNameProperty.setFont(new java.awt.Font("Arial", Font.PLAIN | Font.BOLD, 12));
	        GridBagConstraints constraints = new GridBagConstraints();
	        constraints.anchor = GridBagConstraints.WEST;
	        constraints.insets = new Insets(5, 5, 5, 5);
	         
	        // add components to the panel
	        constraints.gridx = 0;
	        constraints.gridy = 0;     
	        newPanel.add(labelNameProperty, constraints);
	 
	        constraints.gridx = 1;
	        newPanel.add(textNameProperty, constraints);
	        
	       // add components to the panel
	        constraints.gridx = 0;
	        constraints.gridy = -1;     
	        newPanel.add(labelTypeProperty, constraints);
	 
	        constraints.gridx = 1;
	        newPanel.add(textTypeProperty, constraints);
	        
	        constraints.gridx = 0;
	        constraints.gridy = -2;     
			JLabel labelArray = new JLabel("Is as a collection?");
		    labelArray.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
			newPanel.add(labelArray, constraints);
		    // Initialization of object of "ButtonGroup" class.
		    ButtonGroup groupRadioButton = new ButtonGroup();
		    JRadioButton jRadioButtonNone = new JRadioButton();  
		    // Initialization of object of "JRadioButton" class.
		    JRadioButton jRadioButtonArray = new JRadioButton();  
	        // Initialization of object of "JRadioButton" class.
		    JRadioButton jRadioButtonMatrix = new JRadioButton();
		    jRadioButtonNone.setText("none");	    
		    jRadioButtonArray.setText("array");
		    jRadioButtonMatrix.setText("matrix");
		    jRadioButtonNone.setBounds(50, 30, 120, 50);
		    jRadioButtonArray.setBounds(50, 30, 120, 50);
	        jRadioButtonMatrix.setBounds(50, 30, 80, 50);
	        constraints.gridy = -2;     
	        constraints.gridx = 1;
	        newPanel.add(jRadioButtonNone, constraints);
	        newPanel.add(jRadioButtonArray, constraints);
	        newPanel.add(jRadioButtonMatrix, constraints);
	        groupRadioButton.add(jRadioButtonNone);
	        groupRadioButton.add(jRadioButtonArray);
	        groupRadioButton.add(jRadioButtonMatrix);
	        constraints.gridwidth = 4;
	        constraints.anchor = GridBagConstraints.CENTER;
	        
	        newPanel.setBorder(BorderFactory.createTitledBorder(
	                BorderFactory.createEtchedBorder(), "Insert Property Data"));
	       
	        newPanel.setVisible(true);
	        String nameProperty;
	        while(ok == false) {
	        	JOptionPane.showConfirmDialog(null, newPanel, 
	  	               element + " Data information", JOptionPane.PLAIN_MESSAGE);  
	        	nameProperty = textNameProperty.getText().replace(" ", "");
		        if(nameProperty.length() > 0) {
		        	if(constants.isKeyword(nameProperty)) {
		        		JOptionPane.showMessageDialog(null, "The property name can't be a keyword. For example, keywords are:  pragma, modifier, library, interface, event, contract, function the diferent property's types, etc.", "Error Message",
			                      JOptionPane.ERROR_MESSAGE);
	        		}
		        	else {
			        	progress.setValue(progress.getValue()+50);	
			        	ok = true;
			        	break;
		        	}
		        }else {
		        	if(nameProperty.length() == 0) {
		      	  	JOptionPane.showMessageDialog(null, "The property name can't be empty", "Error Message",
		                      JOptionPane.ERROR_MESSAGE);
		        	}
		        	else {
		        		if(constants.isKeyword(nameProperty)) {
			        		JOptionPane.showMessageDialog(null, "The property name can't be a keyword. For example, keywords are:  pragma, modifier, library, interface, event, contract, function the diferent property's types, etc.", "Error Message",
				                      JOptionPane.ERROR_MESSAGE);
		        		}
		        	}
		        }
	        }
	        int dimension;
	        nameProperty = textNameProperty.getText();
	        String selectedType = textTypeProperty.getItemAt(textTypeProperty.getSelectedIndex());
	        if (jRadioButtonArray.isSelected()) {
	        	  
	        	dimension = 1;
	        }
	
	        else if (jRadioButtonMatrix.isSelected()) {
	
	        	dimension = 2;
	        }
	        else {
	
	            dimension = 0;
	        }	       
	        Property property = new Property(nameProperty,selectedType,dimension);
	        properties.add(property);
	        progress.setValue(progress.getValue()+10);
	        int input = showDialogConfirm("Do you want add another property?");
	        if(input != 0){
	        	finish = true;
	        }
	    }
		return properties;
	}
	
	public String generateJPanelEvent(){
		JLabel labelEventName= new JLabel("Event name");
	    JTextField textEventName = new JTextField(20);
	    JPanel newPanel = new JPanel(new GridBagLayout());
	    newPanel.setSize(200, 200);
	    labelEventName.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
	    textEventName.setFont(new java.awt.Font("Arial", Font.PLAIN | Font.BOLD, 12));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);
         
        // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = 0;     
        newPanel.add(labelEventName, constraints);
 
        constraints.gridx = 1;
        newPanel.add(textEventName, constraints);
         
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        
        newPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Insert Event Data"));       
        newPanel.setVisible(true);
        JOptionPane.showConfirmDialog(null, newPanel, 
                "Event Information",JOptionPane.PLAIN_MESSAGE);
        String eventName = textEventName.getText().replace(" ", "");;
        progress.setValue(progress.getValue()+50);
		return eventName;
	}
	
	
	public String generateJPanelContract(ContractPersonalized contractPersonalized){
		JLabel labelContractName= new JLabel("Contract name");
	    JTextField textContractName = new JTextField(20);
	    JPanel newPanel = new JPanel(new GridBagLayout());
	    newPanel.setSize(200, 200);
	    labelContractName.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
	    textContractName.setFont(new java.awt.Font("Arial", Font.PLAIN | Font.BOLD, 12));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);
         
        // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = 0;     
        newPanel.add(labelContractName, constraints);
 
        constraints.gridx = 1;
        newPanel.add(textContractName, constraints);
         
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        
        JButton button = new JButton("Tooltip about define smart contract name");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) { 
            	 JOptionPane pane = new JOptionPane();
            	 pane.setSize(200,200);
            	 JOptionPane.showMessageDialog(null,"It is necessary to specify the name of the contract in which the value exchanges between " + contractPersonalized.getActor_x().getName() + " and " + contractPersonalized.getActor_y().getName());
            }
        });       
        newPanel.add(button, constraints);
        constraints.anchor = GridBagConstraints.CENTER;
        
        newPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Insert Contract Data"));       
        newPanel.setVisible(true);
        boolean ok = false;
        String contractName = "";
        while(ok == false) {
	        JOptionPane.showConfirmDialog(null, newPanel, 
	                "Contract Information between " + contractPersonalized.getActor_x().getName() + " & " + contractPersonalized.getActor_y().getName(),JOptionPane.PLAIN_MESSAGE);
	        contractName = textContractName.getText().replace(" ", "");
	        if(contractName.length() > 0) {
	        	if(constants.isKeyword(contractName)) {
	        		JOptionPane.showMessageDialog(null, "The name can't be a keyword. For example, keywords are:  pragma, modifier, library, interface, event, contract, function the diferent property's types, etc.", "Error Message",
		                      JOptionPane.ERROR_MESSAGE);
        		}
	        	else {
	        		progress.setValue(progress.getValue()+50);	
		        	ok = true;
		        	break;	
	        	}	        	
	        }else {
	        	if(contractName.length() == 0) {
	      	  		JOptionPane.showMessageDialog(null, "The name can't be empty", "Error Message",
	                      JOptionPane.ERROR_MESSAGE);
	        	}
	        	else {
	        		if(constants.isKeyword(contractName)) {
		        		JOptionPane.showMessageDialog(null, "The name can't be a keyword. For example, keywords are:  pragma, modifier, library, interface, event, contract, function the diferent property's types, etc.", "Error Message",
			                      JOptionPane.ERROR_MESSAGE);
	        		}
	        	}
	        }
        }
		return contractName;
	}
	
	
	
	public String generateJPanelActor(String name){
	    JPanel newPanel = new JPanel(new GridBagLayout());
	    newPanel.setSize(200, 200);
		//int opcion = this.showDialogConfirm("The exchange of value between the actors in which actor X sends or grants the Omega to actor Y is going to become a function. You can then parameterize it however you like.");
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);
		JLabel labelActorName= new JLabel("Actor name: " + name);
		labelActorName.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
        // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = 0;  
        newPanel.add(labelActorName, constraints);
        JLabel labelVisibilityProperty= new JLabel("Actor nature: ");
        labelVisibilityProperty.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
	    String[] optionsToChoose = {"User", "Company", "Personalized"};
        JComboBox<String> textVisibilityProperty = new JComboBox<>(optionsToChoose);
         // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = -1;     
        newPanel.add(labelVisibilityProperty, constraints);
        constraints.gridx = 1;
        constraints.gridy = -1;   
        newPanel.add(textVisibilityProperty, constraints);
        constraints.gridx = 0;
        constraints.gridy = -3; 
        constraints.anchor = GridBagConstraints.CENTER;
        JButton button = new JButton("Tooltip about define actor nature");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) { 
            	 JOptionPane pane = new JOptionPane();
            	 pane.setSize(200,200);
            	 JOptionPane.showMessageDialog(null,"This statement specifies the actor type." + "\n" +
            			"User: Represents a person. User option comprises a series of attributes for the actor, such as the name, surname, email and its address that represents it in a blockchain." + "\n" + 
            	 		"Company: Represents a company. Company option comprises a series of attributes for the company, such as the name, city, email and its address that represents it in a blockchain." + "\n" + 
        				"Personalized: Personalized option only containts its address that represents it in a blockchain.");
            }
        });       
        newPanel.add(button, constraints);
        newPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Select Actor Type"));       
        newPanel.setVisible(true);
        JOptionPane.showConfirmDialog(null, newPanel, 
                "Actor " + name.replace(" ", "") + " Information",JOptionPane.PLAIN_MESSAGE);
        String visibility = null;
        visibility = textVisibilityProperty.getItemAt(textVisibilityProperty.getSelectedIndex());    
        progress.setValue(progress.getValue()+progressActor);
		return visibility;
	}
      
	
	public Function generateJPanelFunction(){
		JLabel labelFunctionName= new JLabel("Function name");
	    JTextField textFunctionName = new JTextField(20);
	    JPanel newPanel = new JPanel(new GridBagLayout());
	    newPanel.setSize(200, 200);
	    labelFunctionName.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
	    textFunctionName.setFont(new java.awt.Font("Arial", Font.PLAIN | Font.BOLD, 12));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);
         
        // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = 0;     
        newPanel.add(labelFunctionName, constraints);
 
        constraints.gridx = 1;
        newPanel.add(textFunctionName, constraints);
         
        
        JLabel labelVisibilityProperty= new JLabel("Function's visibility");
        labelVisibilityProperty.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
	    String[] optionsToChoose = {"public", "private", "internal"};
        JComboBox<String> textVisibilityProperty = new JComboBox<>(optionsToChoose);
         // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = -1;     
        newPanel.add(labelVisibilityProperty, constraints);
 
        constraints.gridx = 1;
        newPanel.add(textVisibilityProperty, constraints);
        
        JLabel labelPayableProperty = new JLabel("Does the function send currency?");
        labelPayableProperty.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
        JCheckBox isPayable = new JCheckBox("payable");
        constraints.gridx = 0;
        constraints.gridy = -2;
        newPanel.add(labelPayableProperty, constraints);
        constraints.gridx = 1;
        newPanel.add(isPayable, constraints);
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        JButton button = new JButton("Tooltip about define function");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) { 
            	 JOptionPane pane = new JOptionPane();
            	 pane.setSize(200,200);
            	 JOptionPane.showMessageDialog(null,"This statement specifies the contract functions." + "\n" 
            			+ "You should be define a name for the function" + 
            			"\r" + "The visibility of the function to be executed by users who interact with the contract. By default it is public." + "\n" + 
            	 		"If a user will send currency to a recipient through a function, it must be marked as payable from the box offered by the wizard.");
            }
        });       
        newPanel.add(button, constraints);
        newPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Insert Function Data"));       
        newPanel.setVisible(true);
        JOptionPane.showConfirmDialog(null, newPanel, 
                "Function Information",JOptionPane.PLAIN_MESSAGE);
        String functionName = null;
        String visibility = null;
        boolean ok = false;
        while(ok == false) {
        	JOptionPane.showConfirmDialog(null, newPanel, 
                     "Function Information" ,JOptionPane.PLAIN_MESSAGE);
            functionName = textFunctionName.getText().replace(" ", "");;
            visibility = textVisibilityProperty.getItemAt(textVisibilityProperty.getSelectedIndex());
	        if(functionName.length() > 0) {
	        	if(constants.isKeyword(functionName)) {
	        		JOptionPane.showMessageDialog(null, "The function name can't be a keyword. For example, keywords are:  pragma, modifier, library, interface, event, contract, function the diferent property's types, etc.", "Error Message",
		                      JOptionPane.ERROR_MESSAGE);
        		}
	        	else {
		        	ok = true;
		        	break;
	        	}	        	
	        }else {
	        	if(functionName.length() == 0) {
	      	  	JOptionPane.showMessageDialog(null, "The function name can't be empty", "Error Message",
	                      JOptionPane.ERROR_MESSAGE);
	        	}
	        	else {
	        		if(constants.isKeyword(functionName)) {
		        		JOptionPane.showMessageDialog(null, "The function name can't be a keyword. For example, keywords are:  pragma, modifier, library, interface, event, contract, function the diferent property's types, etc.", "Error Message",
			                      JOptionPane.ERROR_MESSAGE);
	        		}
	        	}
	        }
        }       
        Function function;
        if (isPayable.isSelected() == true){
        	function = new Function(functionName,visibility,true,"","");
        }
        else {
        	function = new Function(functionName,visibility,false,"","");
        }
		return function;
	}
	
	public Function generateJPanelFunction(ValueExchangePersonalized valueExchangePersonalized){
		
		JLabel labelFunctionName = new JLabel("Function name");
	    JTextField textFunctionName = new JTextField(20);
	    JPanel newPanel = new JPanel(new GridBagLayout());
	    newPanel.setSize(200, 200);
		//int opcion = this.showDialogConfirm("The exchange of value between the actors in which actor X sends or grants the Omega to actor Y is going to become a function. You can then parameterize it however you like.");
	    labelFunctionName.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
	    textFunctionName.setFont(new java.awt.Font("Arial", Font.PLAIN | Font.BOLD, 12));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);
         
        // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = 0;     
        newPanel.add(labelFunctionName, constraints);
 
        constraints.gridx = 1;
        newPanel.add(textFunctionName, constraints);
         
        
        JLabel labelVisibilityProperty= new JLabel("Function's visibility");
        labelVisibilityProperty.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
	    String[] optionsToChoose = {"public", "private", "internal"};
        JComboBox<String> textVisibilityProperty = new JComboBox<>(optionsToChoose);
         // add components to the panel
        constraints.gridx = 0;
        constraints.gridy = -1;     
        newPanel.add(labelVisibilityProperty, constraints);
 
        constraints.gridx = 1;
        newPanel.add(textVisibilityProperty, constraints);
        
        JLabel labelPayableProperty = new JLabel("Does the function send currency?");
        labelPayableProperty.setFont(new java.awt.Font("Arial", Font.ITALIC | Font.BOLD, 12));
        JCheckBox isPayable = new JCheckBox("payable");
        constraints.gridx = 0;
        constraints.gridy = -2;
        newPanel.add(labelPayableProperty, constraints);
        constraints.gridx = 1;
        newPanel.add(isPayable, constraints);
        constraints.gridy = -3;
        constraints.gridx = 0;
        JButton button = new JButton("Tooltip about define function" + valueExchangePersonalized.getActorSend() + " --> " + valueExchangePersonalized.getActorReceipt());
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) { 
            	 JOptionPane pane = new JOptionPane();
            	 pane.setSize(200,200);
            	 JOptionPane.showMessageDialog(null,"This wizard allows you to define the parameters of the function corresponding to the exchange of value between " + valueExchangePersonalized.getActorSend() + " that sends/grants " + valueExchangePersonalized.getValueObject().getName()  + " as a value object to " + valueExchangePersonalized.getActorReceipt() + "." + "\n" 
            			+ "First, you should be define a name for the function." +  "\n" 
            			+ "The function's visibility to be executed by users who interact with the contract. By default it is public." + "\n" + 
            	 		"If a user will send currency to a recipient through a function, it must be marked as payable from the box offered by the wizard.");
            }
        });       
        newPanel.add(button, constraints);
        constraints.anchor = GridBagConstraints.CENTER;
        newPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Insert Function Data"));       
        newPanel.setVisible(true);
        boolean ok = false;
        String functionName = null;
        String visibility = null;
        while(ok == false) {
        	JOptionPane.showConfirmDialog(null, newPanel, 
                     "Function Information about value exchange between " + valueExchangePersonalized.getActorSend() + " to " + valueExchangePersonalized.getActorReceipt(),JOptionPane.PLAIN_MESSAGE);
            functionName = textFunctionName.getText();
            visibility = textVisibilityProperty.getItemAt(textVisibilityProperty.getSelectedIndex());
	        if(functionName.length() > 0) {
	        	if(constants.isKeyword(functionName)) {
	        		JOptionPane.showMessageDialog(null, "The function name can't be a keyword. For example, keywords are:  pragma, modifier, library, interface, event, contract, function the diferent property's types, etc.", "Error Message",
		                      JOptionPane.ERROR_MESSAGE);
        		}
	        	else {
	        		progress.setValue(progress.getValue()+50);	
		        	ok = true;
		        	break;
	        	}	        	
	        }else {
	        	if(functionName.length() == 0) {
	      	  	JOptionPane.showMessageDialog(null, "The function name can't be empty", "Error Message",
	                      JOptionPane.ERROR_MESSAGE);
	        	}
	        	else {
	        		if(constants.isKeyword(functionName)) {
		        		JOptionPane.showMessageDialog(null, "The function name can't be a keyword. For example, keywords are:  pragma, modifier, library, interface, event, contract, function the diferent property's types, etc.", "Error Message",
			                      JOptionPane.ERROR_MESSAGE);
	        		}
	        	}
	        }
        }       
        Function function;
        if (isPayable.isSelected() == true){
        	function = new Function(functionName,visibility,true,valueExchangePersonalized.getActorSend(),valueExchangePersonalized.getActorReceipt());
        }
        else {
        	function = new Function(functionName,visibility,false,valueExchangePersonalized.getActorSend(),valueExchangePersonalized.getActorReceipt());
        }
		return function;
	}
      
	
	
	
	public Constants getConstants() {
		return constants;
	}

	public void setConstants(Constants constants) {
		this.constants = constants;
	}

	public JProgressBar getProgress() {
		return progress;
	}

	public void setProgress(JProgressBar progress) {
		this.progress = progress;
	}

	public int getLimitProgressBar() {
		return limitProgressBar;
	}

	public void setLimitProgressBar(int limitProgressBar) {
		this.limitProgressBar = limitProgressBar;
	}

	public int getNumberContractsIdentified() {
		return numberContractsIdentified;
	}

	public void setNumberContractsIdentified(int numberContractsIdentified) {
		this.numberContractsIdentified = numberContractsIdentified;
	}

	public int getNumberValueExchangesIdentified() {
		return numberValueExchangesIdentified;
	}

	public void setNumberValueExchangesIdentified(int numberValueExchangesIdentified) {
		this.numberValueExchangesIdentified = numberValueExchangesIdentified;
	}

	public int getNumberActorsIdentified() {
		return numberActorsIdentified;
	}

	public void setNumberActorsIdentified(int numberActorsIdentified) {
		this.numberActorsIdentified = numberActorsIdentified;
	}

	public int getProgressContract() {
		return progressContract;
	}

	public void setProgressContract(int progressContract) {
		this.progressContract = progressContract;
	}

	public int getProgressFunction() {
		return progressFunction;
	}

	public void setProgressFunction(int progressFunction) {
		this.progressFunction = progressFunction;
	}

	public int getProgressActor() {
		return progressActor;
	}

	public void setProgressActor(int progressActor) {
		this.progressActor = progressActor;
	}

	public void getSmaCQAModel(){
		 File inputFile = null;
		 JFileChooser selector = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
		 selector.setDialogTitle("Select a SmaCQA textual model");
		 selector.setAcceptAllFileFilterUsed(false);
		 FileNameExtensionFilter filter = new FileNameExtensionFilter("SmaC Questions and Answers Files (.qa extension)", "qa");
		 selector.addChoosableFileFilter(filter);

		 int returnValue = selector.showOpenDialog(null);
		 if (returnValue == JFileChooser.APPROVE_OPTION) {
			System.out.println(selector.getSelectedFile().getPath());
			inputFile = selector.getSelectedFile();
			progress.setValue(10);
		 }
	}
	
	
}
