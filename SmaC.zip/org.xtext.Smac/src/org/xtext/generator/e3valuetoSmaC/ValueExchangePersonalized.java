package org.xtext.generator.e3valuetoSmaC;

import java.util.ArrayList;

import e3Value.BusinessActor;
import e3Value.EndStimulus;
import e3Value.StartStimulus;
import e3Value.ValueExchange;
import e3Value.ValueObject;


public class ValueExchangePersonalized {

	@Override
	public String toString() {
		return "ValueExchangePersonalized [id=" + id + ", actorSend=" + actorSend + ", actorReceipt=" + actorReceipt
				+ ", valueObject=" + valueObject + ", valueExchange=" + valueExchange + "]";
	}
	private String id;
	private String actorSend;//Nombre del actor que env�a el objeto de valor
	private BusinessActor eObjectActorSend;//Objecto actor que env�a el objeto de valor
	private String actorReceipt;//Nombre del actor que recibe el objeto de valor
	private BusinessActor eObjectActorReceipt;//Objecto actor que recibe el objeto de valor
	private ValueObject valueObject;//Objecto de valor que se env�a de un actor a otro
	private ValueExchange valueExchange;// El value exchange del modelo e3value asociado a este intercambio de valor personalizado
	private org.xtext.smaCQA.ValueExchange valueExchangeSmaCQA;// El value exchange del modelo qa asociado a este intercambio de valor personalizado
	private StartStimulus startStimulus;// Los stimulus
	private EndStimulus endStimulus;// Los stimulus
	private ArrayList<String> modifiersIdentified;
	private ArrayList<StructValueObjectIdentified> structsIdentified;
	
	public ArrayList<StructValueObjectIdentified> getStructsIdentified() {
		return structsIdentified;
	}
	public void setStructsIdentified(ArrayList<StructValueObjectIdentified> structsIdentified) {
		this.structsIdentified = structsIdentified;
	}
	private boolean insertPropertyAge;
	
	public boolean isInsertPropertyAge() {
		return insertPropertyAge;
	}
	public void setInsertPropertyAge(boolean insertPropertyAge) {
		this.insertPropertyAge = insertPropertyAge;
	}
	public ArrayList<String> getModifiersIdentified() {
		return modifiersIdentified;
	}
	public void setModifiersIdentified(ArrayList<String> modifiersIdentified) {
		this.modifiersIdentified = modifiersIdentified;
	}
	public BusinessActor geteObjectActorSend() {
		return eObjectActorSend;
	}
	public void seteObjectActorSend(BusinessActor eObjectActorSend) {
		this.eObjectActorSend = eObjectActorSend;
	}
	public BusinessActor geteObjectActorReceipt() {
		return eObjectActorReceipt;
	}
	public void seteObjectActorReceipt(BusinessActor eObjectActorReceipt) {
		this.eObjectActorReceipt = eObjectActorReceipt;
	}
	
	public ValueExchange getValueExchange() {
		return valueExchange;
	}
	public void setValueExchange(ValueExchange valueExchange) {
		this.valueExchange = valueExchange;
	}
	public ValueObject getValueObject() {
		return valueObject;
	}
	public void setValueObject(ValueObject valueObject) {
		this.valueObject = valueObject;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getActorSend() {
		return actorSend;
	}
	public void setActorSend(String actorSend) {
		this.actorSend = actorSend;
	}
	public String getActorReceipt() {
		return actorReceipt;
	}
	public void setActorReceipt(String actorReceipt) {
		this.actorReceipt = actorReceipt;
	}
	public StartStimulus getStartStimulus() {
		return startStimulus;
	}
	public void setStartStimulus(StartStimulus startStimulus) {
		this.startStimulus = startStimulus;
	}
	public EndStimulus getEndStimulus() {
		return endStimulus;
	}
	public void setEndStimulus(EndStimulus endStimulus) {
		this.endStimulus = endStimulus;
	}

	public org.xtext.smaCQA.ValueExchange getValueExchangeSmaCQA() {
		return valueExchangeSmaCQA;
	}
	
	public void setValueExchangeSmaCQA(org.xtext.smaCQA.ValueExchange valueExchangeSmaCQA) {
		this.valueExchangeSmaCQA = valueExchangeSmaCQA;
	}
	
	/*
	 * Argumentos de entrada:Una lista de los contratos que se han identificado a partir de una pareja de intercambios de valor
	 * Descripci�n: Recibe los contratos identificados para ver si el propio intercambio de valor debe crear un contrato (smart contract) o ya lo ha creado otro intercambio de valor antes.
	 * Para saber si lo debe de crear, comprueba por cada contrato los actores que intervienen y si son iguales a los del propio intercambio de valor no se necesita crear un contrato a partir de este intercambio de valor
	 * Argumento de salida: Ninguno
	 */
	public ContractPersonalized isValueExchangeToCreateContract(ArrayList<ContractPersonalized>contractsIdentified) {
	    if (contractsIdentified.size() == 0) {//Si la lista esta vac�a se puede crear un contrato a partir de este intercambio de valor
	    	return null;
	    }
	    else {
	    	boolean enc = false;
	    	int contador = 0;
	    	ContractPersonalized contract = null;
	    	while(enc == false && contador<contractsIdentified.size()) {
	    		ContractPersonalized contractIdentified = contractsIdentified.get(contador);
	    		if((contractIdentified.idActor_x == this.eObjectActorSend.hashCode() && contractIdentified.idActor_y == this.eObjectActorReceipt.hashCode()) || (contractIdentified.idActor_x == this.eObjectActorReceipt.hashCode() &&  contractIdentified.idActor_y == this.eObjectActorSend.hashCode())){
	    			enc = true;
	    			contract =  contractIdentified;
	    			break;
	    		}
	    		else {
	    			contador++;
	    		}
	    	}
	    	if(enc == false) {
	    		return null;//No hay un contrato con los actores del intercambio de valor, por tanto se ha de crear uno nuevo a partir de este intercambio de valor
	    	}
	    	else {
	    		return contract;//Se ha encontrato un contrato con los actores del intercambio de valor
	    	}
		}
	}
	
	
	
	
	
}
