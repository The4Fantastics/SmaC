package org.xtext.generator.e3valuetoSmaC;

import java.util.ArrayList;

public class StructValueObjectIdentified {
	
	private String name;
	private ArrayList<Property> properties = new ArrayList<Property>();

	public ArrayList<Property> getProperties() {
		return properties;
	}
	public void setProperties(ArrayList<Property> properties) {
		this.properties = properties;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
