package org.xtext.generator.e3valuetoSmaC;

import java.util.Date;

public class Task{
	
	private String name;
	private int idProcess;
	private Date date;
	
	public Task(String name, Date date) {
		super();
		this.name = name;
		this.idProcess =  (int)(Math.random()*50000+1);
		this.date = date;
	}
	
	

	@Override
	public String toString() {
		return "Task [name=" + name + ", idProcess=" + idProcess + ", date=" + date + "]";
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getIdProcess() {
		return idProcess;
	}
	public void setIdProcess(int idProcess) {
		this.idProcess = idProcess;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	
}