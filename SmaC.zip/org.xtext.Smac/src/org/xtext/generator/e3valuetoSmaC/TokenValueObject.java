package org.xtext.generator.e3valuetoSmaC;

public class TokenValueObject {

	String name;
	String symbol;
	String supply;
	boolean mintable;
	boolean burnable;

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isMintable() {
		return mintable;
	}
	public void setMintable(boolean mintable) {
		this.mintable = mintable;
	}
	public boolean isBurnable() {
		return burnable;
	}
	public void setBurnable(boolean burnable) {
		this.burnable = burnable;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getSupply() {
		return supply;
	}
	public void setSupply(String supply) {
		this.supply = supply;
	}
	
	
}
