package org.xtext.generator.e3valuetoSmaC;

import java.io.IOException;
import java.util.ArrayList;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.xtext.generator.IFileSystemAccess2;
import org.eclipse.xtext.generator.IGeneratorContext;
import org.eclipse.xtext.resource.XtextResourceSet;
import org.xtext.SmaCStandaloneSetup;
import org.xtext.generator.ERCTokenGenerator;
import org.xtext.smaCQA.DataRegister;
import org.xtext.smaCQA.Model;
import org.xtext.smaCQA.TimeValueExchangeDurationQuestion;
import org.xtext.smaCQA.ValueObjectQuestion;
import org.xtext.smaCQA.impl.ValueObjectTangibleQuestionImpl;
import org.xtext.smaCQA.impl.ValueObjectTokenQuestionImpl;

import com.google.inject.Injector;

import e3Value.BusinessActor;
import e3Value.ConnectionElement;
import e3Value.EndStimulus;
import e3Value.StimulusElement;
import e3Value.OutputPort;
import e3Value.StartStimulus;
import e3Value.ValueExchange;
import e3Value.ValueInterface;
import e3Value.ValuePort;
import e3Value.ValuePortIn;
import e3Value.ValuePortOut;

public class PreProcessor {

	static final String EMF_SOURCE_GENERATED_DIRECTORY = "EMF-src-generated";
	Constants constants = new Constants();
	
	
	/*
	 * Argumentos de entrada: El actor, el port out del value interface actual, la lista de intercambios analizados y la value interface que contiene al port out que se recibe como entrada
	 * Descripci�n:Por cada intercambio de valor que salga del port out se extraen sus datos y se a�ade en la lista de intercambios 
	 * Argumento de salida: Ninguno
	 */
	public void createValueExchangesIdentified(BusinessActor actor,ValuePortOut portOut, ArrayList<ValueExchangePersonalized>valueExchangesIdentified,ValueInterface valueInterface) {
		for(ValueExchange valueExchange : portOut.getValueexchange()) {
			ValuePort portInSend = valueExchange.getSourceValuePort();
			ValueExchangePersonalized valueExchangeIdentified = new ValueExchangePersonalized();
			valueExchangeIdentified.setId(String.valueOf(valueExchange.hashCode()));
			valueExchangeIdentified.setActorSend(actor.getName().replace(" ", ""));
			valueExchangeIdentified.seteObjectActorSend(actor);
			valueExchangeIdentified.setActorReceipt(String.valueOf(portInSend.hashCode()));
			valueExchangeIdentified.setValueObject(valueExchange.getValueExchangeHasValueObject());
			valueExchangeIdentified.setValueExchange(valueExchange);
			valueExchangesIdentified.add(valueExchangeIdentified);
			/*for (StimulusElement stimulus : actor.getHasStimulusElement()) {
				if(stimulus.getClass().getSimpleName().equals("StartStimulusImpl")) {
					StartStimulus startStimulus = (StartStimulus) stimulus;
					for(ConnectionElement connectionElement : startStimulus.getConnectionelement()) {
						System.out.println("ConnectionElement Start Stimulus : " + connectionElement.getTargetDependenceElement().toString());
					}
				}
				else {
					EndStimulus endStimulus = (EndStimulus) stimulus;
					for(ConnectionElement connectionElement : endStimulus.getConnectionelement()) {
						System.out.println("ConnectionElement End Stimulus : " + connectionElement.getTargetDependenceElement().toString());
					}
				}
			}
			for(ConnectionElement connectionElement : valueInterface.getBindsResponsabilityElement().getConnectionelement()) {
				System.out.println("Actor name: " + actor.getName());
				System.out.println("Connection Element: " + connectionElement.toString());
				System.out.println("Source Connection Element: " + connectionElement.getSourceDependenceElement().toString());
				System.out.println("Source Eclass Connection Element: " + connectionElement.getSourceDependenceElement().eClass().getName());
				System.out.println("Target Connection Element: " + connectionElement.getTargetDependenceElement().toString());
				System.out.println("Target Eclass Connection Element: " + connectionElement.getTargetDependenceElement().eClass().getName());
			}*/
		}		
	}
	
	/*
	 * Argumentos de entrada: El actor, el port in del value interface actual, la lista de intercambios analizados y la value interface que contiene al port in que se recibe como entrada
	 * Descripci�n:Se comprueba que el port in este a�adido en alguno de los intercambios de valor ya analizados del port out. Una vez que se encuentra el intercambio de valor que lo contiene,
	 * se a�ade el nombre del actor que recibe el value object de ese intercambio de valor.
	 * Argumento de salida: Ninguno
	 */
	public void completeValueExchangesIdentified(BusinessActor actor,ValuePortIn portIn, ArrayList<ValueExchangePersonalized>valueExchangesIdentified,ValueInterface valueInterface) {
		ValueExchange valueExchangePortIn = portIn.getInConnectWithValueExchange();
		for(ValueExchangePersonalized valueExchangeIdentified : valueExchangesIdentified) {
			if(valueExchangeIdentified.getValueExchange().equals(valueExchangePortIn) == true) {
				valueExchangesIdentified.get(valueExchangesIdentified.indexOf(valueExchangeIdentified)).setActorReceipt(actor.getName().replace(" ", ""));
				valueExchangeIdentified.seteObjectActorReceipt(actor);
			}
		}
	}
	
	/*
	 * Argumentos de entrada:Los contratos identificados y los intercambios de valor entre actores
	 * Descripci�n://Se comprueba si los actores de este intercambio de valor ya se encuentr�n en un contrato, si est�n no hace falta crear uno nuevo se a�ade a la lista de funciones del contrato
	 * Argumento de salida: Ninguno
	 */
	public void addValueExchangeToContract(ArrayList<ContractPersonalized> contractsIdentified,ValueExchangePersonalized valueExchangeIdentified){
		if (valueExchangeIdentified.isValueExchangeToCreateContract(contractsIdentified) == null) { //No hay un contrato que contenga un intercambio de valor con estos actores
    		ContractPersonalized contract = createContractPersonalized(valueExchangeIdentified);//Hay que crear un contrato y a�adir los datos del intercambio de valor al contrato
			contractsIdentified.add(contract);//Se a�ade el intercambio de valor al contrato
		}else {
    		valueExchangeIdentified.isValueExchangeToCreateContract(contractsIdentified).addValueExchange(valueExchangeIdentified);
		}
	}
	
	
	/*
	 * Argumentos de entrada: El intercambio de valor identificado
	 * Descripci�n: Se crea un contrato nuevo a partir del intercambio de valor y se a�ade que actores intervienen y el propio intercambio al contrato
	 * Argumento de salida: El contrato reci�n creado
	 */
	private ContractPersonalized createContractPersonalized(ValueExchangePersonalized valueExchangePersonalized){
		ContractPersonalized contract = new ContractPersonalized();
		contract.setActor_x(valueExchangePersonalized.geteObjectActorSend());//actor que interviene
		contract.setActor_y(valueExchangePersonalized.geteObjectActorReceipt());//actor que recibes
		contract.setIdActor_x(valueExchangePersonalized.geteObjectActorSend().hashCode());//El hash del actor que envia
		contract.setIdActor_y(valueExchangePersonalized.geteObjectActorReceipt().hashCode());//El hash del actor que recibe
		contract.getValueExchanges().add(valueExchangePersonalized);
		return contract;
	}
	
	
	
	/*public void generateControlDurationValueExchangeModifier(TimeValueExchangeDurationQuestion timeValueExchangeQuestion,ArrayList<Modifier> modifiersIdentified) {
		String condition;
		if(timeValueExchangeQuestion.getAnswerUnitTime().getLiteral().equals("days")){
			condition = "now <= " + timeValueExchangeQuestion.getAnswer() + " " + timeValueExchangeQuestion.getAnswerUnitTime().getLiteral();
		}
		else{
			condition = "now <= " + timeValueExchangeQuestion.getAnswer() + " " + timeValueExchangeQuestion.getAnswerUnitTime().getLiteral();
		}
		defineSmaCModifier(modifiersIdentified,"theValueExchangeIsAvailable",condition,"The user's balance is less than the minimum amount required.");
	}*/
	
	/*
	 * Argumentos de entrada: La lista de los modificadores que se han identificado, el nombre del modificador, la condici�n y el mensaje de la excepci�n
	 * Descripci�n:Crea un modificador para poder ser plasmado posteriormente en el smart contract.
	 * Argumento de salida: Ninguno
	 */
	public void defineSmaCModifier(ArrayList<Modifier> modifiersIdentified,String name,String condition,String message){
		Modifier modifierRestrictedAccess = new Modifier();
		modifierRestrictedAccess.name = name;
		modifierRestrictedAccess.condition = condition;
		modifierRestrictedAccess.message = message;
		modifiersIdentified.add(modifierRestrictedAccess);
	}
	
	/*
	 * Argumentos de entrada: El nombre de la funci�n, la visibilidad de la funci�n, el valor boolean que determina si es payable o no y el nombre de los actores que env�an y reciben el value object
	 * Descripci�n:Crea una funci�n para poder ser plasmada posteriormente en el smart contract.
	 * Argumento de salida: La funci�n con los par�metros que recibe como entrada
	 */
	public Function createFunction(String nameFunction,String visibility,boolean payable, String actorSend, String actorReceipt) {
		Function function = new Function(nameFunction,visibility,payable,actorSend,actorReceipt);
		return function;
	}
	
	/*
	 * Argumentos de entrada:La lista de funciones identificadas para ser plasmadas en un smart contract y la funci�n que se ha creado recientmeente
	 * Descripci�n: Se a�ade la funci�n a la lista de funciones identificadas para ser plasmadas posteriormente en un smart contract.
	 * Argumento de salida: Ninguno
	 */
	public void addFunctionToListContractFunctions(ArrayList<Function> functionsIdentified,Function function) {
		functionsIdentified.add(function);
	}
	
	/*
	 * Argumentos de entrada:La lista de intercambios de valor identificados
	 * Descripci�n:  Limpia la lista de intercambios de valor analizados del anterior proceso
	 * Argumento de salida: La lista de intercambios de valor identificados limpia
	 */
	public ArrayList<ValueExchangePersonalized> cleanValueExchangesIdentified(ArrayList<ValueExchangePersonalized> valueExchangesIdentified){
		if(valueExchangesIdentified.size() > 0) {
			valueExchangesIdentified.clear();
		}
		return valueExchangesIdentified;
	}
	
	/*
	 * Argumentos de entrada:La lista de contratos identificados
	 * Descripci�n:  Limpia la lista de contratos analizados del anterior proceso
	 * Argumento de salida: La lista de contratos identificados limpia
	 */
	public ArrayList<ContractPersonalized> cleanContractsIdentified(ArrayList<ContractPersonalized> contractsIdentified){
		if(contractsIdentified.size() > 0) {
			contractsIdentified.clear();
		}
		return contractsIdentified;
	}
	
	/*
	 * Argumentos de entrada:La lista de modificadores identificados
	 * Descripci�n:  Limpia la lista de modificadores analizados del anterior smart contract para poder recoger los nuevos del smart contract actual
	 * Argumento de salida: La lista de modificadores identificados limpia
	 */
	public ArrayList<Modifier> cleanModifiers(ArrayList<Modifier> modifiersIdentified){
		if(modifiersIdentified.size() > 0) {
			modifiersIdentified.clear();
		}
		return modifiersIdentified;
	}
	
	/*
	 * Argumentos de entrada:La lista de expresiones del constructor identificadas
	 * Descripci�n:  Limpia la lista de expresiones de constructor analizadas del anterior smart contract para poder recoger las nuevas expresiones del nuevo constructor del smart contract actual
	 * Argumento de salida: La lista de expresiones del constructor identificadas limpia
	 */
	public ArrayList<String> cleanExpressionsConstructor(ArrayList<String> expressionsConstructorIdentified){
		if(expressionsConstructorIdentified.size() > 0) {
			expressionsConstructorIdentified.clear();
		}
		return expressionsConstructorIdentified;
	}
	
	/*
	 * Argumentos de entrada:La lista de funciones identificados
	 * Descripci�n:  Limpia la lista de funciones analizados del anterior smart contract para poder recoger los nuevos del smart contract actual
	 * Argumento de salida: La lista de funciones identificados limpia
	 */
	public ArrayList<Function> cleanFunctions(ArrayList<Function> functionsIdentified){
		if(functionsIdentified.size() > 0) {
			functionsIdentified.clear();
		}
		return functionsIdentified;
	}
	
	/*
	 * Argumentos de entrada:La lista de modificadores identificados
	 * Descripci�n:  Limpia la lista de modificadores analizados del anterior smart contract para poder recoger los nuevos del smart contract actual
	 * Argumento de salida: La lista de modificadores identificados limpia
	 */
	public ArrayList<Property> cleanProperties(ArrayList<Property> propertiesIdentified){
		if(propertiesIdentified.size() > 0) {
			propertiesIdentified.clear();
		}
		return propertiesIdentified;
	}
	
	/*
	 * Argumentos de entrada:La lista de structs identificados
	 * Descripci�n:  Limpia la lista de structs analizados del anterior smart contract para poder recoger los nuevos del smart contract actual
	 * Argumento de salida: La lista de structs identificados limpia
	 */
	public ArrayList<StructValueObjectIdentified> cleanStructsValueObject(ArrayList<StructValueObjectIdentified> structsValueObjectPhysical){
		if(structsValueObjectPhysical.size() > 0) {
			structsValueObjectPhysical.clear();
		}
		return structsValueObjectPhysical;
	}
	
	/*
	 * Argumentos de entrada:La lista de intercambios de valor analizados y el modelo de preguntas y respuestas acerca de los intercambios de valor
	 * Descripci�n:  Asocia los intercambios de valor identificados con su hom�logo del modelo qa. Para ello es necesario que el nombre del actor que env�a, del que recibe y el valor del objeto sean id�nticos
	 * Argumento de salida: Ninguno
	 */
	public void associateValueExchangesBetweenModel(ArrayList<ValueExchangePersonalized> valueExchangePersonalizeds, Model smacqaModel){
		for(org.xtext.smaCQA.ValueExchange valueExchangeSmaCQA : smacqaModel.getValueExchanges()){
			for(ValueExchangePersonalized valueExchange_e3value : valueExchangePersonalizeds){
				if(valueExchange_e3value.getActorSend().equals(valueExchangeSmaCQA.getActorSend()) && valueExchange_e3value.getActorReceipt().equals(valueExchangeSmaCQA.getActorReceipt()) && valueExchange_e3value.getValueObject().getName().replace(" ", "").equals(valueExchangeSmaCQA.getValueObject())){
					valueExchange_e3value.setValueExchangeSmaCQA(valueExchangeSmaCQA);
					break;
				}
			}
		}
	}
	
	/*
	 * Argumentos de entrada:El contrato identificado
	 * Descripci�n:  Recoge los tokens analizados para ese contrato y genera un string para formar la expresi�n de la herencia del contrato
	 * Argumento de salida: El string /directriz con los contratos de los que hereda
	 */
	public String createInheranceContract(ContractPersonalized contractPersonalized) {
		String tokenHeredity = "";
		for(int i = 0; i < contractPersonalized.getTokensContract().size();i++) {
			if (contractPersonalized.getTokensContract().get(i).equals(contractPersonalized.getTokensContract().get(contractPersonalized.getTokensContract().size()-1))){
				tokenHeredity += contractPersonalized.getTokensContract().get(i).getName();
			}
			else {
				tokenHeredity += tokenHeredity += contractPersonalized.getTokensContract().get(i).getName() + "," ;	
			}
		}	
		return tokenHeredity;
	}
	
	/*
	 * Argumentos de entrada:El contrato identificado
	 * Descripci�n:  Recoge los tokens analizados para ese contrato y genera un string para formar la expresi�n del constructor del contrato
	 * Argumento de salida: El string /directriz con los contratos de los que hereda
	 */
	public String createInheranceConstructors(ContractPersonalized contractPersonalized) {
		String tokenHeredity = "";
		for(int i = 0; i < contractPersonalized.getTokensContract().size();i++) {
			if (contractPersonalized.getTokensContract().get(i).equals(contractPersonalized.getTokensContract().get(contractPersonalized.getTokensContract().size()-1))){
				tokenHeredity += contractPersonalized.getTokensContract().get(i).getName() + "()";
			}
			else {
				tokenHeredity += tokenHeredity += contractPersonalized.getTokensContract().get(i).getName() + "()" ;	
			}
		}	
		return tokenHeredity;
	}
	
	/*
	 * Argumentos de entrada:La lista de intercambios de valor analizados y el modelo de preguntas y el nombre del actor que realiza la acci�n
	 * Descripci�n:  Limpia la lista de funciones analizados del anterior smart contract para poder recoger los nuevos del smart contract actual
	 * Argumento de salida: Un valor booleano que es true si lo ha encontrado
	 */
	public boolean controlInsertPropertyAge(ArrayList<ValueExchangePersonalized> valuesExchangePersonalizeds, String nameActor) {
		nameActor = nameActor.trim().toUpperCase().replace(" ","");//Limpia posibles espacios en blanco y pone su inicial en may�scula
		boolean enc = false;
		for(ValueExchangePersonalized valueExchangePersonalized : valuesExchangePersonalizeds) {
			if(valueExchangePersonalized.isInsertPropertyAge() == true && valueExchangePersonalized.getActorSend().trim().toUpperCase().replace(" ", "").equals(nameActor)) {
				enc = true;
				break;
			}
		}
		return enc;
	}
	
	/*
	 * Argumentos de entrada:La lista de propiedades del smart contract identificadas
	 * Descripci�n:  Analiza si ya existe una propiedad owner en el contrato para no tenerla que a�adir
	 * Argumento de salida: Ninguno
	 */
	public void createPropertyAddressOwner(ArrayList<Property> propertiesIdentified) {
		boolean enc = false;
		Property propertyOwner = new Property();
		propertyOwner.setName("owner");
		propertyOwner.setType(constants.TYPE_ADDRESS);
		propertyOwner.setComment("This attribute has been created to control who owns the contract (deployed it)");
		for(Property propertyIdentified : propertiesIdentified){
			if(propertyIdentified.getName().equals(propertyOwner.getName()) && propertyIdentified.getType().equals(propertyOwner.getType())){
				enc = true;
				break;
			}
		}
		if(enc == false) {
			propertiesIdentified.add(propertyOwner);
		}
	}
	
	/*
	 * Argumentos de entrada:La lista de intercambios de valor analizados y el modelo de preguntas y respuestas acerca de los intercambios de valor
	 * Descripci�n:  Limpia la lista de funciones analizados del anterior smart contract para poder recoger los nuevos del smart contract actual
	 * Argumento de salida: El Token como objeto de valor
	 */
	public TokenValueObject createERCToken(Resource input, IFileSystemAccess2 fsa, IGeneratorContext context,ValueObjectQuestion valueObjectQuestionInput) {
		ERCTokenGenerator generatorERC = new ERCTokenGenerator();
		ValueObjectTokenQuestionImpl valueObjectTokenQuestion = (ValueObjectTokenQuestionImpl) valueObjectQuestionInput;
		generatorERC.doGenerateERC(input,fsa,context,valueObjectTokenQuestion);
		TokenValueObject token = new TokenValueObject();
		token.name = "Token_" + valueObjectTokenQuestion.getAnswer().getName();	
		if(valueObjectTokenQuestion.getAnswer().getAnswerMintSentence().toString().equals(constants.ANSWER_YES)) {
			token.mintable = true;
		}
		else {
			token.mintable = false;
		}
		if(valueObjectTokenQuestion.getAnswer().getAnswerBurnSentence().toString().equals(constants.ANSWER_YES)) {
			token.burnable = true;
		}
		else {
			token.burnable = false;
		}
		return token;
	}
	
	/*
	 * Argumentos de entrada:La lista de intercambios de valor analizados y el modelo de preguntas y respuestas acerca de los intercambios de valor
	 * Descripci�n:  Busca si en la lista de tokens creados ya hay un token con el mismo nombre y s�mbolo
	 * Argumento de salida: Si ese token ya ha sido creado previamente devuelve el valor booleano true
	 */
	public boolean controlCreateERCToken(ValueObjectQuestion valueObjectQuestionInput,ArrayList<TokenValueObject> registerTokens) {
		ValueObjectTokenQuestionImpl valueObjectTokenQuestion = (ValueObjectTokenQuestionImpl) valueObjectQuestionInput;
		TokenValueObject tokenCreacion = new TokenValueObject();
		boolean enc = false;
		tokenCreacion.setName("Token_" + valueObjectTokenQuestion.getAnswer().getName());	
		for(TokenValueObject token : registerTokens){
			if(token.getName().equals(tokenCreacion.getName()) && valueObjectTokenQuestion.getAnswer().getSymbol().equals(tokenCreacion.getSymbol())) {
				enc = true;
				break;
			}
		}		
		return enc;
	}
	
	
	
	/*
	 * Argumentos de entrada:La lista de intercambios de valor analizados y el modelo de preguntas y respuestas acerca de los intercambios de valor
	 * Descripci�n:  Busca si en la lista de tokens creados ya hay un token con el mismo nombre y s�mbolo
	 * Argumento de salida: Si ese token ya ha sido creado previamente devuelve el valor booleano true
	 */
	public StructValueObjectIdentified createStructValueObject(ValueObjectQuestion valueObjectQuestionInput,ValueExchangePersonalized valueExchangePersonalized){
		StructValueObjectIdentified structValueObject = new StructValueObjectIdentified();
		ValueObjectTangibleQuestionImpl valueObjectQuestion = (ValueObjectTangibleQuestionImpl) valueObjectQuestionInput;
		structValueObject.setName(valueExchangePersonalized.getValueObject().getName());
		for(DataRegister dataStruct : valueObjectQuestion.getAnswer()) {
			Property property = new Property();
			property.setName(dataStruct.getName());
			if(dataStruct.getType().getLiteral().equals("TrueOrFalse")) {
				property.setType(constants.TYPE_BOOLEAN);
			}
			else if(dataStruct.getType().getLiteral().equals("Number")) {
				property.setType(constants.TYPE_UINT);
			}
			else {
				property.setType(constants.TYPE_STRING);
			}			
			structValueObject.getProperties().add(property);
		}
		return structValueObject;
	}
	
	public Resource exportXMI(Resource smacqaresource) {
		
		String absuloteTargetFolderPath = smacqaresource.getURI().path().toString().replace("/resource","");
		absuloteTargetFolderPath = absuloteTargetFolderPath.replace(smacqaresource.getURI().lastSegment().toString(), "");	
		System.out.println("AbsuloteTargetFolderPath uri: " + absuloteTargetFolderPath);
		Injector injector =  new SmaCStandaloneSetup().createInjectorAndDoEMFRegistration();
	    XtextResourceSet resourceSet = injector.getInstance(XtextResourceSet.class);
	    String inputURI =  absuloteTargetFolderPath + smacqaresource.getURI().lastSegment();//Sacamos el nombre con extensi�n	
	    int positionDotExtension = smacqaresource.getURI().lastSegment().lastIndexOf('.');
	    String namesmacqaresource = smacqaresource.getURI().lastSegment().substring(0,positionDotExtension);//Sacamos el nombre limpio, es decir, sin extensi�n
	    String outputURI = absuloteTargetFolderPath + EMF_SOURCE_GENERATED_DIRECTORY + "/" + namesmacqaresource +".xmi";
	    System.out.println("Output uri: " + outputURI);
	    URI uri = URI.createURI(inputURI);
	    Resource xtextResource = resourceSet.getResource(uri, true);
	    EcoreUtil.resolveAll(xtextResource);
	    Resource xmiResource = resourceSet.createResource(URI.createURI(outputURI));
	    xmiResource.getContents().add(xtextResource.getContents().get(0));
	    try {
	        xmiResource.save(null);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return xmiResource;
	}
	
}
